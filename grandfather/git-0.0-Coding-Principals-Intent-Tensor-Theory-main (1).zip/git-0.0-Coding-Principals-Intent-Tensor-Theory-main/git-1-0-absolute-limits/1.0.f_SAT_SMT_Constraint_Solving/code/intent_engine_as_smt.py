"""
Encode the ITT Intent Engine as an SMT problem.

This replaces the hand-rolled Kleene iteration from git-0.* with a single
Z3 solver call. Instead of iterating to a fixed point, Z3 solves the
simultaneous constraint system in one step (via CDCL + theory solvers).

The trade-off:
  - Hand-rolled Kleene: predictable iteration cost, may oscillate on
    non-monotone constraints.
  - SMT encoding: potentially exponential but gives globally correct
    answer every time it returns `sat`/`unsat`.
"""

from z3 import Solver, Optimize, Bool, Int, And, Or, Not, Implies, sat, unsat


def encode_email_example():
    """
    Original engine from git-0.* /Non-Linear-Example docs:

      derivation:  eligible := email ∧ optedIn
      constraint (priority 10):   eligible ∧ ¬sent → sent = True
      constraint (priority 100):  blocked → ¬sent

    Encode as a weighted SMT-Optimize problem.
    """
    opt = Optimize()

    # State variables
    email_present = Bool('email_present')
    opted_in      = Bool('opted_in')
    eligible      = Bool('eligible')
    sent          = Bool('sent')
    blocked       = Bool('blocked')

    # Derivation as biconditional (hard constraint)
    opt.add(eligible == And(email_present, opted_in))

    # Priority-10 constraint: eligible ∧ ¬blocked → sent
    # Encode as soft constraint with weight 10
    opt.add_soft(Implies(eligible, sent), weight=10)

    # Priority-100 constraint: blocked → ¬sent
    # Encode as soft constraint with weight 100
    opt.add_soft(Implies(blocked, Not(sent)), weight=100)

    # Input: email given, opted_in true, blocked true
    opt.add(email_present == True)
    opt.add(opted_in == True)
    opt.add(blocked == True)

    result = opt.check()
    print(f"Result: {result}")
    if result == sat:
        m = opt.model()
        print(f"  eligible = {m[eligible]}")
        print(f"  sent     = {m[sent]}  ← priority-100 wins")
        print(f"  blocked  = {m[blocked]}")


def encode_multi_variable_system():
    """
    A more complex encoding: 3 tasks with resource constraints and priorities.

    Tasks: launch_campaign, send_newsletter, run_ab_test.
    Each costs some resources; total budget is bounded.
    Each has a priority.
    """
    opt = Optimize()

    launch  = Bool('launch_campaign')
    news    = Bool('send_newsletter')
    abtest  = Bool('run_ab_test')

    # Resource costs (encoded as a budget constraint)
    cost = Int('cost')
    opt.add(cost == 100 * If_int(launch) + 50 * If_int(news) + 30 * If_int(abtest))
    opt.add(cost <= 120)  # budget constraint

    # Priorities (soft constraints)
    opt.add_soft(launch, weight=100)  # highest priority
    opt.add_soft(news,   weight=50)
    opt.add_soft(abtest, weight=30)

    result = opt.check()
    print(f"Multi-task result: {result}")
    if result == sat:
        m = opt.model()
        print(f"  launch  = {m[launch]}")
        print(f"  news    = {m[news]}")
        print(f"  abtest  = {m[abtest]}")
        print(f"  cost    = {m[cost]}")


def If_int(bool_expr):
    """Helper: convert Bool to 0/1 Int."""
    from z3 import If
    return If(bool_expr, 1, 0)


if __name__ == "__main__":
    encode_email_example()
    print("---")
    encode_multi_variable_system()
