# 1.0.a — Overview and Front Matter

## Contents

- `00_abstract.md` — One-paragraph statement of the chapter.
- `01_notation_conventions.md` — Mathematical and code notation used throughout.
- `02_reading_order.md` — Suggested paths for different backgrounds.
- `03_itt_bridge.md` — How the objects in this chapter connect to ITT primitives.

## Purpose

This folder is the entry point. If you read nothing else in Chapter 1, read `00_abstract.md` and `03_itt_bridge.md`.
