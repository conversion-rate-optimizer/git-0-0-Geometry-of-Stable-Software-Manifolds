-- Lean 4 examples: propositions as types, proofs as programs.

-- 1. Basic proposition: A ∧ B → B ∧ A
theorem and_swap (A B : Prop) : A ∧ B → B ∧ A := by
  intro h
  exact ⟨h.right, h.left⟩

-- The term version (no tactics):
def and_swap' : ∀ (A B : Prop), A ∧ B → B ∧ A :=
  fun _ _ h => ⟨h.2, h.1⟩

-- 2. Natural number addition is commutative
theorem add_comm' : ∀ (n m : Nat), n + m = m + n := by
  intro n m
  induction n with
  | zero => simp
  | succ k ih => simp [Nat.succ_add, Nat.add_succ, ih]

-- 3. A length-indexed vector type
inductive Vec (α : Type) : Nat → Type where
  | nil  : Vec α 0
  | cons : α → Vec α n → Vec α (n + 1)

-- Length-preserving map
def Vec.map {α β : Type} (f : α → β) : Vec α n → Vec β n
  | .nil       => .nil
  | .cons x xs => .cons (f x) (xs.map f)

-- The type `Vec α n → Vec β n` guarantees length preservation statically.
-- You cannot write a wrong `map` that drops elements — it won't type-check.

-- 4. A safe `head` function: cannot be called on the empty vector
def Vec.head : Vec α (n + 1) → α
  | .cons x _ => x

-- Vec.head nil  -- does not type-check: nil : Vec α 0, not Vec α (n+1).

-- 5. Dependent sum: a vector bundled with its length
def packedVec (α : Type) : Type := (n : Nat) × Vec α n

-- 6. Using `grind` tactic (Lean 4's SMT-style automation)
example (x y : Int) (h1 : x > 0) (h2 : y > 0) : x + y > 0 := by grind

-- 7. A small proof about list reversal
theorem reverse_involutive {α : Type} (l : List α) : l.reverse.reverse = l := by
  induction l with
  | nil        => rfl
  | cons x xs ih => simp [List.reverse_cons, ih]
