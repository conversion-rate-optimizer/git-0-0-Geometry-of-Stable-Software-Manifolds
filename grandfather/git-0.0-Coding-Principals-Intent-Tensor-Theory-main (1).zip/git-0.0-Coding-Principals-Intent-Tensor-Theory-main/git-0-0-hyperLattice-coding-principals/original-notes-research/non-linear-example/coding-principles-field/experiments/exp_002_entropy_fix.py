#!/usr/bin/env python3
"""
exp_002_entropy_fix.py

Compares approximate bloom denominator (std(phi)) vs a fuller free-mode entropy term:
S_free = eta1 * Var(phi) - eta2 * sum(p_i * ln p_i)
"""

from __future__ import annotations

import json
import math
from pathlib import Path

from exp_001_min_field import (
    NODES,
    VECTORS,
    SEEDS,
    LAMBDA,
    COS_THRESHOLD,
    COS_POWER,
    ETA,
    MU,
    NU,
    DT,
    ITERATIONS,
    EPS,
    build_weight_matrix,
    diffuse,
    graph_laplacian,
    allen_cahn,
)

ETA1 = 1.0
ETA2 = 0.25


def variance(values: list[float]) -> float:
    m = sum(values) / len(values)
    return sum((x - m) ** 2 for x in values) / len(values)


def entropy_term(phi: list[float]) -> float:
    shifted = [max(0.0, x + 1.0) for x in phi]
    total = sum(shifted) + EPS
    probs = [x / total for x in shifted]
    return -sum(p * math.log(p + EPS) for p in probs)


def s_free(phi: list[float]) -> float:
    return ETA1 * variance(phi) - ETA2 * entropy_term(phi)


def q_with_sfree(lap: list[float], phi: list[float], theta: float = 1.0) -> float:
    numerator = sum(abs(x) for x in lap)
    denominator = theta * abs(s_free(phi)) + EPS
    return numerator / denominator


def run() -> dict:
    W = build_weight_matrix(VECTORS)
    phi = [0.0] * len(NODES)

    q_std_curve = []
    q_sfree_curve = []
    s_free_curve = []

    for _ in range(ITERATIONS):
        phi = diffuse(phi, W, SEEDS)
        lap = graph_laplacian(phi, W)
        phi = allen_cahn(phi, lap)

        q_std = sum(abs(x) for x in lap) / (math.sqrt(variance(phi)) + EPS)
        q_free = q_with_sfree(lap, phi)

        q_std_curve.append(q_std)
        q_sfree_curve.append(q_free)
        s_free_curve.append(s_free(phi))

    bloom_std = next((i for i, q in enumerate(q_std_curve) if q > 1.0), None)
    bloom_sfree = next((i for i, q in enumerate(q_sfree_curve) if q > 1.0), None)

    return {
        "nodes": NODES,
        "parameters": {
            "lambda": LAMBDA,
            "cos_threshold": COS_THRESHOLD,
            "cos_power": COS_POWER,
            "eta": ETA,
            "mu": MU,
            "nu": NU,
            "dt": DT,
            "iterations": ITERATIONS,
            "eta1": ETA1,
            "eta2": ETA2,
        },
        "q_std_curve": q_std_curve,
        "q_sfree_curve": q_sfree_curve,
        "s_free_curve": s_free_curve,
        "bloom_std_iteration": bloom_std,
        "bloom_sfree_iteration": bloom_sfree,
    }


if __name__ == "__main__":
    result = run()
    root = Path(__file__).resolve().parents[1]
    logs_dir = root / "logs"
    logs_dir.mkdir(parents=True, exist_ok=True)

    with (logs_dir / "exp_002_summary.json").open("w", encoding="utf-8") as f:
        json.dump(result, f, indent=2)

    print("exp_002_entropy_fix complete")
    print(
        f"bloom_std_iteration={result['bloom_std_iteration']} "
        f"bloom_sfree_iteration={result['bloom_sfree_iteration']}"
    )
