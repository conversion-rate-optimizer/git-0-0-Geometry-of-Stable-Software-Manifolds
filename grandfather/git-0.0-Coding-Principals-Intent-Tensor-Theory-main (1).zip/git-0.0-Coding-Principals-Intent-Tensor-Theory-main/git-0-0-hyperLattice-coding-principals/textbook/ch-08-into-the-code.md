# Chapter 08 — Into the Code

*Read time: 10 minutes*

---

## Reading the Files

At this point you have the concepts. Now read the 
actual files. This chapter walks through each one 
and connects it to what you learned.

The files live in `git-0-0-hyperLattice-coding-principals/`.

---

## Start Here: `-Z_BASE/axioms.ts`

This file is the ground state. It defines every constant 
in the system. Nothing in the codebase is allowed to 
define its own thresholds — they all come from here.

```typescript
export const CTS = {
  eta: 0.08,    // diffusion rate — Chapter 03
  mu:  1.20,    // cubic growth
  nu:  0.35,    // linear decay
  epsilon: 0.01, // first-crossing threshold
  dt:  0.02,    // time step size

  get phi_star(): number {
    return Math.sqrt(this.nu / this.mu); // ≈ 0.540
  },
}
```

`phi_star` is the energy barrier (not a stable attractor — 
see the comment in the file, corrected after testing). 
The formula `√(ν/μ)` is the equilibrium of the 
nonlinear term μΦ³ − νΦ when set to zero.

```typescript
export const SELECTION = {
  persistence: 1.0,  // S ≥ 1 to exist — Chapter 05
  bloom: 1.1,        // Q > 1.1 to bloom — Chapter 07
  cycle_persistence: 1.0,  // S_C ≥ 1 — Chapter 06
  anchor: 1.2,       // S_C ≥ 1.2 — Chapter 06
}
```

Every threshold in the system comes from here. If you 
want to change how strict or lenient the gates are, 
this is where you change them.

---

## The Field Solver: `0.0_SUBSTRATE/allen_cahn_engine.ts`

```typescript
export function stepNode(
  nodeId: string,
  phi: Map<string, number>,
  weights: Map<string, Map<string, number>>,
  seed: Map<string, number>,
  lambda: number = LATTICE.lambda  // 0.63
): number {
  const phi_i = phi.get(nodeId) ?? 0;
  const s_i = seed.get(nodeId) ?? 0;

  const laplacian = graphLaplacian(nodeId, phi, weights);
  const phase = allenCahnPhase(phi_i);
  const forcing = lambda * (s_i - phi_i);

  const dphi = CTS.eta * laplacian + phase + forcing;
  return Math.max(0, phi_i + CTS.dt * dphi);
}
```

Three terms added together on every step:

1. `CTS.eta * laplacian` — diffusion from Chapter 03. 
   Spreads the field through connections.

2. `phase` — the nonlinear term μΦ³ − νΦ. 
   Provides the energy barrier behavior.

3. `forcing` — `lambda * (seed - phi)`. 
   This is the seed pressure. Without this term, 
   the field decays to zero (tested and confirmed). 
   The seed is what keeps modules alive.

The `Math.max(0, ...)` prevents negative field values — 
Φ is always non-negative in this system.

---

## The Weight Matrix: `0.1_LATTICE/weight_matrix.ts`

```typescript
export function computeCoupling(
  a: IntentVector,
  b: IntentVector,
  threshold: number = LATTICE.resonance_threshold,  // 0.16
  exponent: number = LATTICE.coupling_exponent       // 1.35
): number {
  const cos = cosineSimilarity(a, b);
  if (cos <= threshold) return 0;
  return Math.pow(cos, exponent);
}
```

Two modules couple based on how similar their intent 
vectors are (cosine similarity). Below 0.16: no 
connection. Above 0.16: connection strength = cosine^1.35.

The exponent 1.35 sharpens the curve — modules that 
are very similar get a stronger coupling than plain 
cosine similarity would give. Modules that are just 
barely above threshold get a weaker coupling than 
plain cosine would give.

This prevents a fully connected, uniformly weighted 
graph (which gives meaningless diffusion) without 
requiring a hard cutoff that throws away borderline connections.

---

## The Bloom Engine: `+Z_APEX/bloom_engine.ts`

```typescript
export function computeQ(
  nodeIds: string[],
  phi: Map<string, number>,
  W: Map<string, Map<string, number>>
): BloomMetrics {
  const A_tot = laplacianAction(nodeIds, phi, W);
  const variance = fieldVariance(nodeIds, phi);
  const entropy = fieldEntropy(nodeIds, phi);
  const S_free = BLOOM.eta_1 * variance + BLOOM.eta_2 * entropy;
  const Q = A_tot / (BLOOM.theta * S_free + LATTICE.epsilon_field);

  return {
    Q,
    A_tot,
    variance,
    entropy,
    S_free,
    isBloom: Q > SELECTION.bloom,
  };
}
```

This is Chapter 07 in code. Every variable has a chapter 
behind it. `A_tot` is the graph Laplacian action — 
how much structure is being enforced. `S_free` is 
the combined disorder. Q is the ratio.

The `+ LATTICE.epsilon_field` in the denominator 
prevents division by zero when the field is completely 
uniform (S_free = 0). Epsilon_field = 1e-12.

---

## Cycle Persistence: `0.2_CYCLES/cycle_persistence.ts`

```typescript
export function cyclePersistence(
  cycle: string[],
  phi: Map<string, number>,
  phi_prev: Map<string, number>
): number {
  let phi_sum = 0;
  let delta_sum = LATTICE.epsilon_field;

  for (const nodeId of cycle) {
    const p = phi.get(nodeId) ?? 0;
    const p_prev = phi_prev.get(nodeId) ?? 0;
    phi_sum += p;
    delta_sum += Math.abs(p - p_prev);
  }

  return Math.min(phi_sum / delta_sum, 1000);
}
```

Chapter 06 in code. Sum the field values around the loop, 
divide by the sum of changes around the loop. The 
`Math.min(..., 1000)` cap is from the test results — 
prevents overflow at convergence, preserves the 
meaningful measurement window during the transient.

---

## The Reading Order in Practice

When you sit down with a real codebase and want to 
apply this system:

1. **Start in `-Z_BASE/axioms.ts`** — understand the constants
2. **Build the weight matrix** from module intent vectors
3. **Seed the field** — set φ = s for your starting modules
4. **Run `settleField()`** for 30 iterations
5. **At steps 2-5**, sample S and S_C for gate decisions
6. **At step 30**, read the final φ values for activation
7. **Compute Q** during the transient for bloom detection

The output: a set of modules with φ values, S values, 
and a set of persistent cycles. These are the field's 
answer to your intent.

---

## Summary

- `-Z_BASE/axioms.ts` — all constants, all thresholds
- `0.0_SUBSTRATE/allen_cahn_engine.ts` — the field step: diffusion + phase + seed
- `0.1_LATTICE/weight_matrix.ts` — coupling strength with threshold
- `+Z_APEX/bloom_engine.ts` — Q with entropy, bloom detection
- `0.2_CYCLES/cycle_persistence.ts` — S_C with cap
- Sample S and S_C at steps 2-5, read φ at step 30

---

**Previous:** [Chapter 07 — The Bloom](./ch-07-the-bloom.md)  
**Next:** [Chapter 09 — What's Next](./ch-09-whats-next.md)
