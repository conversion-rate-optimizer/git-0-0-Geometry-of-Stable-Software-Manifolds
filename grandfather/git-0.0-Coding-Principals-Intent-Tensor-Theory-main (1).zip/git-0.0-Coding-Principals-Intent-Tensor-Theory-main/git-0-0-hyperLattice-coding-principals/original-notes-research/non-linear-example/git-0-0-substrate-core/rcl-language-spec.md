# Ghostless Language Spec v1.0

## 1) Naming law
All structural directories MUST follow:

`git-<x>-<y>-<semantic-slug>`

- `x`,`y` are immutable lattice coordinates.
- Slug is descriptive, but never used as primary address key.

## 2) Resolver law
Primary address resolution is coordinate-first:

`resolve(x, y) -> git-x-y-<slug>`

No traversal or fuzzy search is allowed for canonical lookup.

## 3) Verb law (no vague verbs)
Disallowed verbs in manifest actions:
- `handle`
- `process`
- `manage`
- `do`

Required action verbs are operationally explicit, e.g.:
- `seed_field`
- `diffuse_state`
- `compute_laplacian`
- `gate_persistence`
- `emit_bloom_report`
- `route_runtime`

## 4) Semantic separation
Coordinates define position.
Manifest defines meaning.
Meaning must not be encoded as the coordinate key.

## 5) Invariance
Renaming the slug MUST NOT change coordinate identity.
