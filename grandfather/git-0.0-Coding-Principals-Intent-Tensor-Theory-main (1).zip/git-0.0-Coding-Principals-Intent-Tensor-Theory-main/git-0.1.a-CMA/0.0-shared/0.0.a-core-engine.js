/**
 * 0.0.a-core-engine.js
 * RCL (Repo Coordinate Language) Core Resolver
 * -----------------------------------------------
 * GitCMA — Git Coordinate Manifold Architecture
 * Intent Tensor Theory Coding Standards
 *
 * Logic: (x, y, z) → Filepath
 * Domain (x) | Function (y) | Sub-Op (z)
 *
 * Created by Armstrong Knight — intent-tensor-theory.com
 * CC BY-NC 4.0
 */

const RCL_ENGINE = {

  // ─── 1. THE DOMAIN MAP (x-axis) ──────────────────────────────────────────
  DOMAINS: {
    0: 'shared',
    1: 'project',
    2: 'map',
    3: 'works',
    4: 'space'
  },

  // ─── 2. THE FUNCTION MAP (y-axis) ────────────────────────────────────────
  FUNCTIONS: {
    1:  'dashboard',
    2:  'social',
    3:  'services',
    4:  'customers',
    5:  'partners',
    6:  'invoices',
    7:  'calendar',
    8:  'inquiry',
    9:  'direct',
    10: 'email',
    11: 'call'
  },

  // ─── 3. THE RESOLVER (Metric Space Transformer) ──────────────────────────
  // Input format: "4.2.a"  →  Output: "/4.0-space/4.2-space-social/4.2.a-live"
  resolve: function (coordinate) {
    const parts = coordinate.split('.');
    const x = parts[0];
    const y = parts[1];
    const z = parts[2] || null;

    const domain   = this.DOMAINS[x];
    const func     = this.FUNCTIONS[y];
    const subLabel = this._subOpLabel(x, y, z);
    const sub      = z ? `/${x}.${y}.${z}${subLabel ? '-' + subLabel : ''}` : '';

    return `/${x}.0-${domain}/${x}.${y}-${domain}-${func}${sub}`;
  },

  // Internal: optional sub-op label lookup
  _subOpLabel: function (x, y, z) {
    if (!z) return null;
    const SUB_OPS = { a: 'live', b: 'threads', c: 'blogs', d: 'short-posts', e: 'albums', f: 'video', g: 'audio' };
    return SUB_OPS[z] || null;
  },

  // ─── 4. THE CURVENT (Social Rail Traversal) ──────────────────────────────
  // Moves across all domains (x) while holding function (y) constant
  getSocialRail: function () {
    const rail = [];
    for (let x = 1; x <= 4; x++) {
      rail.push({ coord: `${x}.2`, path: this.resolve(`${x}.2`) });
    }
    return rail;
  },

  getRail: function (y) {
    const rail = [];
    for (let x = 1; x <= 4; x++) {
      rail.push({ coord: `${x}.${y}`, path: this.resolve(`${x}.${y}`) });
    }
    return rail;
  },

  // ─── 5. MANHATTAN DISTANCE (Metric Space Logic) ──────────────────────────
  // Measures "Business Distance" between two coordinates
  getDistance: function (coordA, coordB) {
    const [x1, y1] = coordA.split('.').map(Number);
    const [x2, y2] = coordB.split('.').map(Number);
    return Math.abs(x1 - x2) + Math.abs(y1 - y2);
  },

  // ─── 6. FIELD SELECTION (Achilles / Writable Filter) ─────────────────────
  // Returns only coordinates where the selection function S(r) = 1
  selectWritables: function (data, isWritable) {
    return data.filter(isWritable);
  },

  // ─── 7. W-AXIS CALCULATOR ─────────────────────────────────────────────────
  // W(φ, θ) = sin(2φ)cos(2θ)
  // Returns "IGNITED" if resonance peak is reached (EigenSpark trigger)
  calculateWAxis: function (phi, theta, threshold = 0.8) {
    const resonance = Math.sin(2 * phi) * Math.cos(2 * theta);
    return resonance > threshold ? 'IGNITED' : 'DORMANT';
  },

  // ─── 8. EIGENSPARK DETECTOR ───────────────────────────────────────────────
  // Ξ = lim[Δ→0] (Φ(w) - Φ(v)) / Δ
  // Detects emergence from delta between positive intent (w) and inverse field (v)
  detectEigenSpark: function (wPotential, vPotential, stepSize = 0.001, stabilityThreshold = 1.0) {
    const delta = wPotential - vPotential;
    const xi = delta / stepSize;
    return xi > stabilityThreshold ? 'IGNITED' : 'STAGNANT';
  }

};

// ─── BARE METAL TEST ────────────────────────────────────────────────────────
if (require.main === module) {
  console.log('─── RCL RESOLUTION TEST ───');
  console.log('Resolve 4.2.a  :', RCL_ENGINE.resolve('4.2.a'));
  console.log('Resolve 1.11   :', RCL_ENGINE.resolve('1.11'));

  console.log('\n─── SOCIAL RAIL TRAVERSAL ───');
  RCL_ENGINE.getSocialRail().forEach(n => console.log(n.coord, '→', n.path));

  console.log('\n─── ARCHITECTURAL DISTANCE ───');
  console.log('Distance 1.1 → 4.2 :', RCL_ENGINE.getDistance('1.1', '4.2'), 'units');

  console.log('\n─── W-AXIS TEST ───');
  console.log('W(0.9, 0.3)  :', RCL_ENGINE.calculateWAxis(0.9, 0.3));
  console.log('W(0.1, 0.1)  :', RCL_ENGINE.calculateWAxis(0.1, 0.1));

  console.log('\n─── EIGENSPARK TEST ───');
  console.log('Ξ(1.5, 0.3)  :', RCL_ENGINE.detectEigenSpark(1.5, 0.3));
}

module.exports = RCL_ENGINE;
