#!/usr/bin/env python3
"""
exp_001_min_field.py

Minimum viable emergence test for a 5-node field.
Tracks:
- phi(t)
- S_sel(t)
- Q(t)

Success criterion:
- Q crosses 1.0 at least once (bloom)
"""

from __future__ import annotations

import json
import math
from pathlib import Path

NODES = ["diffusion", "entropy", "persistence", "bloom", "gradient"]

# Hand-built vectors so the experiment is deterministic and dependency-free.
VECTORS = [
    [0.95, 0.10, 0.05],  # diffusion
    [0.20, 0.90, 0.10],  # entropy
    [0.85, 0.25, 0.20],  # persistence
    [0.90, 0.20, 0.35],  # bloom
    [0.92, 0.12, 0.40],  # gradient
]

SEEDS = [0.9, 0.2, 0.8, 1.0, 0.7]
LAMBDA = 0.63
COS_THRESHOLD = 0.16
COS_POWER = 1.35
ETA = 0.08
MU = 1.2
NU = 0.35
DT = 0.02
ITERATIONS = 30
EPS = 1e-12


def dot(a: list[float], b: list[float]) -> float:
    return sum(x * y for x, y in zip(a, b))


def norm(a: list[float]) -> float:
    return math.sqrt(dot(a, a)) + EPS


def cosine(a: list[float], b: list[float]) -> float:
    return dot(a, b) / (norm(a) * norm(b))


def build_weight_matrix(vectors: list[list[float]]) -> list[list[float]]:
    n = len(vectors)
    W = [[0.0 for _ in range(n)] for _ in range(n)]
    for i in range(n):
        for j in range(n):
            if i == j:
                continue
            c = cosine(vectors[i], vectors[j])
            W[i][j] = c**COS_POWER if c > COS_THRESHOLD else 0.0
    return W


def diffuse(phi: list[float], W: list[list[float]], seeds: list[float]) -> list[float]:
    out = [0.0] * len(phi)
    for i in range(len(phi)):
        row_sum = sum(W[i])
        avg = 0.0 if row_sum <= EPS else sum(W[i][j] * phi[j] for j in range(len(phi))) / row_sum
        out[i] = LAMBDA * seeds[i] + (1.0 - LAMBDA) * avg
    return out


def graph_laplacian(phi: list[float], W: list[list[float]]) -> list[float]:
    lap = [0.0] * len(phi)
    for i in range(len(phi)):
        lap[i] = sum(W[i][j] * (phi[j] - phi[i]) for j in range(len(phi)))
    return lap


def allen_cahn(phi: list[float], lap: list[float]) -> list[float]:
    out = [0.0] * len(phi)
    for i in range(len(phi)):
        value = phi[i] + DT * (ETA * lap[i] + MU * (phi[i] ** 3) - NU * phi[i])
        out[i] = max(-1.0, min(1.0, value))
    return out


def std(values: list[float]) -> float:
    m = sum(values) / len(values)
    var = sum((x - m) ** 2 for x in values) / len(values)
    return math.sqrt(var)


def selection_numbers(phi: list[float], prev: list[float]) -> list[float]:
    out = []
    for x, p in zip(phi, prev):
        delta = abs(x - p) + EPS
        out.append(x / delta)
    return out


def bloom_q(lap: list[float], phi: list[float], theta: float = 1.0) -> float:
    numerator = sum(abs(x) for x in lap)
    denominator = theta * std(phi) + EPS
    return numerator / denominator


def run() -> dict:
    W = build_weight_matrix(VECTORS)
    phi = [0.0] * len(NODES)

    q_curve: list[float] = []
    s_sel_mean_curve: list[float] = []
    phi_curve: list[list[float]] = []

    for _ in range(ITERATIONS):
        prev = phi[:]
        phi = diffuse(phi, W, SEEDS)
        lap = graph_laplacian(phi, W)
        phi = allen_cahn(phi, lap)

        s_sel = selection_numbers(phi, prev)
        q = bloom_q(lap, phi)

        q_curve.append(q)
        s_sel_mean_curve.append(sum(s_sel) / len(s_sel))
        phi_curve.append(phi[:])

    bloom_iteration = next((i for i, q in enumerate(q_curve) if q > 1.0), None)

    return {
        "nodes": NODES,
        "parameters": {
            "lambda": LAMBDA,
            "cos_threshold": COS_THRESHOLD,
            "cos_power": COS_POWER,
            "eta": ETA,
            "mu": MU,
            "nu": NU,
            "dt": DT,
            "iterations": ITERATIONS,
        },
        "q_curve": q_curve,
        "s_sel_mean_curve": s_sel_mean_curve,
        "phi_curve": phi_curve,
        "bloom_iteration": bloom_iteration,
        "bloom_crossed": bloom_iteration is not None,
    }


if __name__ == "__main__":
    result = run()
    root = Path(__file__).resolve().parents[1]
    logs_dir = root / "logs"
    logs_dir.mkdir(parents=True, exist_ok=True)

    with (logs_dir / "Q_curves.json").open("w", encoding="utf-8") as f:
        json.dump({"exp_001_min_field": result["q_curve"]}, f, indent=2)

    with (logs_dir / "S_sel_curves.json").open("w", encoding="utf-8") as f:
        json.dump({"exp_001_min_field": result["s_sel_mean_curve"]}, f, indent=2)

    with (logs_dir / "exp_001_summary.json").open("w", encoding="utf-8") as f:
        json.dump(result, f, indent=2)

    print("exp_001_min_field complete")
    print(f"bloom_crossed={result['bloom_crossed']} bloom_iteration={result['bloom_iteration']}")
