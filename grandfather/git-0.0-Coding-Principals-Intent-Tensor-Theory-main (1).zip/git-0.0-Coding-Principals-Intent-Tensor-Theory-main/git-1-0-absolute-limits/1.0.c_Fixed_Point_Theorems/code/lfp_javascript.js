/**
 * JavaScript implementations of fixed-point iteration.
 *
 * Matches the style of the ITT Intent Engine from the parent repo's documents.
 * Includes Kleene iteration, bounded version, and a contractive variant.
 */

/**
 * Kleene iteration: iterate f from `start` until a fixed point is reached.
 * Uses structural equality via JSON for state objects.
 *
 * @param {Function} f        - Function of type S -> S.
 * @param {*} start           - Starting state.
 * @param {number} [maxIter]  - Maximum iterations before bailing out.
 * @returns {*}               - The fixed point.
 * @throws {Error}            - If no fixed point found within maxIter.
 */
function lfpKleene(f, start, maxIter = 10000) {
  let x = start;
  for (let i = 0; i < maxIter; i++) {
    const xNext = f(x);
    if (deepEqual(x, xNext)) return x;
    x = xNext;
  }
  throw new Error(
    `lfpKleene: no fixed point after ${maxIter} iterations — ` +
    `operator may not be monotone.`
  );
}

/**
 * Kleene iteration with a custom equality function.
 * Useful when deep JSON equality isn't the right semantics.
 */
function lfpKleeneEq(f, start, equals, maxIter = 10000) {
  let x = start;
  for (let i = 0; i < maxIter; i++) {
    const xNext = f(x);
    if (equals(x, xNext)) return x;
    x = xNext;
  }
  throw new Error(`lfpKleeneEq: no fixed point after ${maxIter} iterations.`);
}

/**
 * Banach iteration on a metric space.
 * Expects a function `d(x, y)` that computes distance, and a tolerance `tol`.
 */
function banachIterate(f, x0, d, tol = 1e-10, maxIter = 1000) {
  let x = x0;
  for (let i = 0; i < maxIter; i++) {
    const xNext = f(x);
    if (d(x, xNext) < tol) return xNext;
    x = xNext;
  }
  throw new Error(`banachIterate: did not converge in ${maxIter} steps.`);
}

/**
 * Emit the Kleene chain as a generator.
 * Useful for debugging — see what F does at each step.
 */
function* kleeneChain(f, start) {
  let x = start;
  while (true) {
    yield x;
    x = f(x);
  }
}

/** Utility: structural equality via JSON. */
function deepEqual(a, b) {
  return JSON.stringify(a) === JSON.stringify(b);
}

// --- Demonstrations ---

if (require.main === module) {
  // Kleene: transitive closure
  const edges = new Set([[1, 2], [2, 3], [3, 4]].map(e => JSON.stringify(e)));
  const closure = lfpKleene(
    r => {
      const rArr = [...r].map(JSON.parse);
      const out = new Set(r);
      for (const [a, b] of rArr)
        for (const [c, d] of rArr)
          if (b === c) out.add(JSON.stringify([a, d]));
      return out;
    },
    edges,
    100
  );
  console.log("Transitive closure:", [...closure].map(JSON.parse));

  // Banach: x = cos(x) has unique fixed point ≈ 0.739085
  const cosFP = banachIterate(
    Math.cos, 0.5, (a, b) => Math.abs(a - b)
  );
  console.log(`Banach (x = cos x): ${cosFP.toFixed(10)}`);
}

module.exports = { lfpKleene, lfpKleeneEq, banachIterate, kleeneChain, deepEqual };
