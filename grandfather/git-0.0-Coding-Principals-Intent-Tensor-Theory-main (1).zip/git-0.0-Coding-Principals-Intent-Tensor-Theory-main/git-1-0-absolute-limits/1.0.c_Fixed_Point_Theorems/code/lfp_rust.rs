//! Fixed-point iteration in Rust, with explicit error handling.
//!
//! Separate variants for Kleene (discrete lattice) and Banach (metric).

use std::fmt::Debug;

/// Kleene iteration: iterate `f` from `start` until a fixed point is reached.
/// Returns `Err` if `max_iter` is exceeded.
pub fn lfp_kleene<A, F>(f: F, start: A, max_iter: usize) -> Result<A, A>
where
    A: PartialEq + Clone,
    F: Fn(&A) -> A,
{
    let mut x = start;
    for _ in 0..max_iter {
        let x_next = f(&x);
        if x == x_next {
            return Ok(x);
        }
        x = x_next;
    }
    Err(x)
}

/// Banach iteration on a metric space.
pub fn banach_iterate<F>(
    f: F,
    x0: f64,
    tol: f64,
    max_iter: usize,
) -> Result<f64, f64>
where
    F: Fn(f64) -> f64,
{
    let mut x = x0;
    for _ in 0..max_iter {
        let x_next = f(x);
        if (x_next - x).abs() < tol {
            return Ok(x_next);
        }
        x = x_next;
    }
    Err(x)
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::collections::BTreeSet;

    #[test]
    fn transitive_closure_kleene() {
        let edges: BTreeSet<(i32, i32)> = [(1, 2), (2, 3), (3, 4)].iter().cloned().collect();
        let closed = lfp_kleene(|r: &BTreeSet<(i32, i32)>| {
            let mut out = r.clone();
            for &(a, b) in r {
                for &(c, d) in r {
                    if b == c { out.insert((a, d)); }
                }
            }
            out
        }, edges, 100);
        assert!(closed.unwrap().contains(&(1, 4)));
    }

    #[test]
    fn cos_fixed_point() {
        let x = banach_iterate(|x| x.cos(), 0.5, 1e-10, 1000).unwrap();
        assert!((x - 0.7390851332).abs() < 1e-6);
    }
}
