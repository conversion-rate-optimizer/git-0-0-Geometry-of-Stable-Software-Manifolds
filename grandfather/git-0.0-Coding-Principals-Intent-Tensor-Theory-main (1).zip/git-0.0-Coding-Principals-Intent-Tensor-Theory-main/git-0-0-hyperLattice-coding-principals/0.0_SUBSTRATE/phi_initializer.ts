/**
 * 0.0_SUBSTRATE: Phi Initializer
 * ================================
 * Seeds the field from S₀ ground state (Φ=0).
 * Every field run starts here before allen_cahn_engine takes over.
 */

import { CTS } from "../-Z_BASE/axioms";

export type SeedStrategy = "POINT" | "UNIFORM" | "NOISE" | "CUSTOM";

/**
 * Initialize field at ground state with optional seed injection.
 *
 * POINT:   one node seeded at value, rest at 0
 * UNIFORM: all nodes seeded equally
 * NOISE:   small random perturbations above epsilon
 * CUSTOM:  caller provides explicit seed map
 */
export function initializeField(
  nodeIds: string[],
  strategy: SeedStrategy = "POINT",
  seedNodeId?: string,
  seedValue: number = 1.0,
  customSeed?: Map<string, number>
): Map<string, number> {
  const phi = new Map<string, number>();

  switch (strategy) {
    case "POINT":
      for (const id of nodeIds) {
        phi.set(id, id === seedNodeId ? seedValue : 0);
      }
      break;

    case "UNIFORM":
      for (const id of nodeIds) {
        phi.set(id, seedValue / nodeIds.length);
      }
      break;

    case "NOISE":
      for (const id of nodeIds) {
        // Small perturbation above epsilon — enough to seed Allen-Cahn
        phi.set(id, CTS.epsilon * (1 + Math.random()));
      }
      break;

    case "CUSTOM":
      for (const id of nodeIds) {
        phi.set(id, customSeed?.get(id) ?? 0);
      }
      break;
  }

  return phi;
}

/**
 * Validate that a seed map is above epsilon for at least one node.
 * A flat zero field never evolves — Allen-Cahn needs perturbation.
 */
export function validateSeed(seed: Map<string, number>): boolean {
  for (const val of seed.values()) {
    if (val > CTS.epsilon) return true;
  }
  return false;
}
