/**
 * THE JAILBREAK — Before and After
 * =================================
 * This file demonstrates the full transition from 2D to field-dynamic.
 */

import Resonance from "@core";

// ─── REGISTER (done once at module init, anywhere in the codebase) ────────────

// Any module registers itself with an intent key and S value
// Location on disk is irrelevant after this point

Resonance.register("MATH_VECTOR_ALPHA", {
  calculateTotal: (nums: number[]) => nums.reduce((a, b) => a + b, 0),
  normalize: (v: number[]) => {
    const mag = Math.sqrt(v.reduce((s, x) => s + x * x, 0));
    return v.map(x => x / mag);
  }
}, 1.5, "+Y_FORWARD");

Resonance.register("AUTH_VALIDATOR", {
  validate: (token: string) => token.length > 0,
  hash: (input: string) => input.split("").reverse().join(""),
}, 1.2, "-Z_BASE");

Resonance.register("FIELD_ENGINE", {
  settle: () => "φ* reached",
  Q: 1.15,
}, 1.8, "0.0_SUBSTRATE");


// ─── CONSUME (the jailbreak in action) ───────────────────────────────────────

console.log("\n=== 2D PRISON (before) ===");
console.log('import { calculateTotal } from "../../utils/math"  // breaks if file moves');
console.log('import { validate } from "../../../services/auth"  // archaeology required');

console.log("\n=== ITT JAILBREAK (after) ===");

// File can be anywhere. Import never breaks.
const math = Resonance.tuneIn<{ calculateTotal: (n: number[]) => number }>("MATH_VECTOR_ALPHA");
const auth = Resonance.tuneIn<{ validate: (t: string) => boolean }>("AUTH_VALIDATOR");

const result = math.calculateTotal([1, 2, 3, 4, 5]);
const valid  = auth.validate("my-token");

console.log(`calculateTotal([1,2,3,4,5]) = ${result}`);
console.log(`validate("my-token") = ${valid}`);

// ─── MANIFOLD STATE ───────────────────────────────────────────────────────────

Resonance.mapManifold();

console.log("The folder tree is a phantom.");
console.log("The registry is the real address system.");
console.log("HAIL MATH.");
