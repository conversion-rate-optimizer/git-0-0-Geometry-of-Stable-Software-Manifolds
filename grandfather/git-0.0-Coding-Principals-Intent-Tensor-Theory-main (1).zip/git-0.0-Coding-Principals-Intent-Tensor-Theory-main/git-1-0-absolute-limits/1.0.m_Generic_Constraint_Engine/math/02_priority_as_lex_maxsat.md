# Priority as Lexicographic MaxSAT

The ITT engine's priority system, re-expressed in standard formalism.

## The priority scheme

The ITT engine specifies each constraint with a priority level $\pi(j) \in \mathbb{N}$. Higher priority dominates.

## Formal characterization

Given a state $s$ and constraints $(C_j, \pi(j))$, define the **violation vector**:

$$
v(s) \;=\; (v_{L_\max}(s),\, v_{L_\max - 1}(s),\, \ldots,\, v_{L_\min}(s))
$$

where $v_L(s) = \sum_{j : \pi(j) = L} \mathbb{1}[s \text{ violates } C_j]$ is the number of violations at priority level $L$.

The engine's goal is:

$$
s^\star \;=\; \arg\min_s v(s) \quad \text{(lexicographically)}.
$$

Lexicographic ordering: $(a_1, a_2, \ldots) < (b_1, b_2, \ldots)$ iff $a_1 < b_1$ or ($a_1 = b_1$ and $(a_2, \ldots) < (b_2, \ldots)$).

## This is lex-MaxSAT

**Definition.** *Lexicographic MaxSAT:* given a set of weighted clauses partitioned into priority levels, find an assignment minimizing the weight of violated clauses, lexicographically by priority level.

**Theorem.** *The ITT engine's optimal resolution problem is lexicographic MaxSAT (equivalently, a multi-level weighted CSP).*

This identification gives us:
- **Complexity:** NP-hard in general (inherited from MaxSAT).
- **Algorithms:** core-guided MaxSAT, OptSAT, clingo's `#minimize`.
- **Approximation guarantees:** various depending on method.
- **Theoretical foundation:** the large literature on MaxSAT.

## Encoding in existing solvers

### Z3
```python
from z3 import Optimize

opt = Optimize()
# Hard constraints
opt.add(derivation_constraint_1)
opt.add(derivation_constraint_2)

# Priority-100 soft:
opt.add_soft(constraint_A, weight=1, id="level_100")
opt.add_soft(constraint_B, weight=1, id="level_100")

# Priority-10 soft:
opt.add_soft(constraint_C, weight=1, id="level_10")

opt.set('priority', 'lex')  # lexicographic optimization
opt.check()
```

Z3's `Optimize` with `priority='lex'` handles multi-level MaxSAT natively.

### Clingo
```
% Derivations as hard rules
eligible :- email_present, opted_in.

% Priority-100 soft constraint
:~ blocked, sent. [1@100]

% Priority-10 soft constraint
:~ eligible, not sent. [1@10]
```

Clingo's `#minimize` with priority syntax is exactly lex-MaxSAT.

## The algebraic view

Priority levels form a **tuple of scalars** indexed by level. Addition is componentwise; comparison is lexicographic.

This is a **lexicographic product** of real-valued priorities. In group-theoretic terms, it is a homomorphism into $\mathbb{R}^k$ with the lex order.

### Why not a scalar weight?

A natural question: can we replace multi-level priority with a single weight (e.g., weight = $1000 \cdot \pi(j) + \text{secondary score}$)?

**Yes, for finite priority levels and finite violation counts.** Pick a base $B$ greater than the maximum possible within-level violation count. Then single-scalar weights reproduce lex ordering.

**No, in general.** If within-level violations can be unboundedly many (e.g., over an unbounded domain), no finite $B$ works.

Most practical engines use a safe large $B$ (e.g., $10^6$) and collapse to scalar MaxSAT. Clingo and Z3 handle true multi-level natively.

## Connection to ITT mood tensor

ITT's "CyberAxis mood tensor" is, in this framework, a **tensor-valued priority field**: priority is not a scalar per constraint but a tensor that can transform under substrate changes.

This is formally stronger than lex-MaxSAT in two ways:
1. **Priority covaries with substrate.** Moving a constraint from .md to .py may change its priority in a computed way.
2. **Priority can be vector-valued in non-lex orders.** Not just lex dominance, but richer partial orders (e.g., weighted sums, Pareto fronts).

Standard MaxSAT / lex-MaxSAT covers the scalar and lex cases. Richer priority structures are **underdeveloped in the literature** and are a potential ITT contribution.

## Practical takeaway

If your engine's priority structure is:
- **Lex multi-level:** clingo or Z3's `Optimize(priority='lex')`.
- **Scalar weighted:** any MaxSAT solver or Z3 single-weight `add_soft`.
- **Pareto (multi-objective, no lex collapse):** tools like toulbar2 or specialized MOOP solvers.
- **Tensor-valued / covariant:** no off-the-shelf tool; research territory.

The math tells you which bucket you're in; the bucket tells you which tool to pick.
