# Nix: deep constructive trace — content-addressed by input hashes.

{ pkgs ? import <nixpkgs> {} }:

pkgs.stdenv.mkDerivation {
  name = "intent-engine-0.1";

  src = ./.;

  buildInputs = with pkgs; [
    python3
    python3Packages.z3
    python3Packages.clingo
  ];

  buildPhase = ''
    echo "Building intent engine..."
    python3 setup.py build
  '';

  installPhase = ''
    mkdir -p $out/bin
    cp -r build $out/bin/
  '';
}
