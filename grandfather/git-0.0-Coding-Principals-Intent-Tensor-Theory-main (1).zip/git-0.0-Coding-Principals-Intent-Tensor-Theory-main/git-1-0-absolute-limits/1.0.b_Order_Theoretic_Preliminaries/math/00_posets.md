# Partial Orders (Posets)

## Definition

A **partial order** on a set $P$ is a binary relation $\leq \subseteq P \times P$ satisfying:

1. **Reflexivity:** $\forall x \in P.\; x \leq x$.
2. **Antisymmetry:** $\forall x, y \in P.\; (x \leq y \wedge y \leq x) \Rightarrow x = y$.
3. **Transitivity:** $\forall x, y, z \in P.\; (x \leq y \wedge y \leq z) \Rightarrow x \leq z$.

A pair $(P, \leq)$ is called a **partially ordered set** or **poset**.

If additionally $\forall x, y \in P.\; x \leq y \vee y \leq x$ (totality), the order is **total** or **linear**.

## Examples

**Example 1.** $(\mathbb{N}, \leq)$ with the usual numerical order is a totally ordered poset.

**Example 2.** $(2^X, \subseteq)$ for any set $X$ is a poset. It is total only when $|X| \leq 1$.

**Example 3.** For a fixed $n \in \mathbb{N}$, the set of divisors of $n$ under the "divides" relation is a poset.

**Example 4.** Function spaces $(X \to \mathbb{R}, \leq)$ with pointwise order ($f \leq g \iff \forall x.\; f(x) \leq g(x)$) form a poset.

## Derived notions

Given a poset $(P, \leq)$ and a subset $S \subseteq P$:

- $u \in P$ is an **upper bound** of $S$ iff $\forall s \in S.\; s \leq u$.
- $l \in P$ is a **lower bound** of $S$ iff $\forall s \in S.\; l \leq s$.
- The **least upper bound** or **supremum** $\bigvee S$, if it exists, is the minimum of the set of upper bounds.
- The **greatest lower bound** or **infimum** $\bigwedge S$, if it exists, is the maximum of the set of lower bounds.

**Uniqueness.** If $\bigvee S$ exists, it is unique by antisymmetry. Same for $\bigwedge S$.

## Chains and directed sets

A subset $C \subseteq P$ is a **chain** iff $\leq$ restricted to $C$ is a total order.

A subset $D \subseteq P$ is **directed** iff $D \neq \emptyset$ and $\forall x, y \in D.\; \exists z \in D.\; x \leq z \wedge y \leq z$. Every chain is directed; not every directed set is a chain.

Directed sets matter because Scott-continuity is defined in terms of their suprema.

## The diagrammatic view

A poset can be drawn as a **Hasse diagram** — a graph where $x$ sits below $y$ iff $x \leq y$ and no intermediate $z$ lies strictly between them. Transitive edges are suppressed; reflexive ones are implicit.

Example Hasse diagram for $(2^{\{a,b\}}, \subseteq)$:

```
        {a, b}
        /    \
      {a}    {b}
        \    /
          ∅
```

Hasse diagrams make it visually obvious when joins and meets exist (they exist whenever pairs of elements have a unique least upper and greatest lower neighbor).

## Dual of a poset

Given a poset $(P, \leq)$, its **dual** is $(P, \geq)$ — the same set with the order reversed. Every poset theorem has a dual: swap $\leq \leftrightarrow \geq$, $\bigvee \leftrightarrow \bigwedge$, $\bot \leftrightarrow \top$, least fixed point ↔ greatest fixed point.

This duality is used implicitly throughout: when we prove something about $\operatorname{lfp}$, the dual proves the same for $\operatorname{gfp}$.
