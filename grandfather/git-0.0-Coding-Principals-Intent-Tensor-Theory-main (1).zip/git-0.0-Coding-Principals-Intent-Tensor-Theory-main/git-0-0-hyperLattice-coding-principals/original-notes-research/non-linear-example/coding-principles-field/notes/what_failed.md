# What failed

Document any run where bloom did not occur (`Q(t) <= 1` for all iterations).

Template:
- Date:
- Experiment:
- Parameters:
- Observed Q range:
- Hypothesized loss pathway:
- Next change:
