# Propositional SAT

The foundational NP-complete problem.

## Problem statement

Given a propositional formula $\varphi$ over Boolean variables $x_1, \ldots, x_n$, the **satisfiability problem** (SAT) asks whether there exists an assignment $\alpha : \{x_1, \ldots, x_n\} \to \{0, 1\}$ such that $\alpha \models \varphi$.

Formulas are usually given in **conjunctive normal form (CNF)**: a conjunction of clauses, where each clause is a disjunction of literals (variables or their negations).

Example CNF:
$$
(x_1 \vee \neg x_2) \wedge (\neg x_1 \vee x_2 \vee x_3) \wedge (\neg x_3)
$$

## Cook–Levin Theorem

**Theorem (Cook 1971, Levin 1973).** *SAT is NP-complete.*

**Proof idea.** SAT $\in$ NP because a satisfying assignment can be verified in polynomial time. SAT is NP-hard because any polynomial-time non-deterministic Turing machine computation can be encoded as a CNF formula whose satisfiability equals the existence of an accepting computation path. The encoding has polynomial size.

**Consequence.** SAT is at least as hard as any problem in NP. If $P = NP$, SAT is in P; if $P \neq NP$, SAT requires super-polynomial time in the worst case.

## Tseytin transformation

Not every formula is in CNF. **Tseytin transformation** converts an arbitrary propositional formula to a *satisfiability-equivalent* CNF formula (possibly with new variables) in polynomial time.

Key idea: for each non-atomic sub-formula, introduce a fresh variable and encode its semantics as a set of clauses. Example: $y = a \wedge b$ becomes

$$
(\neg y \vee a) \wedge (\neg y \vee b) \wedge (\neg a \vee \neg b \vee y).
$$

This means modern SAT solvers can accept general propositional formulas as input; the tool performs CNF conversion internally.

## Complexity classes around SAT

- **SAT:** NP-complete.
- **TAUT (tautology):** coNP-complete. "Is $\varphi$ true for every assignment?"
- **#SAT:** #P-complete. "How many satisfying assignments?"
- **MaxSAT:** NP-hard (decision); $\text{FP}^\text{NP}$-complete (optimization).
- **QBF (quantified Boolean formulas):** PSPACE-complete.

SAT sits at the boundary between decidable and hard: decidable trivially (try all assignments), but no polynomial-time algorithm is known.

## Benchmarks and progress

Despite NP-completeness, modern SAT solvers handle formulas with $10^7$ clauses routinely. This is possible because:
- **Most real-world formulas have structure** (locality, redundancy, symmetry).
- **CDCL** (see `01_dpll_and_cdcl.md`) learns from each conflict.
- **Decades of engineering** (heuristics, restarts, phase saving, clause deletion) have optimized the inner loop.

However, carefully constructed **hard instances** (random 3-SAT at the phase transition, pigeonhole principle) remain exponentially hard — the theoretical NP-completeness is not a false alarm.

## Why SAT sits in this chapter

SAT is the *archetypal* instance of "declare constraints, get a solution." It does not fit into the fixed-point iteration framework of §§3-5 — instead it uses **backtracking search with learning**. This is a genuinely different computational paradigm.

The correctness of SAT solvers is expressed via fixed points at a different level: the set of learned clauses is closed under resolution; CDCL's fixed point is an empty clause (UNSAT) or a complete model (SAT).

## Relation to constraint satisfaction

SAT is a special case of **constraint satisfaction problems (CSPs)**: variables $X_1, \ldots, X_n$ over domains $D_1, \ldots, D_n$, with constraints $C_1, \ldots, C_m$. SAT is "all variables Boolean; all constraints clauses."

**CSP** generalizes to finite discrete domains, **SMT** to combinations of theories, **MaxSAT** to weighted constraints. All share the core difficulty: searching an exponential space with clever pruning.

## Connection to ITT engine

The ITT Intent Engine, viewed propositionally, is a CSP: each state variable has a domain, each constraint restricts admissible combinations. Modern SAT/SMT solvers could replace the hand-rolled Kleene iteration with global search, trading performance predictability for worst-case completeness.

The Nelson–Oppen theory combination framework (see `03_nelson_oppen.md`) is what lets you combine Boolean, arithmetic, and structural constraints into a single solver call — the production-grade route for any multi-substrate engine.
