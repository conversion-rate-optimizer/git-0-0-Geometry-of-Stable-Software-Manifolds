"""
ASP-backed Intent Engine via clingo.
Encodes derivations as rules and priority constraints as weak constraints.
Clingo finds the optimal stable model.

Install: pip install clingo
"""

import clingo
from typing import Dict, Any


def run_asp_engine(email_present: bool, opted_in: bool, blocked: bool) -> Dict[str, Any]:
    facts = []
    if email_present: facts.append("email_present.")
    if opted_in:      facts.append("opted_in.")
    if blocked:       facts.append("blocked.")
    fact_block = "\n".join(facts)

    program = fact_block + """

        % Derivation rule
        eligible :- email_present, opted_in.

        % Choice: sent is a free Boolean (to be set by constraints)
        { sent } :- email_present.

        % Priority-10 weak constraint: eligible → sent
        :~ eligible, not sent. [10@1]

        % Priority-100 weak constraint: blocked → ¬sent
        :~ blocked, sent. [100@2]
    """

    ctl = clingo.Control(["--opt-mode=opt"])
    ctl.add("base", [], program)
    ctl.ground([("base", [])])

    best_model = None
    with ctl.solve(yield_=True) as handle:
        for model in handle:
            best_model = model.symbols(atoms=True)

    result = {"eligible": False, "sent": False}
    if best_model:
        atom_names = {s.name for s in best_model}
        result["eligible"] = "eligible" in atom_names
        result["sent"]     = "sent"     in atom_names
    return result


if __name__ == "__main__":
    for (em, op, bl) in [(True, True, False), (True, True, True), (True, False, False)]:
        result = run_asp_engine(em, op, bl)
        print(f"email={em}, opted_in={op}, blocked={bl} → {result}")
