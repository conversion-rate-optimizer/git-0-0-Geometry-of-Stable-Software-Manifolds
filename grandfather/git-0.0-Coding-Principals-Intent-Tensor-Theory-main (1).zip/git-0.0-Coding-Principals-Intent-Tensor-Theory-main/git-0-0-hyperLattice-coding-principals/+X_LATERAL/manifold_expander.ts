/**
 * +X_LATERAL: Manifold Expander
 * ==============================
 * When Q > 1.1 (bloom), a module may spawn sub-geometry —
 * new coordinate axes within the manifold.
 *
 * Bloom = the module is producing structure faster than disorder.
 * It has earned the right to influence the manifold's topology.
 */

import { fieldBus } from "./event_emitter";
import { SELECTION } from "../-Z_BASE/axioms";

export interface SubGeometry {
  parentId: string;
  childIds: string[];
  spawnedAt: number;
  Q: number;           // Q value that triggered the spawn
}

export class ManifoldExpander {
  private expansions: SubGeometry[] = [];
  private iteration = 0;

  tick(): void { this.iteration++; }

  /**
   * Attempt expansion for a module.
   * Only fires if Q > bloom threshold.
   * Returns the new sub-geometry if spawned, null otherwise.
   */
  tryExpand(
    moduleId: string,
    Q: number,
    proposedChildren: string[]
  ): SubGeometry | null {
    if (Q <= SELECTION.bloom) return null;
    if (proposedChildren.length === 0) return null;

    const sub: SubGeometry = {
      parentId: moduleId,
      childIds: proposedChildren,
      spawnedAt: this.iteration,
      Q,
    };

    this.expansions.push(sub);
    fieldBus.emit("BLOOM", moduleId, { Q, childCount: proposedChildren.length });

    console.log(`[MANIFOLD_EXPANSION]: ${moduleId} spawned ${proposedChildren.length} sub-nodes (Q=${Q.toFixed(2)})`);
    return sub;
  }

  expansionsFor(moduleId: string): SubGeometry[] {
    return this.expansions.filter(e => e.parentId === moduleId);
  }

  get totalExpansions(): number { return this.expansions.length; }
}
