"""
Python implementations of all three fixed-point theorems.

Kleene-style iteration, bounded Kleene, and Banach contraction.
"""

from __future__ import annotations
from typing import Callable, TypeVar, Iterator, Optional
import math

A = TypeVar("A")
R = TypeVar("R")


# ---------------------------------------------------------------
# Kleene (discrete lattice iteration)
# ---------------------------------------------------------------

def lfp_kleene(f: Callable[[A], A], start: A, max_iter: int = 10_000) -> A:
    """
    Kleene iteration: S_{n+1} = f(S_n), starting from `start`, until fixed.
    Assumes:
      - Some notion of equality on A.
      - f is monotone/Scott-continuous on some lattice.
      - start <= lfp(f) in that lattice (typically, start = ⊥).

    Raises RuntimeError if no fixed point is reached within max_iter.
    """
    x = start
    for _ in range(max_iter):
        x_next = f(x)
        if x_next == x:
            return x
        x = x_next
    raise RuntimeError(
        f"lfp_kleene: no fixed point after {max_iter} iterations."
    )


def kleene_chain(f: Callable[[A], A], start: A) -> Iterator[A]:
    """Generator of the Kleene chain: bot, f(bot), f^2(bot), ..."""
    x = start
    while True:
        yield x
        x = f(x)


# ---------------------------------------------------------------
# Banach (metric contraction)
# ---------------------------------------------------------------

def banach_iterate(
    f: Callable[[float], float],
    x0: float,
    tol: float = 1e-10,
    max_iter: int = 1000,
) -> float:
    """
    Banach iteration on ℝ: find the unique fixed point of a contraction.

    The caller is responsible for ensuring f is a contraction with factor < 1.
    Convergence is exponential: err ~ q^n * (initial err) / (1 - q).
    """
    x = x0
    for n in range(max_iter):
        x_next = f(x)
        if abs(x_next - x) < tol:
            return x_next
        x = x_next
    raise RuntimeError(
        f"banach_iterate: did not converge in {max_iter} iterations."
    )


def newton_method(
    g: Callable[[float], float],
    g_prime: Callable[[float], float],
    x0: float,
    tol: float = 1e-12,
    max_iter: int = 100,
) -> float:
    """
    Newton's method as Banach contraction (near a simple root).
    x_{n+1} = x_n - g(x_n) / g'(x_n)
    """
    def f(x: float) -> float:
        return x - g(x) / g_prime(x)
    return banach_iterate(f, x0, tol, max_iter)


# ---------------------------------------------------------------
# Demonstrations
# ---------------------------------------------------------------

if __name__ == "__main__":
    # Kleene: transitive closure
    def close_relation(R: frozenset) -> frozenset:
        return R | frozenset(
            (a, d) for (a, b) in R for (c, d) in R if b == c
        )

    edges = frozenset({(1, 2), (2, 3), (3, 4), (4, 5)})
    closure = lfp_kleene(close_relation, edges)
    print(f"Kleene (transitive closure): {sorted(closure)}")

    # Banach: solve x = cos(x) (unique fixed point ≈ 0.739085)
    result = banach_iterate(math.cos, 0.5)
    print(f"Banach (x = cos x): {result:.10f}")

    # Newton: find root of x^3 - 2 (= cube root of 2)
    root = newton_method(lambda x: x**3 - 2, lambda x: 3 * x**2, x0=1.0)
    print(f"Newton (∛2): {root:.10f}")

    # Kleene chain visualization
    chain = kleene_chain(lambda n: min(100, n + 13), 0)
    first_ten = [next(chain) for _ in range(10)]
    print(f"Bounded Kleene chain: {first_ten}")
