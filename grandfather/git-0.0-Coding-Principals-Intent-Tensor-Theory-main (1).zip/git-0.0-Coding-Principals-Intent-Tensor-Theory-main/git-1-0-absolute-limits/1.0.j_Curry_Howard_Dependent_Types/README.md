# 1.0.j — Curry–Howard and Dependent Types

Propositions as types, proofs as programs. Lean 4, Idris, Agda.

## Files

**Math:**
- `math/00_propositions_as_types.md` — The isomorphism.
- `math/01_dependent_type_theory.md` — Π, Σ, inductive types, universes.
- `math/02_type_inhabitation.md` — The undecidability wall.
- `math/03_homotopy_type_theory.md` — HoTT, univalence, cubical.

**Code:**
- `code/lean4_examples.lean` — Lean 4 tactics and term-mode proofs.
- `code/haskell_gadts.hs` — Haskell's approximation via GADTs.
- `code/idris_vect.idr` — Idris with length-indexed vectors.
