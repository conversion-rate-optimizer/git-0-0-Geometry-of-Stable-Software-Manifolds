# Chapter 1 — The Law of the Locked Lattice (git-0-0-)

## Triple Anchor
1. Platform anchor: `git-`
2. Lattice coordinate: `<x>-<y>`
3. Semantic slug: `-<intent>`

Canonical example:
- `git-0-1-ignition-main`

Coordinate = `(0,1)`
Distance to root (L1) = `|0| + |1| = 1`

## Hyper-lattice vs Ghost
If path names drift without coordinate anchor, tooling must guess.
If coordinates are locked, tooling computes deterministic addresses.

## Manifest role
Lattice = spine.
Manifest = brain.

Changing slug text must not break coordinate references.

## Student assignment: Exorcising the Root
- `config/` + `env/` -> `git-0-0-substrate-config/`
- `main.js` + `init.ts` -> `git-0-1-ignition-main/`
- `services/` + `api/` -> `git-0-2-runtime-api/`
- `components/` + `styles/` -> `git-1-0-interface-ui/`
