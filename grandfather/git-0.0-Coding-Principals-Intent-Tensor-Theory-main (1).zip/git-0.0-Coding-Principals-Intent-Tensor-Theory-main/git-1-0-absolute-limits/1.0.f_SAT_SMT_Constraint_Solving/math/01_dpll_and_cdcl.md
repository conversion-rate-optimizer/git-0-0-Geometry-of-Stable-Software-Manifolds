# DPLL and CDCL

The two dominant SAT algorithms. CDCL (conflict-driven clause learning) is DPLL with the single most important engineering addition of the last three decades.

## DPLL

The **Davis–Putnam–Logemann–Loveland** algorithm (1962). Pseudocode:

```
DPLL(φ):
    φ := unit_propagate(φ)
    φ := pure_literal_eliminate(φ)
    if φ is empty: return SAT
    if φ contains empty clause: return UNSAT
    x := choose_variable(φ)
    if DPLL(φ ∧ x):  return SAT
    if DPLL(φ ∧ ¬x): return SAT
    return UNSAT
```

### Unit propagation

A **unit clause** is a clause with one remaining literal, say $\ell$. For the formula to be satisfiable, $\ell$ must be true. Assign $\ell = 1$ and simplify.

Repeat until no unit clauses remain. This is the engine that drives most of the solver's work.

### Pure literal elimination

A literal is **pure** if it appears only positively or only negatively across the formula. Assign it the value that satisfies all its occurrences. This never sacrifices satisfiability.

### Branching

When no unit or pure literals exist, pick an unassigned variable and try $x = 1$; if that leads to UNSAT, try $x = 0$. This is the **exponential** step — naive DPLL can take $2^n$ time.

## CDCL

**Conflict-Driven Clause Learning** (Marques-Silva, Sakallah, 1996; Zhang et al., 2001) adds:

### Implication graph

Track the decisions and unit propagations as a DAG:
- Nodes: assigned literals, labeled with decision level.
- Edges: from a clause's propagating literals to the propagated one.

When a conflict occurs (empty clause derived), analyze the implication graph to find **why** the conflict happened.

### Conflict analysis and learning

Compute a **cut** of the implication graph separating the conflict from early decisions. The negation of the literals on the cut is a new clause implied by the formula — a **learned clause**. Add it to the formula.

Each conflict prevents at least one exponential family of similar conflicts from recurring.

### Non-chronological backtracking

Instead of undoing the most recent decision, jump back to the **assertion level** — the highest decision level in the learned clause other than the conflict level. This can skip many useless branches.

### Variable selection (VSIDS)

**Variable State Independent Decaying Sum:** maintain an activity score for each variable, incremented when the variable appears in a conflict, periodically decayed. Always branch on the highest-scoring unassigned variable.

This heuristic, combined with restarts, is empirically devastating for real-world instances.

### Restarts

Periodically abandon the current search tree (but *keep* all learned clauses). Begin a fresh search from scratch with a new variable ordering.

Counter-intuitively, restarts improve performance because:
- Early bad decisions compound into deep useless sub-trees.
- Learned clauses from the abandoned tree guide the new search.
- The portfolio of restart strategies (luby sequence, geometric, etc.) is well-tuned.

## Correctness invariants

CDCL's correctness rests on two invariants:

1. **Soundness of learning:** every learned clause is logically implied by the input formula (guaranteed by resolution proofs in the implication graph).
2. **Completeness of search:** the search exhaustively explores the space; if SAT is returned, a model is present; if UNSAT is returned, no model exists.

These are proved in standard textbooks (Biere et al., *Handbook of Satisfiability*).

## Complexity

CDCL is worst-case exponential (inherited from DPLL's NP-completeness). **However:**

- Most SAT competition benchmarks: milliseconds to hours.
- Hand-crafted hard instances (e.g., pigeonhole PHP, doubled variables): exponential.

Modern solvers (Kissat, CaDiCaL, Glucose, MiniSat) implement CDCL with hundreds of micro-optimizations and achieve solving rates that would have been unthinkable in 2000.

## DPLL(T): the SMT extension

For **Satisfiability Modulo Theories**, CDCL is extended to handle literals that are **theory atoms** (e.g., $x + y \leq 5$, $a[i] = v$). The algorithm:

1. Treat each theory atom as a propositional literal.
2. Run CDCL to find a propositional model.
3. Check theory-consistency of the model using a **theory solver**.
4. If theory-inconsistent, generate a **theory lemma** (the negation of the inconsistent subset) and feed it to CDCL as a learned clause.
5. Resume CDCL with the new lemma.

This is **DPLL(T)** (Ganzinger, Hagen, Nieuwenhuis, Oliveras, Tinelli 2004).

Z3, cvc5, MathSAT, Yices are all DPLL(T) solvers with different theory-solver implementations.

## What you literally write

```python
from z3 import Solver, Int, And, Not, sat

s = Solver()
x, y = Int('x'), Int('y')
s.add(x + y == 10)
s.add(x - y == 4)

if s.check() == sat:
    print(s.model())  # x=7, y=3
```

That is DPLL(T) running internally. You wrote three lines of code; the solver executed CDCL with a linear-arithmetic theory solver in the background.
