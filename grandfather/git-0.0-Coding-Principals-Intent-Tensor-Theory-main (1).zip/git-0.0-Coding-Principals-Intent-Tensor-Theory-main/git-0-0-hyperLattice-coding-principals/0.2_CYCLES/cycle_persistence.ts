/**
 * 0.2_CYCLES: Cycle Persistence Engine
 * =====================================
 * The 3D closure layer. Nodes are transient. Cycles are permanent.
 *
 * An Object in this system is defined as:
 *   A cycle C such that S_C ≥ 1
 *
 * Where:
 *   S_C = Σ_{i ∈ C} φ_i / (Σ_{i ∈ C} |Δφ_i| + ε)
 *
 * This is the cycle-level Selection Number — the persistence ratio
 * applied not to individual nodes but to closed loops.
 *
 * Mechanical meaning:
 *   - Linear chains dissipate (influence bleeds out)
 *   - Cycles retain energy (influence returns to origin)
 *   - S_C ≥ 1 means the loop sustains itself without external forcing
 *   - S_C > 1.2 means the loop is an ANCHOR — persists even if seed is removed
 *
 * Connection to Intratessellation (Atomic Polarity):
 *   In chemistry, intratessellation = Morse-cell partition of void boundary
 *   In code, intratessellation = stable cycle partition of the weight graph
 *   Both emerge from the same Morse-Smale decomposition of the anisotropy field
 */

import { SELECTION, LATTICE } from "../-Z_BASE/axioms";

export interface CodeCycle {
  nodes: string[];        // Ordered node sequence forming the loop
  S_C: number;            // Cycle persistence ratio
  phi_sum: number;        // Σφ along loop
  delta_sum: number;      // Σ|Δφ| along loop
  isObject: boolean;      // S_C ≥ 1.0
  isAnchor: boolean;      // S_C > 1.2
}

/**
 * Find all simple cycles in the directed weight graph.
 * Uses Johnson's algorithm (iterative DFS with stack).
 *
 * Note: In production, this calls into a graph library.
 * Here we implement a simple DFS cycle finder for self-contained operation.
 */
export function findCycles(
  W: Map<string, Map<string, number>>,
  maxCycleLength: number = 8  // Mirrors n_max from CTS
): string[][] {
  const nodes = Array.from(W.keys());
  const cycles: string[][] = [];
  const visited = new Set<string>();
  const stack: string[] = [];
  const onStack = new Set<string>();

  function dfs(nodeId: string, startId: string, depth: number): void {
    if (depth > maxCycleLength) return;

    onStack.add(nodeId);
    stack.push(nodeId);

    const neighbors = W.get(nodeId);
    if (!neighbors) {
      stack.pop();
      onStack.delete(nodeId);
      return;
    }

    for (const neighborId of neighbors.keys()) {
      if (neighborId === startId && stack.length > 1) {
        // Found a cycle — record it
        cycles.push([...stack]);
        continue;
      }
      if (!onStack.has(neighborId) && (W.get(neighborId)?.size ?? 0) > 0) {
        dfs(neighborId, startId, depth + 1);
      }
    }

    stack.pop();
    onStack.delete(nodeId);
  }

  for (const nodeId of nodes) {
    if (!visited.has(nodeId)) {
      dfs(nodeId, nodeId, 0);
      visited.add(nodeId);
    }
  }

  return cycles;
}

/**
 * Compute cycle persistence S_C for a given cycle.
 *
 * S_C = Σ_{i ∈ C} φ_i(t) / (Σ_{i ∈ C} |φ_i(t) - φ_i(t-1)| + ε)
 *
 * CRITICAL: Sample this at iterations 2-10 during field evolution.
 * At convergence |Δφ| → 0 and S_C → ∞ for any non-zero cycle,
 * making it uninformative. The meaningful signal is in the transient.
 * Test-verified: cycles show S_C > 1 from step 0; chains resolve
 * differently based on whether all nodes receive activation.
 */
export function cyclePersistence(
  cycle: string[],
  phi: Map<string, number>,
  phi_prev: Map<string, number>
): number {
  let phi_sum = 0;
  let delta_sum = LATTICE.epsilon_field;

  for (const nodeId of cycle) {
    const p = phi.get(nodeId) ?? 0;
    const p_prev = phi_prev.get(nodeId) ?? 0;
    phi_sum += p;
    delta_sum += Math.abs(p - p_prev);
  }

  // Cap at 1000 — same reason as selectionNumber.
  // S_C → ∞ at convergence. Gate during transient (steps 2-10).
  return Math.min(phi_sum / delta_sum, 1000);
}

/**
 * Evaluate all cycles in the lattice and classify them.
 * Returns only cycles above the epsilon floor (φ_sum > 0).
 */
export function evaluateCycles(
  W: Map<string, Map<string, number>>,
  phi: Map<string, number>,
  phi_prev: Map<string, number>
): CodeCycle[] {
  const rawCycles = findCycles(W);
  const results: CodeCycle[] = [];

  for (const cycle of rawCycles) {
    let phi_sum = 0;
    let delta_sum = LATTICE.epsilon_field;

    for (const nodeId of cycle) {
      const p = phi.get(nodeId) ?? 0;
      const p_prev = phi_prev.get(nodeId) ?? 0;
      phi_sum += p;
      delta_sum += Math.abs(p - p_prev);
    }

    const S_C = phi_sum / delta_sum;

    results.push({
      nodes: cycle,
      S_C,
      phi_sum,
      delta_sum,
      isObject: S_C >= SELECTION.cycle_persistence,
      isAnchor: S_C >= SELECTION.anchor,
    });
  }

  // Sort by S_C descending — highest persistence = most real
  return results.sort((a, b) => b.S_C - a.S_C);
}

/**
 * Cycle competition: given multiple candidate cycles over the same nodes,
 * return only the one with highest S_C (winner-take-all in the CTS).
 *
 * In chemistry analog: only one tessellation configuration minimizes
 * total pre-geometric tension.
 */
export function resolveCompetingCycles(cycles: CodeCycle[]): CodeCycle[] {
  const nodeOwnership = new Map<string, CodeCycle>();

  for (const cycle of cycles) {
    if (!cycle.isObject) continue;

    let dominated = false;
    for (const nodeId of cycle.nodes) {
      const competitor = nodeOwnership.get(nodeId);
      if (competitor && competitor.S_C > cycle.S_C) {
        dominated = true;
        break;
      }
    }

    if (!dominated) {
      for (const nodeId of cycle.nodes) {
        nodeOwnership.set(nodeId, cycle);
      }
    }
  }

  // Return unique winning cycles
  const winners = new Set(nodeOwnership.values());
  return Array.from(winners);
}

/**
 * The Object Manifest: the set of all real objects (persistent cycles)
 * in the current lattice state.
 *
 * "Object" = cycle such that S_C ≥ 1
 * "Anchor" = cycle such that S_C ≥ 1.2 (survives seed removal)
 */
export function buildObjectManifest(
  W: Map<string, Map<string, number>>,
  phi: Map<string, number>,
  phi_prev: Map<string, number>
): {
  objects: CodeCycle[];
  anchors: CodeCycle[];
  noise: CodeCycle[];
} {
  const all = evaluateCycles(W, phi, phi_prev);
  const stable = resolveCompetingCycles(all);

  return {
    objects: stable.filter(c => c.isObject && !c.isAnchor),
    anchors: stable.filter(c => c.isAnchor),
    noise: all.filter(c => !c.isObject),
  };
}
