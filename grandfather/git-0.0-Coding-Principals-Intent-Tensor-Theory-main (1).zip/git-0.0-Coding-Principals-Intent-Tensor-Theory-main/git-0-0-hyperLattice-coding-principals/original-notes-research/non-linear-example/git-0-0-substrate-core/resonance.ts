/**
 * Resonance Registry
 * Index-to-index lookup by sub-key identity, not relative file path.
 */

export type ResonanceFn<T = unknown> = (...args: unknown[]) => T;

interface Entry<T = unknown> {
  subKey: string;
  provider: ResonanceFn<T>;
  metadata?: Record<string, string>;
}

export class ResonanceRegistry {
  private entries = new Map<string, Entry>();

  register<T>(entry: Entry<T>): void {
    this.entries.set(entry.subKey, entry as Entry);
  }

  tune<T>(subKey: string): ResonanceFn<T> {
    const entry = this.entries.get(subKey);
    if (!entry) {
      throw new Error(`Resonance miss: ${subKey}`);
    }
    return entry.provider as ResonanceFn<T>;
  }

  has(subKey: string): boolean {
    return this.entries.has(subKey);
  }

  list(): string[] {
    return [...this.entries.keys()].sort();
  }
}

export const Resonance = new ResonanceRegistry();
