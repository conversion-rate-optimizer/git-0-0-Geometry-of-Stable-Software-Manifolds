# Chapter 03 — How Fields Spread

*Read time: 8 minutes*

---

## A Metal Rod

Hold one end of a metal rod over a flame. Wait.

The end you are holding gets hot. Not immediately — it 
takes time. The heat travels from the flame end toward 
your hand, slowly, point by point through the metal.

This is **diffusion**. Heat spreading from where there 
is more of it to where there is less of it.

The rule is simple: heat flows from hot to cold. The 
greater the temperature difference between two adjacent 
points, the faster heat flows between them.

---

## The Diffusion Equation

In 1822, Joseph Fourier wrote this observation down as 
a mathematical rule:

```
rate of change = (diffusion constant) × (curvature of the field)
```

The "curvature of the field" is how much the value at 
a point differs from its neighbors. If you are hotter 
than everyone around you, your value curves sharply 
downward — you will cool fast. If everyone around you 
is the same temperature, there is no curvature, no 
flow, no change.

In symbols:

```
∂Φ/∂t = η × ∇²Φ
```

- `∂Φ/∂t` means: how fast Φ is changing right now
- `η` is the diffusion constant (how fast things spread — a number)
- `∇²Φ` is the curvature of the field at this point

In this repository: `η = 0.08`. That number was calibrated 
to give the field time to spread meaningfully across a 
graph in about 30 iterations without either flooding 
instantly or moving too slowly to matter.

---

## Curvature on a Graph

On a metal rod, "curvature" means: how different is this 
point from the points immediately next to it in physical space?

On a graph, "neighbors" are not physical neighbors — 
they are connected nodes. The curvature of node i 
on a graph is:

```
∇²Φ at node i = sum over all neighbors j of: W_ij × (Φ_j - Φ_i)
```

Read this in English: for each neighbor j, compute the 
difference in their field values. Multiply by the 
connection strength W_ij. Add them all up.

If all your neighbors have higher Φ than you, the sum 
is positive — you will gain field value (you are heating up). 
If your neighbors all have lower Φ, the sum is negative — 
you will lose field value (you are cooling down). If your 
neighbors are exactly the same as you, the sum is zero — 
nothing moves.

This is called the **graph Laplacian** and it is written 
`L = D - W`, where D is the degree matrix from Chapter 02.

---

## The Full Field Equation in This Codebase

The pure diffusion equation is just the first piece. 
The full equation in this system is:

```
Φ(t+1) = λ × seed + (1-λ) × (field diffused from neighbors)
```

Where `λ = 0.63`. This number controls the balance 
between two forces:

**The seed** is the starting intent — the value you 
initialize a module with. The seed represents what you 
*want* the system to care about. The seed does not go away. 
It keeps pulling the field back toward the original intent 
on every step.

**The diffusion** is the field spreading from connected 
neighbors. It represents what the structure of the graph 
*actually supports* — which modules naturally reinforce 
each other based on their connections.

With `λ = 0.63`: the field is 63% anchored to the seed 
at every step, and 37% shaped by its neighbors. The seed 
is stronger than the network — it is the human intent 
that the field organizes around.

---

## What Happens Step by Step

Say Auth starts at Φ = 1.0, everything else at Φ = 0.

**Step 0:** Auth=1.0, Logic=0, DB=0, UI=0  
**Step 1:** Auth stays near 1.0 (seed holds it). Logic rises to ~0.26 (pulled by Auth). DB and UI barely move.  
**Step 2:** Logic is now nonzero, so DB and UI begin to rise. Auth barely changes.  
**Step 10:** The field has spread through the graph. All connected modules have risen. Unconnected modules stay at zero.  
**Step 30:** The field has settled. Values are no longer changing. This is equilibrium.

At equilibrium, you read off which modules have Φ above 
a threshold. Those are the "active" modules — the ones 
the system has determined are relevant to the current intent.

---

## Why 30 Iterations?

The spreading radius of a diffusion field at time t is 
approximately `√(4ηt)`. With η = 0.08 and t = 30:

```
spreading radius = √(4 × 0.08 × 30) = √9.6 ≈ 3.1
```

This means the field has meaningfully reached about 3 
hops away from the seed after 30 steps. For a typical 
codebase graph — where most modules are within 3-4 hops 
of any other module — 30 steps is enough to settle.

This is not a magic number. It is the natural settling 
time given the diffusion constant η = 0.08. Change η, 
you change the settling time.

---

## The Key Insight

Diffusion does not find the "best" path. It finds all 
paths simultaneously and assigns weights to each.

This is fundamentally different from how standard code 
works. In a standard codebase, you call a function: 
one path, direct, predetermined. In a field-diffusion 
system, you seed an intent and let the field settle: 
all paths explored simultaneously, weights determined 
by connection strength.

The result is not a single path. It is a distribution 
of activation across the entire graph — the field's 
answer to: given this intent, what matters?

---

## Summary

- Diffusion: values spread from high to low through connections
- The graph Laplacian measures "how different am I from my neighbors"
- λ = 0.63 balances seed pressure (intent) vs neighbor influence (structure)
- 30 iterations settles a typical graph given η = 0.08
- The result is a distribution of activation, not a single path

---

**Previous:** [Chapter 02 — What Is a Graph?](./ch-02-what-is-a-graph.md)  
**Next:** [Chapter 04 — What Is a Matrix?](./ch-04-what-is-a-matrix.md)
