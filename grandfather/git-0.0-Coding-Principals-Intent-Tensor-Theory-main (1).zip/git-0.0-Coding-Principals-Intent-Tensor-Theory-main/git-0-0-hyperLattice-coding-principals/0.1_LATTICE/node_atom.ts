/**
 * 0.1_LATTICE: Node Atom
 * =======================
 * A node in the HyperLattice — a code unit with an intent vector Ψ.
 *
 * Identity is not location. Identity is the unit vector Ψ_i.
 * Two atoms are semantically close when Ψ_i · Ψ_j is high.
 */

import { normalize, cosineSimilarity, type IntentVector } from "./weight_matrix";

export interface AtomMetadata {
  id: string;
  label: string;       // Human-readable name
  coordinate: string;  // IHCTB zone (e.g. "+Y_FORWARD")
  logicRef?: unknown;  // Reference to actual logic (function, class, etc.)
}

export class Atom {
  public readonly id: string;
  public readonly intentVector: IntentVector;
  public readonly meta: AtomMetadata;

  constructor(meta: AtomMetadata, rawVector: IntentVector) {
    this.id = meta.id;
    this.meta = meta;
    // Normalize at construction — Ψ is always a unit vector
    this.intentVector = normalize(rawVector);
  }

  /**
   * Cosine similarity to another atom.
   * This is the semantic resonance — the basis for W_ij.
   */
  resonanceWith(other: Atom): number {
    return cosineSimilarity(this.intentVector, other.intentVector);
  }

  /**
   * Effective distance to another atom (Topological Proximity Collapse).
   * D_eff → 0 at perfect resonance.
   */
  distanceTo(other: Atom, D0: number = 1.0): number {
    return D0 / (1 + this.resonanceWith(other));
  }
}

/**
 * Build an Atom from a string description.
 * In production, use an embedding model for the vector.
 * Here: simple deterministic hash into a fixed-dim vector.
 */
export function atomFromString(
  id: string,
  description: string,
  coordinate: string,
  dims: number = 16
): Atom {
  // Deterministic pseudo-embedding from string
  const vec: number[] = new Array(dims).fill(0);
  for (let i = 0; i < description.length; i++) {
    vec[i % dims] += description.charCodeAt(i) / 128;
  }
  return new Atom({ id, label: description, coordinate }, vec);
}
