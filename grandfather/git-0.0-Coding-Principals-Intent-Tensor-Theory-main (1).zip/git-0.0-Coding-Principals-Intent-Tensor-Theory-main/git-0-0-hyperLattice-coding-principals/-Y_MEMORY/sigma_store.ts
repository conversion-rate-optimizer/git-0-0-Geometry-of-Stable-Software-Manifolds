/**
 * -Y_MEMORY: Sigma Store
 * =======================
 * σ = accumulated phase residue — unclosed tension.
 *
 * When a node fails S < 1, its φ value is not deleted.
 * It is archived here as potential field excitation.
 * Under different seeds or graph conditions, residue
 * may achieve closure in a future run.
 */

import { SELECTION } from "../-Z_BASE/axioms";

export interface ResidueRecord {
  nodeId: string;
  phi: number;          // Field value at time of failure
  S: number;            // Selection number at failure
  failedAt: number;     // Iteration number
  reason: string;       // Why it failed
}

export class SigmaStore {
  private archive: ResidueRecord[] = [];
  private maxSize: number;

  constructor(maxSize: number = 1000) {
    this.maxSize = maxSize;
  }

  /**
   * Archive a node that failed the selection gate.
   */
  store(nodeId: string, phi: number, S: number, iteration: number, reason = "S < 1"): void {
    if (this.archive.length >= this.maxSize) {
      // Drop oldest when full
      this.archive.shift();
    }
    this.archive.push({ nodeId, phi, S, failedAt: iteration, reason });
  }

  /**
   * Retrieve residue that might be viable under new conditions.
   * Returns records where φ > threshold — non-trivial potential.
   */
  retrieve(minPhi: number = 0.01): ResidueRecord[] {
    return this.archive.filter(r => r.phi > minPhi);
  }

  /**
   * Convert viable residue back into a seed map.
   * Used when re-seeding the field after a failed run.
   */
  toSeed(minPhi: number = 0.01): Map<string, number> {
    const seed = new Map<string, number>();
    for (const record of this.retrieve(minPhi)) {
      // Scale down — residue is weaker than a fresh seed
      seed.set(record.nodeId, record.phi * 0.5);
    }
    return seed;
  }

  /**
   * Total accumulated sigma (phase residue energy).
   */
  get totalSigma(): number {
    return this.archive.reduce((s, r) => s + r.phi, 0);
  }

  get size(): number { return this.archive.length; }

  clear(): void { this.archive = []; }
}
