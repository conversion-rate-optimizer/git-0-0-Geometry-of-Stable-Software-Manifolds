-- Pure Kleene fixed-point iteration in Haskell.
--
-- `lfp :: (Eq a) => (a -> a) -> a -> a` reads:
--   "Give me a type a that has equality. Give me a function a -> a.
--    Give me a starting a. I'll give you back an a — the fixed point."
--
-- This is the constructive content of Kleene's theorem: iterate until stable.

module Lfp where

-- Generic Kleene iteration.
-- Terminates iff the lattice has finite ascending chains from `start`.
lfp :: Eq a => (a -> a) -> a -> a
lfp f start = go start
  where
    go x = let x' = f x
           in if x' == x then x else go x'

-- Bounded Kleene iteration.
-- Returns Nothing if the iteration did not stabilize within `n` steps.
lfpBounded :: Eq a => Int -> (a -> a) -> a -> Maybe a
lfpBounded n f start
  | n <= 0    = Nothing
  | otherwise = let start' = f start
                in if start' == start then Just start
                                       else lfpBounded (n - 1) f start'

-- The Kleene chain as an explicit list, for inspection.
kleeneChain :: (a -> a) -> a -> [a]
kleeneChain f x = iterate f x

-- Example 1: Factorial via fix
-- The Y combinator pattern: fix builds recursion without explicit names.
fix :: (a -> a) -> a
fix f = let x = f x in x

factorial :: Int -> Int
factorial = fix (\rec n -> if n == 0 then 1 else n * rec (n - 1))

-- Example 2: Transitive closure via lfp over Data.Set
import qualified Data.Set as Set
import Data.Set (Set)

transClose :: (Ord a) => Set (a, a) -> Set (a, a)
transClose edges = lfp step edges
  where
    step r = r `Set.union` Set.fromList
      [(a, d) | (a, b) <- Set.toList r
              , (c, d) <- Set.toList r
              , b == c]

-- main :: IO ()
-- main = do
--   print (factorial 5)                               -- 120
--   print (transClose (Set.fromList [(1,2),(2,3)]))   -- {(1,2),(1,3),(2,3)}
