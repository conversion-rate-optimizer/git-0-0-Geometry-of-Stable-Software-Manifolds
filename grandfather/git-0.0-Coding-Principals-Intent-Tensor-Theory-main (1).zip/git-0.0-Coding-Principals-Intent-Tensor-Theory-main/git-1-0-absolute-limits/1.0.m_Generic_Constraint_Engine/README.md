# 1.0.m — The Generic Constraint + Derivation + Priority Engine

The ITT Intent Engine, formally situated in the landscape of Chapter 1.

## Files

**Math:**
- `math/00_engine_formalization.md` — Types and operators.
- `math/01_convergence_analysis.md` — Three regimes.
- `math/02_priority_as_lex_maxsat.md` — Lexicographic MaxSAT correspondence.
- `math/03_energy_formulation.md` — Variational view.

**Code:**
- `code/engine_typescript.ts` — Typed engine (matches `git-0.*` style).
- `code/engine_smt_backed.ts` — SMT-backed variant via Z3.
- `code/engine_reactive.jsx` — React/SAC variant for UI integration.
- `code/engine_asp_backed.py` — ASP/Clingo variant for combinatorial completeness.
