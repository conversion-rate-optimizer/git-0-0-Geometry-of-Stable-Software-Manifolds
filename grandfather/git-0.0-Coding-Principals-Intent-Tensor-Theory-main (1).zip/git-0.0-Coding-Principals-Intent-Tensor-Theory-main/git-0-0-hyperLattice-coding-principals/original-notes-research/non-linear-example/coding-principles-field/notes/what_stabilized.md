# What stabilized

Document runs where bloom occurred and persistence improved.

Template:
- Date:
- Experiment:
- Bloom iteration:
- Peak Q:
- S_sel trend:
- Why this likely stabilized:
