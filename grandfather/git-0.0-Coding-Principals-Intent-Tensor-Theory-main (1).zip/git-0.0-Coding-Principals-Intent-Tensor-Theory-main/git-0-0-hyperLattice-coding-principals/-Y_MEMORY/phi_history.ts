/**
 * -Y_MEMORY: Phi History
 * =======================
 * Stores φ(t) time series across iterations.
 * Required for S and S_C computation (need φ_prev).
 * Also enables Q''(t) > 0 check for bloom acceleration.
 */

export interface FieldSnapshot {
  iteration: number;
  phi: Map<string, number>;
  Q?: number;   // Bloom quotient at this step if computed
}

export class PhiHistory {
  private snapshots: FieldSnapshot[] = [];
  private maxHistory: number;

  constructor(maxHistory: number = 50) {
    this.maxHistory = maxHistory;
  }

  record(iteration: number, phi: Map<string, number>, Q?: number): void {
    if (this.snapshots.length >= this.maxHistory) {
      this.snapshots.shift();
    }
    // Store a copy — not a reference
    this.snapshots.push({ iteration, phi: new Map(phi), Q });
  }

  /** Most recent snapshot */
  get latest(): FieldSnapshot | undefined {
    return this.snapshots[this.snapshots.length - 1];
  }

  /** Second most recent — used as phi_prev */
  get previous(): FieldSnapshot | undefined {
    return this.snapshots[this.snapshots.length - 2];
  }

  /** Get phi_prev map for S computation */
  get phiPrev(): Map<string, number> {
    return this.previous?.phi ?? new Map();
  }

  /**
   * Q(t) trajectory — for bloom acceleration check Q''(t) > 0.
   */
  get QHistory(): number[] {
    return this.snapshots
      .filter(s => s.Q !== undefined)
      .map(s => s.Q!);
  }

  /**
   * Second derivative of Q(t) — positive means accelerating emergence.
   * Required for Master Manifest merge eligibility.
   */
  get QAccelerating(): boolean {
    const Q = this.QHistory;
    if (Q.length < 3) return false;
    const n = Q.length;
    return Q[n-1] - 2*Q[n-2] + Q[n-3] > 0;
  }

  get length(): number { return this.snapshots.length; }

  clear(): void { this.snapshots = []; }
}
