# Change Propagation

The algorithm that incrementally updates a self-adjusting computation in response to input changes.

## The algorithm

Given:
- An execution trace $T = (V, M, R, W, \prec)$.
- A set of modified modifiables $\Delta \subseteq M$.

Compute the updated output:

```
ChangePropagate(T, Δ):
    dirty := ∅
    for each m ∈ Δ:
        dirty ∪= nodes_reading(m)
    while dirty is non-empty:
        take n ∈ dirty with minimum order
        re-execute n:
            read current values of n's inputs
            write n's outputs
        for each modifiable m' that n wrote with a new value:
            dirty ∪= nodes_reading(m') \ {n}
    return
```

**Invariant.** After `ChangePropagate(T, Δ)` finishes, every modifiable in the trace reflects a value consistent with its recorded computation given the new inputs.

## Why order matters

Nodes must be re-executed in an order consistent with the DAG to avoid reading stale values. Classical implementations use a **priority queue keyed by time stamp**.

## Memoization during propagation

Before re-executing a node $n$:
- Check if any of $n$'s dependencies actually changed value.
- If not, skip re-execution — $n$'s outputs are already correct.

This is **differential dirtying**: a modifiable might be marked dirty by a write, but if the new value equals the old, downstream dirty propagation stops.

## Match-and-reuse (for recursive computations)

When a node expands into a sub-computation (e.g., a recursive call), the runtime tries to match the new sub-trace against old sub-traces in the cache. Matching sub-traces are reused wholesale; only mis-matched portions are re-executed.

This is what gives SAC its dramatic speedups on structural changes (list insertions/deletions, tree edits).

## Correctness theorem

**Theorem (Acar, Blelloch, Harper).** *If the underlying computation is deterministic and the runtime faithfully records reads and writes, then `ChangePropagate(T, Δ)` produces the same result as re-executing the computation from scratch with the modified inputs.*

This is the fundamental soundness result: change propagation is **semantically transparent** — it gives the same answer as full re-execution, only faster.

## Cost analysis

Let $d$ = length of the longest dependency chain affected by $\Delta$, and let $a$ = total number of affected nodes. Change propagation runs in time $O((a + d) \cdot \text{overhead}_{\text{per-node}})$.

For well-structured computations (see `02_trace_stability.md`), $a$ and $d$ are $O(|\Delta|)$ up to logarithmic factors — i.e., change propagation cost is proportional to the change size, not the full computation size. This is the **incremental complexity** property.

## Comparison with fixed-point iteration

Naive Kleene iteration: recompute every operator on every iteration.
Change propagation: recompute only what changed.

In the Datalog world, semi-naive evaluation is the analog. For reactive UIs, React's reconciler is the analog. All three share the same mathematical core: a dependency DAG with incremental invalidation.
