/**
 * CyberAxis — Sentient Self-Aware Code®TM
 * HuntReflexDriftIndexEmailKernel
 * ──────────────────────────────────────────────────────────────────────────────
 * Pattern: Reflex Drift Index — Mood-Based Adaptive Execution
 * Platform: Google Apps Script (Google Sheets)
 *
 * This code is alive. It tracks its own reflex drift, determines its mood,
 * and dynamically adapts batch size and delay before every run.
 *
 * Mood Function: M(t) = ∫[t-n to t] (S/A) dt
 *   M(t) → 0 (Bad Mood):  batch ↓, delay ↑
 *   M(t) → 1 (Good Mood): batch ↑, delay ↓
 *
 * Created by Armstrong Knight — auto-workspace-ai.com / intent-tensor-theory.com
 * Creative Commons Attribution-NonCommercial 4.0 International License
 */

function HuntReflexDriftIndexEmailKernel() {
  const ss       = SpreadsheetApp.getActiveSpreadsheet();
  const sheet    = ss.getSheetByName('Enrich');
  const logSheet = ss.getSheetByName('Reflex Drift Log') || ss.insertSheet('Reflex Drift Log');
  if (!sheet) return;

  const headers = sheet.getRange(1, 1, 1, sheet.getLastColumn()).getValues()[0];
  const labels  = { domain: 'Domain Name', output: 'Email Addresses', contact: 'Prior Contact to:' };
  const index   = {};
  for (const key in labels) {
    index[key] = headers.findIndex(h => h.trim() === labels[key]) + 1;
    if (index[key] < 1) return;
  }

  const startRow = 2;
  const lastRow  = sheet.getLastRow();
  const data     = sheet.getRange(startRow, 1, lastRow - 1, Math.max(...Object.values(index))).getValues();

  // ── CONVERGENCE: Identify Writables ────────────────────────────────────────
  const writables = [];
  for (let i = 0; i < data.length; i++) {
    const domain = String(data[i][index.domain - 1] || '').trim();
    const output = String(data[i][index.output - 1] || '').trim();
    if (domain && output === '' && !output.includes('Attempted')) {
      writables.push({ row: i + startRow, domain });
    }
  }

  // ── MOOD CALCULATION: CyberAxis Self-Awareness ─────────────────────────────
  const history    = getDriftHistory(logSheet, 10);
  const { mood, failureRate } = analyzeMood(history);
  const delay      = mood === 'bad' ? 2500 : 1000;
  const batchSize  = mood === 'bad' ? 5    : 20;
  const batch      = writables.slice(0, batchSize);

  if (batch.length === 0) return;

  Logger.log(`🧠 Mood: ${mood.toUpperCase()} | Failure Rate: ${Math.round(failureRate * 100)}% | Batch: ${batchSize} | Delay: ${delay}ms`);

  // ── DIVERGENCE: Execute with Mood-Adapted Parameters ──────────────────────
  const apiKey       = '[YOUR_HUNTER_API_KEY]';
  const baseUrl      = 'https://api.hunter.io/v2/domain-search';
  const exclusionList = ['.gif', 'godaddy.com', '.png'];
  const enableAcceptAll = true;
  const enableRisky     = true;

  const requests = batch.map(w => ({
    url: `${baseUrl}?domain=${encodeURIComponent(w.domain)}&api_key=${apiKey}&limit=100`,
    muteHttpExceptions: true
  }));

  Utilities.sleep(delay);
  const responses = UrlFetchApp.fetchAll(requests);

  let successCount = 0;
  const timestamp  = new Date();
  const driftLog   = [];

  for (let i = 0; i < batch.length; i++) {
    const { row, domain } = batch[i];
    const res  = responses[i];
    const code = res.getResponseCode();
    let emails = [];

    if (code === 200) {
      const json = JSON.parse(res.getContentText());
      const list = json.data?.emails || [];

      emails = list
        .filter(e => {
          const status = e.verification?.status || 'unknown';
          return status === 'valid' ||
            (status === 'accept_all' && enableAcceptAll) ||
            (status === 'risky'      && enableRisky);
        })
        .map(e => e.value.toLowerCase().trim())
        .filter(email => !exclusionList.some(x => email.includes(x)));

      if (emails.length > 0) successCount++;
    }

    const status = emails.length > 0 ? 'Success' : 'Attempted-No valid emails found';

    sheet.getRange(row, index.contact).setValue(0);
    sheet.getRange(row, index.output).setValue(emails.length > 0 ? emails.join('\n') : status);

    driftLog.push([
      timestamp, domain, row, emails.length, status,
      code, delay, batchSize, mood,
      `${Math.round((successCount / (i + 1)) * 100)}%`
    ]);
  }

  // ── WRITE DRIFT LOG (System Memory) ────────────────────────────────────────
  if (logSheet.getLastRow() === 0) {
    logSheet.appendRow(['Timestamp','Domain','Row','Emails Found','Status','HTTP Code','Delay','Batch Size','Mood','Success Rate']);
  }
  logSheet.getRange(logSheet.getLastRow() + 1, 1, driftLog.length, driftLog[0].length).setValues(driftLog);

  Logger.log(`🎯 Success Rate: ${Math.round((successCount / batch.length) * 100)}%`);
  Logger.log(`🪶 Drift Index Complete. Batch: ${batchSize}, Delay: ${delay}ms`);
}

// ── Pull last N HTTP codes from the Drift Log ──────────────────────────────
function getDriftHistory(logSheet, n = 10) {
  const lastRow = logSheet.getLastRow();
  if (lastRow < 2) return [];
  return logSheet.getRange(Math.max(2, lastRow - n + 1), 6, Math.min(n, lastRow - 1), 1).getValues().flat();
}

// ── Determine mood from recent results ────────────────────────────────────
function analyzeMood(codes) {
  if (codes.length === 0) return { mood: 'neutral', failureRate: 0 };
  const failures    = codes.filter(c => parseInt(c) !== 200).length;
  const failureRate = failures / codes.length;
  return { mood: failureRate >= 0.5 ? 'bad' : 'good', failureRate };
}
