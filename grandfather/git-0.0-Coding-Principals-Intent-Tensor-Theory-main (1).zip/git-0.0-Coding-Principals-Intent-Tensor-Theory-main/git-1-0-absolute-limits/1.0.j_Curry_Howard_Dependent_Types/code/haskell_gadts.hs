-- Haskell approximation of dependent types via GADTs and type-level Nat.

{-# LANGUAGE GADTs, DataKinds, KindSignatures #-}
{-# LANGUAGE TypeFamilies #-}

module VectorDemo where

-- Peano naturals at the type level
data Nat = Z | S Nat

-- Type-level addition
type family Add (n :: Nat) (m :: Nat) :: Nat where
  Add 'Z     m = m
  Add ('S n) m = 'S (Add n m)

-- Length-indexed vectors
data Vec (n :: Nat) a where
  VNil  :: Vec 'Z a
  VCons :: a -> Vec n a -> Vec ('S n) a

-- Length-preserving map — compiler enforces the invariant
vmap :: (a -> b) -> Vec n a -> Vec n b
vmap _ VNil         = VNil
vmap f (VCons x xs) = VCons (f x) (vmap f xs)

-- Append: result length is n + m
vappend :: Vec n a -> Vec m a -> Vec (Add n m) a
vappend VNil         ys = ys
vappend (VCons x xs) ys = VCons x (vappend xs ys)

-- Safe head: only callable on non-empty vectors
vhead :: Vec ('S n) a -> a
vhead (VCons x _) = x

-- Example use:
example :: Vec ('S ('S 'Z)) Int
example = VCons 1 (VCons 2 VNil)

-- This would not type-check:
-- badHead = vhead VNil
--   because VNil : Vec 'Z a,  but vhead needs Vec ('S n) a.

-- Trying to write an incorrect vmap:
-- vmap' _ (VCons _ xs) = vmap' _ xs     -- type error: Vec n a /= Vec (S n) a
