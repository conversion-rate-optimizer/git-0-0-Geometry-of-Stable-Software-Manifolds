# Multi-Substrate Extension

The extension of the task abstraction to ITT's multi-file-type vision.

## The standard task abstraction

From `00_task_abstraction.md`:

$$
\text{Task}\, c\, k\, v \;=\; \forall f.\; c\, f \Rightarrow (k \to f\, v) \to f\, v.
$$

Each task produces a value of type $v$.

## The constraint-emitting extension

In the ITT multi-substrate vision, each task **not only produces a value but also imposes constraints on other keys**. The extended type:

$$
\text{CTask}\, c\, k\, v \;=\; \forall f.\; c\, f \Rightarrow (k \to f\, v) \to f\, (v \times \text{Constraint}\, k\, v).
$$

Where `Constraint k v` is a set of assertions on other keys' values.

## Build-as-constraint-solving

Now the build function is no longer a topological pass plus dirty-bit checks — it's a **constraint solver**. Given:
- A collection of CTasks (one per key).
- A target key.
- An initial store.

Find a store $s^\star$ such that:
1. Each task's value in $s^\star$ equals its declared output.
2. Each task's emitted constraints are all satisfied by $s^\star$.

This is a **fixed-point computation over the product lattice** of all keys' value spaces.

## Formal statement

Let $\mathcal{S} = \prod_k V_k$ be the global store. Each CTask $T_k$ defines:
- A value-update operator $V_k : \mathcal{S} \to V_k$.
- A constraint-projection operator $C_k : \mathcal{S} \to \mathcal{S}$ enforcing $T_k$'s declared constraints.

The build operator is

$$
F(s) \;=\; \left(\bigcirc_k C_k\right) \circ \left(\bigcirc_k \iota_k \circ V_k\right)(s)
$$

where $\iota_k$ injects the $k$-th value into its slot. The build result is $\operatorname{lfp}(F)$ — i.e., the Kleene iteration until no change across all tasks and constraints.

## What this enables

- **Cross-substrate constraints.** The `.py` file's task can declare "my implementation's contract matches the `.md` file's specification." If either changes, both are rechecked and possibly re-built.
- **Incremental correctness.** Edits to the Markdown spec propagate to Python tests and HTML output in one coordinated pass.
- **Bidirectional edits.** If the HTML output is manually edited, the constraint system can attempt to back-propagate to the underlying source substrates.

## The convergence question

Convergence of the build operator $F$ hinges on the convergence analysis from `1.0.c/math/03_convergence_comparison.md`:
- If all $V_k, C_k$ are monotone on the product lattice, Kleene applies.
- If constraints can *retract* values, we are in the non-monotone regime and must either stratify or accept potential non-termination.

## An open research problem

**What are the natural structural conditions on cross-substrate constraints that guarantee convergence without over-restricting expressivity?**

Standard options:
- **Stratification:** order substrates so later substrates' constraints cannot affect earlier ones.
- **Directed propagation:** constraints point only one way (e.g., .md → .py → .html, no back-edges).
- **Soft constraints only:** replace hard constraints with weighted soft ones; convergence via MaxSAT.
- **Typed constraints:** each constraint has a "level" in a type hierarchy; resolution is stratified by level.

None of these is universally adopted in the build-system literature. There is genuine room for ITT-specific work here.

## What the ITT extension might add

ITT's tensor-field perspective suggests viewing cross-substrate couplings as **vector-valued transport operators** on the product lattice. This gives:
- A geometric formalism (connections, parallel transport) for reasoning about propagation.
- Covariant derivatives of priority fields (how priority changes as you move across substrates).
- Curvature-like obstructions to stratifiability.

Whether this perspective yields concrete theorems remains open, but the formal setup is ready.

## Production-grade skeleton

For practical purposes, the multi-substrate engine can be built today as a layered system:

1. **Per-substrate engines** handling local resolution (e.g., a Markdown parser, a Python AST checker, a DOM validator).
2. **Cross-substrate translators** converting values or constraints across substrates.
3. **A coordinating Kleene loop** iterating until global stability.
4. **A fallback SMT encoding** for the whole system when the Kleene loop does not converge.

This is the architecture shown in `1.0.n_Multi_Substrate_Engine/`.
