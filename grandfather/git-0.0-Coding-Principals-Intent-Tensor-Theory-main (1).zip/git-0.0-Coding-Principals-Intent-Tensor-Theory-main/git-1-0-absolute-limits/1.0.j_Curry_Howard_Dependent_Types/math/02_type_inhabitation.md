# Type Inhabitation and Undecidability

The mathematical ceiling of dependent-type programming.

## Problem statement

**Type inhabitation.** Given a closed type $A$ in a type theory, is there a closed term $t : A$?

Equivalently (via Curry–Howard): given a proposition, is there a proof?

## The theorem

**Theorem.** *Type inhabitation in the Calculus of Inductive Constructions (CIC), or in dependent type theory with sufficient expressive power, is undecidable.*

**Proof sketch.** Encode Peano Arithmetic in type theory: each formula $\varphi$ of PA becomes a type $\llbracket \varphi \rrbracket$, and $\varphi$ is provable in PA iff $\llbracket \varphi \rrbracket$ is inhabited. Provability in PA is undecidable by Gödel's incompleteness / Church's theorem. Hence type inhabitation is undecidable. $\blacksquare$

## What is decidable

- **Type checking:** Given $\Gamma, t, A$, does $\Gamma \vdash t : A$? **Decidable** in CIC (up to handling of axioms).
- **Type inference:** Given $\Gamma, t$, find $A$ such that $\Gamma \vdash t : A$. **Decidable** in CIC.

The asymmetry:
- If you give me a proposed proof, I can verify it in finite time.
- If you give me a theorem, I cannot always find a proof.

This is exactly the NP-style gap (verification vs. search), except here the search is **genuinely undecidable**, not just hard.

## Proof search in practice

Despite undecidability, practical proof search handles enormous amounts of formal mathematics:

- **Hammer tactics:** translate Lean/Rocq goals to first-order logic, call SMT/ATPs (Vampire, E, CVC5), translate back.
- **LeanDojo, DeepSeek-Prover, Lean Copilot:** LLM-guided proof search, often finding proofs humans overlook.
- **Canonical (Norman & Avigad, ITP 2025):** exhaustive type-inhabitation search; 84% success on the Natural Number Game.
- **Mathlib:** 210,000+ theorems formalized by distributed community effort.

None of these are complete — they fail on hard theorems. But they push the frontier practically.

## Proof-irrelevance and strictness

In CIC with `Prop`:
- `Prop` is the universe of **propositions** (logical content).
- Values in `Prop` are proof-irrelevant: two proofs of the same proposition are considered equal.
- This simplifies reasoning and makes some proofs decidable.

**Lean 4** uses **definitional proof irrelevance**: proofs in `Prop` are computationally identified. This affects type checking but keeps it decidable.

## Strong normalization

**Theorem.** *CIC is strongly normalizing: every well-typed term reduces to a normal form in finitely many steps.*

Consequence: **CIC is consistent** — there is no closed term of type $\bot$ (the empty proposition), because any such term would reduce to a normal form, but no normal form inhabits $\bot$.

Strong normalization is why CIC-based theorem provers are trusted as foundations for mathematics.

## Incompleteness

**Gödel's second incompleteness theorem** applies: CIC cannot prove its own consistency within itself. To trust CIC, you must accept consistency as an external axiom (or meta-theoretic proof).

This is the fundamental limit. No system expressive enough to encode arithmetic can prove itself consistent. The theorem applies to Lean, Rocq, Agda, and every other serious proof assistant.

## Computational content

Every constructive proof in CIC is **executable**. Proving `(xs : List Int) -> Σ ys : List Int, Sorted ys ∧ Permutation xs ys` *gives you a sort function* — one that is proved correct by construction.

This is why dependent type theory is both a mathematical foundation and a programming language.

## Practical takeaways

- You **can** encode any invariant as a type and have the compiler verify.
- You **cannot** always automate proof search; you'll write many proofs manually.
- You **can** use modern automation (hammer, rewrite, simp) for tractable sub-goals.
- You **cannot** escape Gödel — every powerful proof system has holes.

The right strategy for dynamic-coding verification is **layered**:
- Small lemmas proved with tactics.
- Medium-size goals discharged by automation.
- Large structures verified by hand with the assistant's help.
- Trust boundary placed at carefully-documented axioms.

This is how Mathlib, Isabelle's AFP, and industrial formal-verification projects (CompCert, seL4, Project Everest) are actually built.
