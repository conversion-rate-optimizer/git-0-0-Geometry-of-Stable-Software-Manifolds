"""
A complete abstract interpreter for a toy IMP-style language,
using the signs abstract domain.

This is a worked example showing:
  - concrete semantics of IMP (sets of integer states).
  - abstract semantics via signs Galois connection.
  - Kleene iteration on the abstract lattice.
  - soundness in action: abstract result over-approximates concrete result.
"""

from typing import Dict
from dataclasses import dataclass

# Signs lattice
BOT, NEG, ZERO, POS, NONPOS, NONNEG, NONZERO, TOP = range(8)
NAMES = ["⊥", "<0", "=0", ">0", "≤0", "≥0", "≠0", "⊤"]


def sign_join(a: int, b: int) -> int:
    """Join in the signs lattice (least upper bound)."""
    if a == BOT: return b
    if b == BOT: return a
    if a == b:   return a
    if a == TOP or b == TOP: return TOP
    # Every other pair: compute union of represented sets.
    # Simplest: precompute a join table.
    table = {
        (NEG, ZERO): NONPOS, (ZERO, NEG): NONPOS,
        (NEG, POS):  NONZERO, (POS, NEG): NONZERO,
        (ZERO, POS): NONNEG, (POS, ZERO): NONNEG,
        (NEG, NONPOS): NONPOS, (NONPOS, NEG): NONPOS,
        (POS, NONNEG): NONNEG, (NONNEG, POS): NONNEG,
        (ZERO, NONPOS): NONPOS, (NONPOS, ZERO): NONPOS,
        (ZERO, NONNEG): NONNEG, (NONNEG, ZERO): NONNEG,
        (NEG, NONNEG): TOP, (NONNEG, NEG): TOP,
        (POS, NONPOS): TOP, (NONPOS, POS): TOP,
        (ZERO, NONZERO): TOP, (NONZERO, ZERO): TOP,
    }
    return table.get((a, b), TOP)


def abs_add(a: int, b: int) -> int:
    """Abstract addition on signs."""
    if a == BOT or b == BOT: return BOT
    if a == ZERO: return b
    if b == ZERO: return a
    if a == POS and b == POS: return POS
    if a == NEG and b == NEG: return NEG
    if a == NONNEG and b == NONNEG: return NONNEG
    if a == NONPOS and b == NONPOS: return NONPOS
    return TOP


def abs_neg(a: int) -> int:
    """Abstract negation: flips signs."""
    mapping = {BOT: BOT, NEG: POS, POS: NEG, ZERO: ZERO,
               NONPOS: NONNEG, NONNEG: NONPOS, NONZERO: NONZERO, TOP: TOP}
    return mapping[a]


# ---------- IMP expressions ----------
@dataclass
class Const: n: int
@dataclass
class Var:   name: str
@dataclass
class Add:   e1: object; e2: object
@dataclass
class Neg:   e: object

Expr = object  # Union of the above


def abs_eval_expr(e: Expr, env: Dict[str, int]) -> int:
    """Abstract evaluation of an expression in a signs environment."""
    if isinstance(e, Const):
        return {POS if e.n > 0 else NEG if e.n < 0 else ZERO}.pop()
    if isinstance(e, Var):
        return env.get(e.name, BOT)
    if isinstance(e, Add):
        return abs_add(abs_eval_expr(e.e1, env), abs_eval_expr(e.e2, env))
    if isinstance(e, Neg):
        return abs_neg(abs_eval_expr(e.e, env))
    raise ValueError(e)


# ---------- IMP statements ----------
@dataclass
class Assign: x: str; e: Expr
@dataclass
class Seq:    s1: object; s2: object
@dataclass
class If:     cond: Expr; then_branch: object; else_branch: object
@dataclass
class While:  cond: Expr; body: object

Stmt = object


def abs_exec(s: Stmt, env: Dict[str, int]) -> Dict[str, int]:
    """Abstract execution of a statement."""
    if isinstance(s, Assign):
        new_env = dict(env)
        new_env[s.x] = abs_eval_expr(s.e, env)
        return new_env
    if isinstance(s, Seq):
        return abs_exec(s.s2, abs_exec(s.s1, env))
    if isinstance(s, If):
        # Without a proper condition analysis, we conservatively
        # execute both branches and join.
        then_env = abs_exec(s.then_branch, env)
        else_env = abs_exec(s.else_branch, env) if s.else_branch else env
        return {k: sign_join(then_env.get(k, BOT), else_env.get(k, BOT))
                for k in set(then_env) | set(else_env)}
    if isinstance(s, While):
        # Kleene iterate the loop body until stable
        cur = env
        for _ in range(100):                                # finite lattice, finite iterations
            next_env = abs_exec(s.body, cur)
            joined = {k: sign_join(cur.get(k, BOT), next_env.get(k, BOT))
                      for k in set(cur) | set(next_env)}
            if joined == cur:
                return cur
            cur = joined
        return cur
    raise ValueError(s)


if __name__ == "__main__":
    # Example: x = 1; while (...) x = x + 1.
    # Concrete: x takes all values 1, 2, 3, ...
    # Abstract (signs): x = POS, stable immediately.
    prog = Seq(
        Assign("x", Const(1)),
        While(Const(1), Assign("x", Add(Var("x"), Const(1))))
    )
    result = abs_exec(prog, {})
    print("Final environment:", {k: NAMES[v] for k, v in result.items()})
