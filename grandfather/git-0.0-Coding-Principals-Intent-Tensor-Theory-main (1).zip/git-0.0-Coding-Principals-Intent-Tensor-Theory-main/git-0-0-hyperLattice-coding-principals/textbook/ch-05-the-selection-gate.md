# Chapter 05 — The Selection Gate

*Read time: 7 minutes*

---

## Two Kinds of Things That Move

Watch a candle flame. The flame moves constantly — it 
flickers, bends in air currents, changes shape. But it 
persists. Ten minutes later the flame is still there.

Now drop a stone in a pond. Ripples spread outward. 
They are real — they have height, they carry energy, 
they reflect off the edges. But they fade. A minute 
later they are gone.

Both the flame and the ripples are real while they exist. 
The difference is one of them persists and one does not.

In a field system, the same distinction exists. Some 
field activations are genuine structure — they persist 
over time. Others are transient fluctuations — they 
appear briefly and decay.

The selection gate is how you tell them apart.

---

## The Measurement

For each node in the field, at each step, compute:

```
S = φ / |φ(now) - φ(previous step)|
```

Read this as: **how large is the value compared to 
how fast it is changing?**

- If φ is large and barely changing: S is very large. 
  The node is stable. It persists.

- If φ is small but changing fast: S is near zero. 
  The node is a transient fluctuation. It will decay.

- If φ is zero: S is zero. The node is not active.

The threshold: **S ≥ 1 means the node is real.**

S < 1 means the node's rate of loss exceeds its 
current value — it is dissolving faster than it exists. 
It will not survive.

---

## Why This Number Works

Think about the bathtub from Chapter 00. Water level 
is high, draining slowly — that tub will be full for 
a long time. Water level is low, draining fast — 
it will be empty soon.

S measures the same thing. It is a persistence ratio: 
*how much is there* divided by *how fast is it going away.*

When S ≥ 1: the structure is retaining itself faster 
than it is losing itself. It counts as real.

When S < 1: the structure is losing itself faster 
than it is sustaining itself. It is a ripple, not a flame.

---

## When to Measure

Here is something the tests revealed directly:

**S is only informative while the field is actively changing.**

At convergence — after the field has settled completely — 
the change between steps is nearly zero. So S becomes 
enormous for every active node. A settled node with 
φ = 0.7 and Δφ = 0.000001 has S = 700,000.

That number tells you nothing useful. Of course a 
settled field is persistent. The interesting measurement 
is during the transient — steps 2 through 10 — when 
the field is still actively spreading and you can see 
which nodes are holding their value versus which are 
just passing the field along to their neighbors.

In the code, the S cap is set at 1000. Not because 
S above 1000 is wrong — it is mathematically correct — 
but because it overflows TypeScript's numbers and 
stops being useful operationally.

---

## What Happens to Nodes That Fail

A node that fails the selection gate (S < 1) is not 
deleted. It is routed to the residue — a record of 
structures that did not persist.

This residue is not garbage. It is memory of what 
was tried and did not survive under the current 
conditions. Under different seeds, different initial 
conditions, or a different connection graph, the 
same structure might persist.

This is how physics works too. A particle configuration 
that is unstable under normal conditions might be 
stable at different energy levels or in a different 
environment. The instability is a property of the 
context, not just of the structure.

---

## The Concrete Code

In `+Z_APEX/bloom_engine.ts`:

```typescript
export function selectionNumber(phi: number, phi_prev: number): number {
  const delta = Math.abs(phi - phi_prev);
  const S = phi / (delta + LATTICE.epsilon_field);
  return Math.min(S, 1000);
}
```

And then:

```typescript
if (S >= SELECTION.persistence) {  // persistence = 1.0
  persistent.push(id);
} else {
  noise.push(id);
}
```

The `LATTICE.epsilon_field = 1e-12` prevents division 
by zero when Δφ is exactly zero.

The `Math.min(S, 1000)` is the cap from the tests — 
prevents overflow at convergence while preserving 
the meaningful gating behavior during transient.

---

## Summary

- S = φ / |Δφ| — field value divided by rate of change
- S ≥ 1: structure persists — it is real
- S < 1: structure dissolves — it is transient noise
- Measure S during the transient (steps 2-10), not at convergence
- Failed nodes go to residue — not deleted, just archived
- Cap at 1000 prevents overflow without changing gate behavior

---

**Previous:** [Chapter 04 — What Is a Matrix?](./ch-04-what-is-a-matrix.md)  
**Next:** [Chapter 06 — What Is a Cycle?](./ch-06-what-is-a-cycle.md)
