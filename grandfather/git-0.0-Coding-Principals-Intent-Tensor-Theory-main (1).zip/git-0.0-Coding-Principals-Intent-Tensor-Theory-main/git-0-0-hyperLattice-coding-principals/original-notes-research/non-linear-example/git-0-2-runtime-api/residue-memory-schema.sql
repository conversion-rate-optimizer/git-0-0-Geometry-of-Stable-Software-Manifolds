-- Memory Zone (-Y): phase residue storage sketch.
create table if not exists phase_residue (
  id bigserial primary key,
  module_key text not null,
  sigma numeric not null,
  context jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);
