"""
Hand-rolled self-adjusting computation in Python using thunks.

Demonstrates:
  - Modifiable cells with subscribers.
  - Dependency tracking via thunk definition.
  - Change propagation via invalidation.
  - Memoization: a thunk recomputes only when marked dirty.
"""

from typing import Callable, Any, List


class Modifiable:
    """A tracked reference cell."""
    def __init__(self, value):
        self.value = value
        self.subscribers: List[Thunk] = []

    def set(self, new_value):
        if self.value != new_value:
            self.value = new_value
            for t in self.subscribers:
                t.invalidate()

    def get(self):
        return self.value


class Thunk:
    """A lazily-evaluated computation node depending on some modifiables."""
    def __init__(self, fn: Callable[[], Any], deps: List[Modifiable]):
        self.fn = fn
        self.deps = deps
        self.cached = None
        self.dirty = True
        for d in deps:
            d.subscribers.append(self)

    def force(self):
        if self.dirty:
            self.cached = self.fn()
            self.dirty = False
        return self.cached

    def invalidate(self):
        self.dirty = True


if __name__ == "__main__":
    x = Modifiable(10)
    y = Modifiable(20)
    z = Thunk(lambda: x.get() + y.get(), [x, y])

    print(f"Initial z = {z.force()}")   # 30
    print(f"Cached  z = {z.force()}")   # 30 — no recomputation

    x.set(99)
    print(f"After x = 99, z = {z.force()}")  # 119

    # Chained thunks
    w = Thunk(lambda: z.force() * 2, [])   # no direct modifiable deps;
                                             # we'd need a proper thunk→thunk tracking
    # For full dependency tracking between thunks, production SAC uses
    # (e.g. Jane Street's Incremental library in OCaml, Adapton in Rust).
