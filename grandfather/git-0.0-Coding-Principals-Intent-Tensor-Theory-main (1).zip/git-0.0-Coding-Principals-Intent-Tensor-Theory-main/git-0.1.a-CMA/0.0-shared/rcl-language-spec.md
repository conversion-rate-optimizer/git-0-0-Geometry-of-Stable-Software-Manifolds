# RCL — Repo Coordinate Language Specification
## Version 1.0

*Created by Armstrong Knight — intent-tensor-theory.com | CC BY-NC 4.0*

---

## Core Axiom

Every object in the repo is addressable by coordinate, not name.

```
R = (x, y, z, t)
```

- x = Domain (Project, Map, Works, Space…)
- y = Function (Dashboard, Social, Services…)
- z = Sub-operation (a, b, c…)
- t = Time (commit / version)

---

## Naming Standard

```
[x.y.z]-[domain]-[function]
```

Rules:
1. Always prefix root repo with `git-0.0-[name]`
2. Use dash (`-`) not underscore — URL-safe, CLI-safe, DNS-safe
3. Coordinate first, label second: `4.2-space-social/`
4. Subcoordinates use letters only: `4.2.a-live/` — no numbers after z-level

---

## Core Commands

```bash
LOC 4.2.a          # Locate physical path
EXEC 4.2.a         # Execute node logic
LABEL 4.2.a        # Return human-readable alias from manifest
PATH 1.2 → 4.2     # Traverse the Social Rail (Curvent)
BROADCAST y=2      # Pulse all domains at function y=2
AGG 1.2 FROM 2..4  # Aggregate satellite data into hub node
LOCK 1.2           # Set node to read-only
WRITE 2.2.a        # Authorize write to node
```

---

## The Dual-Layer Architecture

### Layer 1: Canonical Field (Machine Reality)
Pure numerical grid. No words. No meaning. Only position.

```
git-0.0-app/
├── 1.0/
│   ├── 1.1/
│   └── 1.2/
├── 2.0/
│   └── 2.2/
└── 4.0/
    └── 4.2/
        ├── 4.2.a/
        └── 4.2.b/
```

### Layer 2: Semantic Field (Human Reality)
The manifest.json. Meaning is swappable. Rename "social" to "comms" without moving a single file or breaking a single import.

```json
{
  "1.1": "project-dashboard",
  "1.2": "project-social",
  "4.2.a": "space-social-live",
  "4.2.b": "space-social-threads"
}
```

---

## Stabilization — The Laplacian

A node is Stabilized if `Φ(x,y,z) ≠ ∅`.

- Folder exists → Machine Layer stabilized
- Coordinate mapped in manifest → Human Layer stabilized
- Folder exists without mapping → **Dark Matter** (unlabeled logic)
- Mapping without folder → **Vacuum** (unrealized intent)

---

## Field Operations

### The Curvent (Traversal)
Moving from `1.2 → 2.2 → 3.2 → 4.2`. The Social Rail. One command pulses through every social node because the y coordinate is invariant.

### The Broadcast (Pulse)
```
BROADCAST y=2
```
The engine ignores folder names. It calculates `(x, 2)` for all `x` and injects the data.

### The Aggregation (Fold)
```json
"1.2": {
  "label": "project-social",
  "aggregate": ["2.2", "3.2", "4.2"]
}
```

---

## Stabilization Levels

| Level | Structure | Description |
|-------|-----------|-------------|
| 1 | 2D Grid | Single domain, flat functions |
| 2 | 3D Space | Subcoordinates (z-axis) added |
| 3 | Multi-Domain | Satellite symmetry across all x |
| 4 | Aggregation | Hub folds satellite data |
| 5 | Full Manifold | Permissions + state + broadcast |
| 6 | Execution Space | Full RCL engine running |

---

## GitCMA System Laws

1. **Positional Invariance** — A coordinate must never change once established.
2. **Semantic Separation** — Meaning must never exist inside the coordinate path.
3. **Axis Consistency** — y-axis represents invariant function across all x domains.
4. **Traversability** — Any coordinate is reachable through deterministic calculation.
5. **Writable Singularity** — Every execution path starts and ends as a writable.
6. **Ghostless Naming** — Every identifier is semantically complete. Zero ambiguity.

---

## The RCL Resolver (JavaScript)

```javascript
function resolve(coordinate) {
  const [x, y, z] = coordinate.split('.');
  const domain = DOMAINS[x];
  const func   = FUNCTIONS[y];
  const sub    = z ? `/${x}.${y}.${z}` : '';
  return `/${x}.0-${domain}/${x}.${y}-${domain}-${func}${sub}`;
}
```

Example:
```
resolve("4.2.a")  →  /4.0-space/4.2-space-social/4.2.a-live
```

---

## The Final Truth

```
Structure = Position
Meaning   = Mapping

R(x,y,z) ⊥ M(x,y,z)
```

By separating position from meaning, we eliminate semantic entropy and enable deterministic traversal, aggregation, and execution across repository space.

You are no longer a Folder Manager. You are a Field Operator.
