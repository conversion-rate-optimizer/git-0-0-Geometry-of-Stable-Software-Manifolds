# MaxSAT and Weighted CSP

Priority and soft constraints formalized.

## Partial MaxSAT

Given a CNF formula with:
- **Hard clauses** $H_1, \ldots, H_k$ (must all be satisfied).
- **Soft clauses** $S_1, \ldots, S_m$ with weights $w_1, \ldots, w_m$ (satisfy as many as possible, weighted).

Find an assignment $\alpha$ satisfying all $H_i$ and maximizing $\sum_{i: \alpha \models S_i} w_i$ (equivalently, minimizing $\sum_{i: \alpha \not\models S_i} w_i$).

## Complexity

- **MaxSAT (pure, no hard):** NP-hard; $\text{FP}^\text{NP}$-complete (functional optimization in the polynomial hierarchy).
- **Partial MaxSAT:** NP-hard; inherits complexity from SAT.
- **Weighted MaxSAT:** Same.

## Algorithms

### Core-guided MaxSAT

Classic approach (Morgado, Heras, Marques-Silva, 2014):

1. Assume all soft clauses hold.
2. If SAT, done.
3. If UNSAT, extract an **unsatisfiable core** — a minimal set of clauses whose conjunction is unsatisfiable.
4. Relax one clause in the core (subtract its weight from the objective).
5. Repeat.

Core-guided solvers (MaxHS, MSCG, Open-WBO) dominate recent MaxSAT competitions.

### Linear MaxSAT (upper-bound refinement)

Maintain an upper bound $U$ on the objective. Solve the SAT problem "is there an assignment with cost $\leq U$?" If SAT, decrement $U$; if UNSAT, done.

### Branch-and-bound

Maintain partial assignments and propagate lower bounds on the remaining cost. Prune whenever the lower bound exceeds the best-known solution.

## Weighted Constraint Satisfaction Problems (WCSP)

A **WCSP** generalizes:
- Variables $X_1, \ldots, X_n$ with finite domains $D_1, \ldots, D_n$.
- **Soft constraints**: $\varphi_i : \prod_{j \in \text{scope}(i)} D_j \to \mathbb{R}_{\geq 0} \cup \{+\infty\}$.

Goal: find assignment minimizing $\sum_i \varphi_i(x_{\text{scope}(i)})$.

$+\infty$ encodes hard constraints (any assignment making some $\varphi_i = \infty$ is forbidden).

### Special cases
- **CSP:** all $\varphi_i \in \{0, \infty\}$.
- **MaxSAT:** $\varphi_i \in \{0, w_i\}$.
- **Max-CSP:** $\varphi_i \in \{0, 1\}$, minimize violations.
- **Markov Random Fields:** arbitrary real $\varphi_i$, probabilistic interpretation.

### WCSP complexity

- **Decision** (is min cost $\leq k$?): NP-complete.
- **Bounded tree-width WCSPs:** polynomial (junction tree algorithm).
- **Arbitrary structure:** exponential in worst case.

## Lexicographic priorities

Your ITT engine's priority system is **lexicographic weighted MaxSAT**:

- Priority levels $L_1 > L_2 > \cdots > L_k$.
- Within each level, a set of soft clauses with weights.
- Solution: find assignment minimizing $(c_1, c_2, \ldots, c_k)$ in lexicographic order, where $c_i$ is the cost at level $L_i$.

This is the formal statement of "higher priority overrides lower."

### Encoding lex-MaxSAT in Z3

```python
from z3 import Optimize, Bool

opt = Optimize()
# ... assertions ...

# Priority level 100 (highest):
opt.add_soft(constraint_A, weight=1, id="high")
# Priority level 10:
opt.add_soft(constraint_B, weight=1, id="low")

opt.set('priority', 'lex')  # lexicographic optimization
opt.check()
```

Z3's `Optimize` object supports lex-MaxSAT natively. The `id` argument groups soft constraints into priority levels; `priority=lex` requests lexicographic resolution.

## The energy formulation

Rewriting WCSP as a single objective:

$$
E(x) \;=\; \sum_i \varphi_i(x_{\text{scope}(i)})
$$

$$
x^\star \;=\; \arg\min_x E(x).
$$

This is the **Boltzmann / Markov Random Field** perspective. Under the probabilistic interpretation

$$
P(x) \propto \exp(-\beta \cdot E(x)),
$$

minimizing $E$ corresponds to maximum-likelihood inference. This connects constraint satisfaction to probabilistic graphical models.

## Practical takeaway

For your engine:
- **Hard constraints only** → use SAT/SMT directly.
- **Priorities** → use MaxSAT with lexicographic levels (or Z3's `Optimize`).
- **Real-valued soft costs** → use WCSP solvers (toulbar2, the UAI libraries).
- **Probabilistic interpretation** → use graphical model inference (belief propagation, junction tree, MCMC).

The choice determines not only what you can express but what guarantees your engine gives. All four are well-trodden paths with mature tooling.
