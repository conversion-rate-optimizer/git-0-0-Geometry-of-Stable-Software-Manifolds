/**
 * 0.3_COMPETITION: Cycle Competition Engine
 * ==========================================
 * Implements Lotka-Volterra-style competition between persistent cycles.
 *
 * The core law:
 *   dM_Ck/dt = M_Ck * (S_Ck - 1) - γ * Σ_{j≠k} Ω(Ck, Cj)
 *
 * Where:
 *   M_Ck  = Σ_{i ∈ C} φ_i         (cycle mass — total activation)
 *   S_Ck  = Σφ / Σ|Δφ|             (persistence ratio)
 *   Ω     = Σ_{i ∈ Ca ∩ Cb} φ_i   (shared energy = interference)
 *   γ     = competition strength
 *
 * Why this matters:
 *   Without competition, all S ≥ 1 cycles survive simultaneously.
 *   With competition, cycles fight for a finite φ_total.
 *   Only the most persistent structure under pressure is real.
 *
 * This is what separates field-solving from selection.
 */

import { SELECTION, LATTICE } from "../-Z_BASE/axioms";

export interface CycleState {
  nodes: string[];
  S: number;           // Persistence ratio
  mass: number;        // Σφ
  dMass: number;       // Net mass change this round
  overlap: number;     // Total overlap penalty
  isWinner: boolean;   // S ≥ 1 AND dMass > 0
}

/** Competition strength — how hard cycles fight over shared nodes */
const GAMMA = 0.15;

/**
 * Compute mass of a cycle: Σ_{i ∈ C} φ_i
 */
function cycleMass(nodes: string[], phi: Map<string, number>): number {
  return nodes.reduce((sum, id) => sum + (phi.get(id) ?? 0), 0);
}

/**
 * Persistence ratio: S_C = Σφ / Σ|Δφ|
 * Capped at 1000 — same reason as node-level S.
 */
function cycleS(
  nodes: string[],
  phi: Map<string, number>,
  phi_prev: Map<string, number>
): number {
  const phi_sum = cycleMass(nodes, phi);
  let delta_sum = LATTICE.epsilon_field;
  for (const id of nodes) {
    delta_sum += Math.abs((phi.get(id) ?? 0) - (phi_prev.get(id) ?? 0));
  }
  return Math.min(phi_sum / delta_sum, 1000);
}

/**
 * Overlap between two cycles: Σ_{i ∈ Ca ∩ Cb} φ_i
 * This is the energy cycles are fighting over.
 */
function overlap(
  nodesA: string[],
  nodesB: string[],
  phi: Map<string, number>
): number {
  const setA = new Set(nodesA);
  let shared = 0;
  for (const id of nodesB) {
    if (setA.has(id)) shared += (phi.get(id) ?? 0);
  }
  return shared;
}

/**
 * Run one full competition round across all cycles.
 *
 * Returns cycle states with dMass computed — positive = growing,
 * negative = losing. Winner = S ≥ 1 AND dMass > 0.
 */
export function competitionRound(
  cycles: string[][],
  phi: Map<string, number>,
  phi_prev: Map<string, number>,
  gamma: number = GAMMA
): CycleState[] {
  const states: CycleState[] = cycles.map(nodes => ({
    nodes,
    S: cycleS(nodes, phi, phi_prev),
    mass: cycleMass(nodes, phi),
    dMass: 0,
    overlap: 0,
    isWinner: false,
  }));

  // Compute dMass for each cycle
  for (let k = 0; k < states.length; k++) {
    const c = states[k];

    // Interaction penalty: γ * Σ_{j≠k} Ω(Ck, Cj)
    let totalOverlap = 0;
    for (let j = 0; j < states.length; j++) {
      if (j === k) continue;
      totalOverlap += overlap(c.nodes, states[j].nodes, phi);
    }

    c.overlap = totalOverlap;
    c.dMass = c.mass * (c.S - 1) - gamma * totalOverlap;
    c.isWinner = c.S >= SELECTION.cycle_persistence && c.dMass > 0;
  }

  return states.sort((a, b) => b.S * b.mass - a.S * a.mass);
}

/**
 * Dominant cycle: argmax_C (S_C * M_C)
 * The single strongest structure under competition.
 */
export function dominantCycle(states: CycleState[]): CycleState | null {
  const winners = states.filter(c => c.isWinner);
  if (winners.length === 0) return null;
  return winners.reduce((best, c) =>
    c.S * c.mass > best.S * best.mass ? c : best
  );
}

/**
 * THE COLLAPSE RULE — non-negotiable.
 *
 * Nodes not in any winning cycle decay.
 * Without this: losers never die, system never resolves.
 * With this: only persistent structures survive.
 */
export function enforceDecay(
  allNodes: string[],
  winners: CycleState[],
  phi: Map<string, number>,
  decayFactor: number = 0.1
): Map<string, number> {
  const winningNodes = new Set(winners.flatMap(c => c.nodes));
  const updated = new Map(phi);

  for (const id of allNodes) {
    if (!winningNodes.has(id)) {
      updated.set(id, (phi.get(id) ?? 0) * decayFactor);
    }
  }

  return updated;
}
