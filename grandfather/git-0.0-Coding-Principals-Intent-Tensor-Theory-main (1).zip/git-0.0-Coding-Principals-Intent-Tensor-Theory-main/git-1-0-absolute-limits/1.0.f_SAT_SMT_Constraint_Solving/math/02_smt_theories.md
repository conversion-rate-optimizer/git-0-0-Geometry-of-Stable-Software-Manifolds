# SMT Theories

The collection of first-order theories with decidable (or at least usefully-incomplete) satisfiability procedures.

## The SMT-LIB logics

The **SMT-LIB** standard defines a set of "logics" — combinations of theories — with names like `QF_LIA`, `QF_BV`, `QF_UF`, etc. The prefix `QF_` means quantifier-free.

### Core theories

- **T_UF** — **Uninterpreted functions with equality.** Symbols like $f, g$ whose semantics is only "$f(a) = f(b) \Leftarrow a = b$."
  - **Decision procedure:** congruence closure.
  - **Complexity:** PTIME (quantifier-free).

- **T_LIA** — **Linear integer arithmetic.** Atoms like $\sum_i a_i x_i \bowtie b$ for integer $x_i$, $\bowtie \in \{\leq, <, =, \neq\}$.
  - **Decision procedure:** Omega test, or specialized solvers (MCSat).
  - **Complexity:** NP-complete (quantifier-free). Decidable but PSPACE-hard with quantifiers.

- **T_LRA** — **Linear real arithmetic.** Atoms like $\sum_i a_i x_i \bowtie b$ for real $x_i$.
  - **Decision procedure:** Simplex.
  - **Complexity:** In P (decision); NP-hard under mixed-integer extension.

- **T_BV** — **Fixed-width bit-vectors.** Atoms like $\text{bvadd}(x, y) = z$ for $n$-bit vectors.
  - **Decision procedure:** bit-blasting + SAT, or specialized lazy procedures.
  - **Complexity:** NP-complete.

- **T_A** — **Arrays.** $\text{select}(a, i)$ and $\text{store}(a, i, v)$ with McCarthy axioms.
  - **Decision procedure:** reductions via congruence + combination.
  - **Complexity:** Varies by extension (NP-complete for the basic quantifier-free theory).

- **T_Strings** — **Strings.** Concatenation, length, substring. Decidability depends on which operations; **word equations with length constraints are undecidable in general**.

### Undecidable fragments

- **T_NIA** — **Non-linear integer arithmetic.** Undecidable (Matiyasevich's resolution of Hilbert's 10th problem).
- **T_NRA** — **Non-linear real arithmetic.** Decidable (Tarski–Seidenberg) but doubly-exponential.
- **Quantifier-laden arithmetic** with uninterpreted functions: generally undecidable.

## Theory solvers

Each theory $T$ has a **theory solver** — a procedure that, given a conjunction of $T$-literals, decides $T$-satisfiability.

- **T_UF solver:** congruence closure. Given equalities $a = b$ and function applications, propagate congruences.
- **T_LRA solver:** Simplex method. Given linear inequalities, find a satisfying point.
- **T_LIA solver:** branch-and-cut, Omega elimination, or MCSat.
- **T_BV solver:** bit-blasting (convert to SAT) or lazy bit-vector reasoning.
- **T_A solver:** axiom instantiation + congruence closure.

## Combining theories

Real SMT problems mix theories: `(x > 0) ∧ (a[x] = f(x))` involves $T_\text{LIA} + T_\text{A} + T_\text{UF}$.

**Nelson–Oppen combination** (see `03_nelson_oppen.md`) provides a general method for combining *stably infinite* decidable theories with disjoint signatures. The combined theory is decidable if each component is.

**Modern solvers** use variants:
- **DPLL(T) with theory combination:** Z3's architecture.
- **MCSat:** Model-Constructing Satisfiability — a newer alternative that avoids some Nelson–Oppen limitations.

## Quantifier handling

**Quantifier-free fragments** are usually decidable (or tractably undecidable).

**With quantifiers**, most theories become undecidable or semi-decidable. SMT solvers use:

- **E-matching:** syntactic pattern matching to instantiate quantifiers heuristically.
- **Model-based quantifier instantiation (MBQI):** construct a candidate model and instantiate quantifiers to refute or confirm.
- **Enumeration:** for small domains, try all instantiations.

None of these is complete in general; SMT solvers often return `unknown` on quantified problems.

## Practical notation

The SMT-LIB v2 format is the lingua franca:

```lisp
(set-logic QF_LIA)
(declare-const x Int)
(declare-const y Int)
(assert (= (+ x y) 10))
(assert (< x y))
(check-sat)
(get-model)
```

Every SMT solver (Z3, cvc5, MathSAT, Yices, Bitwuzla) accepts this input format.

Python wrappers:
```python
from z3 import Solver, Int, sat

x, y = Int('x'), Int('y')
s = Solver()
s.add(x + y == 10, x < y)
print(s.check(), s.model() if s.check() == sat else None)
```

## When to use which theory

| Problem type                                    | Theory              |
|-------------------------------------------------|---------------------|
| Straight logical constraints                    | Propositional SAT   |
| Arithmetic constraints with integer variables   | QF_LIA              |
| Arithmetic with reals (LP-style)                | QF_LRA              |
| Machine-word arithmetic (overflow, bitwise)     | QF_BV               |
| Program semantics with memory                   | QF_AUFBV            |
| Higher-order specifications                     | HO-SMT (newer)      |
| String manipulation                             | QF_S (limited)      |
| Mixed integer-real                              | QF_LIRA             |

For the ITT Intent Engine: most realistic constraint systems live in `QF_LIA + QF_UF` or `QF_BV + QF_UF`. Z3 and cvc5 handle both natively.

## The ceiling in practice

Undecidability and complexity of SMT surface as:
- `unknown` responses from the solver.
- Timeouts.
- Exponential solve times on seemingly innocent problems.

The solver's `unknown` is **the code-level manifestation of the mathematical ceiling** — it is the same statement as "this theory has no decision procedure" compiled into a concrete output.
