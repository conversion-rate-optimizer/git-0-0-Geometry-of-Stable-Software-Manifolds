# Chapter 07 — The Bloom

*Read time: 8 minutes*

---

## When Structure Outpaces Disorder

A seed planted in soil does not just stay the same 
size. Under the right conditions, it grows — it adds 
structure faster than entropy breaks it down. Cells 
divide, organize, differentiate. Order emerges from 
what looked like chaos.

Under the wrong conditions — wrong soil, wrong 
temperature, too little water — the seed does not 
grow. It sits or decays.

The difference is a ratio: how fast is structure 
being built versus how fast disorder is eating it?

When the building rate exceeds the breakdown rate, 
you get growth. When it does not, you get stasis or decay.

In this system, the moment that ratio exceeds 1 
is called the **Bloom**.

---

## The Bloom Quotient Q

The bloom quotient Q measures exactly this ratio:

```
Q = (structure being enforced) / (disorder in the field)
```

More precisely:

```
Q = A_total / (Θ × [η₁ × Var(φ) + η₂ × H(φ)])
```

**Numerator — structure being enforced:**
`A_total` is the sum of the absolute graph Laplacian 
values across all nodes — how much the field is 
actively being shaped, pulled, organized at this moment.
When the field is settling into a coherent structure, 
this is high. When the field has already fully settled, 
this drops toward zero.

**Denominator — disorder in the field:**
Two kinds of disorder, because they are genuinely different:

- `Var(φ)` — **spatial disorder**: how spread out are 
  the φ values? A field with one high node and many 
  low nodes has low variance. A field with values 
  scattered randomly has high variance.

- `H(φ)` — **distributional disorder** (Shannon entropy): 
  how fragmented is the field? Even if variance is low, 
  a field split evenly across many nodes is fragmented — 
  no coherent center, no dominant structure.

**The threshold:** Q > 1.1 is a Bloom.

---

## Why Both Disorder Terms Are Necessary

This was confirmed by the tests. Here is the specific case 
that demonstrates it:

**Field A** — one strong node: `[0.9, 0.05, 0.03, 0.02]`  
Variance: low (dominated by one node)  
Entropy: low (one node has almost all the probability mass)  
Q = 2.09 → **BLOOM**

**Field B** — evenly spread: `[0.25, 0.25, 0.25, 0.25]`  
Variance: low (all values similar)  
Entropy: **high** (four nodes share probability equally — maximum fragmentation)  
Q = 0.00 → **NO BLOOM**

If you only used variance, Fields A and B would look 
similar — both have low variance. The entropy term is 
what correctly identifies Field B as fragmented and 
incoherent, preventing a false bloom signal.

A coherent field concentrates in a meaningful way. 
A fragmented field is evenly spread with no center. 
The combination of variance and entropy distinguishes them.

---

## Shannon Entropy — What It Measures

Claude Shannon developed information entropy in 1948 
to measure how unpredictable a message is.

For a probability distribution p, entropy is:
```
H = -Σ p_i × log(p_i)
```

Low entropy: one outcome dominates, the result is predictable.  
High entropy: outcomes are evenly spread, result is unpredictable.

In this system, the "probability distribution" is 
the field values normalized by their sum:
```
p_i = φ_i / (sum of all φ values)
```

High entropy in the field means: activation is spread 
evenly across many modules with no coherent center. 
The system has not organized around anything.

Low entropy means: a few modules dominate, the field 
has a clear structure. The system has found something 
to organize around.

The Bloom requires *low disorder in both senses* — 
coherent spatially (low variance) and coherent 
distributionally (low entropy).

---

## After the Bloom

When Q > 1.1, the module that caused the bloom is 
granted permission to spawn sub-structures — to 
define new coordinate axes within the manifold, 
to influence the topology of the system itself.

This is the code equivalent of the seed that has 
germinated. It is no longer just surviving. It is 
growing. It can now affect its environment rather 
than just existing within it.

In the code, `+Z_APEX/bloom_engine.ts` handles 
this transition. The `isBloom` flag signals that 
a module has crossed from persistence into emergence.

---

## What Q Looks Like Over Time

During the transient (the field actively spreading):
- A_total is high — lots of structure being enforced
- If the field is organizing coherently, disorder is falling
- Q rises

At convergence (field settled):
- A_total drops toward zero — field is no longer changing
- Q drops toward zero

The bloom signal appears during the transition, not at rest. 
This is the natural window — the moment of organization — 
where Q is meaningful. A bloom that completes before 
convergence indicates the field organized coherently. 
A field that converges without blooming organized 
into something too fragmented or too uniform to sustain 
the structure-building ratio above 1.

---

## Summary

- Q = structure enforced / disorder present
- Q > 1.1 is a Bloom — structure is outpacing disorder
- Numerator: graph Laplacian action (how much shaping is happening)
- Denominator: variance + entropy (two different kinds of disorder)
- Entropy is necessary — variance alone misses fragmented fields
- Bloom occurs during the transient, not at convergence
- Post-bloom: module can influence the manifold topology

---

**Previous:** [Chapter 06 — What Is a Cycle?](./ch-06-what-is-a-cycle.md)  
**Next:** [Chapter 08 — Into the Code](./ch-08-into-the-code.md)
