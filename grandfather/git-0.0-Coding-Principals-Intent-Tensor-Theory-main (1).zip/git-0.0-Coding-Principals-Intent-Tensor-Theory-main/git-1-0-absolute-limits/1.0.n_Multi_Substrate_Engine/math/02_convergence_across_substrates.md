# Convergence of the Multi-Substrate Engine

When does the coupled engine converge?

## The main theorem

**Theorem.** *Let the coupled engine operator be*

$$
F \;=\; \left(\bigcirc_{(i,j)} \tilde \alpha_{ij}\right) \circ \left(\bigcirc_i \hat F_i\right)
$$

*on the product lattice $\mathcal{S} = \prod_i \mathcal{S}_i$. If:*

1. *Each $F_i$ is Scott-continuous on $\mathcal{S}_i$, and*
2. *Each $\alpha_{ij}$ is Scott-continuous on $\mathcal{S}_i \to \mathcal{S}_j$,*

*then $F$ is Scott-continuous on $\mathcal{S}$, and*

$$
\operatorname{lfp}(F) = \bigvee_n F^n(\bot).
$$

*The engine terminates in countably many steps.*

**Proof.** Scott-continuity of $\hat F_i$ follows from Scott-continuity of $F_i$ (injection and projection are Scott-continuous). Scott-continuity of $\tilde \alpha_{ij}$ follows from Scott-continuity of $\alpha_{ij}$. Composition of Scott-continuous operators is Scott-continuous. Apply Kleene. $\blacksquare$

## The convergence rate

Let $H_i = $ height of $\mathcal{S}_i$ (length of longest ascending chain). Let $H = \sum_i H_i$.

**Corollary.** *If each $\mathcal{S}_i$ has finite height, $F$ reaches its fixed point in at most $H$ iterations of the outer loop.*

This gives a computable bound on convergence. For finite-domain substrates (bounded Boolean state, bounded enum, ...), this is immediately applicable.

## Non-monotone substrates

If some substrate operator $F_i$ is non-monotone (e.g., has retractive constraints), the global engine inherits non-monotonicity and may oscillate.

**Strategies:**
1. **Stratify within each substrate.** Ensure each $F_i$ is monotone within its internal run, even if individual constraints are not.
2. **Stratify across substrates.** Run translators only in specific directions (e.g., .md → .py → .html one-way); no feedback edges.
3. **SMT backend.** Encode the whole product system as a single SMT problem and let the solver handle inconsistencies.

## The acyclic case

If the cross-substrate translator graph is a DAG (no cycles), the engine converges trivially:
- Topologically sort substrates.
- Resolve each in order, using translators to propagate from resolved substrates.
- No iteration needed.

**This is the multi-substrate build system.** One pass through a topological sort.

## The cyclic case

If the translator graph has cycles (bidirectional propagation), Kleene iteration is required. The convergence theorem above applies — assuming Scott-continuity.

If Scott-continuity fails (retractive constraints), consider:
- Does the cycle actually need to be cyclic? Often bi-directional propagation can be split into two directional passes.
- Can conflicts be resolved by priority (weighted MaxSAT)?
- Can inconsistent cycles be caught early and reported as errors?

## Incremental maintenance

Once the product engine is established, its results can be maintained incrementally via SAC (§1.0.g) or DBSP (§1.0.h):

- **SAC variant.** Track cross-substrate edges in the dependency graph. When any substrate changes, invalidate downstream nodes.
- **DBSP variant.** Model each substrate's state as a Z-set. Translators become linear / bilinear operators. The whole product is incrementally maintainable.

For production deployment, incremental maintenance is essential — full re-resolution on every edit is too expensive.

## The ICHTB-like observation

Cross-substrate resolution involves a **precision–responsiveness trade-off**:
- More precise translators (tight couplings) → slower convergence, more oscillation risk.
- Looser translators (weak couplings) → fast convergence but weaker consistency.

This is structurally analogous to ITT's ICHTB uncertainty relation. Formalizing it as a theorem — "precision × speed ≤ constant" for certain classes of translators — is an open research direction (see `03_open_questions.md`).

## Implementation checklist

For a convergent multi-substrate engine:

- [ ] Each substrate's local engine is monotone (or at least stratified).
- [ ] Each substrate's state lattice has finite height (or widening is applied).
- [ ] Cross-substrate translators are monotone.
- [ ] Translator graph is acyclic, OR cycles have a convergence plan.
- [ ] Outer Kleene loop has a `maxIter` safeguard.
- [ ] Oscillation detection logs state history.
- [ ] Fallback SMT encoding is available for hard cases.

A system meeting these can be trusted; one violating them cannot.

## The formal novelty claim

**No production build system** treats cross-substrate constraints as first-class mathematical objects. The nearest literature is:
- **Shake / Bazel:** monadic tasks, but constraints are dependencies, not assertions.
- **Nix:** content-addressed derivations, but no cross-substrate constraint propagation.
- **IDE cross-references:** ad-hoc, not formalized.

The formalism of this chapter gives multi-substrate engines a **proper mathematical foundation**. The open question is what additional structure (groupoid laws on translators, tensor-valued priorities, HoTT-style equivalences) yields the best practical engines. This is where ITT's perspective might contribute.
