# Chapter 00 — Before the Math

*Read time: 5 minutes*

---

## What Math Actually Is

Most people are taught math as a set of rules to follow. Multiply these. 
Solve for x. Use this formula. The rules work, but nobody explains where 
the rules came from.

Here is where they came from: **someone watched something happen, over and 
over, and noticed a pattern. Then they wrote the shortest possible 
description of that pattern.**

That is all math is. Compressed observation.

---

## An Example From Real Life

Watch water drain from a bathtub. The closer the water level gets to the 
drain, the slower it drains. If there is a lot of water, it drains fast. 
If there is almost no water, it drains very slowly.

Someone watched this and wrote:

> *The rate of draining depends on how much water is there.*

Then they made it shorter:

> *rate = k × amount*

Then they made it even shorter with symbols:

> *dV/dt = −kV*

That is a differential equation. It says: the rate of change of volume (dV/dt) 
equals negative k times the current volume. The minus sign means it is 
going down. k is just a number that describes how fast your particular 
drain is.

Every differential equation in this repository came from exactly this 
process — someone watched something and wrote the shortest honest 
description of what they saw.

---

## Why This Matters for the Code

The code in this repository implements equations. But if you do not know 
what the equations are describing, the code looks like magic. Or worse — 
it looks arbitrary, like someone just chose these numbers because they 
sounded impressive.

They did not. Every constant, every formula, every function has a reason.

This textbook explains the reasons.

---

## What You Need to Bring

Nothing except the ability to read and a willingness to sit with 
something unfamiliar for a few minutes before deciding you do not 
understand it.

You do not need to know algebra. You do not need to have taken calculus. 
You do not need to know what a matrix is. You do not need to know 
what a field is.

Those are all in the next chapters.

---

## One Thing to Hold Onto

Before you read anything else in this textbook, hold onto this one idea:

**Every equation describes something you could watch.**

When you see an equation and do not understand it, ask: *what would I 
see if I were watching the thing this equation describes?* 

The answer to that question is always simpler than the equation looks.

---

**Next:** [Chapter 01 — What Is a Field?](./ch-01-what-is-a-field.md)
