# Monotone, Scott-Continuous, and Contractive Functions

The three regularity conditions that drive the three master fixed-point theorems.

## Monotone functions

**Definition.** Let $(L, \leq)$ be a poset. A function $f : L \to L$ is **monotone** (or **order-preserving**) iff

$$
\forall x, y \in L.\; x \leq y \;\Rightarrow\; f(x) \leq f(y).
$$

### Consequences

1. **Composition.** If $f$ and $g$ are monotone, so is $f \circ g$.
2. **Iteration.** For any $x \in L$ with $x \leq f(x)$, the sequence $x, f(x), f^2(x), \ldots$ is non-decreasing.
3. **Chain preservation.** Monotone functions send chains to chains.

### The Knaster–Tarski regime

On a complete lattice, monotonicity alone suffices for the existence of fixed points (see `1.0.c/math/00_knaster_tarski.md`). No continuity is needed. The price: the theorem is non-constructive — it proves $\operatorname{lfp}(f)$ exists but does not give a computable procedure to reach it.

## Scott-continuous functions

**Definition.** Let $(L, \leq)$ be a DCPO. A function $f : L \to L$ is **Scott-continuous** iff for every directed subset $D \subseteq L$,

$$
f\left(\bigvee D\right) \;=\; \bigvee f(D),
$$

where $f(D) = \{f(x) : x \in D\}$.

### Consequences

1. **Scott-continuity implies monotonicity.** Proof: $\{x, y\}$ with $x \leq y$ is directed; its sup is $y$; so $f(y) = f(\bigvee \{x, y\}) = \bigvee f(\{x, y\}) = f(x) \vee f(y)$, hence $f(x) \leq f(y)$.
2. **Composition of Scott-continuous functions is Scott-continuous.**
3. **The set of Scott-continuous functions** on a DCPO forms a DCPO under pointwise order.

### The Kleene regime

On a pointed DCPO, Scott-continuity of $f$ guarantees that $\operatorname{lfp}(f) = \bigvee_{n \geq 0} f^n(\bot)$ — the least fixed point is reached as the sup of the iteration chain from $\bot$. This is the constructive fixed-point theorem.

## Contractive functions

**Definition.** Let $(X, d)$ be a metric space. A function $f : X \to X$ is a **contraction** (with **contraction factor** $q \in [0, 1)$) iff

$$
\forall x, y \in X.\; d(f(x), f(y)) \;\leq\; q \cdot d(x, y).
$$

### Consequences

1. Contractions are continuous (in the metric-topology sense).
2. Contractions are injective (except when $X$ is a single point).
3. On a complete metric space, every contraction has a unique fixed point (Banach).

### The Banach regime

Banach's theorem gives not only existence and uniqueness but an exponential convergence rate:

$$
d(f^n(x_0), x^\star) \leq \frac{q^n}{1-q} \cdot d(x_1, x_0).
$$

This is the fixed-point framework used in numerical methods (Newton's method, Picard iteration for ODEs, gradient-descent-like schemes).

## Relationships between the three

| Condition          | Needs                      | Existence? | Unique? | Constructive? | Rate?     |
|--------------------|----------------------------|------------|---------|---------------|-----------|
| Monotone           | Complete lattice           | Yes        | No      | No (in general)| —        |
| Scott-continuous   | Pointed DCPO               | Yes        | No      | Yes           | Countable|
| Contractive        | Complete metric space      | Yes        | Yes     | Yes           | $O(q^n)$  |

**Chain of implications (roughly, on appropriate domains):**

Contractive $\Rightarrow$ Scott-continuous (after suitable topology) $\Rightarrow$ Monotone.

## Why we care about the distinctions

The choice of which theorem applies to your engine determines what you can promise:

- If your operator is only monotone, you can promise: *"a fixed point exists, but iterating may not reach it."*
- If it is Scott-continuous, you can promise: *"iterating from $\bot$ converges to the least fixed point in countably many steps."*
- If it is a contraction, you can promise: *"iterating from *any* point converges to *the* fixed point, with a known rate."*

Most real engines (Datalog, reactive systems, constraint propagation) operate in the Scott-continuous regime. Numerical simulations operate in the Banach regime. SMT solvers and ASP solvers operate outside this framework entirely (they use search, not iteration), but *their correctness* is still expressed via fixed points of the lattice of candidate models.
