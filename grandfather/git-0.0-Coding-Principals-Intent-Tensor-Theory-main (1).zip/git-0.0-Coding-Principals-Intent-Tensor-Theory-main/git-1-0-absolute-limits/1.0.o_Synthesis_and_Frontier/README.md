# 1.0.o — Synthesis and Frontier

The final folder: cheat sheet, master equation table, frontier directions.

## Files

- `00_master_cheat_sheet.md` — The equation-to-syntax master table.
- `01_equations_that_drive_the_frontier.md` — One-pager of every theorem in this chapter.
- `02_novel_directions_for_itt.md` — Where ITT could genuinely contribute.
- `03_checklist_for_dynamic_engines.md` — Production-grade engineering checklist.
