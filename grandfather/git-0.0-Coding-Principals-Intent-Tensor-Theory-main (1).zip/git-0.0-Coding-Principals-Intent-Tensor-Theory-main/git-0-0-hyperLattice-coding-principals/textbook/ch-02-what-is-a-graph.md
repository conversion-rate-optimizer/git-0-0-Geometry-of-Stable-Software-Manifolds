# Chapter 02 — What Is a Graph?

*Read time: 7 minutes*

---

## Cities and Roads

Imagine a map of five cities. Between some pairs of cities there 
are roads. Between others there are not.

That map — cities connected by roads — is a **graph**.

The cities are called **nodes**. The roads are called **edges**. 
That is the entire vocabulary of graph theory. Nodes and edges.

A graph is just a set of things and a set of connections 
between those things.

---

## Why Graphs Describe Code

A software project is a graph.

Every file is a node. Every time one file uses something from 
another file, there is an edge between them. 

In standard coding, that edge is an import path:
```
import { calculateTotal } from "../../utils/math"
```

The edge goes from this file to `utils/math`. That is a 
directional edge — the arrow points from the file that 
needs something toward the file that provides it.

In this repository, edges are not import paths. They are 
**coupling strengths** — a number between 0 and 1 that 
measures how semantically related two modules are.

Two modules that do very similar things have a high coupling 
strength (close to 1). Two modules that have nothing to 
do with each other have a coupling strength of 0 — no edge.

This is the graph **W** in the codebase. W stands for the 
weight matrix. Every row is a module. Every column is a 
module. The number at row i, column j is the coupling 
strength between module i and module j.

---

## What a Weight Matrix Looks Like

Say you have four modules: Auth, Logic, Database, UI.

```
         Auth  Logic   DB    UI
Auth  [   0    0.7    0      0   ]
Logic [  0.7    0    0.6   0.5   ]
DB    [   0    0.6    0      0   ]
UI    [   0    0.5    0      0   ]
```

Reading this: Auth and Logic are strongly connected (0.7). 
Logic and DB are connected (0.6). Logic and UI are connected (0.5). 
Auth and DB have no direct connection (0). 

The field — the Φ values — will spread through this graph 
when the system runs. If Auth gets activated (seeded with 
a high Φ value), that activation spreads to Logic (strong 
connection), then from Logic to DB and UI (medium connections).

Auth does not directly touch DB. But it touches Logic, and 
Logic touches DB. The field finds the path.

---

## The Threshold: Why Some Edges Do Not Exist

Not every pair of modules gets an edge. There is a threshold.

In this system: if the coupling strength between two modules 
is below **0.16**, the edge is set to zero. No connection.

Why 0.16? Because without a threshold, every module would 
be weakly connected to every other module. The graph would 
be fully connected — a dense mesh where everything influences 
everything. In a fully connected graph, the field spreads 
everywhere uniformly and the pattern disappears.

The threshold enforces **locality**. Only meaningfully 
similar modules communicate. Distant, unrelated modules 
ignore each other.

This is how the real world works too. A temperature change 
in your living room does not immediately affect the 
temperature in your neighbor's house three blocks away. 
Heat spreads locally. The threshold is the code version 
of that physical fact.

---

## The Degree of a Node

One useful number for each node: its **degree**. The degree 
of a node is the sum of all its edge weights.

```
degree(Logic) = 0.7 + 0.6 + 0.5 = 1.8
degree(Auth)  = 0.7
degree(DB)    = 0.6
degree(UI)    = 0.5
```

Logic has the highest degree — it is the most connected 
node in this graph. When the field evolves, Logic will 
receive influence from the most directions and also 
distribute its influence the most widely.

Highly connected nodes are the hubs. In a codebase, 
a hub module is one that many other modules depend on. 
In a city graph, a hub is a city that many roads pass through.

The degree matrix **D** is just the diagonal matrix where 
each node's degree sits on the diagonal and everything 
else is zero. You will see D in the field equations. 
It normalizes the influence so that a node with ten 
connections does not dominate over a node with two.

---

## Directed vs Undirected

In the city analogy: some roads are one-way. You can drive 
from A to B but not from B to A. That is a **directed graph**.

Some roads go both ways. That is **undirected**.

Code dependency graphs are usually directed — module A 
imports from module B, but B does not necessarily import 
from A. The coupling strength matrix W in this system 
is built from semantic similarity (how related two modules 
are), which is symmetric — if A is similar to B, then 
B is similar to A. So the graph here is undirected.

---

## Summary

- A graph is nodes (things) connected by edges (relationships)
- Every file in a codebase is a node
- Every dependency is an edge with a weight (strength)
- W is the weight matrix — coupling strength for every pair
- Threshold at 0.16 removes weak/irrelevant connections
- Degree of a node = sum of its edge weights (how connected it is)
- D is the diagonal matrix of degrees — used to normalize the field

---

**Previous:** [Chapter 01 — What Is a Field?](./ch-01-what-is-a-field.md)  
**Next:** [Chapter 03 — How Fields Spread](./ch-03-how-fields-spread.md)
