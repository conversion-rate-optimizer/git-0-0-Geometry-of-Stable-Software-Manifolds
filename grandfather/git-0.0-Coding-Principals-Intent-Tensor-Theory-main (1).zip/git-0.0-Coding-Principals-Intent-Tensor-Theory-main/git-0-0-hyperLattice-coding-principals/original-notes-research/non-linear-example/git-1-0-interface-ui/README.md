# git-1-0-interface-ui

Interface stage for projection of runtime outputs.
