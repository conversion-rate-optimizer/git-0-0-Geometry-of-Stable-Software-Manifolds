# Chapter 1 — Law of the Locked Lattice

A folder name is not a suggestion. It is a physical coordinate anchor.

## Triple Anchor
1. Platform anchor: `git-`
2. Lattice coordinate: `<x>-<y>`
3. Semantic slug: `<intent>`

Canonical form:
`git-<x>-<y>-<semantic-slug>`

## Why this matters
Without an anchor, tools normalize names inconsistently. With the anchor, sort and lookup are deterministic.

## Invariance law
Renaming slug text must not change coordinate identity.
