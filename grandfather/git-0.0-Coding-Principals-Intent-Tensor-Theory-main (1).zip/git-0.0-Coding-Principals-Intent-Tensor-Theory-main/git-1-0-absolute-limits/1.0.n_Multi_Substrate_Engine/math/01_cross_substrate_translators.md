# Cross-Substrate Translators

The coupling operators that make the product engine genuinely multi-substrate.

## Definition

A **cross-substrate translator** is a monotone map

$$
\alpha_{ij} : \mathcal{S}_i \to \mathcal{S}_j
$$

that re-expresses information from substrate $i$ in substrate $j$'s language.

Translators are NOT required to form Galois connections (though they often do). They only need to be monotone.

## Lifted translator

Each $\alpha_{ij}$ lifts to an operator on the product:

$$
\tilde \alpha_{ij} : \mathcal{S} \to \mathcal{S}, \qquad \tilde \alpha_{ij}(s) = (s_1, \ldots, s_j \sqcup \alpha_{ij}(s_i), \ldots, s_k).
$$

In words: take the information from substrate $i$, translate to substrate $j$'s language, and merge with $s_j$.

## Coupled engine operator

Define the **coupled engine operator**:

$$
F \;\coloneqq\; \left(\bigcirc_{(i,j)} \tilde \alpha_{ij}\right) \circ \left(\bigcirc_i \hat F_i\right).
$$

The order matters:
1. First, each substrate's local engine runs independently (producing updates).
2. Then, all cross-substrate translators fire (propagating information).

Iterate until fixed point.

## Design principles for translators

### Principle 1: Locality
Each $\alpha_{ij}$ should look at a small, structurally-meaningful subset of $s_i$ and produce a small update to $s_j$. Global translators defeat the purpose of substrate separation.

### Principle 2: Monotonicity
Each $\alpha_{ij}$ must be monotone for Kleene convergence.

### Principle 3: Consistency
For bidirectional translators ($\alpha_{ij}$ and $\alpha_{ji}$), the composition should roughly match the identity on the shared sub-structure:
$$
\pi_{\text{shared}} \circ \alpha_{ji} \circ \alpha_{ij} \approx \pi_{\text{shared}} \circ \iota_i.
$$

This is the **coherence condition**. Without it, bidirectional translators can oscillate.

## Example: `.md` ↔ `.py` translator

Substrate states (simplified):
- $\mathcal{S}_{.md}$ = sets of "intent statements" like `{send_email, log_event, ...}`.
- $\mathcal{S}_{.py}$ = sets of "function obligations" like `{must_have_fn(send_email), must_have_fn(log_event), ...}`.

Translator:
$$
\alpha_{\text{md} \to \text{py}}(s_{.md}) = \{\text{must\_have\_fn}(i) : i \in s_{.md}\}.
$$

This is a simple lift: each intent becomes an obligation. Monotone, local, consistent.

Reverse translator:
$$
\alpha_{\text{py} \to \text{md}}(s_{.py}) = \{i : \text{must\_have\_fn}(i) \in s_{.py}\}.
$$

This retrieves the intents from the obligations. Coherence: $\alpha_{\text{py} \to \text{md}} \circ \alpha_{\text{md} \to \text{py}} = \text{id}_{\mathcal{S}_{.md}}$. Ideal.

## Example: `.py` ↔ `.html` translator

Substrate states:
- $\mathcal{S}_{.py}$ = function implementations.
- $\mathcal{S}_{.html}$ = DOM elements.

Translator:
$$
\alpha_{\text{py} \to \text{html}}(s_{.py}) = \{\text{button\_for}(f) : f \in s_{.py},\; f \text{ is a public action}\}.
$$

For each public Python function, create a corresponding HTML button. Monotone.

Reverse translator: less clean — HTML buttons don't fully determine Python implementations. Typically, HTML → Python is an incomplete retrieval. This is OK mathematically; just don't expect coherence.

## When translators are Galois connections

If $\alpha_{ij}$ and $\alpha_{ji}$ form a Galois connection:

$$
\alpha_{ij}(s_i) \leq s_j \iff s_i \leq \alpha_{ji}(s_j),
$$

we get stronger guarantees:
- Automatic soundness: round-trips are over-approximations.
- Abstract-interpretation-style soundness theorems (§1.0.d).

Most practical translators are *not* Galois connections — they are just monotone maps. Achieving Galois-connection status is a design goal, not a default.

## The cross-substrate coherence group

Given $k$ substrates and all $k(k-1)$ pairwise translators, the translators should form a **commutative diagram** under composition:

$$
\alpha_{ik} \approx \alpha_{jk} \circ \alpha_{ij}.
$$

"Going through an intermediary substrate should give the same result as going directly." When this holds, the translators form a groupoid-like structure.

In practice, perfect commutativity is rare but approximate commutativity is achievable with careful design.

## Implementation in the engine

The coupled engine (see `code/multi_substrate_engine.ts`) encodes each translator as a data structure:

```typescript
type CrossLink = {
  from: string;
  to: string;
  translate: (s_from: any) => Partial<any> | null;
};
```

The engine's resolve loop applies all translators each iteration after local engines have stabilized. The outer loop ensures cross-substrate consistency.

This architecture directly realizes the math above.
