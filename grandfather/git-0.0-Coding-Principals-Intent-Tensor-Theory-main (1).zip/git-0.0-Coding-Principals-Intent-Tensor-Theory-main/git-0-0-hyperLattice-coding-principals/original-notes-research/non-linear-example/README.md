# git-0.0-Coding-Principals-Intent-Tensor-Theory

## College Textbook Draft: Ghostless Infrastructure & Dynamic Manifolds

**HAIL MATH.**

This repository is now treated as a **dynamic manifold** rather than a static folder tree.
The central claim of the textbook is mechanical:

> stable software structure emerges when retention dominates loss over the relevant timescale.

\[
S_{sel} = \frac{R}{\dot{R}\, t_{ref}} \ge 1
\]

---

## Book Orientation (Book 0A)

### Learning Outcomes
After working through this repository, a student should be able to:
1. Convert a linear file-path architecture into a coordinate-anchored lattice.
2. Define a manifest as a topological constraint object instead of a config bucket.
3. Implement a resonance registry for index-to-index lookup.
4. Enforce a selection gate before runtime manifestation.
5. Run small-field bloom experiments and interpret `Q(t)` and `S_sel(t)`.

### Required naming law (Locked Lattice)
Every structural root follows:

`git-<x>-<y>-<semantic-slug>`

- `git-` = platform anchor
- `<x>-<y>` = immutable lattice coordinate
- `<semantic-slug>` = human readability layer

Identity is coordinate-first; slug is overlay-only.

---

## Lattice Chassis

```text
git-0-0-substrate-core/      # manifest, registry, formal math, resolver
git-0-1-ignition-main/       # selection gate / initialization
git-0-2-runtime-api/         # runtime transduction and residue I/O
git-1-0-interface-ui/        # interface projection
coding-principles-field/     # measured experiments (Q(t), S_sel(t))
```

---

## Genesis Objects (First Non-Linear Objects)

- Root ground-state manifest: `.itt-manifest.json`
- Ghostless semantic overlay: `git-0-0-substrate-core/manifest.ghostless.json`
- Resonance registry core: `git-0-0-substrate-core/resonance.ts`
- Selection gate: `git-0-1-ignition-main/selection-gate.ts`

These objects transition the repo from string naming to manifold constraints.

---

## Textbook Chapters

1. `docs/textbook/00-syllabus.md`
2. `docs/textbook/01-law-of-locked-lattice.md`
3. `docs/textbook/02-genesis-manifest.md`
4. `docs/textbook/03-resonance-registry.md`
5. `docs/textbook/04-sop-first-commit-manifold-initialization.md`

---

## First Hard Gate (Execution before abstraction)

Run:

```bash
python3 coding-principles-field/experiments/exp_001_min_field.py
python3 coding-principles-field/experiments/exp_002_entropy_fix.py
```

If bloom is not reproducible in the small field, do not scale architecture.

---

© Armstrong Knight | intent-tensor-theory.com | CC BY-NC 4.0
