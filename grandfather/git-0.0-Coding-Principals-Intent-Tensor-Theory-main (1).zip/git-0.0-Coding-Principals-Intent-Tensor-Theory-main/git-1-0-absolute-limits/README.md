# git-1-0 — Absolute Limits

### Chapter 1 of the Intent Tensor Theory Coding Principles

> *Everything in `git-0.*` was the lead-up.*
> *This is Chapter 1: the actual ceiling of dynamic computation, mapped with full mathematical rigor and executable code.*

---

## What this chapter is

Chapter 1 is a complete survey of the mathematical frontier of **dynamic, non-linear, constraint-driven computation** — the territory ITT has been approaching from the physics side. Every paradigm that could plausibly realize "declare the world, let it resolve itself" is here, with:

1. **The literal mathematics** — theorems, definitions, proofs or proof sketches.
2. **The literal code** — runnable syntax (Haskell, Python, TypeScript, Rust, OCaml, Lean 4, Clingo, SQL) that realizes the math.
3. **The hard ceiling** — undecidability, NP-hardness, and incompleteness, stated formally.
4. **The frontier** — where novel ITT-aligned contributions remain possible.

## Organization

Each topic has a **math** subfolder (theorem-statement rigor) and a **code** subfolder (runnable syntax). Topics are ordered so that each depends only on earlier ones.

| Folder                                        | Topic                                                                 |
|-----------------------------------------------|-----------------------------------------------------------------------|
| `1.0.a_Overview_and_Front_Matter`             | Abstract, scope, notation conventions, reading order                  |
| `1.0.b_Order_Theoretic_Preliminaries`         | Posets, lattices, monotone & Scott-continuous functions               |
| `1.0.c_Fixed_Point_Theorems`                  | Knaster–Tarski, Kleene, Banach — full proofs                          |
| `1.0.d_Abstract_Interpretation`               | Galois connections, soundness, widening/narrowing                     |
| `1.0.e_Logic_Programming_Datalog`             | Immediate-consequence operator, Herbrand semantics, semi-naive eval   |
| `1.0.f_SAT_SMT_Constraint_Solving`            | DPLL, CDCL, DPLL(T), Nelson–Oppen, MaxSAT                             |
| `1.0.g_Self_Adjusting_Computation`            | Trace stability, change propagation, React-as-SAC                      |
| `1.0.h_Differential_Dataflow_DBSP`            | Z-sets, integration/differentiation, incremental view maintenance     |
| `1.0.i_Answer_Set_Programming`                | Gelfond–Lifschitz reduct, stable models, weight constraints           |
| `1.0.j_Curry_Howard_Dependent_Types`          | Propositions-as-types, Lean 4, HoTT, type-inhabitation undecidability |
| `1.0.k_Build_Systems`                         | Task abstraction (Mokhov–Mitchell–Peyton Jones), Shake, Nix, Bazel    |
| `1.0.l_Hard_Ceilings`                         | Halting, Rice, Cook–Levin, Gödel — full proofs                        |
| `1.0.m_Generic_Constraint_Engine`             | The ITT Intent Engine, formally situated                              |
| `1.0.n_Multi_Substrate_Engine`                | The product-lattice fixed-point engine across file types              |
| `1.0.o_Synthesis_and_Frontier`                | Master cheat sheet, novel directions for ITT contribution             |
| `1.0.z_Full_Papers`                           | The two full-length companion papers                                  |

## Reading order

**For mathematicians:** a → b → c → d → e → f → g → h → i → j → k → l → m → n → o
**For engineers:** a → c → e → f → m → n → (reference others as needed)
**For physicists:** a → b → c → m → n → o (then back-fill)

## The central claim

> **Every "dynamic coding" paradigm is a fixed-point computation on a lattice.**
>
> $$S^\star = F(S^\star)$$
>
> The differences between paradigms are choices of lattice, choices of operator structure (monotone, continuous, contractive, projective), and choices of effect (pure, reactive, incremental, distributed). The ceilings — undecidability, NP-hardness, incompleteness — are invariant across those choices.

## Relationship to prior chapters

- `git-0.0` established the ITT coding foundations (ghostless architecture, GlyphMath, Writables Doctrine).
- `git-0.1.a` built out the CMA (Coordinate Manifold Architecture).
- `git-0.2` developed the concepts and strategies (including Pillar X: Jailbreaking Directory Trees and Pillar XI: Non-Linear Binding Syntax).
- **`git-1-0` (this chapter)** connects those ITT-side constructions to the broader mathematical territory of dynamic computation — locating where ITT sits in the formal landscape, what it inherits, what it genuinely extends.

## License

Inherits from the repo root (see `/LICENSE`).

## How to cite

> *Intent Tensor Theory Coding Principles, Chapter 1: Absolute Limits.* Intent-Tensor-Theory.com, 2026.
> ORCID 0009-0004-8153-8335.
