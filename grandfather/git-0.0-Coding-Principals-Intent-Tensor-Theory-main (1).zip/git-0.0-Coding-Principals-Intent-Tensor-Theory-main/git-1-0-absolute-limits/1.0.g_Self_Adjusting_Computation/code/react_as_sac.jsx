// React hooks as self-adjusting computation.
//
// This JSX file demonstrates that the React reconciler is literally an
// SAC runtime:
//   - useState creates modifiables.
//   - useMemo creates memoized computation nodes with explicit dependency lists.
//   - React's reconciler implements change propagation.

import React, { useState, useMemo, useEffect } from 'react';

export function IntentEngineView({ initialInput }) {
  const [email, setEmail]       = useState(initialInput.email);
  const [optedIn, setOptedIn]   = useState(initialInput.optedIn);
  const [blocked, setBlocked]   = useState(initialInput.blocked);

  // DERIVATION: eligible = email ∧ optedIn
  // useMemo is literally a SAC thunk: recomputes only when deps change.
  const eligible = useMemo(() => {
    console.log("Recompute: eligible");
    return Boolean(email && optedIn);
  }, [email, optedIn]);

  // CONSTRAINT: priority-100 overrides priority-10
  const sent = useMemo(() => {
    console.log("Recompute: sent");
    if (blocked) return false;         // priority 100
    if (eligible) return true;          // priority 10
    return false;
  }, [eligible, blocked]);

  // Side effect: simulate actual email send
  useEffect(() => {
    if (sent) console.log("→ Send email to", email);
  }, [sent, email]);

  return (
    <div>
      <div>Email: <input value={email || ''} onChange={e => setEmail(e.target.value)} /></div>
      <div>Opted in: <input type="checkbox" checked={optedIn} onChange={e => setOptedIn(e.target.checked)} /></div>
      <div>Blocked: <input type="checkbox" checked={blocked} onChange={e => setBlocked(e.target.checked)} /></div>
      <hr />
      <div>eligible: {String(eligible)}</div>
      <div>sent: {String(sent)}</div>
    </div>
  );
}

/*
 * Observation: when you type in the email box, only `eligible` and `sent`
 * recompute. When you click `blocked`, only `sent` recomputes. This is
 * change propagation in your frontend — you've been using the math from
 * this chapter every time you've written a useMemo call.
 */
