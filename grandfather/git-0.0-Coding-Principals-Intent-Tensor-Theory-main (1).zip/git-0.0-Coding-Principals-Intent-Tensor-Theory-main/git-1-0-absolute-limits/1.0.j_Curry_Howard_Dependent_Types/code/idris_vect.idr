-- Idris 2: full dependent types.

module Main

-- Length-indexed vectors (already in the Idris standard library as `Vect`)
data Vec : Nat -> Type -> Type where
  Nil  : Vec Z a
  (::) : a -> Vec n a -> Vec (S n) a

-- Append: output length is the type-level sum of inputs
appendV : Vec n a -> Vec m a -> Vec (n + m) a
appendV Nil      ys = ys
appendV (x::xs) ys = x :: appendV xs ys

-- Safe indexing: the index must be < length
data Fin : Nat -> Type where
  FZ : Fin (S n)
  FS : Fin n -> Fin (S n)

indexV : Fin n -> Vec n a -> a
indexV FZ     (x::_)  = x
indexV (FS i) (_::xs) = indexV i xs

-- The following will not compile:
-- bad : Vec 0 Int -> Int
-- bad v = indexV FZ v    -- FZ : Fin (S n), but v : Vec 0 Int

-- Example that does compile:
example : Int
example = indexV (FS FZ) (10 :: 20 :: 30 :: Nil)   -- = 20

-- Type-level arithmetic is fully elaborated: the compiler confirms
-- that FS FZ : Fin 3 matches Vec 3 Int, and that 20 is returned.
