/**
 * SMT-backed Intent Engine.
 *
 * Replaces the hand-rolled Kleene iteration with a single Z3 call,
 * encoding all derivations as biconditionals and constraints as
 * weighted soft assertions (lexicographic MaxSAT).
 *
 * Requires: npm install z3-solver
 */

import { init } from 'z3-solver';

export async function runSMTBackedEngine(input: {
  email: string | null;
  optedIn: boolean;
  blocked: boolean;
}) {
  const { Context } = await init();
  const Z3 = Context('main');
  const { Solver, Bool, Optimize } = Z3;

  const opt = new Optimize();

  // Declare state variables
  const email_present = Bool.const('email_present');
  const opted_in      = Bool.const('opted_in');
  const eligible      = Bool.const('eligible');
  const sent          = Bool.const('sent');
  const blocked       = Bool.const('blocked');

  // Hard: derivation as biconditional
  opt.add(eligible.eq(email_present.and(opted_in)));

  // Soft (priority 10): eligible → sent
  opt.add_soft(eligible.implies(sent), 1, 'low');

  // Soft (priority 100): blocked → ¬sent
  opt.add_soft(blocked.implies(sent.not()), 1, 'high');

  // Input facts
  opt.add(email_present.eq(Boolean(input.email)));
  opt.add(opted_in.eq(input.optedIn));
  opt.add(blocked.eq(input.blocked));

  if ((await opt.check()) !== 'sat') {
    throw new Error("Unsatisfiable constraint system.");
  }
  const model = opt.model();

  return {
    email_present: model.eval(email_present).toString() === 'true',
    opted_in:      model.eval(opted_in).toString() === 'true',
    eligible:      model.eval(eligible).toString() === 'true',
    sent:          model.eval(sent).toString() === 'true',
    blocked:       model.eval(blocked).toString() === 'true',
  };
}

// Usage:
// runSMTBackedEngine({ email: "a@b.com", optedIn: true, blocked: true })
//   .then(console.log);
