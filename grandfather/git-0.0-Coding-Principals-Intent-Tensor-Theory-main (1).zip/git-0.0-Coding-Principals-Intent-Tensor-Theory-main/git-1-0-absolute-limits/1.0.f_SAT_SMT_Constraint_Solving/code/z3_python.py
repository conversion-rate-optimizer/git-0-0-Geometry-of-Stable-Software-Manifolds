"""
Z3 SMT solver: canonical Python usage examples.

Install: pip install z3-solver
"""

from z3 import (
    Solver, Optimize, Int, Real, Bool, Array, Function, IntSort,
    And, Or, Not, Implies, Exists, ForAll, Distinct, If, sat, unsat, unknown
)


def basic_sat():
    """Satisfiability over Booleans."""
    s = Solver()
    a, b, c = Bool('a'), Bool('b'), Bool('c')
    s.add(Or(a, Not(b)), Or(Not(a), c), Or(b, Not(c)))
    print("Basic SAT:", s.check())
    if s.check() == sat:
        print(" model:", s.model())


def linear_integer():
    """QF_LIA: solve a linear integer system."""
    s = Solver()
    x, y = Int('x'), Int('y')
    s.add(x + 2*y == 10, x - y == 1)
    print("Linear system:", s.check(), s.model())


def linear_real():
    """QF_LRA: linear real arithmetic."""
    s = Solver()
    x, y = Real('x'), Real('y')
    s.add(x * 3 + y == 10)
    s.add(x > 0, y > 0)
    print("Linear real:", s.check(), s.model())


def uninterpreted_functions():
    """QF_UF: uninterpreted functions with equality."""
    s = Solver()
    f = Function('f', IntSort(), IntSort())
    a, b = Int('a'), Int('b')
    s.add(a == b, f(a) != f(b))
    print("UF contradiction:", s.check())  # unsat


def arrays():
    """QF_A: array theory."""
    s = Solver()
    a = Array('a', IntSort(), IntSort())
    s.add(a[0] == 5, a[1] != a[0])
    print("Arrays:", s.check(), s.model())


def mixed_theories():
    """Nelson-Oppen combination in action."""
    s = Solver()
    x = Int('x')
    a = Array('a', IntSort(), IntSort())
    f = Function('f', IntSort(), IntSort())
    s.add(x > 0, a[x] == f(x), f(x) == 42)
    print("Mixed theories:", s.check(), s.model())


def max_sat_priorities():
    """Encode lexicographic priorities via Optimize.add_soft."""
    opt = Optimize()
    a, b, c = Bool('a'), Bool('b'), Bool('c')

    # Hard: at most one can be true
    opt.add(Or(Not(a), Not(b)), Or(Not(a), Not(c)), Or(Not(b), Not(c)))

    # High priority soft (weight 100)
    opt.add_soft(a, weight=100)
    # Lower priority soft (weight 1)
    opt.add_soft(b, weight=1)
    opt.add_soft(c, weight=1)

    print("MaxSAT:", opt.check(), opt.model())
    # Expects: a=True, b=False, c=False (high priority wins)


def unknown_territory():
    """Non-linear integer arithmetic: may hit 'unknown' — the ceiling in code."""
    s = Solver()
    s.set("timeout", 3000)  # 3 seconds
    x, y = Int('x'), Int('y')
    s.add(x*x + y*y == 100)
    s.add(x > 0, y > 0)
    s.add(x*y*x > 50)
    result = s.check()
    print("Non-linear:", result)
    if result == unknown:
        print("  (Solver hit the mathematical ceiling — Matiyasevich's theorem.)")


if __name__ == "__main__":
    basic_sat()
    linear_integer()
    linear_real()
    uninterpreted_functions()
    arrays()
    mixed_theories()
    max_sat_priorities()
    unknown_territory()
