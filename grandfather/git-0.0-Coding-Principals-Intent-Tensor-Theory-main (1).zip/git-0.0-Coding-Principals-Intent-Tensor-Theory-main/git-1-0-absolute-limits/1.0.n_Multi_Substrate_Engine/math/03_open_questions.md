# Open Questions and Research Directions

Where the multi-substrate engine meets the frontier.

## Question 1: Natural structural conditions for convergence

*What are the structural conditions on cross-substrate translators that guarantee convergence without unduly restricting expressivity?*

Known partial answers:
- **Acyclic translator graphs** always converge.
- **Monotone + Scott-continuous operators** always converge (Kleene).

Open:
- Are there intermediate regimes (e.g., "cyclic but with bounded retraction") where convergence holds?
- Are there syntactic checks on translator definitions that imply monotonicity?
- Can one design a translator DSL in which only convergent translators can be written?

## Question 2: Tensor-valued priority

*Can priority itself be a tensor that transforms under substrate change, as ITT's CyberAxis suggests?*

Standard lexicographic MaxSAT uses scalar priorities per constraint. ITT's mood-tensor formulation suggests priorities should:
- Transform covariantly under substrate change.
- Admit a "priority field" defined over the product state space.
- Interact with priority tensors of coupled constraints.

Open:
- What is the right algebraic structure for tensor priorities?
- Do tensor priorities collapse to lex-MaxSAT under reasonable conditions, or do they give strictly more?
- What algorithms solve tensor-priority constraint systems?

This is a promising direction because it genuinely goes beyond the current literature.

## Question 3: Formal ICHTB-style theorems

*Is there a theorem of the form "precision × responsiveness ≤ constant" for multi-substrate engines?*

Conjectured form:

$$
\text{iterations to converge} \times \text{consistency precision} \geq C(\text{system parameters})
$$

Known relatives:
- Widening-narrowing precision/termination trade-off in abstract interpretation.
- Incremental-computation trade-offs (responsiveness vs. memory).

Open:
- Is there a quantitative lower bound on this product for specific classes of engines?
- How does the bound depend on the structure of the translator graph?
- Does ITT's physics-motivated formulation suggest a specific form?

## Question 4: HoTT-formalized multi-substrate engines

*Can the coherence of cross-substrate translators be formalized using HoTT's path/equivalence machinery?*

Under Voevodsky's univalence, "isomorphic substrates are equal." For multi-substrate engines, this means:
- Coherence conditions become types of paths.
- Round-trip consistency is a higher coherence.
- Transport along substrate equivalences gives a principled notion of "substrate change."

Open:
- Formalize a simple multi-substrate engine in Cubical Agda.
- Prove soundness and coherence as type-theoretic theorems.
- Evaluate whether the formalization scales.

## Question 5: LLM-in-the-loop engines

*How does an LLM acting as a "smart translator" affect the convergence properties of the product engine?*

LLMs can provide translators that are:
- Probabilistic (not strictly deterministic).
- Approximately monotone (usually, but not always).
- Trained on domain-specific corpora (injecting prior knowledge).

Open:
- Does LLM-in-the-loop break Kleene convergence?
- Can LLM translators be bounded in a way that preserves convergence guarantees?
- How does uncertainty in the translator propagate through the fixed point?

This is highly timely and practically relevant for AI-augmented coding.

## Question 6: Quantitative incremental-maintenance guarantees

*For a multi-substrate engine maintained via DBSP-style incremental computation, what is the relationship between the size of the delta and the cost of maintenance?*

Known:
- For linear operators, cost is $O(|\Delta|)$.
- For bilinear (joins), cost is $O(|\Delta| \cdot |\text{prior state}|)$ in the worst case.

Open:
- For typical multi-substrate engines, what is the amortized cost per edit?
- Can one construct adversarial examples where small edits cascade globally?
- Is there a quantitative lower bound (an "information-theoretic" minimum cost)?

## Question 7: Unified theory of "compatible substrates"

*When do two substrates "play well together"? Is there a formal notion of substrate compatibility?*

ITT's formalism suggests substrates with "compatible tensor fields" should compose nicely. Standard math offers:
- Galois connections (abstraction-concretization).
- Adjoint functors (category-theoretic).
- Equivalences of categories (HoTT).

Open:
- Which formalism is the right one for multi-substrate engines?
- Can one characterize "compatible substrate families" syntactically?
- Are there canonical examples (e.g., source ↔ AST ↔ bytecode) that fit the theory perfectly?

## Why these matter

Each of these is a place where **ITT's perspective might contribute something genuinely new**. The existing mathematical literature is mostly silent on multi-substrate engines; the work done in this chapter is synthesis from adjacent areas.

An ITT research program that addressed even one of these questions with a clean theorem would be a genuine advance, not a restatement.

## What NOT to claim

Do not claim:
- That the ITT engine "transcends" the halting problem, Rice's theorem, or Gödel.
- That multi-substrate engines escape NP-hardness.
- That a physics analogy is a theorem.

These ceilings are invariant. ITT's contribution, if real, will come from **choosing its lattices, operators, and effects more creatively** than existing systems do, within those ceilings — and from proving new theorems in regions the standard literature has not yet explored.

The open questions above are the right target.
