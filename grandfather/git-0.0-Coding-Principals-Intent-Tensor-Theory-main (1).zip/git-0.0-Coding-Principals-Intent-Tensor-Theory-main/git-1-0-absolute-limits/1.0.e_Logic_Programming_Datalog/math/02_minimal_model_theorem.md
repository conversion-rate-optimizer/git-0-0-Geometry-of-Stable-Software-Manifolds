# The Minimal Model Theorem (van Emden–Kowalski)

The semantic justification for Datalog evaluation.

## Statement

**Theorem (van Emden–Kowalski, 1976).** *For any Datalog program $P$:*

$$
M_P \;=\; \operatorname{lfp}(T_P) \;=\; \bigcup_{n \geq 0} T_P^n(\emptyset)
$$

*is the unique minimal Herbrand model of $P$, and coincides with the set of ground atoms logically entailed by $P$ under the closed-world assumption.*

## Proof sketch

**Existence of minimal model.** By the intersection-closure property: if $\{M_i\}_{i \in I}$ are all models of $P$, then $\bigcap_i M_i$ is a model of $P$. The intersection of all models is therefore the minimal one.

**Characterization as $\operatorname{lfp}(T_P)$.** By Proposition 4 of `01_immediate_consequence_operator.md`, a set is a model iff it is a pre-fixed point of $T_P$. The least pre-fixed point is the least fixed point (Knaster–Tarski). Hence $M_P = \operatorname{lfp}(T_P)$.

**Kleene form.** $T_P$ is Scott-continuous (Proposition 2), so $\operatorname{lfp}(T_P) = \bigcup_n T_P^n(\emptyset)$ by Kleene's theorem.

**Logical entailment.** A ground atom $a$ is entailed by $P$ iff it is true in every model of $P$. Since $M_P$ is the minimal model, $a \in M$ for every model $M$ iff $a \in M_P$. So entailment equals membership in $M_P$. $\blacksquare$

## Three equivalent semantics

The theorem unifies:

1. **Model-theoretic:** the minimal Herbrand model.
2. **Fixed-point:** $\operatorname{lfp}(T_P)$.
3. **Proof-theoretic:** atoms derivable by a finite number of rule applications.

All three characterizations yield the same set. This is why Datalog has a clean, unambiguous declarative semantics.

## Corollaries

**Corollary 1 (Termination).** For Datalog (function-free), $\operatorname{lfp}(T_P)$ is reached in at most $|B_P|$ iterations. Since $|B_P|$ is polynomial in the number of constants, Datalog evaluation terminates in polynomial time.

**Corollary 2 (Monotonicity under extension).** Adding new facts to the database can only add derived atoms: $\operatorname{lfp}(T_{P \cup D_1}) \subseteq \operatorname{lfp}(T_{P \cup D_2})$ whenever $D_1 \subseteq D_2$.

**Corollary 3 (Incremental view maintenance).** Adding a single fact $f$ can only trigger new derivations whose body contains $f$ (or an atom derived using $f$). This observation underlies semi-naive evaluation.

## Limitations

- **No negation:** The theorem requires pure positive Horn clauses. With negation, $T_P$ becomes non-monotone.
- **No aggregation:** Aggregates (SUM, COUNT, MIN) break monotonicity and require special care.
- **No function symbols:** Full Prolog's $T_P$ is still Scott-continuous but the fixed point is generally infinite and query termination is undecidable.

Extensions addressing these (stratified negation, aggregate semantics, well-founded semantics) preserve most of the theorem's content within carefully delineated sub-cases.

## Why this matters for dynamic coding

Every Datalog rule you write is shorthand for a piece of the $T_P$ operator. Every query answer is a witness to membership in $\operatorname{lfp}(T_P)$. Writing Datalog is literally writing the operator whose fixed point you want.

This is the purest instance of "declare the shape, get the resolved state" in all of computer science. The ITT Intent Engine, stripped of priorities and retractions, **is** a Datalog engine — it inherits the minimal-model theorem as its convergence guarantee.
