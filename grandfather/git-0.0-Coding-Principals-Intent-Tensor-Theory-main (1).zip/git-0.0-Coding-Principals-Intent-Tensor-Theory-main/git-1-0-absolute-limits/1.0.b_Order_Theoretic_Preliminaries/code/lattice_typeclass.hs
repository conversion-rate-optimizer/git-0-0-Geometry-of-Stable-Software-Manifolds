-- Haskell typeclass for lattices.
--
-- The :: says "has type." Reading:
--   bottom :: a           — "bottom has type a"
--   (\/)   :: a -> a -> a — "join has type: function from two a's to an a"
--
-- This is literally the encoding of the mathematical structure
--   (L, ≤, ∨, ∧, ⊥, ⊤)
-- from 1.0.b/math/01_lattices.md.

{-# LANGUAGE FlexibleInstances #-}

module Lattice where

import qualified Data.Set as Set
import Data.Set (Set)

class Lattice a where
  bottom :: a
  top    :: a
  (\/)   :: a -> a -> a    -- join / least upper bound
  (/\)   :: a -> a -> a    -- meet / greatest lower bound
  leq    :: a -> a -> Bool

-- Example 1: Bool as a 2-element lattice (False ≤ True)
instance Lattice Bool where
  bottom = False
  top    = True
  (\/)   = (||)
  (/\)   = (&&)
  leq    = (<=)   -- False <= True

-- Example 2: Finite set ordered by inclusion.
-- This is only a bounded lattice if we fix the carrier; for unbounded
-- Sets we omit 'top'.
instance Ord k => Lattice (Set k) where
  bottom = Set.empty
  top    = error "unbounded Set — no top element"
  (\/)   = Set.union
  (/\)   = Set.intersection
  leq    = Set.isSubsetOf

-- Example 3: A flat domain with Maybe
data Flat a = FBot | FVal a | FTop deriving (Eq, Show)

instance Eq a => Lattice (Flat a) where
  bottom = FBot
  top    = FTop
  FBot     \/ y        = y
  x        \/ FBot     = x
  FTop     \/ _        = FTop
  _        \/ FTop     = FTop
  FVal a   \/ FVal b
    | a == b           = FVal a
    | otherwise        = FTop
  FBot     /\ _        = FBot
  _        /\ FBot     = FBot
  FTop     /\ y        = y
  x        /\ FTop     = x
  FVal a   /\ FVal b
    | a == b           = FVal a
    | otherwise        = FBot
  leq FBot _            = True
  leq _ FTop            = True
  leq (FVal a) (FVal b) = a == b
  leq _ _               = False

-- The least fixed-point operator (Kleene form, for finite-height lattices):
lfp :: (Eq a, Lattice a) => (a -> a) -> a
lfp f = go bottom
  where
    go x = let x' = f x
           in if x == x' then x else go x'

-- Least fixed-point from a given starting point:
lfpFrom :: (Eq a, Lattice a) => (a -> a) -> a -> a
lfpFrom f x = let x' = f x
              in if x == x' then x else lfpFrom f x'
