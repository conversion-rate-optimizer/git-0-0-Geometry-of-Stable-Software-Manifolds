/**
 * Event Horizon Code Series®TM — ContactGenesis
 * ──────────────────────────────────────────────────────────────────────────
 * Pattern: Temporal Selection Pressure — Runtime as Event Horizon
 * Platform: Google Apps Script (Google Sheets)
 *
 * The code collapses and converges completed work product as its event horizon.
 * Runtime = Time. Only states that complete before the horizon exist.
 *
 * Created by Armstrong Knight — auto-workspace-ai.com / intent-tensor-theory.com
 * Creative Commons Attribution-NonCommercial 4.0 International License
 */

function ContactGenesis() {
  const ss    = SpreadsheetApp.getActiveSpreadsheet();
  const sheet = ss.getSheetByName('Enrich');
  const lastRow = sheet.getLastRow();

  const labels = {
    domain:   'Domain Name',
    fallback: 'Email Addresses',
    to:       'Prior Contact to:',
    from:     'Prior Contact from:'
  };

  const spectrum = { green: '#38761d', red: '#cc0000' };

  // ── HEADER RESOLUTION ─────────────────────────────────────────────────────
  const headers = sheet.getRange(1, 1, 1, sheet.getLastColumn()).getValues()[0];
  const index   = {};
  for (const key in labels) {
    const pos = headers.findIndex(h => h.trim() === labels[key]);
    if (pos === -1) throw new Error(`Header "${labels[key]}" not found`);
    index[key] = pos + 1;
  }

  // ── FIELD DEFINITION ──────────────────────────────────────────────────────
  const domainData   = sheet.getRange(2, index.domain,   lastRow - 1).getValues();
  const fallbackData = sheet.getRange(2, index.fallback, lastRow - 1).getValues();
  const toData       = sheet.getRange(2, index.to,       lastRow - 1).getValues();
  const fromData     = sheet.getRange(2, index.from,     lastRow - 1).getValues();

  // ── CONVERGENCE: Identify Writables ───────────────────────────────────────
  const writables = [];
  for (let i = 0; i < domainData.length; i++) {
    const row      = i + 2;
    const domain   = String(domainData[i][0]   || '').trim();
    const fallback = String(fallbackData[i][0] || '').trim().split(/\r?\n/).filter(e => e);
    const to       = String(toData[i][0]).trim();
    const from     = String(fromData[i][0]).trim();

    const isPopulated  = domain !== '';
    const isUnwritten  = to === '' && from === '';
    const isFetchable  = /^[\w.-]+\.[a-z]{2,}$/i.test(domain);
    const isWritable   = isPopulated && isUnwritten && isFetchable;
    const useFallback  = (to === '0' && from === '0' && fallback.length > 0);

    if (isWritable) writables.push({ row, domain, fallback, useFallback });
  }

  Logger.log(`🌌 Writables Ready: ${writables.length}`);

  // ── DIVERGENCE: Execute Writables Only ────────────────────────────────────
  const results = [];
  for (let j = 0; j < writables.length; j += 50) {
    const batch = writables.slice(j, j + 50);
    batch.forEach(entry => {
      const emails    = entry.useFallback
        ? entry.fallback.filter(e => !e.includes(entry.domain))
        : [entry.domain];
      const toCount   = emails.reduce((s, e) => s + GmailApp.search(`to:${e}`).length,   0);
      const fromCount = emails.reduce((s, e) => s + GmailApp.search(`from:${e}`).length, 0);
      results.push({ row: entry.row, domain: entry.domain || emails.join(','), toCount, fromCount });
    });
  }

  // ── FIELD COLLAPSE: Write Back ────────────────────────────────────────────
  results.forEach(res => {
    const toCell   = sheet.getRange(res.row, index.to);
    const fromCell = sheet.getRange(res.row, index.from);

    if (res.toCount > 0) {
      toCell.setFormula(`=HYPERLINK("https://mail.google.com/mail/u/0/#search/to:${res.domain}","${res.toCount}")`);
      toCell.setFontColor(spectrum.green);
    } else { toCell.setValue(0); toCell.setFontColor(spectrum.red); }

    if (res.fromCount > 0) {
      fromCell.setFormula(`=HYPERLINK("https://mail.google.com/mail/u/0/#search/from:${res.domain}","${res.fromCount}")`);
      fromCell.setFontColor(spectrum.green);
    } else { fromCell.setValue(0); fromCell.setFontColor(spectrum.red); }
  });

  Logger.log('🔮 ContactGenesis Collapse: Complete');
}
