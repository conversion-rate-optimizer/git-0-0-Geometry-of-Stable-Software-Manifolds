# Chapter 2 — Genesis Manifest (.itt-manifest.json)

The manifest is the `Phi=0` seed object.

It defines:
- substrate identity
- axis assignments
- selection threshold
- closure condition

The manifest is not a settings dump; it is a topological contract.
