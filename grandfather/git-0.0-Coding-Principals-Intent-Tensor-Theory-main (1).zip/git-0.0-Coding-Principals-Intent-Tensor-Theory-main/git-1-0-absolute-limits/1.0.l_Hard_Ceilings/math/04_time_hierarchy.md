# The Time Hierarchy Theorem

More time strictly buys more computational power.

## Statement

**Theorem (Hartmanis & Stearns 1965).** *Let $f, g : \mathbb{N} \to \mathbb{N}$ be time-constructible functions with*

$$
f(n) \cdot \log f(n) \;=\; o(g(n)).
$$

*Then $\text{DTIME}(f) \subsetneq \text{DTIME}(g)$.*

Here $\text{DTIME}(h)$ is the class of languages decidable by a deterministic Turing machine in $O(h(n))$ steps.

## Proof sketch

Diagonalization again. Construct a $g$-time decider $D$ that "differs" from every $f$-time decider:

1. Enumerate all $f$-time Turing machines $M_1, M_2, \ldots$ (possible because of computability).
2. On input $x$, $D$ computes the index $i$ of an $M_i$ encoded by $x$, simulates $M_i$ on $x$ for $f(|x|)$ steps, and outputs the opposite of whatever $M_i$ outputs.
3. $D$ is not equivalent to any $M_i$ — it disagrees on some input. Hence $D$ is not in $\text{DTIME}(f)$.
4. $D$ runs in $O(g(n))$ time (simulation overhead is $O(\log f)$ per step, total $O(f \log f) = o(g)$).

Hence $D \in \text{DTIME}(g) \setminus \text{DTIME}(f)$. $\blacksquare$

## Corollary: Proper hierarchies

- $\text{DTIME}(n) \subsetneq \text{DTIME}(n^2) \subsetneq \text{DTIME}(n^3) \subsetneq \cdots$.
- $\text{DTIME}(n^k) \subsetneq \text{DTIME}(2^n)$ for any fixed $k$.

So **polynomial time is a strict subclass** of exponential time, and within polynomial time, each higher exponent is strictly more powerful.

## Space hierarchy

**Theorem (analogous).** $\text{DSPACE}(f) \subsetneq \text{DSPACE}(g)$ if $f(n) = o(g(n))$ and both are space-constructible.

Note: the space hierarchy is tighter than the time hierarchy (no $\log$ factor needed).

## Non-deterministic hierarchies

Similar but slightly weaker statements hold for $\text{NTIME}$ (by Cook–Seiferas and Zák).

## Consequences

- **There is no "best" algorithm.** Harder problems can require strictly more time.
- **Limit on universal speedup.** You cannot hope for a single compiler optimization to reduce $O(n^2)$ algorithms to $O(n)$ in general.
- **Proof of $P \neq EXPTIME$.** Even without resolving $P \stackrel{?}{=} NP$, we know exponential time is strictly more powerful than polynomial time.

## Gap theorems

In contrast, there are **gap theorems** (Borodin 1972): for any computable function $h$, there is a function $f$ such that $\text{DTIME}(f) = \text{DTIME}(h(f))$. I.e., at some scale, more time does not help at all.

The combination (hierarchy + gap) gives a rich structure: sometimes more time helps, sometimes not.

## Relation to concrete lower bounds

The time hierarchy says harder-in-principle problems exist, but it doesn't tell us which problems. Finding **concrete lower bounds** for natural problems (e.g., "SAT requires $2^{\Omega(n)}$ time") is much harder and mostly open.

The best-known lower bound for SAT on deterministic Turing machines is $\tilde O(n^{1.8})$ time (Van Melkebeek, Raz). This is far from the exponential lower bound that most researchers believe holds.

## Practical import

For dynamic-coding engines:
- **Scaling laws exist.** An engine that handles $10^3$ constraints may fail at $10^6$ not because of implementation but because the problem is inherently harder at scale.
- **Profile and measure.** Empirical scaling tells you where your engine sits in the hierarchy; no amount of math tells you in advance.
- **Accept fundamental limits.** Some constraint systems simply cannot scale.

## Summary: the cosmic ceilings

| Ceiling                           | Says you cannot...                                                         |
|-----------------------------------|----------------------------------------------------------------------------|
| Halting (Turing)                  | decide termination of arbitrary programs.                                 |
| Rice                              | decide any non-trivial semantic property.                                 |
| Cook–Levin                        | solve SAT in polynomial time (assuming P ≠ NP).                           |
| Gödel incompleteness              | prove consistency of an expressive formal system from within itself.      |
| Time hierarchy                    | uniformly reduce time complexity of all algorithms.                       |

These walls are mathematical, not engineering. They do not move.

But they are **partial** walls: they constrain the whole space without forbidding specific progress. Every modern solver, verifier, and engine lives by the trade-offs these theorems impose, finding the largest usable subspace below the ceilings.

The ITT Intent Engine, and any genuinely novel dynamic-computation system, must do the same.
