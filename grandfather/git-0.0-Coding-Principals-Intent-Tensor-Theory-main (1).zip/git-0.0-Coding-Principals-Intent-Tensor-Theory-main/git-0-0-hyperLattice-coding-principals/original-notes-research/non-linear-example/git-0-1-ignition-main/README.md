# git-0-1-ignition-main

Ignition stage for initializing field thresholds and startup checks.
