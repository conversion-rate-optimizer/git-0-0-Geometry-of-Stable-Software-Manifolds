# The Immediate Consequence Operator $T_P$

The Scott-continuous operator whose least fixed point is the minimal model.

## Definition

Let $P$ be a Datalog program with Herbrand base $B_P$. The **immediate consequence operator**

$$
T_P : 2^{B_P} \to 2^{B_P}
$$

is defined by

$$
T_P(I) \;=\; \{\, h\sigma \;\mid\; (h \leftarrow b_1, \ldots, b_k) \in P,\; \sigma \text{ ground},\; \{b_1\sigma, \ldots, b_k\sigma\} \subseteq I \,\}.
$$

In words: $T_P(I)$ contains every head of a rule whose body is satisfied by $I$.

## Properties

**Proposition 1 (Monotonicity).** $I \subseteq J \Rightarrow T_P(I) \subseteq T_P(J)$.

*Proof.* If $h\sigma \in T_P(I)$, some rule has body $\{b_1\sigma, \ldots, b_k\sigma\} \subseteq I \subseteq J$, so $h\sigma \in T_P(J)$. $\blacksquare$

**Proposition 2 (Scott-continuity).** For every directed $\mathcal{D} \subseteq 2^{B_P}$:

$$
T_P\left(\bigcup \mathcal{D}\right) \;=\; \bigcup_{I \in \mathcal{D}} T_P(I).
$$

*Proof.* $(\supseteq)$ by monotonicity. $(\subseteq)$: if $h\sigma \in T_P(\bigcup \mathcal{D})$, then $\{b_1\sigma, \ldots, b_k\sigma\} \subseteq \bigcup \mathcal{D}$. Each $b_i\sigma$ is in some $I_i \in \mathcal{D}$. Because $\mathcal{D}$ is directed, there is a common $I \in \mathcal{D}$ with each $I_i \subseteq I$. Then $\{b_1\sigma, \ldots, b_k\sigma\} \subseteq I$, so $h\sigma \in T_P(I) \subseteq \bigcup_{I \in \mathcal{D}} T_P(I)$. $\blacksquare$

**Proposition 3 (Finitary).** $T_P$ is **finitary**: for any $I$, $T_P(I) = \bigcup \{T_P(F) : F \subseteq I, F \text{ finite}\}$.

This is stronger than Scott-continuity and gives us Kleene's theorem with *finite* approximants.

## Models as pre-fixed points

**Proposition 4.** $I$ is a model of $P$ iff $T_P(I) \subseteq I$.

*Proof.* By definition of model: for every ground rule instance, body in $I$ implies head in $I$. This is exactly the condition $T_P(I) \subseteq I$. $\blacksquare$

So models are **pre-fixed points** of $T_P$. The minimal model is $\bigcap \{I : T_P(I) \subseteq I\} = \operatorname{lfp}(T_P)$ by Knaster–Tarski.

## Fixed points are exactly models

**Proposition 5.** $I$ is a fixed point of $T_P$ iff $I$ is a **supported model**: every atom in $I$ is the head of some satisfied ground rule instance.

Supported models exclude "spurious" atoms — atoms present without justification. Not every model is supported; e.g., in the program $\{p \leftarrow p.\}$, both $\emptyset$ and $\{p\}$ are models, but only $\emptyset$ is supported (and is the minimal model, which equals $\operatorname{lfp}(T_P) = \emptyset$).

## Kleene characterization

By Kleene's theorem:

$$
\operatorname{lfp}(T_P) \;=\; \bigcup_{n \geq 0} T_P^n(\emptyset).
$$

The sequence $T_P^0(\emptyset) = \emptyset, T_P^1(\emptyset), T_P^2(\emptyset), \ldots$ stabilizes in at most $|B_P|$ steps for Datalog (since $B_P$ is finite and the chain is strictly increasing until it stabilizes).

## Example computation

Program:
```
edge(1, 2).
edge(2, 3).
path(X, Y) :- edge(X, Y).
path(X, Y) :- edge(X, Z), path(Z, Y).
```

- $T_P^0 = \emptyset$.
- $T_P^1 = \{\text{edge(1,2)}, \text{edge(2,3)}\}$ (facts fire).
- $T_P^2 = T_P^1 \cup \{\text{path(1,2)}, \text{path(2,3)}\}$.
- $T_P^3 = T_P^2 \cup \{\text{path(1,3)}\}$.
- $T_P^4 = T_P^3$ — stable.

So $\operatorname{lfp}(T_P) = T_P^3$, five atoms.

## Efficiency consideration

Naive iteration recomputes $T_P(I_n)$ from scratch each step. For Datalog with a program of size $m$, a database of size $n$, and longest derivation chain $d$, this costs $O(d \cdot m \cdot n^k)$ where $k$ is max arity.

Semi-naive evaluation (see `03_naive_vs_semi_naive.md`) avoids the redundancy and achieves $O(m \cdot n^k)$ total — the minimum possible.

## Generalization: negation

With **stratified negation**, the operator becomes piecewise monotone (monotone within each stratum, using the fixed point of lower strata as a constant). The minimal-model theorem generalizes to the **well-founded model** or **perfect model**.

With **unstratified negation**, $T_P$ is no longer monotone; the analog is the Gelfond–Lifschitz reduct (see `1.0.i_Answer_Set_Programming`). There, multiple **stable models** are possible.
