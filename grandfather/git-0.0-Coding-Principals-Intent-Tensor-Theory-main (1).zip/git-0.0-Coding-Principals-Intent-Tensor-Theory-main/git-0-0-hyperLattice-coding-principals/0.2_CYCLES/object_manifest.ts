/**
 * 0.2_CYCLES: Object Manifest
 * ============================
 * Registry of all persistent cycles — the real objects in the system.
 *
 * An Object = cycle with S_C ≥ 1
 * An Anchor = cycle with S_C ≥ 1.2 for 5+ consecutive steps
 *
 * The manifest is the ground truth of what exists right now.
 * Anything not in the manifest is noise or residue.
 */

import { SELECTION } from "../-Z_BASE/axioms";
import type { CodeCycle } from "./cycle_persistence";

export interface ObjectEntry {
  cycle: CodeCycle;
  registeredAt: number;    // Iteration when first registered
  lastSeen: number;        // Most recent iteration where S_C ≥ 1
  consecutiveWins: number;
  isAnchor: boolean;
}

export class ObjectManifest {
  private objects: Map<string, ObjectEntry> = new Map();
  private iteration: number = 0;

  /**
   * Canonical key for a cycle — sorted node list.
   * Order-independent identity.
   */
  private key(cycle: CodeCycle): string {
    return [...cycle.nodes].sort().join(",");
  }

  /**
   * Update manifest from current cycle states.
   * Registers new objects, updates streaks, removes dissolved ones.
   */
  update(cycles: CodeCycle[]): void {
    this.iteration++;

    const active = new Set<string>();

    for (const cycle of cycles) {
      if (!cycle.isObject) continue;

      const k = this.key(cycle);
      active.add(k);

      const existing = this.objects.get(k);
      if (existing) {
        existing.cycle = cycle;
        existing.lastSeen = this.iteration;
        existing.consecutiveWins++;
        existing.isAnchor = existing.consecutiveWins >= 5
          && cycle.S_C >= SELECTION.anchor;
      } else {
        this.objects.set(k, {
          cycle,
          registeredAt: this.iteration,
          lastSeen: this.iteration,
          consecutiveWins: 1,
          isAnchor: false,
        });
      }
    }

    // Remove objects not seen this iteration
    for (const [k, entry] of this.objects) {
      if (!active.has(k)) {
        entry.consecutiveWins = 0;
        entry.isAnchor = false;
        // Remove if unseen for 3+ iterations
        if (this.iteration - entry.lastSeen > 3) {
          this.objects.delete(k);
        }
      }
    }
  }

  get all(): ObjectEntry[]        { return Array.from(this.objects.values()); }
  get anchors(): ObjectEntry[]    { return this.all.filter(e => e.isAnchor); }
  get transient(): ObjectEntry[]  { return this.all.filter(e => !e.isAnchor); }
  get count(): number             { return this.objects.size; }

  /** Nodes that are part of at least one real object */
  get activeNodes(): Set<string> {
    const nodes = new Set<string>();
    for (const entry of this.objects.values()) {
      for (const n of entry.cycle.nodes) nodes.add(n);
    }
    return nodes;
  }

  summary(): string {
    return `ObjectManifest [t=${this.iteration}]: ${this.count} objects (${this.anchors.length} anchors)`;
  }
}
