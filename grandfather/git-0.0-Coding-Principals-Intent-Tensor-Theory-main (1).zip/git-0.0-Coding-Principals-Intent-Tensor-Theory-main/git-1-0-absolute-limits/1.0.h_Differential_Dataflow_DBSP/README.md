# 1.0.h — Differential Dataflow and DBSP

The algebra of incremental view maintenance: Z-sets, streams, integration, differentiation.

## Files

**Math:**
- `math/00_z_sets.md` — Multisets with negative counts.
- `math/01_streams_and_time.md` — Time-indexed sequences; frontiers.
- `math/02_integration_differentiation.md` — The I/D operator calculus.
- `math/03_incremental_view_maintenance.md` — Q^Δ = D ∘ Q ∘ I.
- `math/04_recursive_queries.md` — Nested fixed points.

**Code:**
- `code/dbsp_calculus_python.py` — Z-sets and I/D operators, pure Python.
- `code/timely_differential_rust.rs` — Timely/Differential Dataflow example.
- `code/materialize_sql.sql` — SQL for streaming incremental views.
