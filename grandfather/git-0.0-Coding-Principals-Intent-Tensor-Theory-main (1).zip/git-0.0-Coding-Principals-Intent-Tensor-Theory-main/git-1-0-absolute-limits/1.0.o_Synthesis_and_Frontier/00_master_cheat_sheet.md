# Master Cheat Sheet

Every paradigm, its equation, its code.

## The one-liner per paradigm

| Paradigm                        | Core equation                                                              | What you type                                        |
|---------------------------------|----------------------------------------------------------------------------|------------------------------------------------------|
| Generic fixed point             | $S^\star = F(S^\star)$                                                     | `lfp(F, bottom)`                                     |
| Kleene iteration                | $S^\star = \bigvee_n F^n(\bot)$                                            | `while changed: x = f(x)`                            |
| Contractive fixed point         | $d(f^n(x_0), x^\star) \leq \frac{q^n}{1-q} d(x_1, x_0)$                    | `while abs(x_next - x) > tol: x = f(x)`              |
| Abstract interpretation         | $\alpha(\operatorname{lfp}(F)) \leq \operatorname{lfp}(F^\sharp)$           | Galois pair + abstract $F^\sharp$                    |
| Datalog                         | $M_P = \operatorname{lfp}(T_P)$                                            | `path(X,Y) :- edge(X,Z), path(Z,Y).`                 |
| SAT                             | $\varphi \models \alpha?$                                                  | `solver.add(clause); solver.check()`                 |
| SMT                             | $T_1 \cup T_2 \text{ decidable}$ (Nelson–Oppen)                            | `solver.add(x + y == 10)`                            |
| MaxSAT / lex priorities         | $\arg\min_S \sum_j w_j \text{viol}_j(S)$ lexicographically                  | `opt.add_soft(c, weight=w, id=level)`                |
| Self-adjusting computation      | $\nabla f(x, \delta) = (f(x+\delta), \delta_y)$                            | `useMemo(fn, [deps])`                                |
| DBSP / differential dataflow    | $Q^\Delta = \mathbf{D} \circ Q \circ \mathbf{I}$                           | `CREATE MATERIALIZED VIEW v AS SELECT ...`           |
| ASP stable model                | $S = \operatorname{lfp}(T_{P^S})$                                          | `:- not valid. #minimize { ... }.`                   |
| Curry–Howard                    | Proposition as type; proof as term                                          | `theorem foo : A → B := by intro h; exact ...`       |
| Dependent types                 | $\prod_{x:A} B(x), \sum_{x:A} B(x)$                                        | `(n : Nat) -> Vec n Int`                             |
| Build systems                   | $\text{build} : \text{Tasks} \to k \to \text{Store} \to \text{Store}$       | `"*.o" %> \out -> do need [src]; cmd ...`            |
| Halting problem                 | $H(P, x)$ undecidable                                                      | `# guarded with maxIterations`                       |
| Rice's theorem                  | Every non-trivial semantic property undecidable                             | `# guarded with timeout`                             |
| Gödel incompleteness            | Consistent strong systems are incomplete                                    | `# axioms accepted externally`                       |

## Code by problem type

### "I want to propagate facts until stable"
→ Datalog (`1.0.e`). Write rules; call `evaluate_semi_naive`.

### "I want to solve a constraint system"
→ SAT/SMT (`1.0.f`). Use Z3 or cvc5.

### "I want efficient incremental updates"
→ SAC (`1.0.g`) or DBSP (`1.0.h`). Use React/Incremental for UI; Materialize/Feldera for data.

### "I want multiple consistent solutions"
→ ASP (`1.0.i`). Use clingo.

### "I want verified correctness"
→ Dependent types (`1.0.j`). Use Lean 4 or Idris.

### "I want automatic recompilation"
→ Build systems (`1.0.k`). Use Shake or Bazel.

### "I want a priority-driven rule engine"
→ Generic engine (`1.0.m`). Use the typed TypeScript engine or SMT-backed variant.

### "I want cross-file-type coordination"
→ Multi-substrate engine (`1.0.n`). Use the coupled engine or SMT-backed variant.

## When things go wrong

| Symptom                    | Likely cause                                      | Chapter          |
|----------------------------|---------------------------------------------------|------------------|
| Kleene loop runs forever   | Non-monotone operator                             | `1.0.c` §3.4     |
| SMT returns `unknown`      | Non-linear arithmetic, quantifiers, timeouts      | `1.0.f` §4       |
| ASP has no stable model    | Inconsistent rules                                | `1.0.i` §2       |
| Build loop detected        | Cyclic monadic task dependency                    | `1.0.k` §2       |
| Type system rejects code   | Invariant violation caught statically             | `1.0.j` §2       |
| Engine oscillates          | Retractive constraints without stratification     | `1.0.m` §3       |
| Multi-substrate diverges   | Incoherent cross-substrate translators            | `1.0.n` §3       |

For each: consult the corresponding chapter and apply the debugging strategy.
