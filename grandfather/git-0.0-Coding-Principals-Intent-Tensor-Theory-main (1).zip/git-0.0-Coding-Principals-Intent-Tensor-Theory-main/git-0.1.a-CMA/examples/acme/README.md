# Acme Corp — GitCMA Teaching Model

> ⚠️ This is NOT a runnable application.
> This is a **coordinate model** — a teaching scaffold showing how GitCMA scales
> from a simple single-domain app to a full multi-satellite enterprise.
> "Acme Corp" is our universal example company. Like Acme in every textbook.

---

## What You Are Looking At

The `acme/` directory demonstrates the **x.y.z coordinate manifold** applied to a
real-world multi-domain business. Every folder is a position in field space — not
a piece of running software.

```
acme/
├── 1.0-project/    ← x=1  Master Hub (aggregates all satellites)
├── 2.0-map/        ← x=2  Satellite A
├── 3.0-works/      ← x=3  Satellite B
└── 4.0-space/      ← x=4  Satellite C
```

The y-axis is invariant across ALL domains:

| y  | Function   | Acme Example           |
|----|------------|------------------------|
| .1 | Dashboard  | acme.com/dashboard     |
| .2 | Social     | acme.com/social        |
| .3 | Services   | acme.com/services      |
| .11| Call       | acme.com/dialer        |

So `2.2` = Map Social. `4.2` = Space Social. `1.2` = the HUB that aggregates both.
Same y, different x. This is the **Social Rail**. You can BROADCAST across it.

---

## The Teaching Point

### Simple → Complex progression:

**Level 1** — One domain, flat:
```
acme/1.0-project/1.1-project-dashboard/
```

**Level 2** — Add z-axis depth:
```
acme/4.0-space/4.2-space-social/4.2.a-live/
acme/4.0-space/4.2-space-social/4.2.b-threads/
```

**Level 3** — Multi-domain symmetry:
```
1.2  ←  aggregates  →  2.2 + 3.2 + 4.2
```

**Level 4** — Field operations become possible:
```javascript
BROADCAST y=2      // pulses ALL social nodes simultaneously
AGG 1.2 FROM 2..4  // folds satellites into hub
PATH 1.2 → 4.2     // traverses the Social Rail (Curvent)
```

---

## W/V Wave Connection

The x.y.z coordinate space IS the manifold that the W and V waves operate on.

```
W(φ, θ) = sin(2φ)cos(2θ)   ← Positive intent field
V(φ, θ) = −W(φ, θ)         ← Negative inverse field
```

When the EigenSpark fires (`Ξ > τ`), execution jumps directly to the target
coordinate — no traversal, no iteration. The manifold **rotates** to align the
target with the execution head. This is why the folder structure IS the math.

The folders are not organizational. They are **positions in field space**.
Navigating them is not file management. It is **field computation**.

---

## Acme as Your Template

When you build a real company on GitCMA, you replace "acme" with your company name.
The coordinate numbers never change. Only the semantic overlay (manifest.json) does.

```json
"4.2": { "label": "your-company-social" }
```

That is the entire "rename." One line. Zero broken imports. Zero refactoring.
This is Semantic Separation in action.

---
© Armstrong Knight | intent-tensor-theory.com | CC BY-NC 4.0
