(* Jane Street Incremental library — the canonical SAC implementation.
   Install: opam install incremental *)

open Core
open Incremental

module Inc = Incremental.Make ()

let () =
  let x = Inc.Var.create 10 in
  let y = Inc.Var.create 20 in

  (* Derivation node: eligible = x > 0 && y > 0 *)
  let eligible =
    Inc.map2
      (Inc.Var.watch x) (Inc.Var.watch y)
      ~f:(fun a b -> a > 0 && b > 0)
  in
  let eligible_obs = Inc.observe eligible in

  (* Constraint node: sent = eligible (simplified) *)
  let sent = Inc.map eligible ~f:(fun e -> e) in
  let sent_obs = Inc.observe sent in

  (* Stabilize to compute initial values *)
  Inc.stabilize ();
  printf "Initial: eligible = %b, sent = %b\n"
    (Inc.Observer.value_exn eligible_obs)
    (Inc.Observer.value_exn sent_obs);

  (* Change x to -1; propagate *)
  Inc.Var.set x (-1);
  Inc.stabilize ();
  printf "After x = -1: eligible = %b, sent = %b\n"
    (Inc.Observer.value_exn eligible_obs)
    (Inc.Observer.value_exn sent_obs);

  (* Change x back; propagate *)
  Inc.Var.set x 50;
  Inc.stabilize ();
  printf "After x = 50: eligible = %b, sent = %b\n"
    (Inc.Observer.value_exn eligible_obs)
    (Inc.Observer.value_exn sent_obs)
