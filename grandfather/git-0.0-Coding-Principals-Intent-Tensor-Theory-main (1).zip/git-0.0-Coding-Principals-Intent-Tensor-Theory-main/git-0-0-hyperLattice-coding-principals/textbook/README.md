# The HyperLattice Textbook

**Who this is for:** Anyone. No college required. No prior math required.  
**What this teaches:** How the code in this repository actually works — from first principles.  
**How long it takes:** Each chapter is under 1000 words. Read one. Stop. Let it settle.

---

## The Honest Promise

Every equation in this repo came from somewhere. A person discovered it. 
They usually discovered it by watching something in nature and asking 
*why does that happen?* Then they wrote the simplest possible description 
of what they saw. That description became math. That math eventually 
became code.

This textbook traces that path in reverse — from the code back to the 
observation, so you understand *why the code is shaped the way it is*, 
not just *what it does*.

---

## Chapters

| Chapter | Title | Core Idea |
|:---|:---|:---|
| [00](./ch-00-before-math.md) | Before the Math | Math is compressed observation |
| [01](./ch-01-what-is-a-field.md) | What Is a Field? | Sand on a plate. The pattern was in the sound. |
| [02](./ch-02-what-is-a-graph.md) | What Is a Graph? | Cities and roads. No jargon. |
| [03](./ch-03-how-fields-spread.md) | How Fields Spread | Heat in a metal rod. The diffusion equation. |
| [04](./ch-04-what-is-a-matrix.md) | What Is a Matrix? | Cayley 1858. Why spreadsheets exist. |
| [05](./ch-05-the-selection-gate.md) | The Selection Gate | Does it persist or decay? |
| [06](./ch-06-what-is-a-cycle.md) | What Is a Cycle? | Why loops hold energy and chains don't |
| [07](./ch-07-the-bloom.md) | The Bloom | When structure grows faster than disorder |
| [08](./ch-08-into-the-code.md) | Into the Code | Reading the actual TypeScript files |
| [09](./ch-09-whats-next.md) | What's Next | Open problems. Where the frontier is. |

---

## How to Read This

Go in order. Every chapter assumes the previous one.

If you get stuck, go back one chapter. The stuck feeling is not a sign 
you are not smart enough. It is a sign something earlier did not land yet.

---

*Armstrong Knight — intent-tensor-theory.com — CC BY-NC 4.0*  
*Written with Claude (Anthropic) as research and writing partner.*
