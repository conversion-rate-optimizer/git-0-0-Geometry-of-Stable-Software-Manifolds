# Streams and Time

Z-sets become truly useful when arranged into streams and annotated with timestamps.

## Streams

A **stream** over $\mathbb{Z}[D]$ is a function

$$
s : \mathbb{N} \to \mathbb{Z}[D].
$$

$s[t]$ is the Z-set at time step $t$. We often write $s = (s[0], s[1], s[2], \ldots)$.

Streams form a ring under pointwise operations:
- $(s + t)[n] = s[n] + t[n]$.
- $(s \cdot t)[n] = \sum_{k=0}^{n} s[k] \cdot t[n-k]$ (convolution, if the underlying $\mathbb{Z}[D]$ has a multiplication).

## Partial order on time

**DBSP** uses $\mathbb{N}$ (total order).
**Differential Dataflow** uses an arbitrary partially-ordered set $(T, \leq)$ of timestamps. For example:
- $T = \mathbb{N}^k$ with pointwise order for $k$-nested iteration.
- $T = \mathbb{N} \times L$ where $L$ is a loop-iteration counter.

The partial order lets you talk about parallelism ("these updates are independent") and loops ("iteration $i$ precedes iteration $i+1$").

## Frontiers

Instead of a single time, a **frontier** is an antichain in $(T, \leq)$:

$$
F \subseteq T, \qquad \forall t_1 \neq t_2 \in F : t_1 \not\leq t_2 \wedge t_2 \not\leq t_1.
$$

Interpretation: $F$ marks the boundary between "known complete" times (below $F$) and "still arriving" times (above or incomparable to $F$).

Differential Dataflow operators advance frontiers as input data arrives, which is how it handles distributed progress tracking.

## Streams of Z-sets in differential dataflow

A **collection** in differential dataflow is:

$$
c : D \times T \to \mathbb{Z}
$$

with finite support. $c[d, t]$ is the multiplicity of $d$ at time $t$.

Equivalently: a stream of Z-sets indexed by $T$.

## Operations lifted to streams

Each operation on $\mathbb{Z}[D]$ lifts pointwise to streams:
- $\sigma_\varphi(s)[t] = \sigma_\varphi(s[t])$.
- $\pi_S(s)[t] = \pi_S(s[t])$.
- $(s_1 \bowtie_\kappa s_2)[t] = s_1[t] \bowtie_\kappa s_2[t]$.

For windowed or across-time operations, additional operators exist (integration, shifts).

## Why time and not just Z-sets

Three reasons:

1. **Recursion and iteration.** A recursive view needs to refer to "the previous iteration" — a time-shifted version of itself. You can't express this without a time dimension.

2. **Distributed progress.** In a distributed system, you need to know which updates have been fully absorbed across all workers. Frontiers are the mechanism.

3. **Incremental view maintenance.** The update calculus (integration/differentiation) fundamentally depends on having a sequence of states, not just a single Z-set.

## Example: live tabular data

Think of a SQL table as a stream:

| $t$   | Insert/delete     | Z-set at $t$                         |
|-------|-------------------|--------------------------------------|
| $0$   | +(1, 'Alice')     | $\{(1,\text{Alice})\}$               |
| $1$   | +(2, 'Bob')       | $\{(2,\text{Bob})\}$                 |
| $2$   | +(3, 'Carol')     | $\{(3,\text{Carol})\}$               |
| $3$   | -(2, 'Bob')       | $-\{(2,\text{Bob})\}$                |

The integrated view is the "current snapshot" at each time (see next file).

## Practical stream programs

Frank McSherry's `timely-dataflow` in Rust lets you define stream computations:

```rust
worker.dataflow::<u64, _, _>(|scope| {
    let input = InputHandle::<u64, (i32, isize)>::new();
    scope.input_from(&input)
        .filter(|(x, _w)| x > &10)
        .count()
        .inspect(|x| println!("{:?}", x));
});
```

Each operator takes streams in and produces streams out. Time is implicit but tracked rigorously via frontiers.
