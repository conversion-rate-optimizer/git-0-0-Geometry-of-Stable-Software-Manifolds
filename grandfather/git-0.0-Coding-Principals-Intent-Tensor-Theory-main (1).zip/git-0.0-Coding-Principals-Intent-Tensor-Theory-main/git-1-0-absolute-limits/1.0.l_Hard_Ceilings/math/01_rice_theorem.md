# Rice's Theorem

The universal undecidability theorem: every non-trivial semantic property of programs is undecidable.

## Statement

**Theorem (Rice, 1953).** *Let $\mathcal{F}$ be a non-trivial set of partial computable functions, i.e., $\mathcal{F} \neq \emptyset$ and $\mathcal{F}$ does not contain all such functions. Then the set*

$$
\{ P : \llbracket P \rrbracket \in \mathcal{F} \}
$$

*is undecidable.*

Where $\llbracket P \rrbracket$ denotes the (partial) function computed by program $P$.

## Proof

We reduce from the halting problem. Pick:
- Some partial function $f_0 \notin \mathcal{F}$ (exists because $\mathcal{F}$ is proper).
- Some partial function $f_1 \in \mathcal{F}$ (exists because $\mathcal{F}$ is non-empty).
- Programs $P_0, P_1$ computing $f_0, f_1$ respectively.

**Case 1: $f_0$ is the always-undefined function.**

Given an instance $(Q, x)$ of halting, construct the program:

```
def R(y):
    run Q on x for finitely many steps
    if Q(x) has halted: return P_1(y)
    else: return P_0(y) = undefined
```

Then:
- If $Q(x)$ halts: $R$ computes $P_1$'s function = $f_1 \in \mathcal{F}$.
- If $Q(x)$ doesn't halt: $R$ computes the always-undefined function = $f_0 \notin \mathcal{F}$.

A decider for "$\llbracket R \rrbracket \in \mathcal{F}$?" would decide halting.

**Case 2: $f_0$ is not the always-undefined function.**

Swap the roles: pick $f_0$ as a witness that $\mathcal{F}^c$ is non-empty and $f_1$ as a witness that $\mathcal{F}$ is non-empty, etc. The symmetric construction works.

$\blacksquare$

## What "semantic" means

A property of programs is **semantic** iff it depends only on the function the program computes, not on its syntactic form.

- Semantic: "does this program halt on every input?"
- Semantic: "does this program compute a bijection?"
- Semantic: "is this program equivalent to program $P_0$?"

- **Not** semantic: "does this program contain a `while` loop?" (syntactic).
- **Not** semantic: "does this program have fewer than 100 lines?" (syntactic).

Rice's theorem says *every* non-trivial **semantic** property is undecidable. Syntactic properties can be decidable.

## Consequences

An astonishingly large collection of problems is automatically undecidable:

- **Totality:** "does $P$ halt on every input?"
- **Injectivity:** "does $P$ compute a one-to-one function?"
- **Equivalence:** "do $P_1, P_2$ compute the same function?"
- **Complexity:** "is $P$ polynomial-time?"
- **Correctness w.r.t. a spec:** "does $P$ compute function $f$?"
- **Termination of recursive calls:** "does this recursive call always terminate?"
- **Convergence of a fixed-point system:** "does $P$ reach a fixed point?"

Every entry here is a direct corollary of Rice.

## The "non-trivial" escape

Rice's theorem requires $\mathcal{F}$ to be non-trivial (neither empty nor everything). The trivial properties are decidable:

- $\mathcal{F} = \emptyset$: always false. Decidable.
- $\mathcal{F}$ = all partial functions: always true. Decidable.

So if you truly want to decide a property of all programs, make it trivially true or trivially false. Not useful.

## Strengthening: Rice–Shapiro

**Theorem (Rice–Shapiro).** *For an "index set" $\mathcal{F}$ (a semantic property) to be recursively enumerable (semi-decidable), $\mathcal{F}$ must be expressible as the union of upper sets on a computable partial order of partial functions.*

Consequence: only positive, finitely-checkable properties are semi-decidable. "$\llbracket P \rrbracket(3) = 7$" is semi-decidable (run $P$ on 3, wait for it to output 7). "$\llbracket P \rrbracket$ is total" is not semi-decidable.

## Practical import

Rice's theorem is why:
- **Static analyzers are incomplete.** They must either miss bugs or raise false alarms.
- **Type systems cannot catch all runtime errors** that depend on runtime behavior.
- **Program-equivalence checking is never perfectly automatic.**
- **Compiler optimizations can only prove equivalence for restricted program classes.**

Every tool you rely on has accepted Rice's theorem and placed its trust boundary accordingly.

## Connection to the ITT engine

If you want to decide: "does this ITT Intent Engine always converge?" — Rice says **no**. It's a non-trivial semantic property of programs.

The best you can do:
- Decide **syntactic** properties (did you use only monotone constraints?).
- Decide **restricted semantic** properties (is this specific engine instance terminating for this specific input class?).
- Accept `unknown` / `maxIter` as first-class outputs.

This is honest engineering in the face of Rice.
