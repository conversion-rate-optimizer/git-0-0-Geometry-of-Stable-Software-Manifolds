/**
 * +Z_APEX: Selection Gate
 * ========================
 * Node-level existence condition: S_i = φ / |Δφ| ≥ 1
 *
 * Separates persistent structure from transient fluctuation.
 * Called during field evolution (steps 2-10), not at convergence.
 */

import { SELECTION, LATTICE } from "../-Z_BASE/axioms";

/**
 * Selection number for a single node.
 * Capped at 1000 — prevents overflow at convergence.
 */
export function selectionNumber(phi: number, phi_prev: number): number {
  const delta = Math.abs(phi - phi_prev);
  return Math.min(phi / (delta + LATTICE.epsilon_field), 1000);
}

/**
 * Apply selection gate to the full field.
 * Returns persistent nodes (S ≥ 1) and noise (S < 1).
 */
export function applySelectionGate(
  phi: Map<string, number>,
  phi_prev: Map<string, number>
): {
  persistent: string[];
  noise: string[];
  S: Map<string, number>;
} {
  const persistent: string[] = [];
  const noise: string[]      = [];
  const S = new Map<string, number>();

  for (const [id, val] of phi) {
    const s = selectionNumber(val, phi_prev.get(id) ?? 0);
    S.set(id, s);
    if (s >= SELECTION.persistence) persistent.push(id);
    else noise.push(id);
  }

  return { persistent, noise, S };
}

/**
 * Gate check for a single node — used at execution time.
 * Returns true if the node is real, false if it's noise.
 */
export function nodeExists(phi: number, phi_prev: number): boolean {
  return selectionNumber(phi, phi_prev) >= SELECTION.persistence;
}
