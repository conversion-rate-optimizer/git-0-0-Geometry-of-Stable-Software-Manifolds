# 1.0.n — Multi-Substrate Engine

The genuinely novel territory: a product-lattice fixed-point engine over multiple file types / representations.

## Files

**Math:**
- `math/00_product_lattices.md` — Product of substrate lattices.
- `math/01_cross_substrate_translators.md` — Coupling operators and their laws.
- `math/02_convergence_across_substrates.md` — When the product engine converges.
- `math/03_open_questions.md` — Research directions.

**Code:**
- `code/multi_substrate_engine.ts` — Full TypeScript implementation.
- `code/itt_three_substrate_demo.ts` — `.md ↔ .py ↔ .html` demo.
- `code/multi_substrate_smt.py` — SMT-backed cross-substrate resolver.
