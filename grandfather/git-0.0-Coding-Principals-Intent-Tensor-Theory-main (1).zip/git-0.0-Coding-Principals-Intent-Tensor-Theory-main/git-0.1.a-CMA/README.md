# git-0.1.a-CMA
## The Coordinate Manifold Architecture — Reference Manual

*Created by Armstrong Knight — intent-tensor-theory.com*
*CC BY-NC 4.0*

---

> This folder IS the architecture it describes.
> The coordinate `0.1.a` means: system layer (0), first subsystem (1), variant a (a).
> You are inside a GitCMA node reading about GitCMA nodes.
> That is not accidental.

---

## PART 1 — THE TWO FORMS: RIGHT AND WRONG

Before anything else, you must be able to see the difference instantly.
This is the most important skill in the entire system.

---

### ❌ THE WRONG FORM — Semantic Pollution

```
git-0.0-app-name/
├── 0.0-shared/
├── 0.1-ignition/
├── 0.2-runtime/
├── 0.3-infrastructure/
├── 1.0-project/
│   ├── 1.1-project-dashboard/
│   ├── 1.2-project-social/
│   └── 1.11-project-call/
├── 2.0-map/
│   ├── 2.1-map-dashboard/
│   └── 2.2-map-social/
└── 4.0-space/
    ├── 4.1-space-dashboard/
    └── 4.2-space-social/
        ├── 4.2.a-live/
        └── 4.2.b-threads/
```

**What is wrong with this:**

| Violation | Where | Why It Breaks |
|-----------|-------|---------------|
| Meaning inside coordinate path | `1.1-project-dashboard/` | Renaming "dashboard" requires moving the folder |
| Semantic pollution | `4.2.a-live/` | "live" is meaning, not position |
| Parser coupling | `4.2.b-threads/` | Code must know the name to build the path |
| Law 2 broken | Every folder | Meaning is not separate — it is baked in |

When you write `4.2.a-live/` you have permanently coupled the word "live" to that coordinate. If "live" becomes "stream" or "broadcast" — you move a folder, you break imports, you refactor references. The name became load-bearing structure. This is **semantic debt** baked into the filesystem.

> The old form is useful as a teaching aid. It maps the coordinates correctly.
> The comments (`<-- THE NERVOUS SYSTEM`) are the manifest — they just aren't
> in a manifest.json. They are floating in human memory. That is the bug.

---

### ✅ THE CORRECT FORM — Pure Coordinate Space

```
git-0.0-app-name/
├── 0.0/
├── 0.1/
├── 0.2/
├── 0.3/
├── 1.0/
│   ├── 1.1/
│   ├── 1.2/
│   └── 1.11/
├── 2.0/
│   ├── 2.1/
│   └── 2.2/
└── 4.0/
    ├── 4.1/
    └── 4.2/
        ├── 4.2.a/
        └── 4.2.b/
```

**What changed:**

```
❌  1.1-project-dashboard/    →    ✅  1.1/
❌  4.2.a-live/               →    ✅  4.2.a/
❌  2.2-map-social/           →    ✅  2.2/
```

No words. No meaning. Only position. The filesystem is now a pure machine.

The meaning that was in the folder names now lives here — and only here:

```json
// manifest.json
{
  "0.0": "shared-engine",
  "0.1": "ignition",
  "0.2": "runtime",
  "0.3": "infrastructure",

  "1.1": "project-dashboard",
  "1.2": "project-social",
  "1.11": "project-call",

  "2.1": "map-dashboard",
  "2.2": "map-social",

  "4.1": "space-dashboard",
  "4.2": "space-social",
  "4.2.a": "space-social-live",
  "4.2.b": "space-social-threads"
}
```

Now if "live" becomes "stream":

```json
"4.2.a": "space-social-stream"   // ← one line change
```

Zero folders moved. Zero imports broken. Zero refactoring. The physics of the system
did not change. Only the label in the manifest changed. This is **Semantic Separation**.

---

### The Core Equation

```
OLD:  structure = meaning           (fragile — coupled)
NEW:  structure = position          (invariant)
      meaning   = manifest mapping  (flexible)
```

```
R(x,y,z)  ⊥  M(x,y,z)

Position (R) is orthogonal to Meaning (M).
They cannot contaminate each other.
```

---

## PART 2 — THE COORDINATE CLASS

The coordinate is not just a folder name. It is a mathematical object.

```python
class Coordinate:
    """
    A position in the GitCMA manifold.
    Three-dimensional: Domain (x), Function (y), Sub-Op (z).
    """
    def __init__(self, x, y, z=None):
        self.x = x          # Domain    — the "Where"
        self.y = y          # Function  — the "What"
        self.z = z          # Sub-Op    — the "Specific" (optional)
        self.vector = [x, y, z or 0]

    def manifold_distance(self, target):
        """
        L1 Norm — Manhattan Distance between two coordinates.
        Measures architectural coupling directly.

        d(Φ₁, Φ₂) = |x₁−x₂| + |y₁−y₂| + |z₁−z₂|

        Distance 0 = same node
        Distance 1 = adjacent (local step)
        Distance 2 = cross-function or cross-domain
        Distance 3+ = cross-domain AND cross-function (high coupling warning)
        """
        return sum(abs(a - b) for a, b in zip(self.vector, target.vector))

    def resolve(self, domains, functions, sub_ops=None):
        """
        Resolve this coordinate to a filesystem path.
        This is the RCL resolver — O(1), pure computation, no I/O.
        """
        domain = domains.get(self.x, str(self.x))
        func   = functions.get(self.y, str(self.y))
        base   = f"/{self.x}.0-{domain}/{self.x}.{self.y}-{domain}-{func}"
        if self.z and sub_ops:
            label = sub_ops.get(self.z, self.z)
            return f"{base}/{self.x}.{self.y}.{self.z}-{label}"
        return base

    def __repr__(self):
        if self.z:
            return f"Coordinate({self.x}.{self.y}.{self.z})"
        return f"Coordinate({self.x}.{self.y})"


# ── Usage ─────────────────────────────────────────────────────────────────────

DOMAINS   = {1: "project", 2: "map", 3: "works", 4: "space"}
FUNCTIONS = {1: "dashboard", 2: "social", 3: "services", 11: "call"}
SUB_OPS   = {"a": "live", "b": "threads", "c": "blogs"}

c1 = Coordinate(4, 2, "a")   # Space Social Live
c2 = Coordinate(1, 2)        # Project Social (hub)
c3 = Coordinate(4, 1)        # Space Dashboard

print(c1.manifold_distance(c2))    # → 3  (cross-domain + has sub-op)
print(c1.manifold_distance(c3))    # → 1  (same domain, adjacent function)
print(c2.manifold_distance(c3))    # → 4  (full cross)
```

### Distance Interpretation Table

```
d = 0    Same node.          You are already there.
d = 1    Local step.         Sibling function in same domain.
d = 2    Cross-function.     Two functions apart, same domain.
         OR cross-domain,    Same function, one domain apart.
d = 3    Cross-domain +      High coupling. Review whether these
         cross-function.     should communicate directly.
d = 4+   Deep cross.         Almost certainly needs an intermediate
                             aggregator node (a 1.x hub).
```

---

## PART 3 — THE TREE CATALOGUE

Every tree below is shown in both forms: **wrong (semantic pollution)** and
**correct (pure coordinate)**. Study the contrast. Then study the correct form
until you cannot see the wrong form without discomfort.

---

### TREE 1 — The Personal Blog / Portfolio Site
**Simplest possible case. One domain. Flat.**

```
Complexity:  ★☆☆☆☆
Domains:     1
Functions:   4
Sub-ops:     0
Coordinates: 4 nodes
```

**❌ Wrong:**
```
my-blog/
├── home/
├── about/
├── posts/
└── contact/
```

**✅ Correct — Pure Coordinate:**
```
git-0.0-my-blog/
├── 1.0/
│   ├── 1.1/
│   ├── 1.2/
│   ├── 1.3/
│   └── 1.4/
└── manifest.json
```

**manifest.json:**
```json
{
  "1.1": "home",
  "1.2": "about",
  "1.3": "posts",
  "1.4": "contact"
}
```

**W-Axis note:** With one domain and four functions, the Social Rail does not yet exist.
You have a line, not a plane. `W(φ,θ)` has one lobe. The EigenSpark fires on any `y`
in domain `x=1`. This is the simplest stabilized manifold.

---

### TREE 2 — The Small Business Website
**One domain. Functions include sub-ops.**

```
Complexity:  ★★☆☆☆
Domains:     1
Functions:   5
Sub-ops:     3 (under posts/services)
Coordinates: 11 nodes
```

**❌ Wrong:**
```
acme-site/
├── home/
├── about/
├── services/
│   ├── consulting/
│   ├── design/
│   └── development/
├── blog/
│   ├── articles/
│   └── case-studies/
└── contact/
```

**✅ Correct:**
```
git-0.0-acme-site/
├── 1.0/
│   ├── 1.1/
│   ├── 1.2/
│   ├── 1.3/
│   │   ├── 1.3.a/
│   │   ├── 1.3.b/
│   │   └── 1.3.c/
│   ├── 1.4/
│   │   ├── 1.4.a/
│   │   └── 1.4.b/
│   └── 1.5/
└── manifest.json
```

**manifest.json:**
```json
{
  "1.1": "home",
  "1.2": "about",
  "1.3": "services",
  "1.3.a": "services-consulting",
  "1.3.b": "services-design",
  "1.3.c": "services-development",
  "1.4": "blog",
  "1.4.a": "blog-articles",
  "1.4.b": "blog-case-studies",
  "1.5": "contact"
}
```

**Key insight:** `1.3.a`, `1.3.b`, `1.3.c` — the z-axis letters are stable.
If "consulting" becomes "advisory", you change one manifest line.
The folder `1.3.a/` never moves.

---

### TREE 3 — The SaaS App (Single Product)
**System layer (0.x) introduced. One product domain.**

```
Complexity:  ★★★☆☆
Domains:     1 product + system layer
Functions:   8
Sub-ops:     4
Coordinates: 16 nodes
```

**❌ Wrong:**
```
git-0.0-acme-app/
├── shared/
├── ignition/
├── runtime/
├── dashboard/
├── users/
│   ├── profiles/
│   └── settings/
├── billing/
├── api/
│   ├── v1/
│   └── v2/
├── notifications/
└── support/
```

**✅ Correct:**
```
git-0.0-acme-app/
├── 0.0/          ← shared engine
├── 0.1/          ← ignition
├── 0.2/          ← runtime
├── 1.0/
│   ├── 1.1/      ← dashboard
│   ├── 1.2/      ← users
│   │   ├── 1.2.a/
│   │   └── 1.2.b/
│   ├── 1.3/      ← billing
│   ├── 1.4/      ← api
│   │   ├── 1.4.a/
│   │   └── 1.4.b/
│   ├── 1.5/      ← notifications
│   └── 1.6/      ← support
└── manifest.json
```

**manifest.json:**
```json
{
  "0.0": "shared-engine",
  "0.1": "ignition",
  "0.2": "runtime",

  "1.1": "dashboard",
  "1.2": "users",
  "1.2.a": "users-profiles",
  "1.2.b": "users-settings",
  "1.3": "billing",
  "1.4": "api",
  "1.4.a": "api-v1",
  "1.4.b": "api-v2",
  "1.5": "notifications",
  "1.6": "support"
}
```

**RCL operations now available:**
```
resolve("1.2.a")   →  /1.0/1.2/1.2.a/
resolve("1.4.b")   →  /1.0/1.4/1.4.b/

distance(1.1, 1.6) = |1−1| + |1−6| = 5   ← high. these should not directly couple.
distance(1.2, 1.2.a) = 0 + 0 + 1 = 1     ← local. parent to child. correct.
```

---

### TREE 4 — The Multi-Brand Platform
**Two domains (satellites). Hub introduced. Social Rail exists.**

```
Complexity:  ★★★★☆
Domains:     2 satellites + hub + system
Functions:   6
Sub-ops:     4
Coordinates: 28 nodes
Rail:        y=2 Social Rail now spans 3 domains
```

**❌ Wrong:**
```
git-0.0-acme-platform/
├── shared/
├── hub/
│   ├── hub-dashboard/
│   └── hub-social/
├── brand-alpha/
│   ├── alpha-dashboard/
│   └── alpha-social/
│       ├── alpha-social-feed/
│       └── alpha-social-posts/
└── brand-beta/
    ├── beta-dashboard/
    └── beta-social/
        ├── beta-social-feed/
        └── beta-social-posts/
```

**✅ Correct:**
```
git-0.0-acme-platform/
├── 0.0/
├── 0.1/
├── 0.2/
│
├── 1.0/               ← HUB (Master Aggregator)
│   ├── 1.1/           ← aggregates 2.1, 3.1
│   ├── 1.2/           ← aggregates 2.2, 3.2
│   ├── 1.3/
│   └── 1.4/
│
├── 2.0/               ← BRAND ALPHA
│   ├── 2.1/
│   ├── 2.2/
│   │   ├── 2.2.a/
│   │   └── 2.2.b/
│   ├── 2.3/
│   └── 2.4/
│
└── 3.0/               ← BRAND BETA
    ├── 3.1/
    ├── 3.2/
    │   ├── 3.2.a/
    │   └── 3.2.b/
    ├── 3.3/
    └── 3.4/
```

**manifest.json:**
```json
{
  "0.0": "shared-engine",
  "0.1": "ignition",
  "0.2": "runtime",

  "1.1": { "label": "hub-dashboard",  "aggregate": ["2.1", "3.1"] },
  "1.2": { "label": "hub-social",     "aggregate": ["2.2", "3.2"] },
  "1.3": { "label": "hub-services",   "aggregate": ["2.3", "3.3"] },
  "1.4": { "label": "hub-billing",    "aggregate": ["2.4", "3.4"] },

  "2.1": "alpha-dashboard",
  "2.2": "alpha-social",
  "2.2.a": "alpha-social-feed",
  "2.2.b": "alpha-social-posts",
  "2.3": "alpha-services",
  "2.4": "alpha-billing",

  "3.1": "beta-dashboard",
  "3.2": "beta-social",
  "3.2.a": "beta-social-feed",
  "3.2.b": "beta-social-posts",
  "3.3": "beta-services",
  "3.4": "beta-billing"
}
```

**The Social Rail now exists:**
```
BROADCAST y=2  →  hits 1.2, 2.2, 3.2 simultaneously

PATH 1.2 → 3.2:
  step 1: (1,2) → (2,2)    distance 1
  step 2: (2,2) → (3,2)    distance 1
  total distance: 2

AGG 1.2 FROM 2..3  →  1.2 pulls data from 2.2 and 3.2
```

**Distance analysis:**
```
distance(2.2.a, 3.2.a) = |2−3| + |2−2| + |a−a| = 1
  → Alpha feed and Beta feed are maximally close.
  → They share rail y=2 and sub-op z=a. One domain apart.
  → A broadcast covers both in one operation. ✓

distance(2.1, 3.4) = |2−3| + |1−4| = 4
  → Alpha dashboard and Beta billing are architecturally distant.
  → They should never directly communicate.
  → If they do, something is wrong with the design. ✗
```

---

### TREE 5 — The Full Enterprise Platform (Acme Corp)
**Four domains. Full function set. Deep z-axis on Social.**
**This is the reference implementation.**

```
Complexity:  ★★★★★
Domains:     4 satellites + hub + system
Functions:   11
Sub-ops:     7 (on 4.2 alone)
Coordinates: 60+ nodes
Rails:       y=1, y=2, y=3 all span 4 domains
```

**✅ Correct — Full Acme:**
```
git-0.0-acme-enterprise/
│
├── 0.0/                    ← Shared Engine
├── 0.1/                    ← Ignition
├── 0.2/                    ← Runtime
├── 0.3/                    ← Infrastructure (Docker)
│
├── 1.0/                    ← MASTER HUB
│   ├── 1.1/                ← Dashboard  (agg: 2.1, 3.1, 4.1)
│   ├── 1.2/                ← Social     (agg: 2.2, 3.2, 4.2)
│   ├── 1.3/                ← Services   (agg: 2.3, 3.3, 4.3)
│   ├── 1.4/                ← Customers
│   ├── 1.5/                ← Partners
│   ├── 1.6/                ← Invoices
│   ├── 1.7/                ← Calendar
│   ├── 1.8/                ← Inquiry
│   ├── 1.9/                ← Direct
│   ├── 1.10/               ← Email
│   └── 1.11/               ← Call
│
├── 2.0/                    ← SATELLITE: MAP
│   ├── 2.1/
│   ├── 2.2/
│   │   ├── 2.2.a/
│   │   ├── 2.2.b/
│   │   └── 2.2.c/
│   └── 2.3/
│
├── 3.0/                    ← SATELLITE: WORKS
│   ├── 3.1/
│   ├── 3.2/
│   │   ├── 3.2.a/
│   │   ├── 3.2.b/
│   │   └── 3.2.c/
│   └── 3.3/
│
└── 4.0/                    ← SATELLITE: SPACE
    ├── 4.1/
    ├── 4.2/
    │   ├── 4.2.a/          ← live
    │   ├── 4.2.b/          ← threads
    │   ├── 4.2.c/          ← blogs
    │   ├── 4.2.d/          ← short-posts
    │   ├── 4.2.e/          ← albums
    │   ├── 4.2.f/          ← video
    │   └── 4.2.g/          ← audio
    └── 4.3/
```

**manifest.json (condensed):**
```json
{
  "0.0": "shared-engine",
  "0.1": "ignition",
  "0.2": "runtime",
  "0.3": "infrastructure",

  "1.1":  { "label": "hub-dashboard",  "aggregate": ["2.1","3.1","4.1"] },
  "1.2":  { "label": "hub-social",     "aggregate": ["2.2","3.2","4.2"] },
  "1.3":  { "label": "hub-services",   "aggregate": ["2.3","3.3","4.3"] },
  "1.4":  "hub-customers",
  "1.5":  "hub-partners",
  "1.6":  "hub-invoices",
  "1.7":  "hub-calendar",
  "1.8":  "hub-inquiry",
  "1.9":  "hub-direct",
  "1.10": "hub-email",
  "1.11": "hub-call",

  "2.1": "map-dashboard",
  "2.2": "map-social",
  "2.2.a": "map-social-live",
  "2.2.b": "map-social-threads",
  "2.2.c": "map-social-blogs",
  "2.3": "map-services",

  "3.1": "works-dashboard",
  "3.2": "works-social",
  "3.2.a": "works-social-live",
  "3.2.b": "works-social-threads",
  "3.2.c": "works-social-blogs",
  "3.3": "works-services",

  "4.1": "space-dashboard",
  "4.2": "space-social",
  "4.2.a": "space-social-live",
  "4.2.b": "space-social-threads",
  "4.2.c": "space-social-blogs",
  "4.2.d": "space-social-short-posts",
  "4.2.e": "space-social-albums",
  "4.2.f": "space-social-video",
  "4.2.g": "space-social-audio",
  "4.3": "space-services"
}
```

**All three rails now active:**
```
BROADCAST y=1  →  1.1, 2.1, 3.1, 4.1   (Dashboard Rail)
BROADCAST y=2  →  1.2, 2.2, 3.2, 4.2   (Social Rail)
BROADCAST y=3  →  1.3, 2.3, 3.3, 4.3   (Services Rail)

AGG 1.1 FROM 2..4   →  pulls all dashboards into hub
AGG 1.2 FROM 2..4   →  pulls all social into hub
```

---

### TREE 6 — The App + Website Relationship
**Two repos. Matching coordinate systems. This is where it gets powerful.**

Two separate git repos — one for the web app, one for the marketing site.
Because both follow GitCMA, their coordinate systems **match and interoperate**.

```
git-0.0-acme-app/           git-0.0-acme-web/
├── 0.0/                    ├── 0.0/
├── 1.0/                    ├── 1.0/
│   ├── 1.1/   ←─────────────── 1.1/   (same function: dashboard/home)
│   ├── 1.2/   ←─────────────── 1.2/   (same function: social/blog)
│   └── 1.3/   ←─────────────── 1.3/   (same function: services/features)
└── manifest.json           └── manifest.json
```

**acme-app manifest:**
```json
{
  "1.1": "app-dashboard",
  "1.2": "app-feed",
  "1.3": "app-settings"
}
```

**acme-web manifest:**
```json
{
  "1.1": "homepage",
  "1.2": "blog",
  "1.3": "features"
}
```

**What this enables:**

Same coordinate `1.2` in two repos. One is the live app feed. One is the marketing blog.
An AI agent or CI pipeline traversing both repos knows exactly where to look because the
y-axis is invariant. It does not parse folder names. It computes `(1, 2)` and finds the
right node in both repos simultaneously.

This is **cross-repo coordinate communication**. One resolver, two manifolds, zero ambiguity.

```python
repos = {
    "app": GitCMARepo("git-0.0-acme-app"),
    "web": GitCMARepo("git-0.0-acme-web")
}

# Find all "social/content" nodes across both repos
social_nodes = {
    name: repo.resolve("1.2")
    for name, repo in repos.items()
}
# → {"app": "/1.0/1.2/", "web": "/1.0/1.2/"}
# Same coordinate. Different manifolds. No searching. O(1) each.
```

---

### TREE 7 — The Microservices Backend
**Each service is a coordinate. Services communicate by coordinate, not by service name.**

```
Complexity:  ★★★★★
Pattern:     Each microservice = one coordinate node
Domains:     Services (1.x), Data (2.x), Infrastructure (3.x)
```

**❌ Wrong — Classic microservices naming:**
```
services/
├── user-service/
├── payment-service/
├── notification-service/
├── auth-service/
└── email-service/
```

No structural relationship. No distance metric. No rails. Just names floating in space.
When "user-service" needs to call "payment-service", it hardcodes the name. When the
name changes — it all breaks.

**✅ Correct:**
```
git-0.0-acme-backend/
├── 0.0/                    ← shared types / proto / contracts
├── 0.1/                    ← ignition / service registry
├── 0.2/                    ← runtime / API gateway
│
├── 1.0/                    ← SERVICE LAYER
│   ├── 1.1/                ← auth-service
│   ├── 1.2/                ← user-service
│   ├── 1.3/                ← payment-service
│   ├── 1.4/                ← notification-service
│   └── 1.5/                ← email-service
│
├── 2.0/                    ← DATA LAYER
│   ├── 2.1/                ← user-db
│   ├── 2.2/                ← payment-db
│   └── 2.3/                ← event-store
│
└── 3.0/                    ← INFRASTRUCTURE
    ├── 3.1/                ← docker
    ├── 3.2/                ← kubernetes
    └── 3.3/                ← monitoring
```

**Service-to-service calls by coordinate:**
```javascript
// WRONG — hardcoded service name
const result = await fetch("http://payment-service/charge");

// RIGHT — coordinate-resolved service call
const addr = RCL.resolve("1.3");   // payment-service
const result = await fetch(`http://${serviceRegistry[addr]}/charge`);
```

**Distance analysis:**
```
distance(1.2, 2.1) = |1−2| + |2−1| = 2   user-service → user-db (correct — low coupling)
distance(1.2, 1.3) = |1−1| + |2−3| = 1   user-service → payment-service (adjacent — acceptable)
distance(1.1, 3.3) = |1−3| + |1−3| = 4   auth → monitoring (high — should only be one-way logging)
```

---

## PART 4 — THE RESOLVER: HOW PATHS ARE BUILT

This is the full implementation of the RCL resolver. Study every line.

```javascript
/**
 * RCL Resolver — O(1) coordinate-to-path transformation
 * No I/O. No search. Pure computation.
 */

const DOMAINS = {
  0: "shared", 1: "project", 2: "map", 3: "works", 4: "space"
};

const FUNCTIONS = {
  1: "dashboard", 2: "social",  3: "services", 4: "customers",
  5: "partners",  6: "invoices", 7: "calendar", 8: "inquiry",
  9: "direct",   10: "email",  11: "call"
};

const SUB_OPS = {
  a: "live", b: "threads", c: "blogs",
  d: "short-posts", e: "albums", f: "video", g: "audio"
};

function resolve(coord) {
  /**
   * Input:  "4.2.a"
   * Output: "/4.0/4.2/4.2.a/"
   *
   * In pure-coordinate mode (correct form), no names in path.
   * In named mode (teaching form), names are appended for readability.
   */
  const parts = coord.split(".");
  const x = parts[0];
  const y = parts[1];
  const z = parts[2] || null;

  // Pure coordinate path — THE CORRECT FORM
  let path = `/${x}.0/${x}.${y}/`;
  if (z) path += `${x}.${y}.${z}/`;

  return path;
}

function resolveNamed(coord) {
  /**
   * Named form — for human-readable output and documentation only.
   * NEVER use this as actual folder names in the repo.
   */
  const parts = coord.split(".");
  const x = parts[0];
  const y = parts[1];
  const z = parts[2] || null;

  const domain = DOMAINS[x]   || x;
  const func   = FUNCTIONS[y] || y;
  const sub    = z ? SUB_OPS[z] || z : null;

  let path = `/${x}.0-${domain}/${x}.${y}-${domain}-${func}/`;
  if (sub) path += `${x}.${y}.${z}-${sub}/`;

  return path;
}

// ── Tests ─────────────────────────────────────────────────────────────────────

console.log(resolve("4.2.a"));        // → /4.0/4.2/4.2.a/
console.log(resolve("1.11"));         // → /1.0/1.11/
console.log(resolve("0.2"));          // → /0.0/0.2/

console.log(resolveNamed("4.2.a"));   // → /4.0-space/4.2-space-social/4.2.a-live/   (docs only)
console.log(resolveNamed("1.11"));    // → /1.0-project/1.11-project-call/            (docs only)
```

---

## PART 5 — STABILIZATION: DARK MATTER AND VACUUM

These are the two failure modes of a GitCMA repo.

```python
def check_stabilization(repo_root, manifest):
    """
    Scan the repo for Dark Matter and Vacuum nodes.

    Dark Matter: folder exists, not in manifest → unlabeled logic
    Vacuum:      manifest entry exists, folder missing → unrealized intent

    A fully stabilized repo has neither.
    ∇²Φ = 0 at every coordinate.
    """
    dark_matter = []   # folders without manifest entries
    vacuum      = []   # manifest entries without folders

    # Check every folder against the manifest
    for folder in scan_coordinate_folders(repo_root):
        coord = folder_to_coord(folder)
        if coord not in manifest:
            dark_matter.append(coord)

    # Check every manifest entry against the filesystem
    for coord in manifest:
        expected_path = resolve(coord)
        if not os.path.exists(os.path.join(repo_root, expected_path)):
            vacuum.append(coord)

    return {
        "stable":      len(dark_matter) == 0 and len(vacuum) == 0,
        "dark_matter": dark_matter,
        "vacuum":      vacuum
    }
```

**The Laplacian condition:**

A node is stabilized when `∇²Φ = 0`:
- The folder exists (Machine Layer is real)
- The manifest entry exists (Human Layer is real)
- They point to the same coordinate (Layers are in agreement)

If either layer is missing, the node is **unstable**. The ignition script
(`0.1/startup.sh`) enforces stabilization at boot.

---

## PART 6 — THE NAMING RULES (PORTABLE EVERYWHERE)

These rules make the system work across GitHub, GitLab, Cloudflare, Docker,
Linux, URLs, DNS, and CLI without modification.

```
Rule 1:  Repo root prefix:   git-0.0-[name]
         ✓ git-0.0-acme-app
         ✗ acme_app
         ✗ 0.0-acme-app   (no leading number without prefix)

Rule 2:  Dash not underscore in folder names that have labels
         ✓ 4.2.a-live
         ✗ 4.2.a_live

Rule 3:  In CORRECT form — no labels at all in folder names
         ✓ 4.2.a/
         ✗ 4.2.a-live/

Rule 4:  z-axis uses letters only (a, b, c...) not numbers
         ✓ 4.2.a/
         ✗ 4.2.1/   (conflicts with version parsing)

Rule 5:  System layer always 0.x
         ✓ 0.0/ 0.1/ 0.2/ 0.3/
         ✗ sys/ shared/ config/

Rule 6:  Manifest is always manifest.json at the repo root
         One manifest per repo. One source of truth.
```

---

## SUMMARY: THE TRANSFORMATION

| Before GitCMA | After GitCMA |
|---|---|
| Folders named by feel | Folders named by position |
| Rename = refactor | Rename = one manifest line |
| No distance metric | `d(Φ₁,Φ₂) = Σ\|kᵢ-kⱼ\|` |
| Search for files | Compute paths |
| Coupling is invisible | Coupling is a number |
| AI must parse names | AI computes `(x,y,z)` |
| One interpretation | Infinite overlays, one substrate |
| Grows more chaotic | Grows more ordered |

---

*You are no longer a Folder Manager.*
*You are a Field Operator navigating a deterministic execution space.*

---
© Armstrong Knight | intent-tensor-theory.com | CC BY-NC 4.0
