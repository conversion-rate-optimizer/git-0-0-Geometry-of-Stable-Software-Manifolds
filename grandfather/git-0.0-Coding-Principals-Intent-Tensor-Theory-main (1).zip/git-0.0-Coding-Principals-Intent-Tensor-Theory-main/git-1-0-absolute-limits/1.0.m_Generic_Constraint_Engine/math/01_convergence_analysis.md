# Convergence Analysis

The three cases for the engine's convergence behavior.

## Case 1: Monotone + Scott-continuous

If all $D_i$ and $C_j$ are monotone and Scott-continuous on a pointed DCPO, then $F$ is Scott-continuous, and Kleene's theorem applies:

$$
\operatorname{lfp}(F) = \bigvee_n F^n(\bot).
$$

The engine iterates and converges in countably many steps. For a finite-height lattice (finitely-many possible states), it terminates in finitely many iterations.

**In practice:** pure Datalog-style engines fall here. Add positive rules only, no negation, no retraction.

## Case 2: Finite lattice + idempotent constraints

If $\mathcal{S}$ is finite and each $C_j$ is idempotent ($C_j \circ C_j = C_j$), then $F$ stabilizes in at most $|\mathcal{S}|$ steps, even if individual $C_j$'s are not monotone.

**In practice:** propositional constraint systems with no retraction across iterations. Applies to most small-domain rule-based engines.

## Case 3: Non-monotone (retractive) constraints

If some $C_j$ sets a variable to a value *incompatible* with a previous derivation (retraction), $F$ may oscillate.

**Example.**
- $D_1$: `sent := eligible && optedIn`. If inputs hold, sets `sent = True`.
- $C_2$: `if blocked then sent := False`. Retracts `sent`.
- $D_1$ fires again, setting `sent = True`.
- $C_2$ fires again...

This is the conflicting-intents case. **No fixed point exists** (in general), and the engine will hit `maxIter`.

## Diagnosing non-convergence

Given a non-converging engine, diagnose by:

1. **Log the Kleene chain.** Print $s_0, s_1, s_2, \ldots$ and look for cycles.
2. **Identify retracting constraints.** Which $C_j$ undoes a derivation's effect?
3. **Stratify.** Can the constraint be moved to a separate stratum, applied after all non-retracting ones converge?
4. **Reformulate.** Can the retraction be avoided by combining constraints into a stronger pre-condition?

## Restoring convergence

### Stratification

Partition constraints into strata $L_1 < L_2 < \cdots < L_k$. Run each stratum to convergence before proceeding to the next. Within a stratum, use only monotone operations.

**Theorem.** *Stratified engines converge if each stratum is monotone, even if the overall system has non-monotone inter-strata interactions.*

This is how Datalog-with-negation works, and is the first thing to try when vanilla Kleene fails.

### SMT encoding

Replace the iterative loop with a single call to Z3 or cvc5 encoding all constraints simultaneously. The solver's CDCL + theory-combination handles the oscillation internally.

**Trade-off:** potentially exponential worst-case time, but no oscillation issues.

### ASP encoding

Model with weak constraints and priority levels; clingo finds the optimal stable model. Correct by construction.

**Trade-off:** requires grounding the program (can blow up); some engineering needed to manage ground-program size.

### Soft constraints + gradient descent

Replace hard retractive constraints with soft weighted penalties. Minimize the total penalty via gradient descent.

**Trade-off:** answer is approximate; convergence depends on convexity/smoothness of the penalty function.

## Decision procedure for the engineer

```
if (all derivations monotone and all constraints don't retract):
    use Kleene iteration (hand-rolled or library)
elif (can stratify into monotone strata):
    use stratified Kleene
elif (finite domain, reasonable size):
    use SAT/SMT/ASP backend
elif (continuous variables, smooth objective):
    use gradient descent / convex optimization
else:
    accept maxIter/timeout fallback
```

This is the tree you walk when building a production engine.

## The ceiling

Rice's theorem says: deciding which case applies for an arbitrary rule set is itself undecidable. Your engine cannot automatically route a user's rules to the right backend. The user must understand the math.

This is why the ITT framework documentation emphasizes **writing constraints carefully** — the mathematical shape of the constraint determines which regime you are in, and that determines what guarantees the engine can give.
