# 1.0.e — Logic Programming & Datalog

The purest instance of "compute the least fixed point of an immediate-consequence operator."

## Files

**Math:**
- `math/00_herbrand_semantics.md` — Herbrand universe, base, interpretations.
- `math/01_immediate_consequence_operator.md` — $T_P$ and its properties.
- `math/02_minimal_model_theorem.md` — Van Emden–Kowalski.
- `math/03_naive_vs_semi_naive.md` — Efficient iteration.
- `math/04_datalog_complexity.md` — PTIME, EXPTIME, stratified negation.

**Code:**
- `code/datalog_python.py` — Hand-rolled Datalog engine (semi-naive).
- `code/datalog_examples.dl` — Example rules (Soufflé syntax).
- `code/crepe_rust.rs` — Datalog via the `crepe` crate (compile-time rules).
