# Datalog Complexity

What Datalog can and cannot decide in polynomial time.

## Data complexity

**Fixing the program, varying the database.**

- **Plain Datalog:** Data complexity is **PTIME-complete**.
- **Datalog with stratified negation:** PTIME-complete.
- **Datalog with well-founded negation:** PTIME-complete (Van Gelder, Ross, Schlipf 1991).
- **Datalog with inflationary negation:** PTIME-complete.

**Implication.** Datalog expresses exactly PTIME (assuming $P \neq NP$, and over ordered databases). This is one of the cleanest complexity-theoretic characterizations of a query language.

## Program complexity

**Fixing the database, varying the program.**

- **Plain Datalog:** Program complexity is **EXPTIME-complete**.

This asymmetry (PTIME data, EXPTIME program) matters in practice: writing a complex rule set can be costly to evaluate even on small data.

## Combined complexity

**Both the program and database vary.**

- **Plain Datalog:** EXPTIME-complete.

## Adding features

### Stratified negation
Negation $\neg p$ allowed if the predicate $p$ is fully computed in a lower stratum. Preserves PTIME data complexity. Allows use cases like "all paths that do NOT go through a blacklisted node."

### Stable model semantics (ASP)
Allows unrestricted negation via the Gelfond–Lifschitz reduct (see `1.0.i`). Data complexity becomes **NP-complete** (deciding existence of a stable model). This is the boundary where Datalog stops being polynomial.

### Disjunctive Datalog
Rule heads can be disjunctions: $h_1 \vee h_2 \leftarrow \text{body}$. Data complexity **$\Sigma_2^P$-complete** — one level higher in the polynomial hierarchy.

### Aggregation
SUM, COUNT, MIN in rule heads. Breaks monotonicity; requires stratification. Data complexity stays PTIME if stratified.

### Recursion over integers
Datalog with arithmetic: undecidable in general. Decidable fragments are studied (linear arithmetic over non-negative integers — Datalog modulo arithmetic).

## Expressive power boundaries

**Not expressible in plain Datalog:**
- **Set equality:** "is set $A$ equal to set $B$?" (needs negation).
- **Parity:** "is $|S|$ even?" (needs counting).
- **Graph isomorphism:** expressible only with strong extensions.

**Expressible:**
- Transitive closure (canonical example).
- Connected components (slightly non-trivial encoding).
- Same-generation queries on trees.
- Shortest path (with aggregation).

## Comparison with related formalisms

| Formalism                   | Data complexity         | Monotone? |
|-----------------------------|-------------------------|-----------|
| Relational algebra (SQL)    | LOGSPACE                | Yes       |
| Plain Datalog               | PTIME                   | Yes       |
| Stratified Datalog$^\neg$   | PTIME                   | No        |
| Well-founded Datalog$^\neg$ | PTIME                   | No        |
| ASP (stable models)         | NP                      | No        |
| Disjunctive ASP             | $\Sigma_2^P$            | No        |
| First-order logic (FOL)     | LOGSPACE (on finite DBs)| Yes       |
| Monadic second-order        | Varies (tree-width)     | —         |

## Fine-grained complexity

Recent work (Aboud et al., PODS 2018; Eisenberg et al., 2021) pins down Datalog evaluation complexity more tightly:
- **Linear Datalog:** evaluable in $O(n)$ time.
- **Monadic Datalog:** evaluable in $O(n)$ per predicate.
- **Nested joins:** reducible to matrix multiplication, so $O(n^\omega)$ with $\omega \approx 2.37$.

These refinements matter for implementation — Soufflé and LogicBlox invest heavily in detecting and optimizing Linear/Monadic sub-fragments.

## Practical takeaway

For a dynamic-coding engine designed around Datalog-style fixed-point computation:

- **Positive rules only → PTIME.** Scales predictably.
- **Add stratified negation → still PTIME.** The standard "safe" zone.
- **Add unrestricted negation → NP.** Expressiveness gain, but you're now in SAT/SMT territory; use an ASP solver rather than hand-rolling.
- **Aggregation → careful.** Monotone aggregates (counting at the fixpoint) preserve correctness; non-monotone ones require stratification.
- **Arithmetic → danger.** Only decidable fragments allowed.

For most practical engines (including the ITT Intent Engine scaled up), stratified Datalog with aggregation over a PTIME fragment is the sweet spot: expressive enough to say useful things, tractable enough to scale.
