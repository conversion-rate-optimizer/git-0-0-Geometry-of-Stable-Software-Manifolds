# Stable-Model Semantics

Properties and applications.

## Fundamental properties

**Theorem.** Every stable model of $P$ is a minimal model of $P$ (in the classical sense).

**Theorem.** Every stable model of $P$ is supported: every atom is the head of a rule whose body is true in the model.

**Theorem.** For negation-free Datalog, the unique stable model coincides with the unique minimal model.

So the stable-model semantics **agrees with Datalog** where Datalog applies, and extends it to negation.

## Multiple models

Unlike Datalog, an ASP program can have:
- **No stable models** (inconsistent program, e.g., `:- a. a.`).
- **Exactly one stable model.**
- **Multiple stable models.**

Programs with multiple stable models are natural for:
- **Combinatorial search** (generate-and-test).
- **Planning** (each plan is a stable model).
- **Diagnosis** (each candidate explanation is a stable model).

## Encoding NP-hard problems

ASP's sweet spot is the **NP class**: problems where each candidate solution is verifiable in polynomial time.

### Graph coloring

```
% Nodes and edges
node(1..N). edge(X, Y) :- ...

% Generate: each node gets exactly one of K colors
{ color(X, 1..K) } = 1 :- node(X).

% Test: no edge has same-color endpoints
:- edge(X, Y), color(X, C), color(Y, C).
```

Each stable model corresponds to a valid $K$-coloring.

### Hamilton cycle

```
node(1..N). edge(X, Y) :- ...

% Select a subset of edges
{ in_cycle(X, Y) } :- edge(X, Y).

% Each node has exactly one outgoing and one incoming edge in the cycle
:- node(X), #count { Y : in_cycle(X, Y) } != 1.
:- node(Y), #count { X : in_cycle(X, Y) } != 1.

% Reachability from node 1 (to prevent disconnected cycles)
reached(1).
reached(Y) :- reached(X), in_cycle(X, Y).
:- node(X), not reached(X).
```

Each stable model is a Hamilton cycle starting at node 1 (up to rotation).

### Boolean SAT itself

```
atom(1..N).                  % N propositional variables

{ true_atom(X) } :- atom(X). % Each variable is either true or not

% For each clause, at least one literal must be satisfied:
:- not satisfied(C), clause(C).
satisfied(C) :- clause(C), literal(C, L, pos), true_atom(L).
satisfied(C) :- clause(C), literal(C, L, neg), not true_atom(L).
```

## Applications

- **Planning.** Each action sequence is a stable model.
- **Scheduling.** Each valid schedule is a stable model.
- **Product configuration.** Each valid configuration is a stable model.
- **Bioinformatics.** Metabolic pathway completion.
- **Natural-language semantics.** Each consistent interpretation is a stable model.
- **Computer security.** Each attack trace is a stable model.

## Comparison with SAT

| Aspect              | SAT                    | ASP                                |
|---------------------|------------------------|------------------------------------|
| Syntax              | CNF clauses            | Horn-like rules with negation      |
| Semantics           | classical              | stable / well-founded              |
| Typical problem     | decision               | search / enumeration               |
| Encoding           | combinatorial             | declarative, rule-based            |
| Expression         | flat                       | hierarchical (predicates, variables)|
| Complexity          | NP-complete            | NP-complete (same as SAT)          |

ASP and SAT are complexity-equivalent, but ASP's rule-based syntax is more natural for many problems.

## Connection to ITT

If your Intent Engine supports negation-as-failure (e.g., "if NOT blocked, send"), it has left Datalog and entered ASP. The stable-model semantics is the formal specification of what "coherent resolution" means in that setting.

Moreover, your priority system is the optimization layer over stable models: find the stable model minimizing the weighted sum of violated soft constraints (see `03_weight_constraints.md`).
