# Fixed-Point Semantics of Dynamic Computation

### An Exhaustive Mathematical Survey of the Frontier

---

## Abstract

Every serious "dynamic coding" paradigm — constraint solving, reactive dataflow, incremental computation, logic programming, dependent type theory, build systems — reduces to a single mathematical object: the **fixed point of a monotone operator on a complete lattice**. This paper unpacks that claim in full. We develop the order-theoretic foundations (Knaster–Tarski, Kleene), the logic-programming semantics (immediate-consequence operator), the constraint-satisfaction machinery (DPLL, CDCL, DPLL(T), Nelson–Oppen), the incremental-computation calculus (Z-sets, DBSP, integration/differentiation operators), the stable-model semantics of Answer Set Programming (Gelfond–Lifschitz reduct), the Curry–Howard isomorphism for dependent types, and the task-abstraction model of build systems. We then prove the hard ceilings: the Halting Problem, Rice's Theorem, the Cook–Levin NP-completeness of SAT, and the undecidability of type inhabitation in dependent type theory. The paper closes by situating a generic constraint + derivation + priority engine within this framework and identifying the precise convergence conditions such engines require.

---

## 1. Introduction

Imperative programming says: *do this, then this, then this.* Declarative, reactive, constraint-based, and dependent-typed programming all say, in different dialects of the same underlying mathematics: *describe the shape of a solution, and let the system converge to it.*

That "converge to it" is not metaphor. It is the statement

$$
S^\star = F(S^\star)
$$

where $F$ is a monotone (or otherwise well-behaved) operator on a complete lattice, and $S^\star$ is the least (or greatest, or uniquely selected) fixed point.

This paper writes out, with full mathematical detail, the equations that make the above sentence rigorous in each of the major frontiers of dynamic computation.

### Roadmap

- §2–3: Order-theoretic preliminaries and the master fixed-point theorems.
- §4: Abstract interpretation as sound approximation.
- §5: Logic programming and Datalog.
- §6: SAT, SMT, and constraint solving.
- §7: Self-adjusting computation.
- §8: Differential dataflow and DBSP.
- §9: Answer Set Programming and stable models.
- §10: Curry–Howard and dependent types.
- §11: Build systems as fixed-point computations.
- §12: The hard ceilings — undecidability and complexity.
- §13: Formal analysis of a generic constraint + derivation + priority engine.
- §14: Synthesis.

---

## 2. Order-Theoretic Preliminaries

### 2.1 Partial orders

A **partially ordered set** (poset) is a pair $(P, \leq)$ with $\leq$ reflexive, antisymmetric, and transitive.

### 2.2 Lattices

A **lattice** is a poset in which every two-element subset $\{a, b\}$ has a least upper bound $a \vee b$ (*join*) and a greatest lower bound $a \wedge b$ (*meet*).

A **complete lattice** is one in which *every* subset $S \subseteq L$ has $\bigvee S$ and $\bigwedge S$. Equivalently, a complete lattice has a top element $\top = \bigvee L$ and a bottom element $\bot = \bigwedge L$.

**Example.** $(2^X, \subseteq)$ for any set $X$ is a complete lattice with $\bigvee = \bigcup$, $\bigwedge = \bigcap$, $\top = X$, $\bot = \emptyset$.

**Example.** For any set $X$, $(X \to \mathbb{R}_{\geq 0}^\infty, \leq)$ with pointwise order is a complete lattice.

### 2.3 Monotone, continuous, and contractive functions

Let $(L, \leq)$ be a poset and $f: L \to L$.

- $f$ is **monotone** iff $x \leq y \implies f(x) \leq f(y)$.
- $f$ is **Scott-continuous** iff for every directed subset $D \subseteq L$, $f(\bigvee D) = \bigvee f(D)$. Scott-continuity implies monotonicity.
- (For metric spaces.) $f$ is a **contraction** with factor $q \in [0,1)$ iff $d(f(x), f(y)) \leq q \cdot d(x,y)$.

### 2.4 Fixed points

An element $x \in L$ is a **fixed point** of $f$ iff $f(x) = x$.
- $x$ is a **pre-fixed point** iff $f(x) \leq x$.
- $x$ is a **post-fixed point** iff $x \leq f(x)$.

The **least fixed point** (if it exists) is denoted $\operatorname{lfp}(f)$; the **greatest fixed point** $\operatorname{gfp}(f)$.

---

## 3. The Master Fixed-Point Theorems

### 3.1 Knaster–Tarski

**Theorem (Knaster–Tarski, 1955).** *Let $(L, \leq)$ be a complete lattice and $f: L \to L$ monotone. Then the set $\operatorname{Fix}(f)$ of fixed points of $f$ is itself a non-empty complete lattice under $\leq$. In particular,*

$$
\operatorname{lfp}(f) \;=\; \bigwedge \{x \in L \mid f(x) \leq x\}, 
\qquad
\operatorname{gfp}(f) \;=\; \bigvee \{x \in L \mid x \leq f(x)\}.
$$

**Proof.** Let $P = \{x : f(x) \leq x\}$ (the pre-fixed points). $P$ is non-empty since $\top \in P$ ($f(\top) \leq \top$ trivially). Let $\alpha = \bigwedge P$. For any $x \in P$: $\alpha \leq x$, so by monotonicity $f(\alpha) \leq f(x) \leq x$. Hence $f(\alpha)$ is a lower bound of $P$, giving $f(\alpha) \leq \alpha$, i.e., $\alpha \in P$. Applying monotonicity once more, $f(f(\alpha)) \leq f(\alpha)$, so $f(\alpha) \in P$, and by minimality $\alpha \leq f(\alpha)$. Combined: $f(\alpha) = \alpha$. Minimality in $\operatorname{Fix}(f)$ follows because any fixed point is a pre-fixed point, so is $\geq \alpha$. The argument for $\operatorname{gfp}$ is dual. $\blacksquare$

**Significance.** Every monotone operator on a complete lattice has a least and greatest fixed point. This is the existence theorem for every declarative semantics in this paper.

### 3.2 Kleene (constructive / ascending chain)

A **pointed directed-complete partial order** (pointed DCPO) is a poset with a bottom element $\bot$ in which every directed subset has a supremum.

**Theorem (Kleene).** *Let $(L, \leq, \bot)$ be a pointed DCPO and $f: L \to L$ Scott-continuous. Then*

$$
\operatorname{lfp}(f) \;=\; \bigvee_{n \in \mathbb{N}} f^n(\bot)
$$

*where $f^0(\bot) = \bot$ and $f^{n+1}(\bot) = f(f^n(\bot))$.*

**Proof sketch.** The chain $\bot \leq f(\bot) \leq f^2(\bot) \leq \cdots$ is directed (by continuity and induction). Let $\alpha = \bigvee_n f^n(\bot)$. By Scott-continuity, $f(\alpha) = f(\bigvee_n f^n(\bot)) = \bigvee_n f^{n+1}(\bot) = \alpha$. For minimality, any fixed point $\beta$ satisfies $\bot \leq \beta$, and by induction $f^n(\bot) \leq \beta$, so $\alpha \leq \beta$. $\blacksquare$

**Significance.** This is the *computable* fixed-point theorem: we can actually iterate $f$ from $\bot$ and reach $\operatorname{lfp}(f)$ in the limit. Every Datalog evaluator, every reactive propagation engine, every abstract interpreter is a Kleene iteration.

### 3.3 Banach (metric / quantitative)

**Theorem (Banach, 1922).** *Let $(X, d)$ be a complete metric space and $f: X \to X$ a contraction with factor $q < 1$. Then $f$ has a unique fixed point $x^\star$, and for any $x_0 \in X$,*

$$
d(f^n(x_0), x^\star) \;\leq\; \frac{q^n}{1-q}\, d(x_1, x_0).
$$

**Significance.** Banach gives *exponential* convergence rates but requires a metric and contractivity — it is the right model for numerical fixed-point iteration (Newton's method, Picard iteration for ODEs, physics simulation), not for symbolic constraint systems.

### 3.4 Why your engine needs one of these

A generic engine iterates $F = C \circ D$ where $D$ is a propagation operator and $C$ a constraint-enforcement operator. It converges iff:

- (Knaster–Tarski regime) $F$ is monotone on a complete lattice, in which case some fixed point exists (but iteration from $\bot$ may not reach it without continuity).
- (Kleene regime) $F$ is Scott-continuous on a pointed DCPO, in which case iterating from $\bot$ reaches $\operatorname{lfp}(F)$ in the limit — this is what Datalog and reactive systems exploit.
- (Banach regime) $F$ is a contraction on a complete metric space — applies to numerical / probabilistic variants.

If $F$ is neither monotone, continuous, nor contractive, **no convergence guarantee exists**, and the engine may oscillate indefinitely. This is the formal content of "conflicting intents."

---

## 4. Abstract Interpretation (Cousot–Cousot, 1977)

Abstract interpretation formalizes *sound approximation* of program semantics.

### 4.1 Galois connections

Let $(C, \leq_C)$ and $(A, \leq_A)$ be complete lattices. A pair of functions

$$
C \;\underset{\gamma}{\overset{\alpha}{\leftrightarrows}}\; A
$$

is a **Galois connection** iff

$$
\forall c \in C, \forall a \in A: \qquad \alpha(c) \leq_A a \;\iff\; c \leq_C \gamma(a).
$$

Intuition: $\alpha$ is an abstraction function (concrete $\to$ abstract); $\gamma$ is a concretization function. $\alpha$ preserves joins; $\gamma$ preserves meets.

### 4.2 Soundness theorem

**Theorem.** *Let $F: C \to C$ be a concrete monotone operator and $F^\sharp: A \to A$ an abstract operator such that $\alpha \circ F \leq_A F^\sharp \circ \alpha$ (or equivalently $F \circ \gamma \leq_C \gamma \circ F^\sharp$). Then*

$$
\alpha(\operatorname{lfp}(F)) \;\leq_A\; \operatorname{lfp}(F^\sharp).
$$

*In particular, any property holding of $\operatorname{lfp}(F^\sharp)$ that is downward-closed under $\leq_A$ holds of $\alpha(\operatorname{lfp}(F))$.*

This is how static analyzers *prove* runtime properties without running the program.

### 4.3 Widening and narrowing

When the abstract lattice has infinite ascending chains, naive Kleene iteration does not terminate. A **widening operator** $\triangledown: A \times A \to A$ satisfies:

1. **Covering:** $a \leq \nabla(a, b)$ and $b \leq \nabla(a, b)$.
2. **Termination:** For any chain $x_0, x_1, \ldots$, the sequence $y_0 = x_0$, $y_{n+1} = \nabla(y_n, x_{n+1})$ stabilizes.

Widening sacrifices precision for termination: $\operatorname{lfp}^\triangledown(F^\sharp) \geq \operatorname{lfp}(F^\sharp)$ but is computable.

---

## 5. Logic Programming & Datalog

### 5.1 Syntax

A **Datalog program** is a finite set of rules

$$
h(\bar{t}_0) \;\leftarrow\; b_1(\bar{t}_1) \wedge \cdots \wedge b_k(\bar{t}_k)
$$

where each $b_i$ is a predicate and $\bar{t}_j$ are tuples of terms (variables or constants). Datalog prohibits function symbols (other than constants) and negation (in the basic form).

### 5.2 Herbrand semantics

The **Herbrand universe** $U_P$ is the set of ground terms (just constants, in Datalog). The **Herbrand base** $B_P$ is the set of ground atoms. An **interpretation** $I \subseteq B_P$ is a set of ground atoms deemed true.

$(2^{B_P}, \subseteq)$ is a complete lattice.

### 5.3 The immediate consequence operator

For a program $P$, define $T_P: 2^{B_P} \to 2^{B_P}$ by

$$
T_P(I) \;=\; \{\, h\sigma \;\mid\; (h \leftarrow b_1 \wedge \cdots \wedge b_k) \in P,\; \sigma \text{ ground},\; \{b_1\sigma, \ldots, b_k\sigma\} \subseteq I \,\}.
$$

**Proposition.** $T_P$ is monotone and Scott-continuous on $(2^{B_P}, \subseteq)$.

### 5.4 Minimal model semantics

**Theorem (van Emden & Kowalski, 1976).** *The minimal model of a Datalog program $P$ is*

$$
M_P \;=\; \operatorname{lfp}(T_P) \;=\; \bigcup_{n \geq 0} T_P^n(\emptyset).
$$

*It coincides with the set of ground atoms logically entailed by $P$ under the closed-world assumption.*

### 5.5 Naive vs. semi-naive evaluation

**Naive:** Compute $I_0 = \emptyset$, $I_{n+1} = T_P(I_n)$, until $I_{n+1} = I_n$. Cost: each iteration recomputes all derivable facts.

**Semi-naive:** Track the delta $\Delta I_n = I_n \setminus I_{n-1}$ and derive only *new* facts:

$$
\Delta I_{n+1} \;=\; T_P^\Delta(I_n, \Delta I_n) \;\setminus\; I_n,
$$

where $T_P^\Delta$ fires only rule instances using at least one fact from $\Delta I_n$. This is the prototype of differential dataflow (§8).

### 5.6 Datalog complexity

- **Data complexity** (program fixed, database varies): PTIME-complete.
- **Combined complexity** (both vary): EXPTIME-complete.

Datalog with negation under stable-model semantics becomes NP-complete and is the basis of ASP (§9).

---

## 6. SAT, SMT, and Constraint Solving

### 6.1 Propositional SAT

Given a propositional formula $\varphi$ in conjunctive normal form (CNF) over Boolean variables $x_1, \ldots, x_n$, SAT asks whether there exists an assignment $\alpha: \{x_i\} \to \{0, 1\}$ with $\alpha \models \varphi$.

**Theorem (Cook–Levin, 1971).** *SAT is NP-complete.*

### 6.2 DPLL

The Davis–Putnam–Logemann–Loveland algorithm decides SAT via:

1. **Unit propagation:** If a clause becomes $\{\ell\}$, assign $\ell = 1$.
2. **Pure literal elimination:** If a literal appears only positively (or only negatively), assign accordingly.
3. **Branching:** Pick an unassigned variable $x$, recurse on $\varphi \wedge x$ and $\varphi \wedge \neg x$.
4. **Backtracking:** If both branches are unsatisfiable, return UNSAT.

### 6.3 CDCL (Conflict-Driven Clause Learning)

Modern SAT solvers extend DPLL with:

- **Implication graph:** A DAG recording which decisions and unit propagations implied each assignment.
- **Conflict analysis:** When a conflict is reached, derive a **learned clause** (the negation of a cut in the implication graph) that prevents the same conflict.
- **Non-chronological backtracking:** Jump back to the assertion level of the learned clause, not one level up.
- **Variable selection heuristics:** VSIDS (Variable State Independent Decaying Sum) — prefer variables in recent conflicts.
- **Restarts:** Periodically abandon the current search tree (keeping learned clauses).

CDCL solvers now handle formulas with $10^7$ clauses routinely.

### 6.4 SMT: Satisfiability Modulo Theories

An **SMT instance** is a formula over a combination of theories $T$ such as:

- $T_\text{LIA}$: linear integer arithmetic.
- $T_\text{LRA}$: linear real arithmetic.
- $T_\text{BV}$: fixed-width bit-vectors.
- $T_\text{A}$: arrays ($\text{select}, \text{store}$).
- $T_\text{UF}$: uninterpreted functions with equality.

An **SMT solver** decides satisfiability in the combined theory.

### 6.5 DPLL(T)

DPLL(T) is the dominant SMT architecture:

1. Treat each theory atom as a propositional literal.
2. Run CDCL on the Boolean abstraction.
3. When CDCL produces a candidate model, query a **theory solver** for $T$-consistency.
4. If $T$-inconsistent, derive a *theory lemma* (the negation of the inconsistent subset) and feed it back to CDCL.

### 6.6 Nelson–Oppen theory combination

**Theorem (Nelson & Oppen, 1979).** *Let $T_1$ and $T_2$ be decidable, stably-infinite, signature-disjoint theories. Then the theory $T_1 \cup T_2$ is decidable.*

The combination works by:

1. **Purification:** Split every formula into conjuncts, each in a single theory, sharing only equality atoms over shared variables.
2. **Equality propagation:** Each theory solver reports all equalities it implies among shared variables to the other.
3. **Satisfiability check:** Both theories together are $T_1 \cup T_2$-satisfiable iff each individual purified formula is satisfiable in its theory under some arrangement (partition) of the shared variables.

### 6.7 Hard limits of SMT

- $T_\text{LIA}$ is decidable but PSPACE-hard.
- $T_\text{LIA} + \text{multiplication}$ (nonlinear integer arithmetic) is **undecidable** (Matiyasevich's resolution of Hilbert's 10th problem).
- $T_\text{BV}$ is NP-complete.
- $T_\text{LRA}$ is in P (Khachiyan's ellipsoid or Karmarkar's interior-point) for linear arithmetic over reals, but polynomial arithmetic over reals (Tarski–Seidenberg) is decidable but has doubly-exponential complexity.

These are hard mathematical walls. No implementation trick moves them.

### 6.8 MaxSAT and weighted constraints

**MaxSAT:** Given a CNF $\varphi$ with clauses $c_1, \ldots, c_m$ and weights $w_1, \ldots, w_m \in \mathbb{R}_{\geq 0}$, find an assignment $\alpha$ that *minimizes*

$$
E(\alpha) \;=\; \sum_{i=1}^{m} w_i \cdot \mathbb{1}[\alpha \not\models c_i].
$$

This is the formalization of "energy minimization over inconsistency." MaxSAT is $\text{FP}^{\text{NP}}$-complete.

**Partial MaxSAT:** Clauses are split into *hard* (must be satisfied) and *soft* (weighted).

**Weighted CSP / Soft CSP:** A generalization where constraints are functions $\varphi_i: \prod_{j \in \text{scope}(i)} D_j \to \mathbb{R}_{\geq 0} \cup \{+\infty\}$ and the goal is to minimize $\sum_i \varphi_i(x)$.

These formalisms subsume any priority-driven constraint engine.

---

## 7. Self-Adjusting Computation

### 7.1 Modifiables and dependency tracking

In SAC (Acar, 2005), state is stored in **modifiables**, which are references tracked by the runtime. A computation that reads a modifiable registers a **dependency edge**. The execution trace is a DAG $G = (V, E)$ where $V$ is the set of function invocations and $E$ records read/write relationships.

### 7.2 Change propagation algorithm

Given a trace $G$ and a set of modified modifiables $M$:

1. Mark all nodes reading from $M$ as *invalid*.
2. Mark all descendants of invalid nodes as invalid.
3. Re-execute invalid nodes in topological order; each may read newly-computed modifiables.
4. Memoize to reuse sub-traces.

### 7.3 Trace stability

**Definition.** The *trace distance* $d(T_1, T_2)$ between two execution traces is the minimum edit distance (insertions, deletions of node invocations) to transform $T_1$ into $T_2$.

**Theorem (Acar, Blelloch, Harper).** *If a program has trace stability — meaning $d(T(x), T(x')) = O(\delta)$ whenever $|x - x'| = O(\delta)$ — then change propagation runs in time $O(d(T(x), T(x')))$, up to logarithmic factors.*

This matches or improves the best per-problem dynamic algorithms across list, tree, and geometric problems.

### 7.4 Incremental as differential

Change propagation can be formalized as follows. Let $f: A \to B$ be a program. SAC provides a pair

$$
(f, \nabla f): A \times \Delta A \to B \times \Delta B
$$

such that $\nabla f(x, \delta) = (f(x + \delta), \delta_y)$ where $\delta_y$ describes the output change. This is the **categorical derivative** of $f$ — a discrete analog of the Jacobian. The differential semantics paper (Kumar, ECOOP 2025) makes this precise for imperative languages.

---

## 8. Differential Dataflow & DBSP

### 8.1 Z-sets

Let $D$ be a countable domain. A **Z-set over $D$** is a function $m: D \to \mathbb{Z}$ with finite support, written formally as

$$
m \;=\; \sum_{d \in D} m(d) \cdot \langle d \rangle.
$$

Z-sets form an abelian group under pointwise addition; positive Z-sets are multisets; negative coefficients represent *retractions*.

### 8.2 Streams

A **stream** over $\mathbb{Z}[D]$ is a function $s: \mathbb{N} \to \mathbb{Z}[D]$, i.e., a time-indexed sequence of Z-sets. Streams form a ring under pointwise operations.

### 8.3 Integration and differentiation

Two fundamental operators on streams:

$$
\mathbf{I}(s)[t] \;=\; \sum_{i=0}^{t} s[i] \qquad (\text{integration})
$$

$$
\mathbf{D}(s)[t] \;=\; s[t] - s[t-1] \qquad (\text{differentiation, with } s[-1] = 0)
$$

**Theorem (DBSP fundamental identities).**

$$
\mathbf{D} \circ \mathbf{I} \;=\; \operatorname{id}, \qquad \mathbf{I} \circ \mathbf{D} \;=\; \operatorname{id}.
$$

### 8.4 Incremental view maintenance

Let $Q: \mathbb{Z}[D]^k \to \mathbb{Z}[D']$ be a query (e.g., a SQL view). Lift $Q$ pointwise to streams. Define the **incremental version** of $Q$ as

$$
Q^\Delta \;=\; \mathbf{D} \circ Q \circ \mathbf{I}.
$$

**Theorem (Budiu–McSherry et al., DBSP).** *For any query $Q$ built from linear operators (selection, projection, union, difference) and bilinear operators (join), $Q^\Delta$ can be mechanically derived and computed in time proportional to the input delta size, not the database size.*

**Example.** For $Q = \sigma_\varphi$ (selection): $Q^\Delta = \sigma_\varphi \circ \mathbf{D} \circ \mathbf{I} = \sigma_\varphi$, because selection commutes with $\mathbf{D}$ and $\mathbf{I}$.

**Example.** For $Q = \bowtie$ (join):

$$
(A \bowtie B)^\Delta(\Delta A, \Delta B) \;=\; \Delta A \bowtie B_\text{prev} \;+\; A_\text{prev} \bowtie \Delta B \;+\; \Delta A \bowtie \Delta B.
$$

### 8.5 Recursive queries and iteration

DBSP handles recursion via a nested fixed-point: for a recursive query $R = F(R, I)$, define

$$
R^\Delta(\Delta I) \;=\; \mathbf{D}(\operatorname{lfp}_t \; F(R, \mathbf{I}(\Delta I))).
$$

This gives incremental maintenance even for recursive (Datalog-style) views.

### 8.6 Differential dataflow specifically

Differential dataflow (McSherry) generalizes DBSP's time domain from $\mathbb{N}$ to an arbitrary **partially ordered set of timestamps**, e.g., $\mathbb{N}^k$ for nested loops. The key algebraic object is a **timestamped Z-set collection**:

$$
c: D \times T \to \mathbb{Z}
$$

with finite support, where $(T, \leq)$ is a partial order. Progress is tracked by **frontiers** — antichains in $T$ — rather than single times.

This is what Materialize productionizes: distributed, fine-grained, recursively incremental view maintenance at petabyte scale.

---

## 9. Answer Set Programming

### 9.1 Syntax

An **ASP program** (normal logic program with negation-as-failure) consists of rules

$$
a_0 \;\leftarrow\; a_1, \ldots, a_m,\; \operatorname{not}\, a_{m+1}, \ldots, \operatorname{not}\, a_n.
$$

### 9.2 The Gelfond–Lifschitz reduct

**Definition.** Let $P$ be a program and $S \subseteq B_P$ a candidate set of ground atoms. The **reduct** $P^S$ is obtained by:

1. Deleting every rule whose body contains $\operatorname{not}\, a$ for some $a \in S$.
2. Deleting all $\operatorname{not}\, a$ literals from the remaining rules.

$P^S$ is a negation-free program; it has a unique minimal model $M(P^S) = \operatorname{lfp}(T_{P^S})$.

**Definition (Stable model / answer set).** $S$ is a **stable model** of $P$ iff $S = M(P^S)$.

### 9.3 Semantics as a fixed point of a fixed point

A stable model is simultaneously:

- The fixed point of the ordinary consequence operator on the reduct.
- A consistent interpretation whose reduct's fixed point reproduces the interpretation itself.

The operator $\Gamma_P(S) = \operatorname{lfp}(T_{P^S})$ is *antitone* (order-reversing) in $S$. Stable models are the fixed points of $\Gamma_P$, found via SAT-like search.

### 9.4 Complexity

- Deciding whether a propositional ASP program has a stable model: **NP-complete**.
- Deciding cautious consequence (atom true in *all* stable models): **coNP-complete**.
- With disjunctive rules: **$\Sigma_2^P$-complete** (one level higher in the polynomial hierarchy).

### 9.5 Weight constraints and optimization

ASP supports soft constraints:

$$
\colon\sim \; a_1, \ldots, a_n. \; [w@l, t_1, \ldots, t_k]
$$

with weight $w$ at priority level $l$. The solver minimizes the weighted sum of violations, lexicographically by priority level — this is multi-level MaxSAT integrated with stable-model semantics.

---

## 10. Curry–Howard & Dependent Types

### 10.1 The propositions-as-types principle

The **Curry–Howard isomorphism** asserts a three-fold correspondence:

| Logic                            | Types                             | Programs                       |
|----------------------------------|-----------------------------------|--------------------------------|
| Proposition $A$                  | Type $A$                          | —                              |
| Proof of $A$                     | Term $t : A$                      | Program of type $A$            |
| $A \Rightarrow B$                | $A \to B$                         | Function                       |
| $A \wedge B$                     | $A \times B$                      | Pair                           |
| $A \vee B$                       | $A + B$                           | Tagged union                   |
| $\forall x : A.\; P(x)$          | $\prod_{x:A} P(x)$ (dependent fn) | Dependently-typed function     |
| $\exists x : A.\; P(x)$          | $\sum_{x:A} P(x)$ (dependent pair)| Existentially-bound witness    |
| $\bot$                           | Empty type $\mathbf{0}$           | —                              |
| Cut elimination / normalization  | $\beta$-reduction                 | Evaluation                     |

### 10.2 Dependent type theory (DTT)

Martin-Löf's intensional type theory adds:

- **Dependent function types:** $\prod_{x:A} B(x)$, where $B$ depends on $x$.
- **Dependent pair types:** $\sum_{x:A} B(x)$.
- **Inductive types:** $\mathbb{N}$, $\text{List}\,A$, $\text{Vec}\,A\,n$ (length-indexed vectors), etc., with eliminators.
- **Identity types:** $\operatorname{Id}_A(a, b)$, expressing propositional equality.
- **Universes:** $\text{Type}_0 : \text{Type}_1 : \text{Type}_2 : \cdots$ (to avoid Girard's paradox).

The **Calculus of Inductive Constructions (CIC)** — the kernel of Rocq and Lean — adds impredicative universes and inductive families.

### 10.3 Type checking vs. type inhabitation

- **Type checking** ($\Gamma \vdash t : A$?): decidable in CIC (up to computational behavior of axioms).
- **Type inhabitation** (does there exist a term $t$ with $t : A$?): **undecidable**. This is because any theorem of first-order Peano arithmetic can be encoded as a type, and provability in PA is undecidable by Gödel.

### 10.4 Homotopy Type Theory (HoTT)

Voevodsky's **univalence axiom** asserts

$$
(A =_{\text{Type}} B) \;\simeq\; (A \simeq B)
$$

— identification of types is equivalent to equivalence of types. This adds a genuine new principle to the math, unifying type theory with $\infty$-groupoids. Cubical type theory (Cohen, Coquand, Huber, Mörtberg) makes univalence *computable*.

### 10.5 Program synthesis via proof search

Since a program of type $A$ is a proof of proposition $A$, **proof search = program synthesis**. Modern tools:

- **Canonical** (Norman & Avigad, ITP 2025) achieves 84% on the Natural Number Game in 51 seconds by exhaustive type inhabitation search.
- **DeepSeek-Prover-V2**, **Lean Copilot**: LLM-guided proof search.
- **Mathlib**: 210,000+ theorems, 100,000+ definitions formalized in Lean 4 as of 2025.

---

## 11. Build Systems as Fixed-Point Computations

### 11.1 The task abstraction (Mokhov, Mitchell & Peyton Jones, ICFP 2018)

A **task** describes how to compute a value of type $v$ given a way to fetch dependencies:

$$
\text{Task}\, c\, k\, v \;=\; \forall f. \; c\, f \;\Rightarrow\; (k \to f\, v) \;\to\; f\, v.
$$

Here $k$ is the type of keys (filenames, cell references), $v$ is the type of values, $f$ is an *effect* (applicative or monadic), and $c$ is a constraint on $f$.

- **Applicative tasks:** $c = \text{Applicative}$. Dependencies are *statically* determined. Example: Excel (without indirect references), Make.
- **Monadic tasks:** $c = \text{Monad}$. Dependencies can be computed dynamically. Example: Shake, Nix, Bazel's late-binding rules.

### 11.2 The Build function

A **build system** is a function

$$
\text{build} : \text{Tasks}\, c\, k\, v \;\to\; k \;\to\; \text{Store}\, i\, k\, v \;\to\; \text{Store}\, i\, k\, v
$$

which, given a collection of tasks, a target key, and a current store (file system, spreadsheet, cache), produces a new store in which the target and all its transitive dependencies are up-to-date.

### 11.3 Correctness conditions

**Correctness.** $\text{build}\, T\, k\, s$ produces a store $s'$ in which $\text{getValue}(s', k) = T\, k\, (\text{getValue}\, s')$ for $k$ and all its dependencies — i.e., every value is consistent with the task that computes it.

**Minimality.** The build system only re-executes tasks whose dependencies have changed.

### 11.4 Design-space characterization

Mokhov et al. show that existing build systems factor cleanly into:

- **Rebuilder:** decides whether a task needs to re-run. Variants: dirty-bit, modification-time, constructive trace, verifying trace.
- **Scheduler:** orders task execution. Variants: topological, restarting, suspending.

The full design space is a $4 \times 3$ grid; most well-known systems occupy distinct cells (Make = dirty-bit + topological; Excel = dirty-bit + restarting; Shake = verifying-trace + suspending; Bazel = constructive-trace + topological).

### 11.5 Multi-substrate extension

A build system where *each file type contributes constraints* — rather than only producing artifacts — generalizes the task abstraction to:

$$
\text{Task}\, c\, k\, v \;=\; \forall f.\; c\, f \;\Rightarrow\; (k \to f\, v) \;\to\; f\, (v \times \text{Constraint}\, k\, v).
$$

Each task emits both a value and a set of constraints it imposes on other keys. The build function must now find a fixed point of the *joint constraint system*, not just propagate dirty bits. This converts the build problem into a Datalog / SMT problem, a direction that is formally under-developed in the literature.

---

## 12. The Hard Ceilings

### 12.1 The Halting Problem (Turing, 1936)

**Theorem.** *There is no total computable function $H: \text{Program} \times \text{Input} \to \{0, 1\}$ such that $H(P, x) = 1$ iff $P$ halts on input $x$.*

**Proof.** Suppose such an $H$ exists. Define

$$
D(P) \;=\; \begin{cases} \text{loop forever} & \text{if } H(P, P) = 1 \\ \text{halt} & \text{if } H(P, P) = 0. \end{cases}
$$

Then $D(D)$ halts $\iff H(D, D) = 0 \iff D(D)$ does not halt. Contradiction. $\blacksquare$

**Consequence.** No system can decide, in general, whether a given constraint system will converge.

### 12.2 Rice's Theorem (Rice, 1953)

**Theorem.** *Let $\mathcal{F}$ be a non-trivial set of partial computable functions (i.e., $\mathcal{F} \neq \emptyset$ and $\mathcal{F}$ does not contain all such functions). Then the set $\{P \mid \llbracket P \rrbracket \in \mathcal{F}\}$ is undecidable.*

**Proof sketch.** Reduction from halting: let $P_0 \notin \mathcal{F}$ and $P_1 \in \mathcal{F}$. Given an instance $(Q, x)$ of halting, construct

$$
R(y) \;=\; \begin{cases} P_0(y) & \text{if } Q(x) \text{ diverges} \\ P_1(y) & \text{if } Q(x) \text{ halts}. \end{cases}
$$

Then $\llbracket R \rrbracket \in \mathcal{F}$ iff $Q(x)$ halts. Deciding membership in $\mathcal{F}$ would decide halting. $\blacksquare$

**Consequence.** *Every* non-trivial semantic property of programs — "does this program compute a total function?", "is this program equivalent to that program?", "does this constraint system have a fixed point?" — is undecidable.

### 12.3 Cook–Levin Theorem

**Theorem (Cook 1971, Levin 1973).** *SAT is NP-complete.*

**Consequence.** Any reduction of constraint solving, planning, or scheduling to a framework at least as expressive as SAT inherits NP-hardness. Every solver past this line depends on heuristics and has worst-case exponential behavior.

### 12.4 Time Hierarchy Theorem

**Theorem (Hartmanis & Stearns).** *If $f, g$ are time-constructible and $f(n) \log f(n) = o(g(n))$, then $\text{DTIME}(f) \subsetneq \text{DTIME}(g)$.*

**Consequence.** There is no "ultimate" fast algorithm; harder problems provably require more time.

### 12.5 Undecidability of type inhabitation in DTT

**Theorem.** *The problem "given a closed type $A$ in CIC, does there exist a closed term $t : A$?" is undecidable.*

**Proof sketch.** Encode provability in Peano Arithmetic as type inhabitation: a proposition $P$ is provable in PA iff the type $\llbracket P \rrbracket$ is inhabited. Provability in PA is undecidable (Gödel), so type inhabitation is. $\blacksquare$

**Consequence.** No system can automatically find proofs for arbitrary specifications. This is the ultimate wall on "declare what you want and the system builds it."

### 12.6 Gödel's Incompleteness (relevance)

**First Incompleteness Theorem (Gödel, 1931).** *Any consistent, computably-axiomatized extension of Peano Arithmetic is incomplete: there exist true arithmetic sentences that it cannot prove.*

**Consequence for dynamic coding.** Even if one builds a perfect theorem prover, there are true facts about one's constraint system it will never derive. *Completeness* of the reasoning engine is mathematically impossible past a minimum expressive threshold.

### 12.7 The combined ceiling

Putting these together: any framework powerful enough to encode arithmetic (which includes any system with Datalog + negation, SMT with bit-vectors, or dependent types) satisfies:

1. **Satisfiability is undecidable** (Rice / Matiyasevich).
2. **Even decidable fragments are NP-hard or worse** (Cook–Levin, hierarchy).
3. **Completeness is impossible** (Gödel).

These walls do not move with cleverness. They move only with restriction: narrow the expressive power and regain decidability and tractability. This trade-off is the real design decision behind every dynamic-coding framework.

---

## 13. A Generic Constraint + Derivation + Priority Engine, Formally Situated

Consider the generic engine described in the prior conversation (and its associated document): a state $S \in \mathcal{S}$, a finite set of derivations $\{D_i\}_{i \in I}$ each a partial function $\mathcal{S} \to \mathcal{S}$, a finite set of constraints $\{C_j\}_{j \in J}$ each a projection $\mathcal{S} \to \mathcal{S}$, and a priority function $\pi: J \to \mathbb{N}$.

### 13.1 The engine as an operator

Define

$$
F \;=\; \left( \bigcirc_{j \in J,\, \text{ordered by } \pi} C_j \right) \;\circ\; \left( \bigcirc_{i \in I} D_i \right).
$$

The engine iterates $S_{t+1} = F(S_t)$ until $S_{t+1} = S_t$.

### 13.2 Convergence analysis

**Case 1: Monotone, Scott-continuous F.** If $\mathcal{S}$ is a complete lattice and all $D_i, C_j$ are monotone and Scott-continuous, then $F$ is Scott-continuous, and by Kleene, iteration from $\bot$ converges to $\operatorname{lfp}(F)$ in countably many steps. This is the Datalog-like regime.

**Case 2: F is a projection on finite $\mathcal{S}$.** If $\mathcal{S}$ is finite and each $C_j$ is idempotent ($C_j \circ C_j = C_j$), then $F$ stabilizes in at most $|\mathcal{S}|$ steps. This is the SAT/ASP regime.

**Case 3: F non-monotone.** If any $C_j$ inverts an assignment (e.g., "if $\text{sent}$ and $\text{blocked}$ then $\neg \text{sent}$"), $F$ may oscillate. This is the regime of *conflicting intents* in the engine's documentation.

**Oscillation theorem.** If there exists a finite cycle $S_0 \to S_1 \to \cdots \to S_k = S_0$ of $F$ with $k > 1$, no fixed point exists along that orbit; iteration diverges.

### 13.3 Priority as lexicographic MaxSAT

The engine's priority system is exactly lexicographic MaxSAT:

$$
S^\star \;=\; \arg\min_{S \in \mathcal{S}} \; \left( \sum_{j : \pi(j) = P_\max} \text{viol}_j(S),\; \sum_{j : \pi(j) = P_\max - 1} \text{viol}_j(S),\; \ldots \right)
$$

in lexicographic order. This is decidable iff $\mathcal{S}$ is finite and each constraint is efficiently evaluable; NP-hard in general.

### 13.4 Energy formulation

Equip each constraint with a real weight $w_j$. Define

$$
E(S) \;=\; \sum_{j \in J} w_j \cdot \text{viol}_j(S), \qquad S^\star = \arg\min_S E(S).
$$

When $\text{viol}_j$ is $\{0, 1\}$-valued, this is MaxSAT. When $\text{viol}_j$ is real-valued and $E$ is smooth, this is continuous optimization; gradient descent converges to a local minimum (but not necessarily $S^\star$). When $\text{viol}_j$ is discrete and the graph of variable interactions is a tree, the problem is solvable in polynomial time by dynamic programming (the junction tree algorithm).

### 13.5 Multi-substrate extension

If $\mathcal{S} = \bigtimes_{i} \mathcal{S}_i$ where each $\mathcal{S}_i$ is the state space of a distinct file type (e.g., $\mathcal{S}_{.md}, \mathcal{S}_{.py}, \mathcal{S}_{.html}$), and each $F_i$ is the local engine for that substrate, the combined engine is

$$
F_\text{total} \;=\; \bigcirc_{i} \;\iota_i \circ F_i \circ \pi_i
$$

where $\pi_i$ projects onto substrate $i$ and $\iota_i$ re-injects the result. The total fixed point exists iff every $F_i$ is monotone *and* the substrates are coupled by monotone injections. Failure of either condition causes cross-substrate oscillation.

This is the formal content of the "multi-substrate repo" vision: a product-lattice fixed-point computation, with each substrate contributing a local operator and the coupling between substrates providing the global constraints. The open research problem is: **what additional structure on inter-substrate couplings guarantees convergence without restricting expressivity below Datalog?**

### 13.6 The engine as an abstract interpretation

If we view the full universe of programs/documents as concrete and each substrate as an abstract domain, the engine becomes an abstract interpretation where the "Galois connection" is replaced by a family of translations $\alpha_{ij}: \mathcal{S}_i \to \mathcal{S}_j$ (e.g., markdown-intent to Python-constraint). Soundness of the engine then reduces to commutativity of local fixed points with inter-substrate translations — a well-defined mathematical question.

---

## 14. Synthesis: The Equations That Drive the Frontier

We have now unpacked, in full mathematical form, the core equations of every major dynamic-computation paradigm:

| Paradigm                       | Core equation                                                              | Underlying theorem           |
|--------------------------------|----------------------------------------------------------------------------|------------------------------|
| Generic fixed-point            | $S^\star = F(S^\star)$                                                     | Knaster–Tarski               |
| Iterative fixed-point          | $S^\star = \bigvee_n F^n(\bot)$                                            | Kleene                       |
| Contractive fixed-point        | $d(f^n(x_0), x^\star) \leq \frac{q^n}{1-q} d(x_1, x_0)$                    | Banach                       |
| Abstract interpretation        | $\alpha(\operatorname{lfp}(F)) \leq \operatorname{lfp}(F^\sharp)$           | Cousot–Cousot soundness      |
| Datalog                        | $M_P = \operatorname{lfp}(T_P) = \bigcup_n T_P^n(\emptyset)$               | van Emden–Kowalski           |
| SAT                            | $\varphi \models \alpha?$ via unit propagation + CDCL                       | Cook–Levin                   |
| SMT (Nelson–Oppen)             | $T_1 \cup T_2$ decidable if each $T_i$ is stably infinite                   | Nelson–Oppen                 |
| MaxSAT / soft CSP              | $S^\star = \arg\min_S \sum_j w_j \cdot \text{viol}_j(S)$                   | —                            |
| Self-adjusting computation     | $\nabla f(x, \delta) = (f(x+\delta), \delta_y)$                            | Acar trace-stability         |
| Differential dataflow / DBSP   | $Q^\Delta = \mathbf{D} \circ Q \circ \mathbf{I};\;\; \mathbf{D}\mathbf{I} = \mathbf{I}\mathbf{D} = \operatorname{id}$ | DBSP fundamental theorem     |
| ASP stable models              | $S = \operatorname{lfp}(T_{P^S})$                                          | Gelfond–Lifschitz            |
| Curry–Howard                   | Type $A$ inhabited $\iff$ proposition $A$ provable                          | Howard 1969                  |
| Dependent type check           | $\Gamma \vdash t : A$ decidable; $\exists t.\; t : A$ undecidable            | Reduction from PA            |
| Build systems                  | $\text{build}: \text{Tasks} \to k \to \text{Store} \to \text{Store}$        | Mokhov–Mitchell–Peyton Jones |
| Halting problem                | $H(P, x)$ undecidable                                                      | Turing 1936                  |
| Rice's theorem                 | Every non-trivial semantic property undecidable                             | Rice 1953                    |
| Gödel's incompleteness         | Consistent sufficiently-strong axiomatic systems are incomplete             | Gödel 1931                   |

### What this table says

Every row is a different *reshaping* of the same fundamental relation: **a computation is a fixed point, up to the lattice, operator, and effect structure one uses**.

- When the operator is monotone-continuous on a complete lattice, we get declarative semantics (Datalog, Cousot).
- When the operator is a projection on a finite lattice, we get SAT/SMT/ASP.
- When the lattice is a stream of differences, we get incremental computation (SAC, DBSP).
- When the fixed-point equation is between types and their inhabitants, we get proof assistants.
- When the fixed point is between tasks and their dependencies, we get build systems.

### The honest ceiling

Past Datalog, every expressive system is undecidable in the general case. Past SAT, every interesting problem is NP-hard. Past Peano Arithmetic, no axiomatic system is complete. The universal frontier of dynamic computation is carved by these three walls — no engineering advance crosses them, only better trade-offs between expressivity and decidability.

### Where genuine novelty is possible

The open territory visible from this survey is:

1. **Multi-substrate fixed-point calculi** (§13.5) — product lattices where each substrate contributes local operators and cross-substrate couplings impose global constraints. Formal conditions for convergence without loss of expressivity remain underdeveloped.

2. **Incremental proof search** — combining SAC / DBSP with dependent-type proof search to get *incremental formalization* as theorems and definitions edit over time. Lean/Mathlib-scale work would benefit enormously.

3. **Algebraic structure on priority systems** — priority has been studied as lexicographic MaxSAT but rarely as a *field of tensions* in the physics sense. A tensor-valued priority function and a covariant derivative on the state space would put the engine in variational / gauge-theoretic language. This is where physics-style formalism might contribute something new.

4. **LLM-guided fixed-point search** — characterizing when an LLM-edit sequence on a codebase converges vs. oscillates, in terms of the operators it induces on the repo's state lattice. No mathematical framework for this currently exists.

These are the directions where the equations of this paper might drive genuinely novel engineering — not past the ceiling, but into its unexplored corners.

---

## References (selected)

- Acar, U. A. *Self-Adjusting Computation.* Ph.D. dissertation, CMU-CS-05-129, 2005.
- Budiu, M., McSherry, F., et al. *DBSP: Incremental Computation on Streams and Its Applications to Databases.* VLDB 2023.
- Cook, S. A. *The Complexity of Theorem-Proving Procedures.* STOC 1971.
- Cousot, P., Cousot, R. *Abstract Interpretation: A Unified Lattice Model for Static Analysis of Programs by Construction or Approximation of Fixpoints.* POPL 1977.
- de Moura, L., Bjørner, N. *Z3: An Efficient SMT Solver.* TACAS 2008.
- Gelfond, M., Lifschitz, V. *The Stable Model Semantics for Logic Programming.* ICLP 1988.
- Gödel, K. *Über formal unentscheidbare Sätze der Principia Mathematica und verwandter Systeme I.* Monatshefte für Mathematik, 1931.
- Howard, W. A. *The Formulae-as-Types Notion of Construction.* 1969 (published 1980).
- Kleene, S. C. *Introduction to Metamathematics.* North-Holland, 1952.
- Knaster, B. *Un théorème sur les fonctions d'ensembles.* Annales de la Société Polonaise de Mathématique, 1928.
- Kumar, P. *Incremental Computing by Differential Execution.* ECOOP 2025.
- Martin-Löf, P. *Intuitionistic Type Theory.* Bibliopolis, 1984.
- McSherry, F., Murray, D., Isaacs, R., Isard, M. *Differential Dataflow.* CIDR 2013.
- Mokhov, A., Mitchell, N., Peyton Jones, S. *Build Systems à la Carte.* ICFP 2018.
- Nelson, G., Oppen, D. C. *Simplification by Cooperating Decision Procedures.* TOPLAS 1979.
- Norman, C., Avigad, J. *Canonical for Automated Theorem Proving in Lean.* ITP 2025.
- Rice, H. G. *Classes of Recursively Enumerable Sets and Their Decision Problems.* TAMS 1953.
- Tarski, A. *A Lattice-Theoretical Fixpoint Theorem and Its Applications.* Pacific J. Math., 1955.
- Turing, A. M. *On Computable Numbers, with an Application to the Entscheidungsproblem.* 1936.
- van Emden, M. H., Kowalski, R. A. *The Semantics of Predicate Logic as a Programming Language.* JACM 1976.
- Voevodsky, V. et al. *Homotopy Type Theory: Univalent Foundations of Mathematics.* Institute for Advanced Study, 2013.

---

*End of paper.*
