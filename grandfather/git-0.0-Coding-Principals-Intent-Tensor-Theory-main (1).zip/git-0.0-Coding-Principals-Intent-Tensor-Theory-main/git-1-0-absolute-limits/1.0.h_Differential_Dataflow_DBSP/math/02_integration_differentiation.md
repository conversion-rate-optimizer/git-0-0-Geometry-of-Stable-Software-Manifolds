# Integration and Differentiation

The two fundamental operators on streams, and their fundamental identities.

## Integration

The **integration operator** $\mathbf{I}$ sums up the history of a stream:

$$
\mathbf{I}(s)[t] \;=\; \sum_{i=0}^{t} s[i].
$$

If $s$ is a stream of Z-set *changes*, then $\mathbf{I}(s)[t]$ is the *snapshot* at time $t$.

**Example.** If $s$ represents inserts and deletes to a SQL table, $\mathbf{I}(s)[t]$ is the table's contents at time $t$.

## Differentiation

The **differentiation operator** $\mathbf{D}$ takes differences:

$$
\mathbf{D}(s)[t] \;=\; s[t] - s[t-1]
$$

with $s[-1] := 0$.

If $s$ is a stream of *snapshots*, then $\mathbf{D}(s)[t]$ is the *change* between $t-1$ and $t$.

## Fundamental identities

**Theorem (DBSP).**

$$
\mathbf{D} \circ \mathbf{I} = \mathbf{I} \circ \mathbf{D} = \mathrm{id}.
$$

**Proof.**

$\mathbf{D}(\mathbf{I}(s))[t] = \mathbf{I}(s)[t] - \mathbf{I}(s)[t-1] = \sum_{i \leq t} s[i] - \sum_{i \leq t-1} s[i] = s[t]$.

$\mathbf{I}(\mathbf{D}(s))[t] = \sum_{i \leq t} (s[i] - s[i-1]) = s[t] - s[-1] = s[t]$. $\blacksquare$

So $\mathbf{D}$ and $\mathbf{I}$ are inverse operators. This is the discrete analog of the Fundamental Theorem of Calculus.

## Significance for incremental computation

Let $Q : \mathbb{Z}[D]^k \to \mathbb{Z}[D']$ be a query — think of it as a SQL view. Lift $Q$ to streams pointwise.

Define the **incremental version**:

$$
Q^\Delta \;=\; \mathbf{D} \circ Q \circ \mathbf{I}.
$$

Given a stream of *deltas* (changes to input tables), $\mathbf{I}$ produces the snapshots, $Q$ produces the view snapshots, and $\mathbf{D}$ produces the view deltas — an output stream of changes to the materialized view.

**The key observation:** if $Q$ is a composition of linear and bilinear operators, we can **push $\mathbf{D}$ and $\mathbf{I}$ through $Q$** algebraically, transforming $Q$ into a form that computes deltas directly without materializing snapshots. This is the algebraic engine of incremental view maintenance.

## Algebraic laws

For **linear** $L$: $L \circ \mathbf{D} = \mathbf{D} \circ L$, and $L \circ \mathbf{I} = \mathbf{I} \circ L$. So $L^\Delta = L$ — linear queries are their own delta.

For **bilinear** $B$ (e.g., join): there is a standard expansion
$$
B(s_1, s_2)^\Delta(\Delta_1, \Delta_2) = B(\Delta_1, \mathbf{I}(s_2)) + B(\mathbf{I}(s_1), \Delta_2) + B(\Delta_1, \Delta_2).
$$

This is the **bilinear delta rule** — given the prior snapshots and the new deltas, compute the view delta directly.

## Time shifts

Define the **shift operator** $z^{-1}$ on streams by

$$
(z^{-1} s)[t] \;=\; s[t - 1]
$$

(with $s[-1] = 0$). Then $\mathbf{D}(s) = s - z^{-1} s$.

The $z^{-1}$ notation is adopted from Z-transform / digital signal processing; DBSP literature sometimes uses it directly.

## The DBSP fundamental theorem

**Theorem (Budiu, McSherry, Ryzhyk, Tannen).** *For any query $Q$ composed from linear and bilinear primitives, $Q^\Delta$ is derivable mechanically and computes in time proportional to the delta size, independent of the database snapshot size.*

This is why Materialize can maintain views over terabytes of data in milliseconds per change: it never looks at the full database once it's "arranged."

## Recursion handling

For recursive queries $R = Q(R, I)$, we need a nested fixed point. DBSP handles this via the **iterate** operator:

$$
R^\star \;=\; \text{iterate}(\lambda r.\; Q(r, I))
$$

which is internally another Kleene iteration — this one using DBSP operators. Because the fixed-point convergence is itself incrementally maintained, recursive views can also be incrementally maintained in DBSP.

## What you literally write

In Materialize SQL:

```sql
CREATE MATERIALIZED VIEW path AS
WITH RECURSIVE p(src, dst) AS (
    SELECT src, dst FROM edges
  UNION
    SELECT e.src, p.dst FROM edges e JOIN p ON e.dst = p.src
)
SELECT * FROM p;
```

Materialize compiles this into the DBSP primitive operators and their $\Delta$ versions. Every insert/delete on `edges` triggers incremental updates to `path`, proportional to how much the transitive closure actually changed.

The mathematics of this chapter is what makes that possible.
