# Notation Conventions

Consistent notation across the chapter.

## Sets and structures

| Symbol                  | Meaning                                                    |
|-------------------------|------------------------------------------------------------|
| $L, (L, \leq)$          | A poset; when complete, a complete lattice.                |
| $\bot, \top$            | Bottom and top of a complete lattice.                      |
| $\vee, \wedge$          | Join (supremum) and meet (infimum).                         |
| $\bigvee S, \bigwedge S$ | Supremum and infimum of a subset $S \subseteq L$.         |
| $\mathcal{S}$           | A generic state space (used for the ITT Intent Engine).    |
| $2^X$                   | Power set of $X$.                                          |
| $\mathbb{Z}, \mathbb{N}, \mathbb{R}$ | Integers, naturals, reals.                      |
| $\mathbb{Z}[D]$         | The abelian group of Z-sets over domain $D$ (DBSP).        |

## Functions and operators

| Symbol                  | Meaning                                                    |
|-------------------------|------------------------------------------------------------|
| $f : A \to B$           | A function from $A$ to $B$.                                |
| $f \circ g$             | Function composition: $(f \circ g)(x) = f(g(x))$.          |
| $\operatorname{id}$     | Identity function.                                         |
| $\operatorname{lfp}(F)$ | Least fixed point of $F$.                                  |
| $\operatorname{gfp}(F)$ | Greatest fixed point of $F$.                               |
| $F^n$                   | $n$-fold composition: $F \circ F \circ \cdots \circ F$.    |
| $T_P$                   | Immediate-consequence operator for a Datalog program $P$.  |
| $\mathbf{I}, \mathbf{D}$| Integration and differentiation operators on streams.      |

## Logic and types

| Symbol                  | Meaning                                                    |
|-------------------------|------------------------------------------------------------|
| $\models$               | Models / satisfies.                                        |
| $\vdash$                | Derives / entails.                                         |
| $\Gamma \vdash t : A$   | In context $\Gamma$, term $t$ has type $A$.                |
| $\prod_{x:A} B(x)$      | Dependent function type.                                   |
| $\sum_{x:A} B(x)$       | Dependent pair type.                                       |
| $\operatorname{Id}_A(a, b)$ | Identity type.                                          |

## Code conventions

All code snippets use the smallest realistic syntax that expresses the math.
- **Haskell** for type-theoretic purity and `::` ("has type") readability.
- **Python** for accessibility and quick experimentation.
- **TypeScript / JavaScript** for frontend-oriented integration.
- **Rust** for performance-critical systems (differential dataflow, Datafrog).
- **OCaml** where Jane Street `Incremental` is canonical.
- **Lean 4** and **Idris** for dependent types.
- **Clingo** for ASP.
- **SQL (Materialize/Feldera dialect)** for DBSP-backed IVM.

Syntax correspondences:
- `x :: A` (Haskell) ≡ `x: A` (Python, TypeScript, Lean) ≡ "$x \in A$" (math).
- `f :: A -> B` ≡ "$f : A \to B$".
- `class Lattice a where ...` ≡ "let $(L, \leq)$ be a lattice."
