# Canonical Abstract Domains

The standard lattices used in practice, ordered by precision/cost.

## Signs

$$
A = \{\bot, \{<0\}, \{=0\}, \{>0\}, \{\leq 0\}, \{\geq 0\}, \{\neq 0\}, \top\}
$$

- **Cost:** constant per operation.
- **Precision:** captures sign but no magnitude.
- **Widening:** not needed (finite).
- **Use case:** quick liveness/null analysis.

## Intervals

$$
A = \{\bot\} \cup \{[a, b] : a \in \mathbb{Z} \cup \{-\infty\},\, b \in \mathbb{Z} \cup \{+\infty\},\, a \leq b\}
$$

- **Cost:** constant per operation.
- **Precision:** captures magnitude but no relations between variables.
- **Widening:** essential (infinite chains).
- **Use case:** array bounds checking, integer overflow.

## Octagons

Expressions of the form $\pm x_i \pm x_j \leq c$ for variable pairs $(x_i, x_j)$ and constants $c$.

- **Cost:** $O(n^3)$ for closure, where $n$ is number of variables.
- **Precision:** captures linear relations between pairs of variables.
- **Widening:** standard in octagon libraries.
- **Use case:** relational integer reasoning, loop invariants.

## Polyhedra

Systems of linear inequalities $\sum_i a_i x_i \leq b$ over variables $x_1, \ldots, x_n$.

- **Cost:** exponential in the number of variables in the worst case.
- **Precision:** captures arbitrary linear relations.
- **Widening:** multiple options (standard, thresholded).
- **Use case:** high-precision relational analysis (e.g., Astrée uses polyhedra).

## Points-to / heap shape

Lattices of abstract memory states (regions, shape graphs, three-valued logic).

- **Cost:** highly variable, from $O(n)$ (Steensgaard) to $O(n^3)$ (Andersen) to exponential.
- **Precision:** captures aliasing and heap structure.
- **Widening:** domain-specific.
- **Use case:** null-pointer analysis, security analyses.

## Trace partitioning

For path-sensitive analysis: partition concrete traces by program path, analyze each partition separately, union at join points.

- **Cost:** exponential in branching depth.
- **Precision:** very high.
- **Widening:** partition-level.
- **Use case:** high-confidence safety proofs.

## Combined domains

In practice, abstract interpreters use **combinations**:
- **Reduced product:** compute on multiple domains in parallel, cross-reduce.
- **Layered/hierarchical:** coarser domain drives a finer domain.

Astrée, for example, combines intervals, octagons, polyhedra, ellipsoids, and filter domains.

## Summary table

| Domain        | Precision | Cost           | Widening needed? |
|---------------|-----------|----------------|------------------|
| Signs         | Low       | O(1)           | No               |
| Intervals     | Medium    | O(1)           | Yes              |
| Octagons      | High      | O(n³)          | Yes              |
| Polyhedra     | Very high | Exponential    | Yes              |
| Points-to     | Various   | Varies         | Sometimes        |
| Partitioning  | Highest   | Exponential    | Yes              |

## Design heuristic

Start with the simplest domain that captures the property you want to prove. Add precision only when you observe analysis failures. Combine domains via reduced product when necessary.

In ITT terms: the choice of abstract domain is the choice of **which substrate to represent state in**. Each substrate has its own cost/precision trade-off. A multi-substrate engine (see `1.0.n`) is effectively a reduced product of abstract domains.
