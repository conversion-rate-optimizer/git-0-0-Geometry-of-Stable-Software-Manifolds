# Banach's Fixed Point Theorem

The **metric / quantitative** fixed-point theorem: contractions have unique fixed points with exponential convergence.

## Statement

**Theorem (Banach, 1922).** *Let $(X, d)$ be a non-empty complete metric space and $f : X \to X$ a contraction with factor $q \in [0, 1)$, i.e.,*

$$
\forall x, y \in X.\; d(f(x), f(y)) \leq q \cdot d(x, y).
$$

*Then:*

1. *$f$ has a unique fixed point $x^\star \in X$.*
2. *For any starting point $x_0 \in X$, the sequence $x_{n+1} = f(x_n)$ converges to $x^\star$.*
3. *The convergence is **exponential** with explicit bounds:*

$$
d(x_n, x^\star) \;\leq\; \frac{q^n}{1 - q} \cdot d(x_1, x_0).
$$

## Proof

**Step 1: The sequence is Cauchy.**
For $m > n$:

$$
d(x_{n+1}, x_n) = d(f(x_n), f(x_{n-1})) \leq q \cdot d(x_n, x_{n-1}) \leq \cdots \leq q^n \cdot d(x_1, x_0).
$$

By the triangle inequality:

$$
d(x_m, x_n) \leq \sum_{k=n}^{m-1} d(x_{k+1}, x_k) \leq \sum_{k=n}^{m-1} q^k \cdot d(x_1, x_0) \leq \frac{q^n}{1-q} \cdot d(x_1, x_0).
$$

Since $q < 1$, this tends to $0$ as $n \to \infty$. The sequence is Cauchy.

**Step 2: Convergence.**
$X$ is complete, so $(x_n)$ converges to some $x^\star \in X$.

**Step 3: $x^\star$ is a fixed point.**
$f$ is continuous (every contraction is Lipschitz, hence continuous), so

$$
f(x^\star) = f(\lim_n x_n) = \lim_n f(x_n) = \lim_n x_{n+1} = x^\star.
$$

**Step 4: Uniqueness.**
Suppose $y^\star$ is another fixed point. Then

$$
d(x^\star, y^\star) = d(f(x^\star), f(y^\star)) \leq q \cdot d(x^\star, y^\star).
$$

Since $q < 1$, we must have $d(x^\star, y^\star) = 0$, i.e., $x^\star = y^\star$.

**Step 5: Error bound.**
Taking $m \to \infty$ in Step 1:

$$
d(x_n, x^\star) \leq \frac{q^n}{1-q} \cdot d(x_1, x_0).
$$

$\blacksquare$

## What this theorem buys you

Banach's theorem is *dramatically* stronger than Knaster–Tarski or Kleene:
- **Unique** fixed point (not just least/greatest).
- **Any starting point** converges (not just $\bot$).
- **Exponential rate** with explicit constants.

The cost: you need a metric structure *and* an actual contraction.

## Non-contractive alternatives

If $f$ is only **non-expansive** ($q = 1$ is allowed), Banach fails. Example: $f(x) = x + 1$ on $\mathbb{R}$ is non-expansive ($q = 1$) but has no fixed point.

If $f$ is a **weak contraction** (strictly decreases distances but possibly with $q$ depending on the points), there are generalized theorems (Ćirić, Kirk) giving existence under additional conditions.

## Applications

### Newton's method
For a smooth function $g : \mathbb{R} \to \mathbb{R}$ with $g'(x^\star) \neq 0$ near a root $x^\star$, Newton's iteration

$$
x_{n+1} = x_n - \frac{g(x_n)}{g'(x_n)}
$$

is a contraction in a neighborhood of $x^\star$ with $q = O(|x_n - x^\star|)$ — so-called **quadratic convergence**. Banach's theorem (or its generalizations) guarantees convergence when started close enough.

### Picard iteration for ODEs
The existence theorem for solutions to $\dot y = g(t, y)$, $y(0) = y_0$, is proved by showing that the integral operator

$$
T(y)(t) = y_0 + \int_0^t g(s, y(s))\, ds
$$

is a contraction on a small enough time interval with respect to the sup-norm. The fixed point of $T$ is the solution to the ODE.

### Gradient flow
For a strongly convex function $g$ with Lipschitz gradient, gradient descent $x_{n+1} = x_n - \eta \nabla g(x_n)$ is a contraction with an appropriate step size $\eta$. This underlies the convergence proofs for most deterministic optimization methods.

### Reinforcement learning (Bellman equation)
The Bellman optimality operator

$$
(T^\star V)(s) = \max_a \left[ R(s, a) + \gamma \sum_{s'} P(s'|s, a) V(s') \right]
$$

is a contraction in the sup-norm with factor $\gamma$ (the discount rate). Banach gives convergence of value iteration.

## When Banach applies to dynamic-coding systems

- **Probabilistic / soft-constraint engines:** if you replace hard constraints with soft penalties and run gradient descent, you're in Banach territory.
- **Numerical simulations:** fixed-point solvers for physics.
- **ITT Allen–Cahn dynamics:** if formulated as gradient flow on an energy landscape with a well-conditioned Hessian, Banach gives convergence of a suitable discretization.

## When Banach does not apply

- **Pure constraint solving (SAT, Datalog, ASP):** no metric structure.
- **Reactive dataflow:** operates on discrete updates, not metric approach.
- **Proof search in type theory:** discrete state, no distance.

For discrete systems, use Knaster–Tarski or Kleene. Use Banach when you have geometry.
