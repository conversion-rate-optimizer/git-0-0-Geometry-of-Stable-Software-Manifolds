/**
 * 0.1_LATTICE: Spectral Engine
 * ==============================
 * Decomposes the field φ into eigenmodes of the weight matrix W.
 *
 *   φ = Σ_k a_k v_k
 *
 * The eigenmodes with largest eigenvalues are the dominant structures —
 * the natural "objects" the graph wants to form.
 *
 * Spectral gap (λ₁ - λ₂) determines mixing time:
 * large gap = fast convergence, intent spreads quickly.
 * small gap = slow convergence, structure is ambiguous.
 */

import { LATTICE } from "../-Z_BASE/axioms";

export interface SpectralMode {
  eigenvalue: number;
  /** Normalized eigenvector — one value per node */
  eigenvector: Map<string, number>;
}

export interface SpectralDecomposition {
  modes: SpectralMode[];
  spectralGap: number;  // λ₁ - λ₂
  dominantNodes: string[];  // Nodes with highest weight in top mode
}

/**
 * Power iteration to find the dominant eigenmode of W.
 * For the full decomposition, multiple runs with deflation.
 */
function powerIteration(
  nodeIds: string[],
  W: Map<string, Map<string, number>>,
  maxIter: number = 100
): SpectralMode {
  // Start with uniform vector
  let v = new Map<string, number>(nodeIds.map(id => [id, 1 / Math.sqrt(nodeIds.length)]));
  let eigenvalue = 0;

  for (let iter = 0; iter < maxIter; iter++) {
    // Wv
    const Wv = new Map<string, number>();
    for (const id of nodeIds) {
      let sum = 0;
      const neighbors = W.get(id);
      if (neighbors) {
        for (const [nId, w] of neighbors) {
          sum += w * (v.get(nId) ?? 0);
        }
      }
      Wv.set(id, sum);
    }

    // Normalize
    let norm = 0;
    for (const val of Wv.values()) norm += val * val;
    norm = Math.sqrt(norm) + LATTICE.epsilon_field;

    eigenvalue = norm;
    for (const [id, val] of Wv) {
      v.set(id, val / norm);
    }
  }

  return { eigenvalue, eigenvector: v };
}

/**
 * Compute top-2 spectral modes and the spectral gap.
 * Full decomposition is expensive — top-2 tells you what you need.
 */
export function spectralDecompose(
  nodeIds: string[],
  W: Map<string, Map<string, number>>
): SpectralDecomposition {
  // Mode 1
  const mode1 = powerIteration(nodeIds, W);

  // Deflate W (remove mode 1 contribution) then find mode 2
  const W2 = new Map<string, Map<string, number>>();
  for (const id of nodeIds) {
    const row = new Map<string, number>();
    const neighbors = W.get(id);
    if (neighbors) {
      for (const [nId, w] of neighbors) {
        const deflated = w - mode1.eigenvalue
          * (mode1.eigenvector.get(id) ?? 0)
          * (mode1.eigenvector.get(nId) ?? 0);
        if (Math.abs(deflated) > LATTICE.epsilon_field) {
          row.set(nId, deflated);
        }
      }
    }
    W2.set(id, row);
  }

  const mode2 = powerIteration(nodeIds, W2);

  // Dominant nodes: top 20% by eigenvector weight
  const sorted = nodeIds
    .map(id => ({ id, weight: Math.abs(mode1.eigenvector.get(id) ?? 0) }))
    .sort((a, b) => b.weight - a.weight);

  const topCount = Math.max(1, Math.ceil(nodeIds.length * 0.2));
  const dominantNodes = sorted.slice(0, topCount).map(x => x.id);

  return {
    modes: [mode1, mode2],
    spectralGap: Math.abs(mode1.eigenvalue - mode2.eigenvalue),
    dominantNodes,
  };
}

/**
 * Project field φ onto dominant eigenmode.
 * Returns alignment score — how much the field matches the natural structure.
 */
export function fieldAlignment(
  phi: Map<string, number>,
  mode: SpectralMode
): number {
  let dot = 0;
  for (const [id, val] of phi) {
    dot += val * (mode.eigenvector.get(id) ?? 0);
  }
  return dot;
}
