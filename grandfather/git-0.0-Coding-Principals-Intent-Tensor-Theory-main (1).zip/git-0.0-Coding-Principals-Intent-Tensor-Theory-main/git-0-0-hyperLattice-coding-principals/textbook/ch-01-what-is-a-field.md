# Chapter 01 — What Is a Field?

*Read time: 8 minutes*

---

## Start With Sand

In 1787, a German physicist named Ernst Chladni took a metal plate, 
sprinkled sand on it, and drew a violin bow along the edge.

The sand moved. It did not scatter randomly. It arranged itself into 
precise geometric patterns — lines, starbursts, rings — depending on 
which note he played.

Different notes made different patterns. The same note always made 
the same pattern, no matter where the sand started or what kind of 
sand it was.

**The pattern was already in the sound.**

The sand did not create the pattern. The sand revealed it. The 
sound — the vibration — organized the space of the plate into 
regions. Some regions were moving. Some were still. The sand 
collected in the still regions because vibrating plates push 
things toward the quiet zones.

What Chladni discovered is that a vibration does not just make 
noise. It *structures space*. Every point on the plate has a value — 
how much it is vibrating at that moment. Some points have high 
values. Some have zero. The collection of all these values, at 
every point, is called a **field**.

---

## What a Field Is

A **field** is a value assigned to every point in a space.

That is the whole definition. It sounds simple because it is simple.

Some familiar fields:

**Temperature in a room.** Every point in the room has a temperature. 
Near the heater it is high. Near the window in winter it is low. 
If you could see every temperature value at every point simultaneously, 
you would see the temperature field.

**Altitude on a map.** A topographic map assigns an elevation number 
to every point on the ground. High in the mountains. Low at the coast. 
The map is a picture of the altitude field.

**Wi-Fi signal strength.** Every point in your house has a signal 
strength. Strong near the router. Weak in the back corner behind 
the refrigerator. This is a field.

In all of these cases: one number, at every point, all at once.

---

## Fields Change Over Time

The temperature field in your room is not static. It changes. When you 
turn on the heater, the field near the heater gets hotter. Then that 
heat slowly spreads — to adjacent regions, then to regions adjacent 
to those, until the whole room warms up.

This is called **field evolution**. The field at time t changes into 
the field at time t+1. The rule for how it changes is the equation 
that governs the field.

In this repository, the field is called **Φ** (the Greek letter phi). 
Every code module has a Φ value. The value represents how active, 
how relevant, how "charged" that module is — given the current 
state of the system.

The field evolves every iteration. Modules connected to active 
neighbors get more active. Modules with no connections and no 
seed decay toward zero.

---

## The Chladni Pattern in Code

Here is the important thing Chladni discovered that nobody taught 
you in school:

**The pattern exists before the sand moves.**

The vibration structures the plate into high-vibration and 
low-vibration zones the instant it starts. The sand then moves to 
reveal what was already there.

In this codebase, the same logic applies. When you seed the 
field with an intent (a starting value for some module), the 
field equation propagates that intent through the connected 
graph. The resulting pattern — which modules are active, which 
are quiet — is not something you design. It emerges from the 
structure of the connections and the initial seed.

The seed is the bow on the violin. The code is the plate. 
The field is the vibration. The active modules are the 
sand collecting in the still zones.

---

## What Φ = 0 Means

In this system, Φ = 0 means a module is in the **ground state** — 
no activation, no contribution, not yet part of the computation.

This is not failure. It is waiting. The ground state is where 
everything starts. Structure emerges from perturbation of 
the ground state. Without the ground state, there is nothing 
for the perturbation to disturb.

When you initialize a new module in this system, it starts 
at Φ = 0. The field equation will either bring it to life 
(if it is connected to something active and relevant) or 
leave it at zero (if it is isolated or irrelevant to the 
current computation).

---

## The Equation — Just the Idea

The field evolution equation in this repository looks like this:

```
Φ(next step) = seed_pressure + influence_from_neighbors + nonlinear_growth
```

We will break each piece down in later chapters. For now, just 
know that this is the rule that says: *given the current Φ value 
of every module, what is the Φ value of every module one step later?*

The whole system runs by applying this rule over and over until 
the field stops changing. When it stops changing, you read off 
which modules are active. Those are the ones the system considers real.

---

## Summary

- A field assigns a value to every point in a space
- Fields change over time according to equations
- In this codebase, Φ is the field — every module has one
- Φ = 0 is the ground state — nothing yet, not failure
- The field evolves until it settles, then you read the result
- The pattern emerges from the structure, not from design

---

**Previous:** [Chapter 00 — Before the Math](./ch-00-before-math.md)  
**Next:** [Chapter 02 — What Is a Graph?](./ch-02-what-is-a-graph.md)
