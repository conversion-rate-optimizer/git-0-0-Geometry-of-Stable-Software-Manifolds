"""
Python ↔ Clingo integration.

Install: pip install clingo
"""

import clingo


def graph_coloring_example():
    ctl = clingo.Control()
    ctl.add("base", [], """
        node(1..5).
        edge(1,2). edge(2,3). edge(3,4). edge(4,5). edge(5,1).

        1 { color(X, red); color(X, green); color(X, blue) } 1 :- node(X).
        :- edge(X, Y), color(X, C), color(Y, C).
    """)
    ctl.ground([("base", [])])
    with ctl.solve(yield_=True) as handle:
        for model in handle:
            colors = [atom for atom in model.symbols(atoms=True) if atom.name == "color"]
            print("Model:", colors[:3], "...")
            break  # just show one


def intent_engine_as_asp(email_present: bool, opted_in: bool, blocked: bool):
    """
    Encode the ITT Intent Engine as an ASP program with weak constraints.
    Let clingo find the optimal stable model.
    """
    ctl = clingo.Control(["--opt-mode=opt"])

    facts = ""
    if email_present: facts += "email_present.\n"
    if opted_in:      facts += "opted_in.\n"
    if blocked:       facts += "blocked.\n"

    ctl.add("base", [], facts + """
        eligible :- email_present, opted_in.
        { sent } :- email_present.

        :~ eligible, not sent. [10@1]       % priority 1, weight 10
        :~ blocked, sent.      [100@2]      % priority 2, weight 100
    """)
    ctl.ground([("base", [])])

    result = []
    with ctl.solve(yield_=True) as handle:
        best = None
        for model in handle:
            symbols = [s.name for s in model.symbols(atoms=True)]
            best = (symbols, model.cost)
        if best:
            result = best

    print(f"Input: email={email_present}, opted_in={opted_in}, blocked={blocked}")
    print(f"Optimal stable model: {result[0]}, cost={result[1]}")


if __name__ == "__main__":
    graph_coloring_example()
    print()
    intent_engine_as_asp(email_present=True, opted_in=True,  blocked=False)
    intent_engine_as_asp(email_present=True, opted_in=True,  blocked=True)
    intent_engine_as_asp(email_present=True, opted_in=False, blocked=False)
