# 1.0.c — Fixed Point Theorems

The three master theorems that guarantee convergence of every dynamic-computation framework.

## Files

**Math:**
- `math/00_knaster_tarski.md` — Existence on complete lattices (non-constructive).
- `math/01_kleene.md` — Constructive fixed point on pointed DCPOs.
- `math/02_banach.md` — Unique fixed point on complete metric spaces, with rate.
- `math/03_convergence_comparison.md` — When to use which.

**Code:**
- `code/lfp_haskell.hs` — Pure Kleene `lfp` in Haskell.
- `code/lfp_python.py` — Kleene `lfp` + Banach contraction in Python.
- `code/lfp_javascript.js` — JavaScript version matching the ITT engine style.
- `code/lfp_rust.rs` — Rust with error handling.
- `code/banach_newton.py` — Banach in action: Newton's method as contraction.
