# 1.0.i — Answer Set Programming

Stable-model semantics, Gelfond–Lifschitz reduct, weight constraints.

## Files

**Math:**
- `math/00_syntax_and_reduct.md` — ASP syntax and the GL reduct.
- `math/01_stable_models.md` — Stable-model semantics.
- `math/02_complexity_and_expressivity.md` — NP, Σ_2^P, what you can encode.
- `math/03_weight_constraints.md` — Soft constraints, optimization.

**Code:**
- `code/clingo_examples.lp` — Clingo rule files.
- `code/clingo_python.py` — Python-Clingo integration.
