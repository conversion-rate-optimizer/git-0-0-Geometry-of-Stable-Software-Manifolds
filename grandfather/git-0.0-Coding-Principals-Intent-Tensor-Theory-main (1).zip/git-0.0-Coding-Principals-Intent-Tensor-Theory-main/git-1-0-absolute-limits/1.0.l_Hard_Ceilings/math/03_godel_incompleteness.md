# Gödel's Incompleteness Theorems

The limits of axiomatic mathematics itself.

## First incompleteness theorem

**Theorem (Gödel 1931).** *Any consistent, computably axiomatizable formal system that includes basic arithmetic (e.g., Peano Arithmetic) is **incomplete**: there exists a sentence $G$ in the language of the system such that neither $G$ nor $\neg G$ is provable in the system.*

## Proof idea (Gödel numbering + self-reference)

1. **Gödel numbering.** Assign a unique natural number to each formula and each proof. Formulas and proofs become numbers; properties of proofs become arithmetical predicates.

2. **Provability predicate.** There is an arithmetical formula $\text{Prov}(x, y)$ meaning "$x$ is the Gödel number of a proof of the formula with Gödel number $y$."

3. **Self-reference via fixed-point lemma.** For any formula $\varphi(y)$ with one free variable, there is a sentence $G$ such that

$$
G \leftrightarrow \varphi(\#G)
$$

is provable, where $\#G$ is the Gödel number of $G$. This is the **diagonal lemma**.

4. **The Gödel sentence.** Apply the fixed-point lemma to $\varphi(y) = \neg \exists x.\; \text{Prov}(x, y)$ — "there is no proof of $y$." Get $G$ such that $G \leftrightarrow \neg \exists x.\; \text{Prov}(x, \#G)$. Informally: "$G$ says: 'I am not provable.'"

5. **Unprovability of $G$.** Suppose $G$ is provable. Then by construction, $\neg \exists x.\; \text{Prov}(x, \#G)$ is provable, meaning the system proves "there is no proof of $G$" — but we just had a proof of $G$. Contradiction (assuming consistency).

6. **Unprovability of $\neg G$.** Suppose $\neg G$ is provable. Then $\exists x.\; \text{Prov}(x, \#G)$ is provable — some concrete $x$ is a proof of $G$. If the system is **$\omega$-consistent**, this would imply $G$ is provable, contradicting step 5. (Rosser's trick improves this to only require ordinary consistency.)

Hence neither $G$ nor $\neg G$ is provable. $\blacksquare$

## Second incompleteness theorem

**Theorem (Gödel).** *Any consistent, computably axiomatizable formal system including basic arithmetic cannot prove its own consistency.*

Informally: the formalized statement "I am consistent" is not provable within the system — unless the system is inconsistent (in which case everything is provable).

**Implication.** To trust a formal system, you must accept its consistency on external / meta-theoretical grounds. There is no way to "bootstrap" trust purely from within.

## Consequences for computer science

### Limits of formal verification

Type checkers (Lean, Rocq, Agda) are proof systems. They cannot prove their own consistency. To trust them, we rely on:
- Small, carefully-written trusted kernel (minimizes attack surface).
- Meta-theoretical proofs of consistency (done on paper, using different systems).
- Empirical trust built over decades.

**No amount of formal verification can produce a system whose correctness is provable from within itself.**

### Limits of program synthesis

If a proof system is incomplete, there are true theorems it cannot prove. Equivalently, there are total computable functions whose implementation cannot be synthesized from their specification within the system.

Concrete example: for Peano Arithmetic, Goodstein's theorem is true but unprovable — it requires ordinal induction beyond PA. The corresponding Goodstein-like algorithm cannot be synthesized from a PA-level specification.

### Limits of self-knowledge

The diagonal structure of Gödel's theorem applies to any sufficiently expressive system that can talk about itself. This is why:
- No Turing-complete program can decide halting (its own).
- No expressive type system can prove its own consistency.
- No sufficiently powerful AI can certify its own correctness (at that level).

## Practical takeaway

For dynamic-coding systems:
- **Accept the consistency of your trusted kernel as an axiom.**
- **Keep the trusted kernel minimal.**
- **Prove meta-properties externally** (on paper, in a stronger system).
- **Don't expect an AI or verifier to certify its own correctness.**

These are the engineering principles that come out of Gödel's theorems.

## Gödel and halting

Gödel's incompleteness and Turing's undecidability of halting are **closely related**: both are diagonal arguments over a computable enumeration of a class of objects. Each can be derived from the other with a bit of work.

Both express the same fundamental limit: **no computable / axiomatizable system is both consistent and complete for Turing-expressive content.** The two theorems are different framings of one ceiling.

## ITT relevance

When the ITT Intent Engine is formalized in Lean 4 (or any similar system), Gödel's theorems apply: the engine's correctness proofs depend on Lean's consistency, which Lean cannot prove about itself.

Practical implication: trust is layered. Trust the engine ≤ trust the proofs ≤ trust Lean ≤ trust the consistency of CIC (axiomatic). Each layer must be examined externally.

This is why formal verification — even of ITT's most ambitious framework — is a *reduction* of trust to a small axiomatic core, not an elimination of trust.
