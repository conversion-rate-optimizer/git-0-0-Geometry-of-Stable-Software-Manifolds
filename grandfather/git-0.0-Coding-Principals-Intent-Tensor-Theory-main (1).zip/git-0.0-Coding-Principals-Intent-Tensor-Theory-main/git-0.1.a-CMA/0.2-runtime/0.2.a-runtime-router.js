/**
 * 0.2.a-runtime-router.js
 * The "Bare Metal" Coordinate Navigator
 * ──────────────────────────────────────
 * GitCMA — Git Coordinate Manifold Architecture
 * Purpose: Translate HTTP Requests into Coordinate Executions
 *
 * URL /4.2.a  →  resolves  →  /4.0-space/4.2-space-social/4.2.a-live/index.html
 *
 * Created by Armstrong Knight — intent-tensor-theory.com
 * CC BY-NC 4.0
 */

const http   = require('http');
const fs     = require('fs');
const path   = require('path');
const RCL    = require('../0.0-shared/0.0.a-core-engine.js');

const CONFIG = {
  PORT:     8080,
  ROOT_DIR: path.join(__dirname, '../')
};

const server = http.createServer((req, res) => {

  // 1. Extract Coordinate from URL  →  "/4.2.a" → "4.2.a"
  let coord = req.url.replace(/^\//, '').trim();

  // Default to Project Dashboard if root
  if (!coord || coord === '') coord = '1.1';

  try {
    // 2. Resolve the Coordinate to a physical path
    const rclPath  = RCL.resolve(coord);
    const fullPath = path.join(CONFIG.ROOT_DIR, rclPath, 'index.html');

    // 3. Check Stabilization (Laplacian closure check)
    if (fs.existsSync(fullPath)) {
      res.writeHead(200, { 'Content-Type': 'text/html' });
      const stream = fs.createReadStream(fullPath);
      stream.pipe(res);
      console.log(`[RCL EXEC]  ${coord}  →  ${rclPath}`);

    } else {
      // 4. Node addressed but not yet Stabilized
      res.writeHead(404, { 'Content-Type': 'text/plain' });
      res.end(`Coordinate [${coord}] is not yet stabilized in this manifold.\nRun: sh ./0.1-ignition/startup.sh`);
      console.warn(`[RCL VOID]  ${coord}  →  ${fullPath} — not found`);
    }

  } catch (err) {
    res.writeHead(400, { 'Content-Type': 'text/plain' });
    res.end(`Invalid RCL Coordinate Syntax: ${coord}`);
    console.error(`[RCL ERR]   ${coord}  →  ${err.message}`);
  }
});

server.listen(CONFIG.PORT, () => {
  console.log('─── RCL RUNTIME ENGINE ACTIVE ────────────────────────────────');
  console.log(`Navigator listening at http://localhost:${CONFIG.PORT}`);
  console.log(`Try: /1.1  /4.2  /4.2.a`);
});
