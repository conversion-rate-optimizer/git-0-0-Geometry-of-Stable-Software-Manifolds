# The Rebuilder / Scheduler Decomposition

The design space of build systems, carved into two orthogonal choices.

## The rebuilder

Given a task $T(k)$ and the current store, the **rebuilder** decides: does $T(k)$ need to re-run?

### Rebuilder variants

1. **Dirty-bit rebuilder.**
   - Track a "dirty" flag per key; set on external modification.
   - Re-execute a task iff any of its (declared) dependencies is dirty.
   - Example: classical Make via modification-time comparison.

2. **Verifying-trace rebuilder.**
   - Record a trace of each successful build: the hashes of inputs and outputs.
   - Re-execute iff the current input hashes don't match the trace.
   - Example: Shake, Buck.

3. **Constructive-trace rebuilder.**
   - Record the *output* against the input hash; if inputs are unchanged, restore the saved output without executing.
   - Enables cross-machine caching.
   - Example: Bazel, Buck, Nix.

4. **Deep constructive trace.**
   - Like constructive, but also records dependencies' traces.
   - Enables full build graph replay from scratch given just the hashes.
   - Example: Nix's content-addressed derivations.

## The scheduler

The **scheduler** decides the **order** in which tasks run.

### Scheduler variants

1. **Topological scheduler.**
   - Works only for applicative tasks (static dependency graph).
   - Topologically sort, execute in order.
   - Simple and fast.

2. **Restarting scheduler.**
   - Execute a task; if it `need`s a stale dependency, restart the current task after updating the dependency.
   - Good for highly-dynamic graphs where suspending is expensive.
   - Example: Excel's recalc engine.

3. **Suspending scheduler.**
   - When a task blocks on a stale dependency, suspend it (coroutine-style); switch to computing the dependency; resume.
   - More efficient than restarting on complex tasks.
   - Example: Shake.

## The design grid

| System        | Rebuilder              | Scheduler    |
|---------------|------------------------|--------------|
| Make          | Dirty-bit (mtime)      | Topological  |
| Excel         | Dirty-bit              | Restarting   |
| Shake         | Verifying trace        | Suspending   |
| Bazel         | Constructive trace     | Topological  |
| Buck          | Verifying trace        | Topological  |
| Ninja         | Dirty-bit              | Topological  |
| Cloud Build   | Constructive trace     | Topological  |
| Nix           | Deep constructive      | Topological  |
| Pluto         | Verifying trace        | Suspending   |

Each cell is a legitimate design choice with real trade-offs.

## Trade-offs

| Dimension       | Dirty-bit       | Verifying     | Constructive   |
|-----------------|-----------------|---------------|----------------|
| Disk usage      | Minimal         | Small (hashes)| Large (outputs)|
| Network use     | N/A             | None          | Caches outputs |
| Cross-machine   | No              | No            | Yes            |
| Speed           | Fastest         | Fast          | Slower (IO)    |

| Dimension       | Topological   | Restarting   | Suspending     |
|-----------------|---------------|--------------|----------------|
| Task type       | Applicative   | Monadic OK   | Monadic OK     |
| Parallelism     | Easy          | Hard         | Medium         |
| Redundant work  | None          | Potentially  | None           |

## Why orthogonal

Rebuilder and scheduler are **independent** design choices. Any rebuilder × any scheduler is a valid build system. The full grid is $4 \times 3 = 12$ cells; about 9 correspond to real systems.

## Correctness by construction

**Theorem (Mokhov et al.).** *Any rebuilder satisfying the soundness property ("if rebuilder says 'clean,' the output is correct") combined with any scheduler that respects dependency order yields a correct build system.*

This is the modular correctness theorem for build systems — you can mix and match rebuilders and schedulers and still get correctness.

## Why this is in the chapter

The rebuilder/scheduler decomposition is a concrete example of how the **abstract fixed-point theory** (§1.0.c) gets specialized:
- The rebuilder is the **equality check** in `lfp`.
- The scheduler is the **iteration order**.

Different choices lead to different build systems, but they are all specialized Kleene iterations.

For the ITT multi-substrate engine: you'll need both a rebuilder (to avoid redundant re-resolutions) and a scheduler (to order substrate updates sensibly). Picking a cell in this grid is the correct engineering step.
