# 1.0.g — Self-Adjusting Computation

Change propagation as the incremental realization of fixed-point iteration.

## Files

**Math:**
- `math/00_dependency_graphs.md` — Modifiables, read/write edges, traces.
- `math/01_change_propagation.md` — The core algorithm.
- `math/02_trace_stability.md` — The Acar–Blelloch–Harper theorem.
- `math/03_incremental_as_differential.md` — Categorical derivative view.

**Code:**
- `code/thunk_sac_python.py` — Hand-rolled dependency tracker.
- `code/react_as_sac.jsx` — React's useMemo/useEffect as SAC.
- `code/jane_street_incremental.ml` — OCaml Incremental usage.
