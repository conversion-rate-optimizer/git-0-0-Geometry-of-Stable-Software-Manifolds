# Reading Order

Different backgrounds, different optimal paths through this chapter.

## For the mathematician

Read in order:

1. `1.0.b_Order_Theoretic_Preliminaries` — foundation.
2. `1.0.c_Fixed_Point_Theorems` — the three master theorems.
3. `1.0.d_Abstract_Interpretation` — first application.
4. `1.0.e_Logic_Programming_Datalog` — second application.
5. `1.0.f_SAT_SMT_Constraint_Solving` — third application.
6. `1.0.g_Self_Adjusting_Computation` — fourth application.
7. `1.0.h_Differential_Dataflow_DBSP` — fifth application.
8. `1.0.i_Answer_Set_Programming` — sixth application.
9. `1.0.j_Curry_Howard_Dependent_Types` — type theory connection.
10. `1.0.k_Build_Systems` — practical application.
11. `1.0.l_Hard_Ceilings` — the walls.
12. `1.0.m_Generic_Constraint_Engine` — formal analysis of the ITT engine.
13. `1.0.n_Multi_Substrate_Engine` — extension to product lattices.
14. `1.0.o_Synthesis_and_Frontier` — novel directions.

## For the engineer

1. `1.0.a_Overview_and_Front_Matter` — orientation.
2. `1.0.c_Fixed_Point_Theorems/code` — runnable `lfp` in every language.
3. `1.0.m_Generic_Constraint_Engine/code` — the ITT engine, typed and running.
4. `1.0.n_Multi_Substrate_Engine/code` — the multi-file-type engine.
5. `1.0.f_SAT_SMT_Constraint_Solving/code` — replace hand-rolled with Z3.
6. `1.0.g_Self_Adjusting_Computation/code` — replace with React/Incremental.
7. `1.0.h_Differential_Dataflow_DBSP/code` — replace with Materialize/Feldera.
8. `1.0.l_Hard_Ceilings/code` — what `unknown`, `timeout`, and `maxIterations` mean.
9. `1.0.o_Synthesis_and_Frontier` — cheat sheet.

## For the physicist

1. `1.0.a_Overview_and_Front_Matter` — orientation.
2. `1.0.b_Order_Theoretic_Preliminaries` — algebraic structure of state.
3. `1.0.c_Fixed_Point_Theorems` — convergence theorems (analogous to equilibria).
4. `1.0.m_Generic_Constraint_Engine` — the engine as a dynamical system.
5. `1.0.n_Multi_Substrate_Engine` — product-lattice dynamics.
6. `1.0.o_Synthesis_and_Frontier` — open questions, ITT bridge.
7. Back-fill `d` through `l` as needed.

## For the curious auto-didact

Read `1.0.a_Overview_and_Front_Matter` fully, then follow your curiosity. Each folder is self-contained enough to read on its own, with cross-references when needed.
