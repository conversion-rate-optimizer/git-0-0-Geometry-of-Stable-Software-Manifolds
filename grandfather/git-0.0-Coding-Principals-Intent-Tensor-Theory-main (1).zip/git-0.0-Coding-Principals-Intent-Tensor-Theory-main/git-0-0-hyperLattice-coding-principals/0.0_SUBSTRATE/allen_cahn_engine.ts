/**
 * 0.0_SUBSTRATE: Allen-Cahn Field Engine
 * =======================================
 * The Collapse Tension Substrate (CTS) solver.
 *
 * This is not an abstraction. It is the literal PDE:
 *   ∂Φ/∂t = η∇²Φ + μΦ³ − νΦ
 *
 * Discretized over the code lattice graph (V, W).
 * Every module in the repository is a node in this field.
 * Every dependency relationship is an edge coupling.
 *
 * The field does not "run code." It settles toward the
 * lowest-energy configuration that still satisfies the intent seed.
 * Code that cannot persist in the field does not exist.
 */

import { CTS, LATTICE, classifyPhi, type StratumLabel } from "../-Z_BASE/axioms";

export interface FieldNode {
  id: string;
  phi: number;        // Current field activation
  phi_prev: number;   // Previous step (for S calculation)
  stratum: StratumLabel;
}

export interface FieldState {
  nodes: Map<string, FieldNode>;
  t: number;          // Current iteration
  converged: boolean;
}

/**
 * Computes the graph Laplacian action on φ:
 *   (∇²_G φ)_i = Σ_j W_ij (φ_j - φ_i)
 */
export function graphLaplacian(
  nodeId: string,
  phi: Map<string, number>,
  weights: Map<string, Map<string, number>>
): number {
  const phi_i = phi.get(nodeId) ?? 0;
  const neighbors = weights.get(nodeId);
  if (!neighbors) return 0;

  let laplacian = 0;
  for (const [neighborId, w] of neighbors) {
    const phi_j = phi.get(neighborId) ?? 0;
    laplacian += w * (phi_j - phi_i);
  }
  return laplacian;
}

/**
 * Allen-Cahn phase term:
 *   f_AC(Φ) = μΦ³ − νΦ
 *
 * Equilibria: Φ = 0 (S₀) and Φ = ±√(ν/μ) ≈ ±0.540 (Φ*₊)
 *
 * STABILITY NOTE (test-verified):
 * In the single-node ODE without spatial coupling or seed forcing,
 * Φ = 0 is the STABLE attractor and Φ*₊ is an energy BARRIER.
 * For 0 < Φ < Φ*₊: field decays to S₀.
 * For Φ > Φ*₊: field diverges (requires seed forcing to saturate).
 *
 * S₂ stability (non-zero settled state) requires either:
 *   (a) The seed forcing term λ(s_i - Φ_i) — implemented in stepNode()
 *   (b) Spatial coupling through the graph Laplacian
 *
 * This is mathematically equivalent to saying S₂ requires intent.
 * A module with no seed and no neighbors decays to S₀.
 */
export function allenCahnPhase(phi: number): number {
  return CTS.mu * Math.pow(phi, 3) - CTS.nu * phi;
}

/**
 * Full single-step update for one node:
 *   Φ_i(t+1) = Φ_i(t) + dt · [η(∇²_G Φ)_i + μΦ_i³ - νΦ_i + λ(s_i - Φ_i)]
 */
export function stepNode(
  nodeId: string,
  phi: Map<string, number>,
  weights: Map<string, Map<string, number>>,
  seed: Map<string, number>,
  lambda: number = LATTICE.lambda
): number {
  const phi_i = phi.get(nodeId) ?? 0;
  const s_i = seed.get(nodeId) ?? 0;

  const laplacian = graphLaplacian(nodeId, phi, weights);
  const phase = allenCahnPhase(phi_i);
  const forcing = lambda * (s_i - phi_i);

  const dphi = CTS.eta * laplacian + phase + forcing;
  return Math.max(0, phi_i + CTS.dt * dphi);
}

/**
 * Full field evolution: run until convergence or max iterations
 *
 * Returns the settled FieldState — the equilibrium Φ* under the intent seed.
 */
export function settleField(
  nodeIds: string[],
  weights: Map<string, Map<string, number>>,
  seed: Map<string, number>,
  maxIterations: number = LATTICE.settle_iterations
): FieldState {
  // Initialize φ at S₀ ground state
  let phi = new Map<string, number>(
    nodeIds.map(id => [id, seed.get(id) ?? CTS.epsilon])
  );
  let phi_prev = new Map<string, number>(phi);

  let t = 0;
  let converged = false;

  for (t = 0; t < maxIterations; t++) {
    const phi_next = new Map<string, number>();

    for (const id of nodeIds) {
      phi_next.set(id, stepNode(id, phi, weights, seed));
    }

    // Check convergence: max |Δφ| < ε
    let maxDelta = 0;
    for (const id of nodeIds) {
      const delta = Math.abs((phi_next.get(id) ?? 0) - (phi.get(id) ?? 0));
      if (delta > maxDelta) maxDelta = delta;
    }

    phi_prev = new Map(phi);
    phi = phi_next;

    if (maxDelta < CTS.epsilon) {
      converged = true;
      break;
    }
  }

  // Build FieldState
  const nodes = new Map<string, FieldNode>();
  for (const id of nodeIds) {
    const p = phi.get(id) ?? 0;
    nodes.set(id, {
      id,
      phi: p,
      phi_prev: phi_prev.get(id) ?? 0,
      stratum: classifyPhi(p),
    });
  }

  return { nodes, t, converged };
}

/**
 * Compute total field energy:
 *   E(φ) = ½Σ_ij W_ij(φ_i - φ_j)² + [λ/2(1-λ)] Σ_i(φ_i - s_i)²
 *
 * This is what the system minimizes. Lower energy = more stable configuration.
 */
export function fieldEnergy(
  nodeIds: string[],
  phi: Map<string, number>,
  weights: Map<string, Map<string, number>>,
  seed: Map<string, number>,
  lambda: number = LATTICE.lambda
): number {
  let smoothing = 0;
  let anchoring = 0;

  for (const id of nodeIds) {
    const phi_i = phi.get(id) ?? 0;
    const s_i = seed.get(id) ?? 0;

    const neighbors = weights.get(id);
    if (neighbors) {
      for (const [nId, w] of neighbors) {
        const phi_j = phi.get(nId) ?? 0;
        smoothing += w * Math.pow(phi_i - phi_j, 2);
      }
    }

    anchoring += Math.pow(phi_i - s_i, 2);
  }

  const alpha = lambda / (2 * (1 - lambda));
  return 0.5 * smoothing + alpha * anchoring;
}
