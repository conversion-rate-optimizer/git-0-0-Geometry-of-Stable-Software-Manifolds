# Weight Constraints and Optimization

ASP with soft constraints, optimization statements, and priority levels.

## Weak constraints

A **weak constraint** is a soft version of `:- body.`:

```
:~ body. [weight@level, term_tuple]
```

Meaning: for each ground instance where `body` holds, add `weight` to the cost at priority `level`.

The solver finds stable models minimizing cost **lexicographically** — prioritizing lower cost at higher levels.

## Minimize / maximize statements

Alternative syntax:

```
#minimize { weight@level, term_tuple : body }.
#maximize { weight@level, term_tuple : body }.
```

Behaviorally equivalent to weak constraints.

## Example: weighted graph coloring

```
node(1..N). edge(X, Y) :- ...

{ color(X, 1..K) } = 1 :- node(X).
:- edge(X, Y), color(X, C), color(Y, C).

% Prefer to use fewer colors
used(C) :- color(_, C).
#minimize { 1, C : used(C) }.
```

The solver finds the coloring using the minimum number of colors.

## Multi-level priorities

```
#minimize { 1@3 : used(color_red) }.   % priority 3: avoid red
#minimize { 1@2 : overflow_node }.     % priority 2: avoid overflow
#minimize { 1@1 : large_chromatic_num }. % priority 1: keep chromatic number small
```

Level-3 constraints dominate level-2 constraints, which dominate level-1 constraints. Ties at each level are broken by the next level down.

This is **lexicographic multi-criteria optimization**.

## Cardinality and weight constraints in rule bodies

```
% Committee selection: choose exactly 5 members
5 { member(P) : candidate(P) } 5.

% At least 2 of x,y,z must be true
2 { x ; y ; z }.

% Weighted sum constraint
10 <= #sum { salary(P) : member(P), experienced(P) } <= 100.
```

These are mathematically equivalent to pseudo-Boolean constraints. Solvers compile them to SAT-friendly forms internally.

## Equivalence to WCSP and MaxSAT

ASP with weak constraints is **equivalent in expressive power** to Weighted CSP and Partial Weighted MaxSAT:
- Every WCSP can be encoded as ASP with weak constraints.
- Every ASP optimization problem can be encoded as a MaxSAT instance.

The conversion is polynomial but lossy in practical efficiency — each tool has strengths for different problem classes.

## The link to your engine

Your ITT Intent Engine's **priority system** is literally the multi-level weak-constraint mechanism:

```
% High-priority constraint: blocked → not sent
:~ blocked, sent. [100@2]

% Lower-priority constraint: eligible → sent
:~ eligible, not sent. [10@1]
```

This encoding gives you:
- Coherent resolution via stable-model semantics.
- Lexicographic priority handling.
- Optimization built in.
- Free SAT-solver-grade performance.

For any serious deployment beyond the hand-rolled Kleene loop, this is the natural backend.

## clingo API summary

```python
import clingo
ctl = clingo.Control()
ctl.add("base", [], program_text)
ctl.ground([("base", [])])
with ctl.solve(yield_=True) as handle:
    for model in handle:
        print(model.symbols(atoms=True), model.cost)
```

Solutions arrive sorted by cost (lexicographic). You iterate through as many as you want.
