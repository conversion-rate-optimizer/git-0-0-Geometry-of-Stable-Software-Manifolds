// TypeScript lattice interface and classes.
//
// `x: A` is the colon-form of Haskell's `x :: A`, of mathematics's `x ∈ A`.
// The `interface` is the TypeScript encoding of a typeclass / protocol.

export interface Lattice<A> {
  bottom(): A;
  top(): A;
  join(x: A, y: A): A;
  meet(x: A, y: A): A;
  leq(x: A, y: A): boolean;
}

// Example 1: Boolean lattice
export class BoolLattice implements Lattice<boolean> {
  bottom() { return false; }
  top()    { return true;  }
  join(x: boolean, y: boolean) { return x || y; }
  meet(x: boolean, y: boolean) { return x && y; }
  leq(x: boolean, y: boolean)  { return !x || y; }
}

// Example 2: Set under inclusion (unbounded — no top)
export class SetLattice<A> implements Lattice<ReadonlySet<A>> {
  bottom() { return new Set<A>(); }
  top(): ReadonlySet<A> { throw new Error("Unbounded set: no top"); }
  join(x: ReadonlySet<A>, y: ReadonlySet<A>): ReadonlySet<A> {
    return new Set([...x, ...y]);
  }
  meet(x: ReadonlySet<A>, y: ReadonlySet<A>): ReadonlySet<A> {
    return new Set([...x].filter(e => y.has(e)));
  }
  leq(x: ReadonlySet<A>, y: ReadonlySet<A>): boolean {
    return [...x].every(e => y.has(e));
  }
}

// Example 3: Flat domain
export type Flat<A> = { kind: "bot" } | { kind: "val", value: A } | { kind: "top" };

export class FlatLattice<A> implements Lattice<Flat<A>> {
  bottom(): Flat<A> { return { kind: "bot" }; }
  top(): Flat<A>    { return { kind: "top" }; }
  join(x: Flat<A>, y: Flat<A>): Flat<A> {
    if (x.kind === "bot") return y;
    if (y.kind === "bot") return x;
    if (x.kind === "top" || y.kind === "top") return { kind: "top" };
    return x.value === y.value ? x : { kind: "top" };
  }
  meet(x: Flat<A>, y: Flat<A>): Flat<A> {
    if (x.kind === "top") return y;
    if (y.kind === "top") return x;
    if (x.kind === "bot" || y.kind === "bot") return { kind: "bot" };
    return x.value === y.value ? x : { kind: "bot" };
  }
  leq(x: Flat<A>, y: Flat<A>): boolean {
    if (x.kind === "bot") return true;
    if (y.kind === "top") return true;
    if (x.kind === "val" && y.kind === "val") return x.value === y.value;
    return false;
  }
}

/**
 * Kleene iteration (universal lfp).
 * Iterates f from start until a fixed point is reached.
 * Throws if maxIter is exceeded — the "conflicting intents" case.
 */
export function lfp<A>(
  f: (x: A) => A,
  start: A,
  equals: (a: A, b: A) => boolean,
  maxIter: number = 10000
): A {
  let x = start;
  for (let i = 0; i < maxIter; i++) {
    const xNext = f(x);
    if (equals(x, xNext)) return x;
    x = xNext;
  }
  throw new Error(
    `No fixed point reached after ${maxIter} iterations — ` +
    `operator may not be monotone.`
  );
}

// Convenience: deep-equal via JSON for simple state objects.
export const deepEqual = <A>(a: A, b: A): boolean =>
  JSON.stringify(a) === JSON.stringify(b);
