# 1.0.z — Full Papers

The two long-form research papers that accompany Chapter 1. These are self-contained and can be read independently of the rest of the chapter, though they reference the math modules by section number.

## Files

### `fixed_point_semantics_of_dynamic_computation.md`
The foundational mathematics paper. Surveys the theoretical landscape of dynamic/constraint-based computation with rigorous theorem/proof structure. Grounded in order theory, lattice theory, and computability.

**Scope.**
- Order-theoretic preliminaries (posets, lattices, Scott-continuity).
- Fixed-point theorems (Knaster–Tarski, Kleene, Banach) with full proofs.
- Abstract interpretation (Cousot–Cousot soundness via Galois connections).
- Datalog semantics (van Emden–Kowalski minimal-model theorem).
- SAT/SMT complexity (Cook–Levin, Nelson–Oppen).
- Self-adjusting computation (Acar–Blelloch–Harper trace stability).
- DBSP calculus (integration / differentiation identities).
- ASP stable-model semantics (Gelfond–Lifschitz reduct).
- Curry–Howard correspondence and dependent type theory.
- The cosmic ceilings (halting, Rice, Gödel, time hierarchy).

**Intended audience.** Readers wanting the mathematical backbone in one place, with attributions and proofs rather than scattered across Chapter 1's section-by-section treatment.

### `equations_to_executable_code.md`
The companion engineering paper. Translates every equation from the first paper into concrete runnable code, showing exactly where each theorem manifests as a programming construct.

**Scope.**
- Each fixed-point theorem → its iteration loop.
- Each Galois connection → its abstract-interpretation pair.
- Each Datalog rule → its semi-naive implementation.
- Each SMT theory → its Z3 / cvc5 call.
- Each SAC principle → its React / Incremental / Adapton usage.
- Each DBSP operator → its Materialize / Feldera SQL.
- Each ASP rule → its clingo encoding.
- Each dependent type → its Lean 4 / Idris syntax.
- Each cosmic ceiling → its `maxIter` / `timeout` / `unknown` in production code.

**Intended audience.** Readers building real engines who want to see precisely which library call corresponds to which theorem — the "what you literally type" end of the spectrum.

## Reading order

- **Math-first readers:** Start with `fixed_point_semantics_of_dynamic_computation.md`, then skim `equations_to_executable_code.md` for implementation references.
- **Engineering-first readers:** Start with `equations_to_executable_code.md`, following its pointers back into the math paper when a theorem's justification is needed.
- **Chapter 1 readers:** These papers are the long-form synthesis of what the `1.0.a`–`1.0.o` folders cover in modular form. Either direction (papers → modules or modules → papers) works.

## Relationship to the rest of Chapter 1

The modular folders (`1.0.a`–`1.0.o`) are the *textbook* version: short files, focused topics, with both `math/` and `code/` subfolders. The two papers here are the *monograph* version: continuous prose, explicit theorem/proof structure, narrative flow across topics.

Content is redundant by design. The papers were written first, during the research phase; the folders are the decomposition for navigability and targeted lookup. Both representations are authoritative.

## Citation

If citing this work:

> Knight, A. (Sensei Intent Tensor). *Intent Tensor Theory: Coding Principles, Chapter 1 — Fixed-Point Semantics of Dynamic Computation and Its Translation to Executable Code.* GitLab: intent-tensor-theory.com-group/git-0.0-Coding-Principals-Intent-Tensor-Theory, 2026. ORCID: 0009-0004-8153-8335.
