# Syllabus — Ghostless Infrastructure & Dynamic Manifolds

## Course description
This text treats software repositories as constrained manifolds where coordinates, not folder prose, provide primary identity.

## Module sequence
- M1: Locked lattice naming and coordinate invariance
- M2: Genesis manifest and topological constraints
- M3: Resonance registry and index-to-index communication
- M4: Selection gate (`S_sel >= 1`) and viability enforcement
- M5: Experimental bloom diagnostics (`Q(t)`) and residue analysis

## Assessment rubric
- Correctness of coordinate-first naming
- Explicitness of manifest semantics (no vague verbs)
- Reproducibility of experiment logs
- Ability to explain failure-to-bloom cases
