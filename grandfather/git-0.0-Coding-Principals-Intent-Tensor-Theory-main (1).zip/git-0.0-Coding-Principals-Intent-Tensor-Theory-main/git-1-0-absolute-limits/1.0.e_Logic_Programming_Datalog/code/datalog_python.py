"""
A working Datalog engine in Python, using semi-naive evaluation.

Supports positive Horn clauses over constants and variables.
Uses a simple unification algorithm.
"""

from __future__ import annotations
from typing import Tuple, List, Dict, Iterator, FrozenSet, Optional
from dataclasses import dataclass

# -------------------------------------------------------------
# Data model: atoms and rules
# -------------------------------------------------------------

# An atom is a tuple: (predicate_name, arg1, arg2, ...).
# Variables are strings starting with an uppercase letter.
# Constants are anything else (strings starting with lowercase, ints, etc.).

Atom = Tuple
Rule = Tuple[Atom, Tuple[Atom, ...]]  # (head, body)


def is_var(t) -> bool:
    return isinstance(t, str) and t and t[0].isupper()


# -------------------------------------------------------------
# Unification
# -------------------------------------------------------------

def unify(pattern: Atom, fact: Atom, sigma: Dict[str, object]) -> Optional[Dict[str, object]]:
    """Return σ extended so that pattern·σ = fact, or None if not unifiable."""
    if pattern[0] != fact[0] or len(pattern) != len(fact):
        return None
    new_sigma = dict(sigma)
    for p, f in zip(pattern[1:], fact[1:]):
        if is_var(p):
            if p in new_sigma:
                if new_sigma[p] != f:
                    return None
            else:
                new_sigma[p] = f
        else:
            if p != f:
                return None
    return new_sigma


def apply(atom: Atom, sigma: Dict[str, object]) -> Atom:
    return (atom[0],) + tuple(sigma.get(t, t) for t in atom[1:])


# -------------------------------------------------------------
# Immediate consequence operator T_P
# -------------------------------------------------------------

def t_p(rules: List[Rule], facts: FrozenSet[Atom]) -> FrozenSet[Atom]:
    new_facts = set(facts)
    for head, body in rules:
        for sigma in _bindings(body, facts):
            new_facts.add(apply(head, sigma))
    return frozenset(new_facts)


def _bindings(body: Tuple[Atom, ...], facts: FrozenSet[Atom],
              sigma: Optional[Dict[str, object]] = None
              ) -> Iterator[Dict[str, object]]:
    """All substitutions σ such that body·σ ⊆ facts."""
    if sigma is None:
        sigma = {}
    if not body:
        yield sigma
        return
    head_atom, *rest = body
    for fact in facts:
        extended = unify(head_atom, fact, sigma)
        if extended is not None:
            yield from _bindings(tuple(rest), facts, extended)


# -------------------------------------------------------------
# Naive evaluator (reference implementation)
# -------------------------------------------------------------

def evaluate_naive(rules: List[Rule], initial_facts: FrozenSet[Atom],
                   max_iter: int = 10000) -> FrozenSet[Atom]:
    facts = initial_facts
    for _ in range(max_iter):
        new_facts = t_p(rules, facts)
        if new_facts == facts:
            return facts
        facts = new_facts
    raise RuntimeError("Datalog did not converge (should not happen).")


# -------------------------------------------------------------
# Semi-naive evaluator
# -------------------------------------------------------------

def evaluate_semi_naive(rules: List[Rule], initial_facts: FrozenSet[Atom]
                        ) -> FrozenSet[Atom]:
    """
    Fire only rules whose body uses at least one new (delta) atom.
    """
    i = initial_facts
    delta = i
    while delta:
        new_delta = set()
        for head, body in rules:
            for k, _ in enumerate(body):
                # Delta rule: body with k-th position required to be in delta
                for sigma in _bindings_with_delta(body, i, delta, k):
                    derived = apply(head, sigma)
                    if derived not in i:
                        new_delta.add(derived)
        delta = frozenset(new_delta) - i
        i = i | delta
    return i


def _bindings_with_delta(body, facts, delta, delta_pos, sigma=None, pos=0):
    if sigma is None:
        sigma = {}
    if pos == len(body):
        yield sigma
        return
    source = delta if pos == delta_pos else facts
    for fact in source:
        extended = unify(body[pos], fact, sigma)
        if extended is not None:
            yield from _bindings_with_delta(body, facts, delta, delta_pos,
                                             extended, pos + 1)


# -------------------------------------------------------------
# Demo: transitive closure
# -------------------------------------------------------------

if __name__ == "__main__":
    # Rules:
    #   path(X, Y) :- edge(X, Y).
    #   path(X, Y) :- edge(X, Z), path(Z, Y).
    rules: List[Rule] = [
        (("path", "X", "Y"), (("edge", "X", "Y"),)),
        (("path", "X", "Y"), (("edge", "X", "Z"), ("path", "Z", "Y"))),
    ]
    edges = frozenset([
        ("edge", 1, 2),
        ("edge", 2, 3),
        ("edge", 3, 4),
        ("edge", 4, 5),
    ])

    # Naive
    result_naive = evaluate_naive(rules, edges)
    paths = sorted(f for f in result_naive if f[0] == "path")
    print(f"Naive:       {len(paths)} paths")
    for p in paths:
        print(f"  path({p[1]}, {p[2]})")

    # Semi-naive
    result_semi = evaluate_semi_naive(rules, edges)
    assert result_naive == result_semi
    print(f"Semi-naive:  {len([f for f in result_semi if f[0] == 'path'])} paths (match)")
