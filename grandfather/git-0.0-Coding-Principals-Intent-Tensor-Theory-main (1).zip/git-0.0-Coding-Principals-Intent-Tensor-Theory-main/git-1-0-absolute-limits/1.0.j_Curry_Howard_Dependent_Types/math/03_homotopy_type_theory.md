# Homotopy Type Theory (HoTT)

The most advanced reformulation of type theory, connecting types to ∞-groupoids.

## The new principle: univalence

In ordinary mathematics, isomorphic structures are "essentially the same" but not *literally* equal. In standard type theory, the same holds: `A = B` (identity type) is stronger than `A ≃ B` (equivalence type).

**Univalence axiom (Voevodsky).**
$$
(A =_{\text{Type}} B) \;\simeq\; (A \simeq B).
$$

Identification of types is equivalent to equivalence of types. Under univalence, "equal up to isomorphism" becomes literal equality.

## Higher inductive types

HoTT adds **higher inductive types (HITs)**, which can include path constructors (equalities in the identity type):

```
inductive Circle where
  | base : Circle
  | loop : base = base
```

The circle has one point and one non-trivial loop — a type with non-trivial homotopy.

## The cubical refinement

**Cubical type theory** (Cohen, Coquand, Huber, Mörtberg 2018) gives univalence a **computational interpretation**:
- Paths are replaced by cube maps.
- Composition, transport, and univalence all reduce.

This solves the long-standing problem of "how to compute with univalence" and underlies Cubical Agda.

## Consequences

- **Mathematics of equivalences** becomes part of the foundational language.
- **∞-groupoid structure** is natively encoded in types.
- **Patch theory, versioning, configuration** problems admit elegant formalizations.

## Status

HoTT is a rapidly developing research area. Cubical Agda and agda-flat implement cubical HoTT directly. Lean 4 has experimental HoTT libraries. Rocq has HoTT extensions.

For dynamic-coding systems, HoTT is currently exotic but worth watching — it may become the right foundation for reasoning about **configuration equivalence**, **code transformation correctness**, and **versioned-data equivalences**.

## Bridge to the ITT engine

Configuration equivalence is a natural problem for any engine operating across multiple substrates with overlapping state. Two configurations might differ structurally but be equivalent in all observable ways — classical type theory cannot express this well, but HoTT can:

```
-- In HoTT:
equivalent : (c1 c2 : Config) -> c1 ≃ c2 -> c1 = c2
```

If the multi-substrate engine of `1.0.n` is formalized in HoTT, the "two substrates agree" relation becomes a first-class equivalence, and the soundness of cross-substrate propagation reduces to a type-checkable proof.

This is speculative but aligned with the direction of modern type theory.
