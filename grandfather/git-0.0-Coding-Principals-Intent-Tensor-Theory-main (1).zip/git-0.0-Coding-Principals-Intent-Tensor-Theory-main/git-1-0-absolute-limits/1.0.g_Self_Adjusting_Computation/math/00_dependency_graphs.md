# Dependency Graphs and Modifiables

The data structure that makes self-adjusting computation possible.

## Modifiables

A **modifiable** is a reference cell whose reads and writes are tracked by the runtime.

$$
\text{Mod}\,\alpha \;=\; \text{a tracked reference storing a value of type } \alpha.
$$

Operations:
- `put : α → Mod α` — create a new modifiable with initial value.
- `read : Mod α → (α → β) → Mod β` — read a modifiable in a computation that produces another modifiable.
- `write : Mod α → α → unit` — set a new value (tracked for change propagation).

## Execution traces

When a self-adjusting computation executes, the runtime records a **trace**:
- Every `read` edge $(m, n)$: computation node $n$ reads modifiable $m$.
- Every `write` edge $(n, m)$: computation node $n$ writes modifiable $m$.
- Order of executions.

The trace forms a DAG: nodes are computation invocations and modifiables; edges are read/write dependencies.

## Formal model

Let $V$ = set of computation nodes, $M$ = set of modifiables.
- **Reads relation:** $R \subseteq V \times M$.
- **Writes relation:** $W \subseteq V \times M$ (a partial function — each node writes at most one modifiable).
- **Execution order:** a linear extension $\prec$ of the transitive closure of $R \cup W^{-1}$.

A trace $T = (V, M, R, W, \prec)$ records the full execution history of a self-adjusting computation.

## Dependency graph

From the trace, the **dependency graph** is:
- Nodes: modifiables.
- Edge $m \to m'$ if some computation node $n$ reads $m$ and writes $m'$.

This is the DAG that change propagation traverses.

## Memoization

Self-adjusting runtimes additionally memoize computation nodes:
- When a node is about to re-execute, check if its inputs (reads) are unchanged.
- If yes, skip re-execution and reuse the cached output.

This generalizes simple memoization to *structural* reuse: a sub-trace with unchanged inputs is reused whole.

## Example

Computation: `z = x + y`.
- $M = \{m_x, m_y, m_z\}$.
- $V = \{n_{add}\}$.
- $R = \{(n_{add}, m_x), (n_{add}, m_y)\}$.
- $W = \{(n_{add}, m_z)\}$.

Dependency graph: $m_x \to m_z, m_y \to m_z$.

When $m_x$ changes, the runtime invalidates $n_{add}$, re-executes it (reading the new $m_x$ and the old $m_y$), and updates $m_z$.

## Practical implementation notes

- **Dirty-bit flavor:** mark modifiables as dirty; re-execute nodes reading dirty modifiables.
- **Ordered trace flavor:** maintain linear time stamps; replay the trace forward, checking each node.
- **Demand-driven (Adapton):** nodes are marked dirty on write but re-executed only when observed.

Each flavor has trade-offs in eager vs. lazy re-execution, memory footprint, and responsiveness to external observers.

See `02_trace_stability.md` for the theorem that bounds the cost of these operations.
