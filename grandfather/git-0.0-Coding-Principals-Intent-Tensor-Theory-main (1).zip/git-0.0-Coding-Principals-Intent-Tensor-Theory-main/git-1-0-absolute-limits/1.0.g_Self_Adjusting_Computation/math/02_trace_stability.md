# Trace Stability

The Acar–Blelloch–Harper theorem bounding the cost of change propagation.

## Definition

Given a self-adjusting computation $C$ and two inputs $x, x'$, the **trace distance** $d(T(x), T(x'))$ is the minimum number of insertions and deletions of computation-node invocations needed to transform $T(x)$ into $T(x')$.

A self-adjusting program is **trace-stable** iff there is a constant $c$ such that

$$
d(T(x), T(x')) \leq c \cdot |x \ominus x'|
$$

where $|x \ominus x'|$ is the edit distance between input $x$ and $x'$.

In words: small input changes produce small trace changes.

## The theorem

**Theorem (Acar–Blelloch–Harper, 2002).** *If a self-adjusting program is trace-stable, then change propagation runs in time*

$$
O(d(T(x), T(x')) \cdot \text{polylog}(|T(x)|))
$$

*— asymptotically proportional to the trace distance, up to polylogarithmic overhead.*

## Consequences

For a variety of algorithms, the theorem gives **optimal** incremental-update times:

| Algorithm                    | Full recomputation | Trace-stable SAC update |
|------------------------------|---------------------|-------------------------|
| List sorting (insertion)     | $O(n \log n)$       | $O(\log n)$             |
| List map (element change)    | $O(n)$              | $O(1)$                  |
| List reduce (tree)           | $O(n)$              | $O(\log n)$             |
| Convex hull (point insertion)| $O(n \log n)$       | $O(\log^2 n)$           |
| Minimum spanning tree        | $O(m \log n)$       | $O(\log n)$ per edge    |
| Voronoi diagram (point ins.) | $O(n \log n)$       | $O(\log n)$             |

These match or beat the best problem-specific incremental algorithms in the literature — obtained *for free* by making the static algorithm self-adjusting.

## Programming techniques for stability

Not all programs are trace-stable. Making them stable requires:

1. **Tree-shaped reductions** instead of linear. Linear `reduce` has trace distance $\Omega(n)$ on an element change; tree `reduce` has $O(\log n)$.
2. **Persistent data structures** to avoid sharing-induced instability.
3. **Explicit memoization barriers** to control where re-use is attempted.

## Why not always trace-stable?

Some algorithms are fundamentally unstable: any input change cascades through the whole trace. Example: a computation that sorts the input and uses the sort permutation in its downstream logic — a single swap at the input can re-order everything.

For such algorithms, SAC gives no asymptotic benefit over full recomputation.

## Practical takeaway

The theorem is a *guide* for algorithm design: if you want fast incremental updates, design your computation to be trace-stable. Tools like Jane Street's `Incremental` let you write naturally-stable code in the combinator style.

If you cannot make your computation trace-stable, SAC is the wrong tool — look instead at problem-specific incremental algorithms (kinetic data structures, persistent structures, CRDT-based systems).

## Connection to your engine

The ITT Intent Engine is naturally trace-stable: most intent changes touch only a few variables, and the propagation graph is small. Making the engine React-style self-adjusting (as shown in the paper `1.0.z_Full_Papers/equations_to_executable_code.md` §7) gives you efficient incremental resolution essentially for free.
