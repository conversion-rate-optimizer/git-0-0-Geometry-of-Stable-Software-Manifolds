/**
 * -X_AUDIT: Stability Basin
 * ==========================
 * Maps the basin of attraction — which seeds produce stable structures
 * and which dissipate. Identifies the boundary between S₁b and S₂.
 *
 * Run this to answer: "given this graph, what seeds actually work?"
 */

import { diffuseToEquilibrium } from "../0.1_LATTICE/field_diffuser";
import { computeQ } from "../+Z_APEX/bloom_engine";
import { SELECTION } from "../-Z_BASE/axioms";

export interface BasinProbe {
  seedNodeId: string;
  seedValue: number;
  finalMaxPhi: number;
  Q: number;
  bloomed: boolean;
  converged: boolean;
  steps: number;
}

/**
 * Probe a single seed to see if it produces a stable structure.
 */
export function probeSeed(
  seedNodeId: string,
  seedValue: number,
  allNodeIds: string[],
  W: Map<string, Map<string, number>>
): BasinProbe {
  const seed = new Map<string, number>(
    allNodeIds.map(id => [id, id === seedNodeId ? seedValue : 0])
  );

  const { phi, steps, converged } = diffuseToEquilibrium(seed, W);
  const metrics = computeQ(allNodeIds, phi, W);

  const finalMaxPhi = Math.max(...Array.from(phi.values()));

  return {
    seedNodeId,
    seedValue,
    finalMaxPhi,
    Q: metrics.Q,
    bloomed: metrics.isBloom,
    converged,
    steps,
  };
}

/**
 * Map the stability basin across all nodes at a given seed value.
 * Returns which nodes, when seeded, produce stable (blooming) fields.
 */
export function mapStabilityBasin(
  nodeIds: string[],
  W: Map<string, Map<string, number>>,
  seedValue: number = 1.0
): {
  stable: string[];
  unstable: string[];
  probes: BasinProbe[];
} {
  const probes = nodeIds.map(id => probeSeed(id, seedValue, nodeIds, W));
  const stable = probes.filter(p => p.bloomed).map(p => p.seedNodeId);
  const unstable = probes.filter(p => !p.bloomed).map(p => p.seedNodeId);

  return { stable, unstable, probes };
}

/**
 * Find the minimum seed value that produces a bloom for a given node.
 * Binary search between 0 and maxSeed.
 */
export function findBloomThreshold(
  seedNodeId: string,
  nodeIds: string[],
  W: Map<string, Map<string, number>>,
  maxSeed: number = 2.0,
  precision: number = 0.05
): number {
  let lo = 0;
  let hi = maxSeed;

  while (hi - lo > precision) {
    const mid = (lo + hi) / 2;
    const probe = probeSeed(seedNodeId, mid, nodeIds, W);
    if (probe.bloomed) hi = mid;
    else lo = mid;
  }

  return (lo + hi) / 2;
}
