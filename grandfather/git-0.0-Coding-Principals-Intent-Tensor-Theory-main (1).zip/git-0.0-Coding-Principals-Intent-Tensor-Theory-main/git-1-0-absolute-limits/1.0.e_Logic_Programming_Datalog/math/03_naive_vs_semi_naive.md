# Naive vs. Semi-Naive Evaluation

How to compute $\operatorname{lfp}(T_P)$ efficiently.

## Naive evaluation

Direct application of Kleene:

```
I_0 := ∅
repeat
    I_{n+1} := T_P(I_n)
until I_{n+1} = I_n
return I_n
```

**Cost analysis.** Each iteration recomputes $T_P$ entirely. For a rule with $k$ body atoms over a database of $n$ tuples, $T_P$ evaluation costs $O(n^k)$. With $d$ iterations, total cost is $O(d \cdot n^k)$.

Crucially, each iteration re-derives all previously derived atoms. This is wasteful.

## The semi-naive insight

**Observation.** If atom $a$ was derivable at iteration $n$ (i.e., $a \in T_P(I_{n-1})$), and nothing has been added to the body of the derivation, then $a$ is still derivable at iteration $n+1$ via the same derivation. We don't need to re-derive it.

**New atoms at iteration $n+1$** must use at least one atom from $\Delta_n := I_n \setminus I_{n-1}$ in their body — otherwise they would have been derivable at iteration $n$.

## Semi-naive algorithm

```
I_0 := ∅
Δ_1 := T_P(∅)                              // all immediate facts
I_1 := Δ_1
n := 1
while Δ_n ≠ ∅ do
    Δ_{n+1} := T_P^Δ(I_n, Δ_n) ∖ I_n      // new atoms using Δ_n
    I_{n+1} := I_n ∪ Δ_{n+1}
    n := n + 1
return I_n
```

where $T_P^\Delta(I, \Delta)$ fires a rule only when at least one body atom is in $\Delta$.

## Delta-rule transformation

For each rule with $k$ body atoms:

$$
h(\bar x) \leftarrow b_1(\bar y_1) \wedge \cdots \wedge b_k(\bar y_k)
$$

create $k$ **delta rules**:

$$
\Delta h(\bar x) \leftarrow b_1(\bar y_1) \wedge \cdots \wedge b_{i-1}(\bar y_{i-1}) \wedge \Delta b_i(\bar y_i) \wedge b_{i+1}(\bar y_{i+1}) \wedge \cdots \wedge b_k(\bar y_k)
$$

for $i = 1, \ldots, k$. Each delta rule fires when exactly one body atom is in $\Delta$ and the rest are in the full $I$.

The union of all delta rules gives $T_P^\Delta$.

## Cost analysis

Semi-naive evaluation's total work is $O(|P| \cdot |M_P| \cdot n^{k-1})$, where $|M_P|$ is the final model size. This is **optimal** up to constants: you must at least touch every derivable atom once.

## Connection to differential dataflow

Semi-naive evaluation is the *prototype* of differential computation:
- Track deltas ($\Delta$) instead of full state.
- Recompute only what depends on the delta.

Differential dataflow (see `1.0.h`) generalizes this to arbitrary streams of arbitrary deltas, not just the "adding one iteration's worth" case of semi-naive.

**The fundamental correspondence:**
- Naive evaluation ↔ full recomputation.
- Semi-naive evaluation ↔ incremental recomputation with natural deltas.
- Differential dataflow ↔ incremental recomputation with arbitrary deltas.

## Example: transitive closure

Program:
```
path(X, Y) :- edge(X, Y).
path(X, Y) :- edge(X, Z), path(Z, Y).
```

Database: $\text{edge} = \{(1,2), (2,3), (3,4)\}$.

**Naive:**
- $I_1 = \{(1,2), (2,3), (3,4)\}$ (edge facts).
- $I_2 = I_1 \cup \{\text{path}(1,2), \text{path}(2,3), \text{path}(3,4)\}$ (path from edge).
- $I_3 = I_2 \cup \{\text{path}(1,3), \text{path}(2,4)\}$ (path from path + edge).
- $I_4 = I_3 \cup \{\text{path}(1,4)\}$.
- $I_5 = I_4$. Done.

**Semi-naive:**
- $\Delta_1 = \{(1,2), (2,3), (3,4)\}$.
- $\Delta_2 = \{\text{path}(1,2), \text{path}(2,3), \text{path}(3,4)\}$.
- $\Delta_3 = \{\text{path}(1,3), \text{path}(2,4)\}$ (fires delta rule with $\Delta$path).
- $\Delta_4 = \{\text{path}(1,4)\}$.
- $\Delta_5 = \emptyset$. Done.

Same final answer, but at each iteration we only considered "new" atoms, saving work on large databases.

## In practice

Every serious Datalog engine (Soufflé, LogicBlox, Datafrog, Crepe, DDlog) uses semi-naive evaluation. Most additionally:
- Use **stratification** to separate strata with negation.
- Use **magic sets** to push query-specific constraints into the evaluation.
- Use **indexes** to speed up joins in body evaluation.

These engineering optimizations are orthogonal to the fundamental semi-naive idea, which is the core algorithmic improvement over naive Kleene iteration.
