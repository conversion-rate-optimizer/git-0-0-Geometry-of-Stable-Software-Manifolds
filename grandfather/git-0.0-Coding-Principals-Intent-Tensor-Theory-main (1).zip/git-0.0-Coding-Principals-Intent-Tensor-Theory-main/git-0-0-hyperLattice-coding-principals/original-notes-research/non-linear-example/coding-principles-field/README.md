# coding-principles-field

This directory is the first operational field-journal for GitCMA/ITT experiments.

## Goal
Validate the selection-law claim in execution (not abstraction):

`S_sel = R / (Rdot * t_ref) >= 1`

and track bloom behavior by monitoring `Q(t)`.

## Layout

- `experiments/exp_001_min_field.py` — 5-node minimum viable emergence loop.
- `experiments/exp_002_entropy_fix.py` — denominator comparison using entropy-augmented `S_free`.
- `logs/Q_curves.json` — Q trajectories written by experiments.
- `logs/S_sel_curves.json` — persistence trajectories written by experiments.
- `notes/what_failed.md` — failure diary.
- `notes/what_stabilized.md` — stabilization diary.

## Run

```bash
python3 coding-principles-field/experiments/exp_001_min_field.py
python3 coding-principles-field/experiments/exp_002_entropy_fix.py
```

## Bloom pass condition

At minimum, `exp_001_min_field.py` should report a non-null `bloom_iteration` (`Q > 1`).
