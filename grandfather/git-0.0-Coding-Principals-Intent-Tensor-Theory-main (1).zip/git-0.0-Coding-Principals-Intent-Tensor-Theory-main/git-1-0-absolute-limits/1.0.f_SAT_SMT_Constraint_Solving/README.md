# 1.0.f — SAT, SMT, and Constraint Solving

The search-based frontier: DPLL, CDCL, DPLL(T), Nelson–Oppen, MaxSAT.

## Files

**Math:**
- `math/00_propositional_sat.md` — SAT, CNF, Cook–Levin.
- `math/01_dpll_and_cdcl.md` — The search algorithms.
- `math/02_smt_theories.md` — SMT theories and DPLL(T).
- `math/03_nelson_oppen.md` — Theory combination.
- `math/04_maxsat_weighted_csp.md` — Soft constraints and priorities.

**Code:**
- `code/z3_python.py` — SMT via Z3's Python API.
- `code/pysat_demo.py` — Pure-SAT via python-sat (CDCL internals).
- `code/cvc5_example.py` — cvc5 alternative.
- `code/intent_engine_as_smt.py` — Your engine encoded as an SMT problem.
