/**
 * +Y_FORWARD: Routing Logic
 * ==========================
 * D_eff(A, B) = D₀ / (1 + Ψ_A · Ψ_B) → 0 at resonance
 *
 * Intent flows toward lowest effective distance.
 * This replaces file-path routing with field-based routing.
 */

import { cosineSimilarity, type IntentVector } from "../0.1_LATTICE/weight_matrix";
import { LATTICE } from "../-Z_BASE/axioms";

/**
 * Effective distance between two modules.
 * Collapses to 0 when Ψ_A · Ψ_B = 1 (perfect resonance).
 */
export function effectiveDistance(
  psiA: IntentVector,
  psiB: IntentVector,
  D0: number = 1.0
): number {
  return D0 / (1 + cosineSimilarity(psiA, psiB));
}

/**
 * Route a query vector to the closest module in a registry.
 * Returns the module ID with lowest D_eff.
 */
export function routeToNearest(
  query: IntentVector,
  registry: Map<string, IntentVector>
): { id: string; distance: number } | null {
  let best: { id: string; distance: number } | null = null;

  for (const [id, psi] of registry) {
    const d = effectiveDistance(query, psi);
    if (!best || d < best.distance) {
      best = { id, distance: d };
    }
  }

  return best;
}

/**
 * Find all modules within a resonance radius.
 * Modules with D_eff < radius are "reachable" from the query.
 */
export function reachableModules(
  query: IntentVector,
  registry: Map<string, IntentVector>,
  radius: number = 0.5
): Array<{ id: string; distance: number }> {
  const results: Array<{ id: string; distance: number }> = [];

  for (const [id, psi] of registry) {
    const d = effectiveDistance(query, psi);
    if (d < radius) results.push({ id, distance: d });
  }

  return results.sort((a, b) => a.distance - b.distance);
}

/**
 * Collapse path: sequence of modules from seed to target
 * via minimum D_eff routing. Greedy hop-by-hop.
 */
export function collapsePath(
  seedId: string,
  targetId: string,
  registry: Map<string, IntentVector>,
  maxHops: number = 10
): string[] {
  const path = [seedId];
  const visited = new Set([seedId]);
  const target = registry.get(targetId);
  if (!target) return path;

  let current = seedId;

  for (let hop = 0; hop < maxHops; hop++) {
    if (current === targetId) break;

    const currentPsi = registry.get(current);
    if (!currentPsi) break;

    let bestNext: { id: string; distance: number } | null = null;

    for (const [id, psi] of registry) {
      if (visited.has(id)) continue;
      const d = effectiveDistance(psi, target);
      if (!bestNext || d < bestNext.distance) {
        bestNext = { id, distance: d };
      }
    }

    if (!bestNext) break;
    path.push(bestNext.id);
    visited.add(bestNext.id);
    current = bestNext.id;
  }

  return path;
}
