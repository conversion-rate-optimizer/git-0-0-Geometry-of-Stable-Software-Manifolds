# Nelson–Oppen Theory Combination

The theorem that makes multi-theory SMT possible.

## The problem

Real constraints mix theories:

$$
(x > 0) \wedge (f(x) = y) \wedge (a[y] = 5)
$$

involves linear arithmetic ($T_\text{LIA}$), uninterpreted functions ($T_\text{UF}$), and arrays ($T_\text{A}$). We want to decide satisfiability in the combined theory without building a single monolithic decision procedure.

## Nelson–Oppen framework

**Theorem (Nelson & Oppen, 1979).** *Let $T_1$ and $T_2$ be theories with:*

1. *Decidable quantifier-free satisfiability.*
2. *Signature disjointness: $\Sigma_1 \cap \Sigma_2$ contains only equality.*
3. *Stable infinity: each $T_i$ has models of every infinite cardinality.*

*Then the quantifier-free fragment of $T_1 \cup T_2$ is decidable.*

The combined decision procedure works by:

### Step 1: Purification

Split every formula into conjuncts, each living in exactly one theory. Introduce fresh variables at theory boundaries. E.g., $f(x + 1) = 0$ becomes $(x' = x + 1) \wedge (f(x') = 0)$ — the arithmetic conjunct $x' = x + 1$ is in $T_\text{LIA}$, the function conjunct $f(x') = 0$ is in $T_\text{UF}$. The **shared variables** (here, $x'$) connect the two.

### Step 2: Theory-local satisfiability checks

Run each theory solver on its conjunct(s). If any is $T_i$-unsatisfiable, the combination is unsatisfiable.

### Step 3: Equality propagation

Each theory reports all equalities among shared variables that are implied by its conjunct. E.g., if $T_\text{LIA}$ concludes from $(x' = y' = 5)$ that $x' = y'$, this equality is sent to $T_\text{UF}$.

Repeat until no new equalities are derived.

### Step 4: Decide

The combined formula is satisfiable iff each purified conjunct is satisfiable *and* the propagated equalities are consistent.

## Why stable infinity

The theorem requires each $T_i$ to have models of every infinite cardinality. This ensures that when the theories disagree about *cardinalities* of the shared domain, the combined theory can "resolve" by picking a suitable infinite cardinality.

Examples:
- $T_\text{LIA}$ is stably infinite (integer models exist at every infinite cardinality, e.g., countably infinite).
- $T_\text{UF}$ is stably infinite.
- A theory with the axiom $\forall x, y.\; x = y$ (all elements equal) is *not* stably infinite — its only models have cardinality 1.

When stable infinity fails, more elaborate combinations are needed (e.g., Nelson–Oppen with cardinality constraints, or polite combination).

## Modern extensions

- **DPLL(T) with NO combination:** Z3's architecture.
- **Shostak-style combination:** handles certain non-convex theories.
- **Polite combination (Ranise, Ringeissen, Zarba):** a generalization handling finite-model theories.
- **Model-based theory combination (MBTC):** used by MathSAT and cvc5; more efficient in practice.

## What this means for you

When you write multi-theory Z3 queries:

```python
from z3 import Int, Array, Function, Solver, sat

s = Solver()
x = Int('x')
a = Array('a', Int, Int)
f = Function('f', Int, Int)
s.add(x > 0, a[x] == f(x), f(x) == 42)
s.check()  # sat, model: x=1, a[1]=42, f(1)=42
```

The solver is running Nelson–Oppen combination behind the scenes. You don't see it; it just works.

**The ceiling:** Non-stably-infinite theories (e.g., bounded bit-vectors combined with arithmetic over bounded integers) require special care. Most modern solvers handle the common cases, but pathological combinations can break.

## Relevance to the ITT engine

A multi-substrate engine where `.md` has string-theoretic constraints, `.py` has arithmetic constraints, and `.html` has tree-structure constraints is precisely a Nelson–Oppen combination problem. The theorem says: if each substrate's theory is decidable and the signature is disjoint, the combined engine has a decision procedure.

This is the *formal justification* for why multi-substrate engines can in principle be engineered without exponential blowup beyond what each component already suffers.
