# Chapter 06 — What Is a Cycle?

*Read time: 7 minutes*

---

## Why Loops Hold Energy

Push a swing. It swings forward, comes back, swings 
forward again. The energy you put in does not disappear 
immediately — it circulates in the system, returning 
to the start and going out again.

Now push a box across a floor. The box moves, slows 
down, stops. The energy you put in dissipates into 
heat from friction. It does not return.

The swing is a cycle. The box is a chain. The 
difference is not about how much energy was put in. 
It is about whether the system has a structure that 
brings influence back to where it started.

---

## Cycles in Graphs

In a graph, a **cycle** is a path that starts at a 
node, travels through a sequence of connected nodes, 
and returns to the starting node.

```
A → B → C → A    (a 3-node cycle)
```

A **chain** is a path that does not return:

```
A → B → C        (a 3-node chain, open end)
```

In the field system, this difference is decisive.

When the field diffuses through a cycle, the activation 
that leaves A reaches B, then C, then comes back to A. 
The node A influences itself — indirectly, through the 
loop. This creates a self-reinforcing structure.

In a chain, activation leaves A, reaches B, reaches C, 
and stops. Nothing returns to A. A's activation 
decays unless the seed keeps pumping it up.

---

## The Cycle Persistence Measurement

For a cycle C (a set of nodes forming a loop), compute:

```
S_C = (sum of φ values around the loop) / (sum of |Δφ| around the loop)
```

This is the same idea as the node-level S from Chapter 05, 
but applied to the entire loop as a unit.

S_C ≥ 1 means: the loop as a whole is retaining its 
field faster than it is losing it. The cycle is a 
self-sustaining structure. In this system, that is 
the definition of an **Object** — a real thing.

S_C < 1 means: the loop is dissipating. It will 
fade. It is not a stable structure.

---

## Why This Matters for Code

In a codebase, a cycle between modules is usually 
considered a problem — a circular dependency that 
should be refactored away.

In this system, cycles are first-class objects. A 
cycle of modules that strongly reinforce each other 
(high coupling weights, all active under the current 
seed) is a stable, self-sustaining computational 
structure. It is more real, in the field sense, 
than any individual module.

The practical implication: when you examine the 
output of the field system, look at the persistent 
cycles first. They are the backbone of the computation. 
Individual nodes are secondary — they matter insofar 
as they participate in cycles.

---

## An Anchor vs a Passing State

When a cycle achieves S_C above 1.2, it becomes 
an **anchor** — a structure persistent enough to 
survive even if the seed is removed.

Think of it like this: if you push a swing hard 
enough and it is in the right environment, it keeps 
going on its own for a while even after you stop 
pushing. The cycle has acquired enough internal 
momentum that it is self-sustaining without 
external forcing.

In the code:
```typescript
isAnchor: S_C >= SELECTION.anchor  // anchor = 1.2
```

Anchors are the most stable structures the system 
can produce. They are the field's answer to 
"what persists here regardless of intent?"

---

## The Test Result — Honest Accounting

When tests were run on this system, there was a 
subtle issue: at convergence, S_C → ∞ for both 
cycles and chains, because Δφ → 0 for everything 
that has settled.

This means the distinction between cycles and chains 
only shows up clearly during the transient — when 
the field is actively spreading. At step 3, a cycle 
shows S_C distinctly higher than a chain with the 
same seed, because the returning activation is 
giving the cycle extra support.

At step 30 (convergence), both show enormous S_C 
values and the cycle/chain distinction is invisible 
in the numbers alone.

**The practical rule:** gate on S_C at steps 2-5. 
Use convergence to determine final Φ values. 
Use transient to determine what is a cycle vs a chain.

---

## Summary

- A cycle is a path through the graph that returns to its start
- A chain is a path that has a dead end
- Cycles self-reinforce — influence returns to the origin
- Chains dissipate — influence leaves and does not return
- S_C ≥ 1: cycle is a persistent Object
- S_C ≥ 1.2: cycle is an Anchor — survives seed removal
- Measure S_C during transient (steps 2-5), not at convergence

---

**Previous:** [Chapter 05 — The Selection Gate](./ch-05-the-selection-gate.md)  
**Next:** [Chapter 07 — The Bloom](./ch-07-the-bloom.md)
