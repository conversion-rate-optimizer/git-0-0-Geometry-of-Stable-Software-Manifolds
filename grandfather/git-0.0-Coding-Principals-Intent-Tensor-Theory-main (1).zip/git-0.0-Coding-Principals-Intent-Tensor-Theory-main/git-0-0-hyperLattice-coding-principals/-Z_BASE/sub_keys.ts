/**
 * -Z_BASE: Sub-Key Primitives
 * ============================
 * The five sub-keys that every excitation carries.
 * From Pre-Veil Mechanics Vol I: minimum 3 sub-keys required
 * for a valid S₂ excitation (E-Cascade completion).
 *
 *   k_xyz  — spatial coordinate encoding (curvature-shell field)
 *   k_pol  — polarity gradient (intrapolarity, ∇Φ direction)
 *   k_curl — phase loop structure (∇×F, memory)
 *   k_freq — frequency / resonance type
 *   k_N    — amplitude / selection number
 *
 * In code: every module's intent vector Ψ decomposes into these.
 */

export interface SubKeySet {
  k_xyz:  number[];  // Spatial coordinate encoding (position in manifold)
  k_pol:  number;    // Polarity gradient amplitude
  k_curl: number;    // Curl / phase memory (rotation in field)
  k_freq: number;    // Resonance frequency
  k_N:    number;    // Amplitude / selection number
}

/**
 * Minimum sub-key count for a valid excitation.
 * If fewer than 3 sub-keys are non-trivial, the module is noise.
 */
export const MIN_SUBKEYS = 3;

/**
 * Count how many sub-keys are meaningfully populated.
 * A sub-key is non-trivial if its magnitude exceeds epsilon.
 */
export function countActiveSubKeys(keys: SubKeySet, epsilon = 0.01): number {
  let count = 0;
  if (keys.k_xyz.some(v => Math.abs(v) > epsilon)) count++;
  if (Math.abs(keys.k_pol) > epsilon)  count++;
  if (Math.abs(keys.k_curl) > epsilon) count++;
  if (Math.abs(keys.k_freq) > epsilon) count++;
  if (Math.abs(keys.k_N) > epsilon)    count++;
  return count;
}

/**
 * E-Cascade check: does this sub-key set have enough structure
 * to be a valid S₂ excitation?
 */
export function eCascadeComplete(keys: SubKeySet): boolean {
  return countActiveSubKeys(keys) >= MIN_SUBKEYS;
}

/**
 * Extract sub-keys from an intent vector Ψ.
 * Simple projection — in production, use a trained decomposition.
 */
export function subKeysFromVector(psi: number[]): SubKeySet {
  const n = psi.length;
  const q = Math.floor(n / 4);

  return {
    k_xyz:  psi.slice(0, q),
    k_pol:  psi.slice(q, 2 * q).reduce((a, b) => a + b, 0) / q,
    k_curl: psi.slice(2 * q, 3 * q).reduce((a, b) => a + b, 0) / q,
    k_freq: psi.slice(3 * q).reduce((a, b) => a + b, 0) / (n - 3 * q),
    k_N:    Math.sqrt(psi.reduce((s, v) => s + v * v, 0)),
  };
}
