"""
Pure-Python implementation of Z-sets, streams, I/D operators, and IVM.

Pedagogical — not production. Demonstrates the DBSP calculus at the
level of literal equations from the math files.
"""

from __future__ import annotations
from collections import defaultdict
from typing import Callable, Hashable, Dict, List, Tuple


class ZSet:
    """Z-set: finite-support function D -> Z."""

    def __init__(self, counts: Dict[Hashable, int] = None):
        self.counts: Dict[Hashable, int] = defaultdict(int, counts or {})
        # Remove zero-count entries to keep support clean.
        self.counts = {k: v for k, v in self.counts.items() if v != 0}

    def __add__(self, other: "ZSet") -> "ZSet":
        combined = defaultdict(int, self.counts)
        for k, v in other.counts.items():
            combined[k] += v
        return ZSet(dict(combined))

    def __sub__(self, other: "ZSet") -> "ZSet":
        return self + other.negate()

    def negate(self) -> "ZSet":
        return ZSet({k: -v for k, v in self.counts.items()})

    def select(self, pred: Callable[[Hashable], bool]) -> "ZSet":
        return ZSet({k: v for k, v in self.counts.items() if pred(k)})

    def project(self, f: Callable[[Hashable], Hashable]) -> "ZSet":
        result = defaultdict(int)
        for k, v in self.counts.items():
            result[f(k)] += v
        return ZSet(dict(result))

    def join(self, other: "ZSet", key_left: Callable, key_right: Callable,
             combine: Callable) -> "ZSet":
        result = defaultdict(int)
        for k1, v1 in self.counts.items():
            for k2, v2 in other.counts.items():
                if key_left(k1) == key_right(k2):
                    result[combine(k1, k2)] += v1 * v2
        return ZSet(dict(result))

    def __eq__(self, other):
        return isinstance(other, ZSet) and dict(self.counts) == dict(other.counts)

    def __repr__(self):
        if not self.counts: return "∅"
        return "{" + ", ".join(f"{v}·{k!r}" for k, v in sorted(self.counts.items(), key=str)) + "}"


# ---------- Streams ----------

Stream = List[ZSet]  # A stream is just a list indexed by time.


def integrate(s: Stream) -> Stream:
    """I(s)[t] = sum_{i<=t} s[i]"""
    out, running = [], ZSet()
    for z in s:
        running = running + z
        out.append(running)
    return out


def differentiate(s: Stream) -> Stream:
    """D(s)[t] = s[t] - s[t-1],  s[-1] := 0"""
    out, prev = [], ZSet()
    for z in s:
        out.append(z - prev)
        prev = z
    return out


# ---------- IVM ----------

def incremental(Q: Callable[[ZSet], ZSet], input_deltas: Stream) -> Stream:
    """Q^Δ = D ∘ Q ∘ I   applied to a delta stream."""
    snapshots = integrate(input_deltas)
    view_snapshots = [Q(s) for s in snapshots]
    return differentiate(view_snapshots)


# ---------- Demo ----------

if __name__ == "__main__":
    # Query: select rows whose second element > 100
    def Q(z: ZSet) -> ZSet:
        return z.select(lambda row: row[1] > 100)

    # A sequence of deltas:
    input_stream = [
        ZSet({("alice", 50):  1}),                  # t=0: add (alice, 50)
        ZSet({("bob",  150): 1}),                   # t=1: add (bob, 150)
        ZSet({("carol",200): 1, ("bob", 150): -1}), # t=2: add carol, remove bob
        ZSet({("alice", 50): -1}),                  # t=3: remove alice
    ]

    # Fundamental identity sanity check
    assert differentiate(integrate(input_stream)) == input_stream
    assert integrate(differentiate(input_stream)) == input_stream

    # IVM: get only the changes to the view at each time step
    view_deltas = incremental(Q, input_stream)

    print("Input deltas:")
    for t, z in enumerate(input_stream):
        print(f"  t={t}: {z}")
    print()
    print("View deltas (Q^Δ):")
    for t, z in enumerate(view_deltas):
        print(f"  t={t}: {z}")

    # Check: integrated view deltas = Q applied to integrated input deltas
    assert integrate(view_deltas) == [Q(s) for s in integrate(input_stream)]
    print()
    print("IVM consistency check passed.")
