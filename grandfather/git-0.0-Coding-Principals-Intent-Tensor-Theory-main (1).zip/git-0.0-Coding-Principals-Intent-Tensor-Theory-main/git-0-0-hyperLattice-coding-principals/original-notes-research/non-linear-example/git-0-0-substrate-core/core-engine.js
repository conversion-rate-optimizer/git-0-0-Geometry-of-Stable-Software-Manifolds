/**
 * Ghostless lattice core.
 * Canonical form: git-<x>-<y>-<semantic-slug>
 */

const LATTICE = {
  "0-0": "git-0-0-substrate-core",
  "0-1": "git-0-1-ignition-main",
  "0-2": "git-0-2-runtime-api",
  "1-0": "git-1-0-interface-ui",
};

export function resolveCoordinate(x, y) {
  const key = `${x}-${y}`;
  const path = LATTICE[key];
  if (!path) throw new Error(`Unknown lattice coordinate: ${key}`);
  return `/${path}`;
}

export function selectionNumber(retention, lossRate, tref = 1) {
  if (lossRate <= 0 || tref <= 0) return Number.POSITIVE_INFINITY;
  return retention / (lossRate * tref);
}

export function gatePersistence(retention, lossRate, tref = 1) {
  return selectionNumber(retention, lossRate, tref) >= 1;
}

export function waveW(phi, theta) {
  return Math.sin(2 * phi) * Math.cos(2 * theta);
}

export function waveV(phi, theta) {
  return -waveW(phi, theta);
}
