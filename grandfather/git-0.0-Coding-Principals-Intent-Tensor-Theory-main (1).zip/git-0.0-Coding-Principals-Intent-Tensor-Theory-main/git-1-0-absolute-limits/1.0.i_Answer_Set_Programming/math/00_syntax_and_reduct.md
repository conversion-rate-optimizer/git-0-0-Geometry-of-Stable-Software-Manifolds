# ASP Syntax and the Gelfond–Lifschitz Reduct

## Syntax

An **ASP program** is a finite set of rules. A rule has the form

$$
a_0 \;\leftarrow\; a_1,\, \ldots,\, a_m,\, \text{not}\, a_{m+1},\, \ldots,\, \text{not}\, a_n.
$$

- $a_0$ is the **head** (a single atom, or $\bot$ for constraints).
- $a_1, \ldots, a_m$ are positive **body** atoms.
- $\text{not}\, a_{m+1}, \ldots, \text{not}\, a_n$ are negative body literals ("negation as failure").

Special cases:
- **Fact:** head only, no body. Written `a.`
- **Constraint:** head is $\bot$ (empty). Written `:- body.` — forbids `body` from being true.
- **Choice rule:** $\{a\} \leftarrow \text{body}$ — optionally derive $a$.

## Why not just the $T_P$ operator?

For programs *without negation*, $T_P$ gives the minimal model as in Datalog. For programs *with negation*, $T_P$ is non-monotone:

$$
p \;\leftarrow\; \text{not}\, q. \qquad q \;\leftarrow\; \text{not}\, p.
$$

Intuitively, this program has two solutions: $\{p\}$ (where $q$ is false, so $p$ is derivable) and $\{q\}$. But $T_P$ iteration from $\emptyset$ gives $\{p, q\}$ — both true — which is not really a stable interpretation.

Gelfond and Lifschitz (1988) proposed the stable-model semantics to handle this.

## The Gelfond–Lifschitz reduct

Given a program $P$ and a candidate model $S \subseteq B_P$, the **reduct** $P^S$ is obtained by:

1. **Delete** every rule whose body contains $\text{not}\, a$ for some $a \in S$.
2. From the remaining rules, **delete** all $\text{not}\, a$ literals from the bodies.

$P^S$ is a **negation-free** program. It has a unique minimal model $M(P^S)$.

## Definition of stable model

**Definition.** $S$ is a **stable model** (or **answer set**) of $P$ iff

$$
S \;=\; M(P^S).
$$

That is, $S$ is the minimal model of the reduct of $P$ by $S$ itself.

## Example (continued)

$P = \{p \leftarrow \text{not}\, q.,\; q \leftarrow \text{not}\, p.\}$.

- **Candidate $S = \{p\}$.** Reduct: delete the second rule (because $p \in S$); delete $\text{not}\, q$ from the first. $P^S = \{p \leftarrow.\}$. Minimal model $= \{p\} = S$. ✓ **Stable.**
- **Candidate $S = \{q\}$.** By symmetry, also stable.
- **Candidate $S = \{p, q\}$.** Reduct: delete both rules. $P^S = \emptyset$. Minimal model $= \emptyset \neq S$. ✗ **Not stable.**
- **Candidate $S = \emptyset$.** Reduct: keep both rules, drop negation. $P^S = \{p \leftarrow.,\; q \leftarrow.\}$. Minimal model $= \{p, q\} \neq S$. ✗ **Not stable.**

So this program has exactly two answer sets: $\{p\}$ and $\{q\}$.

## Why this semantics works

The GL reduct has an intuitive interpretation:

> *"$S$ is a stable model iff, after committing to the negative information (which atoms are false), the positive rules derive exactly $S$."*

This is **self-consistency** — the interpretation confirms itself when we check which negative assumptions it licenses.

## Fixed point view

Define $\Gamma_P(S) := M(P^S)$. Stable models are fixed points of $\Gamma_P$.

**Property.** $\Gamma_P$ is **antitone** (order-reversing) in $S$: if $S_1 \subseteq S_2$, then $\Gamma_P(S_2) \subseteq \Gamma_P(S_1)$.

Antitone operators do not necessarily have unique fixed points. This is why ASP programs can have multiple answer sets — each a distinct stable model.

## Computation

Solvers (clingo, DLV, WASP) compute stable models via a combination of:
- **Grounding:** instantiate variables over the Herbrand universe to get a propositional program.
- **Search:** SAT-like conflict-driven clause learning over the grounded program, augmented with the stable-model check.

The solver finds all stable models (or one, or enumerates up to a bound, depending on user settings).

## Complexity

- **Deciding existence of a stable model:** NP-complete.
- **Brave (credulous) reasoning** ("is $a$ in some stable model?"): NP-complete.
- **Cautious (skeptical) reasoning** ("is $a$ in every stable model?"): coNP-complete.
- **With disjunction in rule heads:** $\Sigma_2^P$-complete.

This is one level higher than Datalog (PTIME) — the price for negation as failure.
