/**
 * +Z_APEX: Bloom Engine
 * =====================
 * The entropy-corrected Dynamic Bloom Quotient Q(t).
 *
 * Q(t) = A_tot(t) / (Θ · [η₁·Var(φ) + η₂·(-Σ p_i ln p_i)])
 *
 * Where:
 *   A_tot = Σ_i |(∇²_G φ)_i|  — structure production rate (Laplacian action)
 *   Var(φ)                     — spatial disorder (spread)
 *   -Σ p_i ln p_i              — distributional disorder (fragmentation)
 *   p_i = φ_i / Σφ             — normalized field probability
 *
 * Q > 1.0 = system removes disorder faster than it generates it = BLOOM
 * Q ≤ 1.0 = disorder dominates = structure decays
 *
 * WHY ENTROPY IS REQUIRED:
 * Two fields can have identical variance but different entropy.
 * Field A: one dominant node (low entropy, coherent) → bloom candidate
 * Field B: evenly spread (high entropy, fragmented) → no bloom
 * Without entropy, the system cannot distinguish coherence from mere spread.
 * This was the gap closed by the Atomic Polarity/Pre-Veil synthesis.
 *
 * S_free = η₁·Var(φ) + η₂·H(φ)
 * where H(φ) = -Σ p_i ln p_i (Shannon entropy of the field distribution)
 */

import { BLOOM, SELECTION, LATTICE } from "../-Z_BASE/axioms";

export interface BloomMetrics {
  Q: number;
  A_tot: number;     // Laplacian action (numerator)
  variance: number;  // Spatial disorder
  entropy: number;   // Distributional disorder
  S_free: number;    // Combined disorder (denominator factor)
  isBloom: boolean;  // Q > 1.1
}

/**
 * Graph Laplacian action on the field:
 *   A_tot = Σ_i |(∇²_G φ)_i|
 *         = Σ_i |Σ_j W_ij(φ_j - φ_i)|
 *
 * Measures how much structure is being actively enforced.
 * High when field is resolving inconsistencies.
 * Falls to zero at equilibrium.
 */
export function laplacianAction(
  nodeIds: string[],
  phi: Map<string, number>,
  W: Map<string, Map<string, number>>
): number {
  let action = 0;

  for (const id of nodeIds) {
    const phi_i = phi.get(id) ?? 0;
    const neighbors = W.get(id);
    if (!neighbors) continue;

    let lap = 0;
    for (const [nId, w] of neighbors) {
      const phi_j = phi.get(nId) ?? 0;
      lap += w * (phi_j - phi_i);
    }
    action += Math.abs(lap);
  }

  return action;
}

/**
 * Variance of the field distribution:
 *   Var(φ) = (1/N) Σ_i (φ_i - μ_φ)²
 */
export function fieldVariance(nodeIds: string[], phi: Map<string, number>): number {
  const N = nodeIds.length;
  if (N === 0) return 0;

  let mean = 0;
  for (const id of nodeIds) mean += (phi.get(id) ?? 0);
  mean /= N;

  let variance = 0;
  for (const id of nodeIds) {
    variance += Math.pow((phi.get(id) ?? 0) - mean, 2);
  }
  return variance / N;
}

/**
 * Shannon entropy of the field distribution:
 *   H(φ) = -Σ_i p_i ln(p_i)
 *   where p_i = φ_i / Σφ
 *
 * Sign note: entropy is defined as POSITIVE here.
 * S_free adds it to variance (both are disorder penalties).
 */
export function fieldEntropy(nodeIds: string[], phi: Map<string, number>): number {
  const total = nodeIds.reduce((s, id) => s + (phi.get(id) ?? 0), 0);
  if (total < LATTICE.epsilon_field) return 0;

  let entropy = 0;
  for (const id of nodeIds) {
    const p = (phi.get(id) ?? 0) / total;
    if (p > LATTICE.epsilon_field) {
      entropy -= p * Math.log(p);
    }
  }
  return entropy;
}

/**
 * S_free: Combined disorder functional
 *   S_free = η₁·Var(φ) + η₂·H(φ)
 */
export function computeSFree(
  nodeIds: string[],
  phi: Map<string, number>
): number {
  const variance = fieldVariance(nodeIds, phi);
  const entropy = fieldEntropy(nodeIds, phi);
  return BLOOM.eta_1 * variance + BLOOM.eta_2 * entropy;
}

/**
 * Dynamic Bloom Quotient Q(t):
 *   Q = A_tot / (Θ · S_free)
 */
export function computeQ(
  nodeIds: string[],
  phi: Map<string, number>,
  W: Map<string, Map<string, number>>
): BloomMetrics {
  const A_tot = laplacianAction(nodeIds, phi, W);
  const variance = fieldVariance(nodeIds, phi);
  const entropy = fieldEntropy(nodeIds, phi);
  const S_free = BLOOM.eta_1 * variance + BLOOM.eta_2 * entropy;
  const Q = A_tot / (BLOOM.theta * S_free + LATTICE.epsilon_field);

  return {
    Q,
    A_tot,
    variance,
    entropy,
    S_free,
    isBloom: Q > SELECTION.bloom,
  };
}

/**
 * Node-level Selection Number:
 *   S_i = φ_i / (|φ_i(t) - φ_i(t-1)| + ε)
 *
 * This is the discrete existence condition:
 *   S_i ≥ 1 → node is REAL (structure persists)
 *   S_i < 1 → node is NOISE (transient fluctuation)
 */
export function selectionNumber(phi: number, phi_prev: number): number {
  const delta = Math.abs(phi - phi_prev);
  const S = phi / (delta + LATTICE.epsilon_field);
  // Cap at 1000: S → ∞ at convergence (correct mathematically) but
  // operationally meaningless above this. S is informative DURING
  // field evolution (steps 1-10), not after settling.
  // Test-verified: field converges in ~30 steps; gate early.
  return Math.min(S, 1000);
}

/**
 * Apply selection gate to all nodes in the field.
 * Returns the persistent submanifold A = {i | S_i ≥ 1}
 */
export function applySelectionGate(
  nodeIds: string[],
  phi: Map<string, number>,
  phi_prev: Map<string, number>
): {
  persistent: string[];
  noise: string[];
  selectionNumbers: Map<string, number>;
} {
  const persistent: string[] = [];
  const noise: string[] = [];
  const selectionNumbers = new Map<string, number>();

  for (const id of nodeIds) {
    const S = selectionNumber(phi.get(id) ?? 0, phi_prev.get(id) ?? 0);
    selectionNumbers.set(id, S);

    if (S >= SELECTION.persistence) {
      persistent.push(id);
    } else {
      noise.push(id);
    }
  }

  return { persistent, noise, selectionNumbers };
}

/**
 * Q(t) slope check: second derivative Q''(t) > 0
 *
 * A feature is only allowed to merge into the Master Manifest if
 * its Q(t) trajectory shows accelerating emergence.
 * Flat or decelerating Q = structure is plateauing or decaying.
 */
export function bloomAccelerating(
  Q_history: number[]
): boolean {
  if (Q_history.length < 3) return false;
  const n = Q_history.length;
  const Q2 = Q_history[n - 1] - 2 * Q_history[n - 2] + Q_history[n - 3];
  return Q2 > 0; // Q'' > 0
}
