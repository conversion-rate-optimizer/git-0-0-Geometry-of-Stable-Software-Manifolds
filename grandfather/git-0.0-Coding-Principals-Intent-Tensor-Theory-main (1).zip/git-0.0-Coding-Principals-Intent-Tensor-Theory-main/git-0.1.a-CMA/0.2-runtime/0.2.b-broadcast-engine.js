/**
 * 0.2.b-broadcast-engine.js
 * The "Field Pulse" Generator
 * ────────────────────────────
 * GitCMA — Git Coordinate Manifold Architecture
 * Purpose: Execute an operation across all domains for a specific function (y).
 *
 * BROADCAST y=2  →  pulses data to 1.2, 2.2, 3.2, 4.2 simultaneously
 *
 * Created by Armstrong Knight — intent-tensor-theory.com
 * CC BY-NC 4.0
 */

const fs   = require('fs');
const path = require('path');
const RCL  = require('../0.0-shared/0.0.a-core-engine.js');

const BROADCAST_ENGINE = {

  /**
   * Pushes a Pulse (Message/Data) to a specific function across all domains.
   * @param {number} targetFunction - The y-coordinate (e.g., 2 for Social)
   * @param {object} payload        - The content to broadcast
   */
  pulse: function (targetFunction, payload) {
    console.log(`\n─── INITIATING BROADCAST: FUNCTION .${targetFunction} ─────────────────`);

    const domains   = [1, 2, 3, 4];
    const timestamp = new Date().toISOString();
    const results   = [];

    domains.forEach(x => {
      try {
        const coord      = `${x}.${targetFunction}`;
        const rclPath    = RCL.resolve(coord);
        const targetDir  = path.join(__dirname, '..', rclPath);
        const targetFile = path.join(targetDir, 'pulse_data.json');

        // Ensure directory exists before writing
        if (!fs.existsSync(targetDir)) {
          console.warn(`  [VOID]  ${coord}  →  directory not stabilized, skipping`);
          results.push({ coord, status: 'VOID' });
          return;
        }

        // The Payload — injected into the coordinate node
        const data = {
          origin:    coord,
          timestamp: timestamp,
          content:   payload.message,
          metadata: {
            domain:   RCL.DOMAINS[x],
            function: RCL.FUNCTIONS[targetFunction]
          }
        };

        fs.writeFileSync(targetFile, JSON.stringify(data, null, 2));
        console.log(`  [OK]    ${coord}  →  ${rclPath}`);
        results.push({ coord, status: 'OK', path: rclPath });

      } catch (err) {
        console.error(`  [FAIL]  Domain ${x}:`, err.message);
        results.push({ coord: `${x}.${targetFunction}`, status: 'FAIL', error: err.message });
      }
    });

    console.log(`─── BROADCAST COMPLETE: ${results.filter(r => r.status === 'OK').length}/${domains.length} nodes pulsed ─────`);
    return results;
  },

  /**
   * Aggregate: collect pulse_data.json from satellite nodes and fold into hub.
   * @param {number} hubX      - The hub domain (e.g., 1 for project)
   * @param {number} y         - The function rail (e.g., 2 for social)
   * @param {Array}  sourceXs  - The satellite domains (e.g., [2, 3, 4])
   */
  aggregate: function (hubX, y, sourceXs = [2, 3, 4]) {
    console.log(`\n─── AGGREGATE: ${hubX}.${y} FROM [${sourceXs.join(', ')}.${y}] ─────────────`);

    const aggregated = [];

    sourceXs.forEach(x => {
      const coord = `${x}.${y}`;
      const rclPath = RCL.resolve(coord);
      const pulseFile = path.join(__dirname, '..', rclPath, 'pulse_data.json');

      if (fs.existsSync(pulseFile)) {
        const data = JSON.parse(fs.readFileSync(pulseFile, 'utf8'));
        aggregated.push(data);
        console.log(`  [READ]  ${coord}`);
      } else {
        console.warn(`  [EMPTY] ${coord}  →  no pulse data`);
      }
    });

    // Write aggregated result to hub
    const hubPath = path.join(__dirname, '..', RCL.resolve(`${hubX}.${y}`));
    if (fs.existsSync(hubPath)) {
      fs.writeFileSync(
        path.join(hubPath, 'aggregate_data.json'),
        JSON.stringify({ aggregated, updatedAt: new Date().toISOString() }, null, 2)
      );
      console.log(`  [HUB]   ${hubX}.${y}  →  aggregate written`);
    }

    return aggregated;
  }
};

// ─── EXAMPLE EXECUTION ──────────────────────────────────────────────────────
if (require.main === module) {
  BROADCAST_ENGINE.pulse(2, {
    message: 'GitCMA field alignment achieved. All coordinates synchronized.'
  });
}

module.exports = BROADCAST_ENGINE;
