/**
 * -Z_BASE: Void Geometry for Code Modules
 * =========================================
 * Direct application of G_void(Z,S;τ) from Atomic Polarity (Knight 2026)
 * to the code module domain.
 *
 * In Atomic Polarity:
 *   G_void(Z,S;τ) = Top{ Σ_{Z,S}(τ) }
 *   where Σ_{Z,S}(τ) = {r : ρ_{e,Z,S}(r) = τ} — the isodensity boundary
 *
 * In hyperLattice:
 *   G_void(module, τ) = Top{ Σ_{module}(τ) }
 *   where Σ_{module}(τ) = the boundary of the module's committed dependency field
 *   and τ = the coupling threshold (LATTICE.resonance_threshold = 0.16)
 *
 * Analogy table:
 * ───────────────────────────────────────────────────────────
 *   Atomic Polarity          │  hyperLattice
 * ───────────────────────────────────────────────────────────
 *   Atom (Z, S)              │  Module (id, subKeys)
 *   Electron density ρ_e     │  Coupling weight W_ij
 *   Void region B_void       │  Uncommitted dependency zone
 *   Open bond site           │  Open import slot (ξ_intra > 0)
 *   Lone pair anchor         │  Internal state with no external bond
 *   Intrapolarity ξ_intra    │  ∇(1 - W_saturation) within B_void
 *   Octet rule (W)=0         │  Module closure (all imports bonded)
 *   Dynamic tessellation     │  Cycle competition resolved
 *   BET catastrophe          │  Cycle topology change (edge add/remove)
 * ───────────────────────────────────────────────────────────
 *
 * Key insight from Atomic Polarity:
 *   The void is primary. The "empty" space around a module — its
 *   uncommitted dependency potential — determines its behavior more
 *   fundamentally than its implemented logic.
 *
 *   A module with 4 open bond sites (like carbon sp³) will tessellate
 *   with 4 partners. A module with 0 open sites (like noble gas) will
 *   not bond — it is already closed.
 */

import { VOID, SELECTION } from "../-Z_BASE/axioms";

export interface ModuleVoidGeometry {
  moduleId: string;
  
  /** Total coupling saturation: how "filled" this module's bond sites are */
  saturation: number;

  /** Open bond sites: number of uncommitted dependency directions */
  openSites: number;

  /** Committed sites: active resonance bonds above threshold */
  committedSites: number;

  /** Intrapolarity field: gradient of uncommitted potential */
  intrapolarity: number;

  /** Phase residue (W): 0 if void is closed (fully bonded), >0 if open */
  phaseResidue: number;

  /** Is this module void-closed? (Analog of octet completion) */
  isClosed: boolean;
}

/**
 * Compute the void geometry of a module.
 *
 * @param moduleId — the module's identity key
 * @param couplings — map of neighbor → W_ij for this module
 * @param maxBondSites — the module's declared capacity (default 4, like carbon)
 */
export function computeVoidGeometry(
  moduleId: string,
  couplings: Map<string, number>,
  maxBondSites: number = 4
): ModuleVoidGeometry {
  const committedSites = couplings.size;
  const openSites = Math.max(0, maxBondSites - committedSites);

  // Saturation: what fraction of bond capacity is committed
  const saturation = committedSites / maxBondSites;

  // Intrapolarity: ξ_intra ∝ ∇(1 - W_sat) within B_void
  // High intrapolarity = strong pre-geometric pull toward new bonds
  const intrapolarity = 1 - saturation;

  // Phase residue: 0 only when all bond sites are committed
  // (W) = 0 ↔ void closure ↔ module is "octeted"
  const phaseResidue = openSites;

  return {
    moduleId,
    saturation,
    openSites,
    committedSites,
    intrapolarity,
    phaseResidue,
    isClosed: openSites === 0,
  };
}

/**
 * Void tessellation check: can module A bond with module B?
 *
 * Analog of chemical bonding:
 *   Bond forms when void geometries are complementary —
 *   A's open sites match B's open sites in resonance direction.
 *
 * In code: A can bond with B if both have open slots and their
 * coupling W_AB exceeds the semantic locality threshold.
 */
export function canTessellate(
  geoA: ModuleVoidGeometry,
  geoB: ModuleVoidGeometry,
  coupling: number
): boolean {
  if (geoA.isClosed || geoB.isClosed) return false;
  if (coupling < VOID.tau * SELECTION.persistence) return false;
  return true;
}

/**
 * Dynamic tessellation event: module A bonds with B.
 *
 * In Atomic Polarity, this is a BET catastrophe — a discrete
 * topological change in the combined void geometry.
 *
 * In code, this is an edge activation: W_AB crosses from
 * below threshold → above threshold (S₁b → S₂ transition).
 */
export function tessellationEvent(
  geoA: ModuleVoidGeometry,
  geoB: ModuleVoidGeometry,
  coupling: number
): {
  bonded: boolean;
  newGeoA: ModuleVoidGeometry;
  newGeoB: ModuleVoidGeometry;
  eventType: "BOND_FORMED" | "BOND_REJECTED" | "VOID_CLOSED";
} {
  if (!canTessellate(geoA, geoB, coupling)) {
    return {
      bonded: false,
      newGeoA: geoA,
      newGeoB: geoB,
      eventType: "BOND_REJECTED",
    };
  }

  // Bond forms: reduce open sites by 1 for each
  const newCouplingsA = new Map([[geoB.moduleId, coupling]]);
  const newCouplingsB = new Map([[geoA.moduleId, coupling]]);

  const updatedGeoA = computeVoidGeometry(
    geoA.moduleId,
    newCouplingsA,
    geoA.openSites + geoA.committedSites
  );
  const updatedGeoB = computeVoidGeometry(
    geoB.moduleId,
    newCouplingsB,
    geoB.openSites + geoB.committedSites
  );

  const eventType = (updatedGeoA.isClosed || updatedGeoB.isClosed)
    ? "VOID_CLOSED"
    : "BOND_FORMED";

  return {
    bonded: true,
    newGeoA: updatedGeoA,
    newGeoB: updatedGeoB,
    eventType,
  };
}

/**
 * Module "octet" check: is this module's void fully closed?
 *
 * A module achieves closure when (W) = 0 — every dependency
 * direction is committed to a resonance partner.
 *
 * Noble gas modules (maxBondSites = 0) are always closed.
 * They do not bond. They are pure identity anchors (-Z_BASE level).
 */
export function isVoidClosed(geo: ModuleVoidGeometry): boolean {
  return geo.phaseResidue === 0;
}
