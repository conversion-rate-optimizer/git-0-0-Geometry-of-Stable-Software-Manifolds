/**
 * Multi-Substrate Intent Engine.
 *
 * Implements the product-lattice fixed-point engine from
 * 1.0.n/math/{00,01,02}_*.md.
 *
 * Each substrate has its own local engine; cross-substrate translators
 * propagate information. An outer Kleene loop ensures global consistency.
 */

export type SubstrateState = Record<string, unknown>;

export type Derivation<S = SubstrateState> = (s: S) => Partial<S> | null;

export interface Constraint<S = SubstrateState> {
  priority: number;
  check: (s: S) => Partial<S> | null;
  label?: string;
}

export interface Substrate<S = SubstrateState> {
  name: string;
  state: S;
  derivations: Derivation<S>[];
  constraints: Constraint<S>[];
}

export interface CrossLink {
  from: string;
  to: string;
  translate: (fromState: SubstrateState) => Partial<SubstrateState> | null;
  label?: string;
}

export class MultiSubstrateEngine {
  private substrates: Map<string, Substrate> = new Map();
  private links: CrossLink[] = [];

  addSubstrate(s: Substrate): this {
    this.substrates.set(s.name, s);
    return this;
  }

  addLink(l: CrossLink): this {
    this.links.push(l);
    return this;
  }

  /**
   * Resolve the entire product lattice to a global fixed point.
   * Outer loop: iterate until nothing changes anywhere.
   * Inner pass per outer iteration:
   *   1. Each substrate resolves locally.
   *   2. All cross-substrate translators propagate.
   */
  resolve(outerMax = 100, innerMax = 1000): Record<string, SubstrateState> {
    const history: string[] = [];

    for (let n = 0; n < outerMax; n++) {
      const snapshot = this.snapshot();
      history.push(snapshot);

      // Resolve each substrate locally
      for (const sub of this.substrates.values()) {
        this.resolveLocal(sub, innerMax);
      }

      // Apply cross-substrate translators
      for (const link of this.links) {
        const from = this.substrates.get(link.from);
        const to   = this.substrates.get(link.to);
        if (!from || !to) continue;
        const update = link.translate(from.state);
        if (update) Object.assign(to.state, update);
      }

      // Global fixed-point check
      if (this.snapshot() === snapshot) {
        return this.getAllStates();
      }

      // Oscillation detection
      const seen = history.filter(h => h === this.snapshot()).length;
      if (seen > 2) {
        throw new Error(
          `Multi-substrate engine oscillating after ${n} outer iterations. ` +
          `Check cross-substrate link consistency.`
        );
      }
    }
    throw new Error(
      `Multi-substrate engine did not converge in ${outerMax} outer iterations.`
    );
  }

  private resolveLocal(sub: Substrate, maxIter: number): void {
    for (let n = 0; n < maxIter; n++) {
      const before = JSON.stringify(sub.state);

      // Derivations
      for (const d of sub.derivations) {
        const update = d(sub.state);
        if (update) Object.assign(sub.state, update);
      }

      // Constraints in decreasing priority order
      const sorted = [...sub.constraints].sort((a, b) => b.priority - a.priority);
      for (const c of sorted) {
        const fix = c.check(sub.state);
        if (fix) Object.assign(sub.state, fix);
      }

      if (JSON.stringify(sub.state) === before) return;
    }
    throw new Error(`Local engine for substrate '${sub.name}' did not converge.`);
  }

  private snapshot(): string {
    const obj: Record<string, SubstrateState> = {};
    for (const [name, sub] of this.substrates) obj[name] = sub.state;
    return JSON.stringify(obj);
  }

  getAllStates(): Record<string, SubstrateState> {
    const obj: Record<string, SubstrateState> = {};
    for (const [name, sub] of this.substrates) obj[name] = { ...sub.state };
    return obj;
  }
}
