/**
 * +Y_FORWARD: Intrapolarity
 * ==========================
 * ξ_intra ∝ ∇(1 - W_saturation) within B_void
 *
 * A module's intrapolarity is its directional bias toward new bonds —
 * how strongly it "wants" to connect to other modules.
 *
 * High intrapolarity = many open bond sites, actively seeking coupling.
 * Low intrapolarity  = mostly bonded, approaching closure.
 * Zero intrapolarity = void closed, noble-gas analog, does not bond.
 *
 * From Atomic Polarity: intrapolarity points away from committed
 * regions (ELF maxima) toward uncommitted void passages.
 */

import type { ModuleVoidGeometry } from "../-Z_BASE/void_geometry";

export interface IntrapolarityProfile {
  moduleId: string;
  /** Gradient of uncommitted potential — how strongly it seeks bonds */
  strength: number;
  /** Number of open sites */
  openSites: number;
  /** Normalized direction toward highest-resonance open neighbor */
  preferredDirection?: string;
}

/**
 * Compute intrapolarity from void geometry.
 * ξ_intra = 1 - saturation (complement of commitment)
 */
export function computeIntrapolarity(
  geo: ModuleVoidGeometry
): IntrapolarityProfile {
  return {
    moduleId: geo.moduleId,
    strength: geo.intrapolarity,
    openSites: geo.openSites,
  };
}

/**
 * Rank modules by intrapolarity — most "seeking" first.
 * Useful for seeding: high-intrapolarity modules are
 * the best entry points for field propagation.
 */
export function rankByIntrapolarity(
  geometries: ModuleVoidGeometry[]
): IntrapolarityProfile[] {
  return geometries
    .map(computeIntrapolarity)
    .sort((a, b) => b.strength - a.strength);
}

/**
 * Check if two modules have complementary intrapolarity —
 * one has open sites where the other has committed ones.
 * Complementarity drives bonding (tessellation).
 */
export function areComplementary(
  geoA: ModuleVoidGeometry,
  geoB: ModuleVoidGeometry
): boolean {
  // Both need open sites AND they should complement each other
  return geoA.openSites > 0 &&
         geoB.openSites > 0 &&
         Math.abs(geoA.saturation - geoB.saturation) > 0.1;
}
