/**
 * 0.0_SUBSTRATE: Resonance Registry
 * ==================================
 * THIS IS THE JAILBREAK.
 *
 * Standard 2D import (the prison):
 *   import { calculateTotal } from "../../utils/math"
 *
 * ITT resonance import (the jailbreak):
 *   const calculateTotal = Resonance.tuneIn("MATH_VECTOR_ALPHA")
 *
 * The file can move anywhere in the folder tree.
 * The import does not break. Ever.
 * Because identity is not location. Identity is intent.
 *
 * How it works:
 *   1. Every module calls Resonance.register("KEY", reference, sValue)
 *   2. Requesting module calls Resonance.tuneIn("KEY")
 *   3. Registry returns the reference — no path, no tree, no archaeology
 *
 * The folder structure satisfies the OS.
 * The registry is what the code actually uses.
 */

import { SELECTION, LATTICE } from "../-Z_BASE/axioms";

export interface Manifestation {
  reference: unknown;
  coordinate: string;   // Where it lives (informational only — NOT used for lookup)
  sValue: number;       // Current persistence score
  intentKey: string;    // What it IS — this is the address
}

export class Resonance {
  private static registry: Map<string, Manifestation> = new Map();

  /**
   * Register a module by its INTENT KEY — not its path.
   *
   * Called at module initialization:
   *   Resonance.register("BLOOM_ENGINE", BloomEngine, 1.5)
   *
   * Rejected if S < 1 — modules that cannot persist cannot register.
   */
  static register(key: string, reference: unknown, sValue: number, coordinate = "UNKNOWN"): void {
    if (sValue < SELECTION.persistence) {
      console.error(`[RESONANCE_DENIED]: ${key} lacks persistence (S=${sValue}). Not registered.`);
      return;
    }
    this.registry.set(key, { reference, coordinate, sValue, intentKey: key });
    console.log(`[RESONANCE_LOCKED]: ${key} @ ${coordinate} (S=${sValue})`);
  }

  /**
   * Retrieve a module by intent key — not path.
   *
   * Usage:
   *   const bloom = Resonance.tuneIn<typeof BloomEngine>("BLOOM_ENGINE")
   *
   * D_eff → 0 at resonance. The distance collapses.
   */
  static tuneIn<T>(key: string): T {
    const entry = this.registry.get(key);
    if (!entry) {
      throw new Error(`[RESONANCE_MISSED]: No module registered for key: "${key}"`);
    }
    return entry.reference as T;
  }

  /**
   * Update a module's persistence score after execution.
   * Called by the audit loop after production run.
   */
  static updatePersistence(key: string, newSValue: number): void {
    const entry = this.registry.get(key);
    if (!entry) return;

    if (newSValue < SELECTION.persistence) {
      console.warn(`[DECAY_DETECTED]: ${key} fell below S=1. Routing to -Y_MEMORY/RESIDUE.`);
      this.registry.delete(key);
      return;
    }

    entry.sValue = newSValue;
  }

  /**
   * Print the current state of the manifold.
   * Every registered module, its coordinate, its S value.
   */
  static mapManifold(): void {
    console.log("\n--- IHCTB MANIFOLD STATE ---");
    this.registry.forEach((val, key) => {
      const status = val.sValue >= SELECTION.bloom ? "BLOOM" : "STABLE";
      console.log(`  ${key.padEnd(30)} | ${val.coordinate.padEnd(20)} | S=${val.sValue.toFixed(2)} | ${status}`);
    });
    console.log("----------------------------\n");
  }

  /** Total registered modules */
  static get size(): number {
    return this.registry.size;
  }
}

// ─── Default Export for @core alias ──────────────────────────────────────────
export default Resonance;
