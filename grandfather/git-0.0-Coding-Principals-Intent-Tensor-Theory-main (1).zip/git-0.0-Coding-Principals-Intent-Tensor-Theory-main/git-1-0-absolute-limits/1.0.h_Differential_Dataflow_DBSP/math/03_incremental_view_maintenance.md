# Incremental View Maintenance (IVM)

The practical engineering consequence of the DBSP calculus.

## The problem

A **materialized view** is a query result cached for fast access:

```sql
CREATE MATERIALIZED VIEW high_value_orders AS
SELECT * FROM orders WHERE amount > 1000;
```

Every time `orders` changes, the view must reflect the new state. Two options:

1. **Full recomputation:** rerun the query. Simple but costs $O(|orders|)$ per update.
2. **Incremental maintenance:** compute only the delta. Cost $O(|\Delta orders|)$.

IVM is the incremental approach.

## The derivation

Given view $V = Q(D)$ for input database $D$, and an update $D \to D + \Delta D$:

$$
V_\text{new} = Q(D + \Delta D).
$$

We want to compute $\Delta V = V_\text{new} - V$ efficiently. DBSP gives us the recipe.

## Linear queries

For linear $Q$ (selection, projection, union, Z-set difference):

$$
\Delta V = Q(\Delta D).
$$

I.e., *apply the same query to the delta*. Cost: proportional to $|\Delta D|$.

**Example.** For $Q = \sigma_{amount > 1000}$:
- $\Delta V = \sigma_{amount > 1000}(\Delta D)$ — filter the delta.

## Bilinear queries (joins)

For $Q = A \bowtie B$:

$$
\Delta V = \Delta A \bowtie B_\text{prev} + A_\text{prev} \bowtie \Delta B + \Delta A \bowtie \Delta B.
$$

**Cost:** requires access to the "previous" states $A_\text{prev}, B_\text{prev}$, typically stored in *arrangements* (sorted indexes).

This is the join delta rule. It is the reason Materialize keeps indexed versions of all input tables.

## Aggregation

For $Q = \gamma_\text{COUNT}(A)$ (count, grouped by some key):

$$
\Delta V = \Delta A_\text{grouped-count}.
$$

That is, group the delta by the same key and count — then add to the previous counts. Aggregation behaves like a linear operator here because COUNT is a homomorphism $\mathbb{Z}[D] \to \mathbb{Z}$.

More complex aggregates (SUM, AVG) admit similar derivations but require storing more state.

## The compiler's job

A DBSP compiler (Materialize, Feldera) takes a SQL query and:

1. Parses it into a relational algebra tree.
2. Applies algebraic laws: push $\mathbf{D}$ and $\mathbf{I}$ through operators.
3. Emits a dataflow graph of $\Delta$-versions of each operator.
4. Schedules the graph across workers.

The user sees one SQL statement; the system runs hundreds of optimized operators.

## Real-time guarantees

Well-engineered IVM systems can provide:

- **Latency:** milliseconds from input change to view update.
- **Throughput:** millions of deltas per second per core.
- **Consistency:** strict serializability (all workers agree on the current frontier).

Materialize, Feldera, and Epsio all claim such properties for various query classes.

## Hard cases

- **Nested aggregates with negation.** Require careful stratification.
- **Windowed queries.** Need explicit window-purge semantics.
- **Cross-joins.** Delta rule produces quadratic outputs; can be expensive.
- **Non-monotonic aggregates** (MIN/MAX under deletions): require extra state.

Each of these has standard engineering solutions but complicates the IVM compiler.

## Connection to fixed points

If you think of the view as an auxiliary state $V$ maintained by a function $F_Q(V, D) := Q(D)$, then IVM is exactly **change propagation on the fixed point**:

$$
V^\star_\text{new} = F_Q(V^\star_\text{old}, D_\text{new}).
$$

DBSP is the algebraic calculus that makes this propagation efficient for a wide class of $F_Q$.

## Connection to your engine

Your ITT Intent Engine, scaled to real-time inputs, is exactly an IVM problem: the "view" is the resolved state $S^\star$; the "input" is the stream of derivations and constraints fired. Recast this way, the engine can be maintained incrementally by DBSP rather than fully re-solved on every input change — the same correctness at orders-of-magnitude lower cost on continuous streams.
