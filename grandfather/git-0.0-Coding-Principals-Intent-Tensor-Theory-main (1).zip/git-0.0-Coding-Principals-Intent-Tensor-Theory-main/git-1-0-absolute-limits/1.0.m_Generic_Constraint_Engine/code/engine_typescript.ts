/**
 * ITT Intent Engine — typed TypeScript version.
 *
 * This is the engine from `git-0.*/Non_Linear_Example` and the document attached
 * to the research conversation, with proper types, explicit convergence
 * handling, and direct mapping to the math of `1.0.m/math/00_engine_formalization.md`.
 */

export type State = Record<string, unknown>;

/**
 * A Derivation D_i : S → S.
 * Returns a partial-state update (to be merged) or null if no change.
 */
export type Derivation = (s: State) => Partial<State> | null;

/**
 * A Constraint C_j : S → S with priority π(j).
 * `check` returns a corrective update if violated, or null if satisfied.
 */
export interface Constraint {
  priority: number;
  check: (s: State) => Partial<State> | null;
  label?: string;
}

export class IntentEngine {
  private state: State = {};
  private derivations: Derivation[] = [];
  private constraints: Constraint[] = [];

  /** Current immutable view of the state. */
  get current(): Readonly<State> { return { ...this.state }; }

  addDerivation(d: Derivation): this {
    this.derivations.push(d);
    return this;
  }

  addConstraint(c: Constraint): this {
    this.constraints.push(c);
    return this;
  }

  /**
   * Run the Kleene iteration F = (∏ C_j) ∘ (∏ D_i) until a fixed point.
   * Throws on non-convergence with a diagnostic message.
   */
  resolve(maxIterations = 1000): State {
    const history: string[] = [];
    for (let n = 0; n < maxIterations; n++) {
      const snapshot = JSON.stringify(this.state);
      history.push(snapshot);

      // Apply all derivations (D_i monotone propagation)
      for (const d of this.derivations) {
        const update = d(this.state);
        if (update) Object.assign(this.state, update);
      }

      // Apply constraints in decreasing priority order
      const sortedConstraints = [...this.constraints].sort(
        (a, b) => b.priority - a.priority
      );
      for (const c of sortedConstraints) {
        const fix = c.check(this.state);
        if (fix) Object.assign(this.state, fix);
      }

      // Fixed-point check
      if (JSON.stringify(this.state) === snapshot) {
        return { ...this.state };
      }

      // Oscillation detection: have we seen this state twice before?
      const seenCount = history.filter(s => s === JSON.stringify(this.state)).length;
      if (seenCount > 2) {
        throw new EngineOscillationError(
          `Engine oscillating — state seen ${seenCount} times. Conflicting intents?`,
          history
        );
      }
    }
    throw new EngineConvergenceError(
      `No fixed point within ${maxIterations} iterations. ` +
      `Review constraints for non-monotonicity.`,
      history
    );
  }

  setState(patch: Partial<State>): State {
    Object.assign(this.state, patch);
    return this.resolve();
  }
}

export class EngineOscillationError extends Error {
  constructor(msg: string, public readonly history: string[]) { super(msg); }
}
export class EngineConvergenceError extends Error {
  constructor(msg: string, public readonly history: string[]) { super(msg); }
}

// ----- Demo -----

if (require.main === module) {
  const engine = new IntentEngine();

  // D_1: eligible = email && optedIn
  engine.addDerivation((s) => ({
    eligible: Boolean(s.email && s.optedIn)
  }));

  // C_1 (priority 10): eligible ∧ ¬sent → sent
  engine.addConstraint({
    priority: 10,
    label: "send if eligible",
    check: (s) => (s.eligible && !s.sent) ? { sent: true, action: "sendEmail" } : null
  });

  // C_2 (priority 100): blocked → ¬sent
  engine.addConstraint({
    priority: 100,
    label: "blocked overrides",
    check: (s) => (s.sent && s.blocked) ? { sent: false } : null
  });

  const result = engine.setState({
    email: "a@b.com",
    optedIn: true,
    blocked: true      // priority-100 wins
  });

  console.log("Resolved:", result);
}
