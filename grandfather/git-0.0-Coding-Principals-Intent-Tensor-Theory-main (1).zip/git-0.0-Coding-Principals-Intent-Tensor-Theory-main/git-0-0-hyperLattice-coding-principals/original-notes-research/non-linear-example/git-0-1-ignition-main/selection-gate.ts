/**
 * +Z Apex Selection Gate
 * Allows manifestation only when S_sel >= threshold.
 */

export interface SelectionInput {
  retention: number;
  lossRate: number;
  tref: number;
}

export function selectionNumber(input: SelectionInput): number {
  const { retention, lossRate, tref } = input;
  if (lossRate <= 0 || tref <= 0) return Number.POSITIVE_INFINITY;
  return retention / (lossRate * tref);
}

export function gate(input: SelectionInput, threshold = 1): boolean {
  return selectionNumber(input) >= threshold;
}
