# Chapter 4 — SOP: First-Commit Manifold Initialization

## Objective
Start a project from `Phi=0` using ghostless laws.

## SOP
1. Create `.itt-manifest.json` with substrate identity, axis map, and selection gate threshold.
2. Create locked lattice roots:
   - `git-0-0-substrate-core`
   - `git-0-1-ignition-main`
   - `git-0-2-runtime-api`
   - `git-1-0-interface-ui`
3. Add `resonance.ts` in substrate core.
4. Add `selection-gate.ts` in ignition.
5. Add one experimental field run and persist logs.
6. Validate bloom behavior before adding product complexity.

## Exit criteria
- Coordinate naming invariant satisfied.
- Manifest parses and maps all active roots.
- Small-field experiment executes successfully.
