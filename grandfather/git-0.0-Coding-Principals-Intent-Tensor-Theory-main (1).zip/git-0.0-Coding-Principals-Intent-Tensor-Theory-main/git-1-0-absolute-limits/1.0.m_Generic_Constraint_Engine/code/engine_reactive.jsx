// Reactive variant of the Intent Engine using React hooks.
//
// Every useMemo is a SAC node. Priority-aware resolution is encoded
// directly in the computation of `sent`.

import React, { useState, useMemo, useEffect } from 'react';

export function ReactiveIntentEngine({ initial }) {
  const [email, setEmail]         = useState(initial.email);
  const [optedIn, setOptedIn]     = useState(initial.optedIn);
  const [blocked, setBlocked]     = useState(initial.blocked);

  // Derivation: eligible = email ∧ optedIn
  const eligible = useMemo(
    () => Boolean(email && optedIn),
    [email, optedIn]
  );

  // Constraints with priorities resolved in-order
  const sent = useMemo(() => {
    // Priority 100: blocked overrides everything
    if (blocked) return false;
    // Priority 10: eligible triggers send
    if (eligible) return true;
    return false;
  }, [eligible, blocked]);

  // Side effect: the actual "send" action
  useEffect(() => {
    if (sent) console.log("→ send email to", email);
  }, [sent, email]);

  return (
    <div style={{ fontFamily: 'monospace' }}>
      <div>email: {email || '(none)'}</div>
      <div>optedIn: {String(optedIn)}</div>
      <div>blocked: {String(blocked)}</div>
      <hr />
      <div>eligible: {String(eligible)}</div>
      <div>sent: {String(sent)}</div>
    </div>
  );
}
