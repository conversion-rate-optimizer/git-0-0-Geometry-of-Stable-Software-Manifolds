/**
 * -X_AUDIT: Entropy Tracker
 * ==========================
 * Tracks Shannon entropy H(φ) = -Σ p_i ln(p_i) over field evolution.
 * where p_i = φ_i / Σφ
 *
 * Used in Q(t) denominator to penalize fragmentation.
 * Rising entropy = field spreading, losing coherence.
 * Falling entropy = field concentrating, structure forming.
 */

import { LATTICE } from "../-Z_BASE/axioms";

export interface EntropySnapshot {
  iteration: number;
  entropy: number;
  variance: number;
  dominantNode: string | null;  // Node with highest φ
}

/**
 * Compute Shannon entropy of current field distribution.
 */
export function fieldEntropy(phi: Map<string, number>): number {
  const total = Array.from(phi.values()).reduce((s, v) => s + v, 0);
  if (total < LATTICE.epsilon_field) return 0;

  let H = 0;
  for (const val of phi.values()) {
    const p = val / total;
    if (p > LATTICE.epsilon_field) H -= p * Math.log(p);
  }
  return H;
}

/**
 * Compute field variance.
 */
export function fieldVariance(phi: Map<string, number>): number {
  const vals = Array.from(phi.values());
  const n = vals.length;
  if (n === 0) return 0;
  const mean = vals.reduce((s, v) => s + v, 0) / n;
  return vals.reduce((s, v) => s + (v - mean) ** 2, 0) / n;
}

export class EntropyTracker {
  private history: EntropySnapshot[] = [];
  private maxHistory = 100;

  record(iteration: number, phi: Map<string, number>): EntropySnapshot {
    const entropy = fieldEntropy(phi);
    const variance = fieldVariance(phi);

    let dominantNode: string | null = null;
    let maxPhi = -Infinity;
    for (const [id, val] of phi) {
      if (val > maxPhi) { maxPhi = val; dominantNode = id; }
    }

    const snapshot: EntropySnapshot = { iteration, entropy, variance, dominantNode };
    if (this.history.length >= this.maxHistory) this.history.shift();
    this.history.push(snapshot);
    return snapshot;
  }

  /** Is entropy decreasing? (structure forming) */
  get isDecreasing(): boolean {
    if (this.history.length < 3) return false;
    const n = this.history.length;
    return this.history[n-1].entropy < this.history[n-2].entropy &&
           this.history[n-2].entropy < this.history[n-3].entropy;
  }

  get latest(): EntropySnapshot | undefined {
    return this.history[this.history.length - 1];
  }

  get series(): EntropySnapshot[] { return [...this.history]; }
}
