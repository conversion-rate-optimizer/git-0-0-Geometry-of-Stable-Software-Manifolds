/**
 * 0.1_LATTICE: Field Diffuser
 * ============================
 * Runs the discrete field diffusion:
 *   φ(t+1) = λs + (1-λ)D⁻¹Wφ(t)
 *
 * This is a contractive affine operator — unique fixed point guaranteed
 * when spectral radius of (1-λ)D⁻¹W < 1.
 *
 * The system solves:
 *   φ* = (I - (1-λ)D⁻¹W)⁻¹(λs)
 *
 * Minimizing energy:
 *   E(φ) = ½Σ W_ij(φ_i-φ_j)² + λ/2(1-λ) Σ(φ_i-s_i)²
 */

import { LATTICE } from "../-Z_BASE/axioms";

/**
 * Single diffusion step for all nodes.
 *   φ_i(t+1) = λs_i + (1-λ) * Σ_j (W_ij/d_i) * φ_j(t)
 */
export function diffuseStep(
  phi: Map<string, number>,
  seed: Map<string, number>,
  W: Map<string, Map<string, number>>,
  lambda: number = LATTICE.lambda
): Map<string, number> {
  const next = new Map<string, number>();

  for (const [id] of phi) {
    const s_i = seed.get(id) ?? 0;
    const neighbors = W.get(id);

    let neighborSum = 0;
    let degree = 0;

    if (neighbors) {
      for (const [nId, w] of neighbors) {
        neighborSum += w * (phi.get(nId) ?? 0);
        degree += w;
      }
    }

    const diffused = degree > 0 ? neighborSum / degree : 0;
    next.set(id, lambda * s_i + (1 - lambda) * diffused);
  }

  return next;
}

/**
 * Run diffusion until convergence or max iterations.
 * Returns final field and number of steps taken.
 */
export function diffuseToEquilibrium(
  seed: Map<string, number>,
  W: Map<string, Map<string, number>>,
  lambda: number = LATTICE.lambda,
  maxIterations: number = LATTICE.settle_iterations
): { phi: Map<string, number>; steps: number; converged: boolean } {
  let phi = new Map(seed);
  let steps = 0;
  let converged = false;

  for (steps = 0; steps < maxIterations; steps++) {
    const next = diffuseStep(phi, seed, W, lambda);

    // Check convergence
    let maxDelta = 0;
    for (const [id, val] of next) {
      maxDelta = Math.max(maxDelta, Math.abs(val - (phi.get(id) ?? 0)));
    }

    phi = next;

    if (maxDelta < LATTICE.epsilon_field * 100) {
      converged = true;
      break;
    }
  }

  return { phi, steps, converged };
}
