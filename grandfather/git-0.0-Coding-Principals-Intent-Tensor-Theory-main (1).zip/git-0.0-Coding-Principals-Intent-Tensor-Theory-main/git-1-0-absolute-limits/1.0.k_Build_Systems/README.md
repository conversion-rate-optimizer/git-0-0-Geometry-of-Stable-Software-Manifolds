# 1.0.k — Build Systems

The task abstraction of Mokhov, Mitchell, and Peyton Jones (ICFP 2018).

## Files

**Math:**
- `math/00_task_abstraction.md` — Applicative, monadic, and selective tasks.
- `math/01_rebuilder_scheduler.md` — Design-space decomposition.
- `math/02_multi_substrate_extension.md` — Where ITT's vision extends.

**Code:**
- `code/shake_example.hs` — Haskell Shake.
- `code/Makefile` — Classic Make.
- `code/BUILD.bazel` — Bazel rules.
- `code/default.nix` — Nix derivations.
