/**
 * -Y_MEMORY: Residue Sink
 * ========================
 * Routes nodes that fail S < 1 to the sigma archive.
 * Connects the selection gate output to the sigma store.
 *
 * Residue is not garbage — it is sub-persistent potential.
 * Under different seeds or changed graph topology,
 * today's residue may become tomorrow's anchor.
 */

import { SigmaStore } from "./sigma_store";
import { selectionNumber } from "../+Z_APEX/s_gate";

export interface SinkResult {
  routed: number;       // How many nodes were archived
  totalPhiLost: number; // Total field energy moved to residue
}

/**
 * Process noise nodes into the sigma store.
 */
export function sinkToResidue(
  noiseNodes: string[],
  phi: Map<string, number>,
  phi_prev: Map<string, number>,
  sigma: SigmaStore,
  iteration: number
): SinkResult {
  let totalPhiLost = 0;

  for (const id of noiseNodes) {
    const p = phi.get(id) ?? 0;
    const S = selectionNumber(p, phi_prev.get(id) ?? 0);
    sigma.store(id, p, S, iteration);
    totalPhiLost += p;
  }

  return { routed: noiseNodes.length, totalPhiLost };
}

/**
 * Mine residue for nodes that might succeed under a new seed.
 * Returns a supplemental seed map from archived φ values.
 */
export function mineResidue(
  sigma: SigmaStore,
  minPhi: number = 0.05
): Map<string, number> {
  return sigma.toSeed(minPhi);
}
