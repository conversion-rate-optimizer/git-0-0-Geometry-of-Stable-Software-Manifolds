# Widening and Narrowing

How to force termination on infinite-height abstract domains.

## The problem

The Kleene chain $\bot, F^\sharp(\bot), (F^\sharp)^2(\bot), \ldots$ is guaranteed to reach $\operatorname{lfp}(F^\sharp)$ only if $F^\sharp$ is Scott-continuous *and* the lattice has no infinite ascending chains (or the chain happens to stabilize).

Interval lattice, polyhedral lattice, octagon lattice — all have infinite ascending chains:

$$
[0, 0] \sqsubset [0, 1] \sqsubset [0, 2] \sqsubset \cdots
$$

On these domains, naive Kleene iteration does not terminate. Abstract interpretation needs a different mechanism.

## Widening

**Definition.** A **widening operator** on an abstract lattice $A$ is a binary operator $\triangledown : A \times A \to A$ satisfying:

1. **Covering:** $a \leq_A (a \triangledown b)$ and $b \leq_A (a \triangledown b)$.
2. **Termination:** For any infinite sequence $x_0, x_1, x_2, \ldots$ in $A$, the sequence

$$
y_0 := x_0, \qquad y_{n+1} := y_n \triangledown x_{n+1}
$$

is eventually stationary.

Widening **sacrifices precision to gain termination**.

## Example: interval widening

For intervals $[a_1, b_1]$ and $[a_2, b_2]$:

$$
[a_1, b_1] \triangledown [a_2, b_2] = [a', b']
$$

where:
- $a' = a_1$ if $a_1 \leq a_2$, else $-\infty$.
- $b' = b_1$ if $b_1 \geq b_2$, else $+\infty$.

Interpretation: if the lower bound shrinks (moves down), jump to $-\infty$. If the upper bound grows, jump to $+\infty$. Otherwise keep the current bound.

This is a "jumping" widening: it accelerates unbounded growth.

### Iteration with widening

Given the concrete Kleene iteration $x_{n+1} = F^\sharp(x_n)$, replace with the widening iteration:

$$
y_0 = \bot, \qquad y_{n+1} = y_n \triangledown F^\sharp(y_n).
$$

**Theorem.** The widening sequence $(y_n)$ stabilizes at some $y^\star$ with $\operatorname{lfp}(F^\sharp) \leq y^\star$ (possibly strictly greater; widening is over-approximating).

## Narrowing

Widening gives a sound but possibly imprecise fixed point. **Narrowing** refines it downward.

**Definition.** A **narrowing operator** $\triangle : A \times A \to A$ satisfies:

1. **Bounded:** $a \wedge b \leq_A (a \triangle b) \leq_A a$ whenever $b \leq_A a$.
2. **Termination:** For any infinite descending sequence, narrowing eventually stabilizes.

### Iteration with narrowing

Starting from the widening fixed point $y^\star$, iterate downward:

$$
z_0 = y^\star, \qquad z_{n+1} = z_n \triangle F^\sharp(z_n).
$$

Each $z_n$ is a sound over-approximation (still $\geq \operatorname{lfp}(F^\sharp)$), but tighter than $y^\star$.

## Example: narrowing for intervals

$$
[a_1, b_1] \triangle [a_2, b_2] = [a', b']
$$

where:
- $a' = a_2$ if $a_1 = -\infty$, else $a_1$.
- $b' = b_2$ if $b_1 = +\infty$, else $b_1$.

Interpretation: if the current bound is "infinite" (a widening artifact) but the new computation gives a finite bound, tighten to the finite bound. Otherwise keep the current bound.

## The widening-narrowing cycle

A classical abstract interpretation runs:

```
1. Widening phase:   iterate y_{n+1} = y_n ▽ F#(y_n) until stable.
2. Narrowing phase:  iterate z_{n+1} = z_n △ F#(z_n) for a few rounds.
3. Return z_∞ as the answer.
```

The result is a sound over-approximation of $\operatorname{lfp}(F^\sharp)$ that is usually much tighter than the raw widening result.

## The ICHTB uncertainty analogy

Widening embodies a **precision ↔ termination trade-off**: you can be more precise (use a tighter widening, iterate longer) or terminate faster (use a more aggressive widening).

This is the nearest standard-mathematical analog of ITT's **ICHTB uncertainty relation** — a constraint on the product of precision and speed in constraint propagation. The widening-narrowing analysis framework is where the ITT perspective might yield a genuinely new theorem: a formal lower bound on (termination cost) × (precision loss) for any widening operator.

## Design space

Widenings are *not* unique. For intervals alone, several standard widenings exist:

- **$\triangledown_\infty$ (jumping to infinity):** as above. Fast but imprecise.
- **$\triangledown_k$ (bounded):** jump to a fixed constant $k$ instead of $\infty$. More precise, but requires tuning.
- **$\triangledown_T$ (thresholded):** parameterize by a finite set of "interesting" values; jump to the next threshold above the current one. Most precise; slower.

Polyhedral widenings, octagonal widenings, etc. each have their own design choices.

## The limit

**No widening is complete.** If you want to prove $x \leq 100$ and your widening jumps to $\infty$, the analysis will fail to prove the bound even when it holds. This is why verifying tight numerical properties of programs is hard even with abstract interpretation — you're fundamentally in an incomplete regime.

For truly tight analysis, you need:
- Domain-specific widenings, or
- Model checking / SMT-based refinement (CEGAR), or
- Relational domains (polyhedra, octagons) instead of non-relational (signs, intervals).

All three are active research areas.
