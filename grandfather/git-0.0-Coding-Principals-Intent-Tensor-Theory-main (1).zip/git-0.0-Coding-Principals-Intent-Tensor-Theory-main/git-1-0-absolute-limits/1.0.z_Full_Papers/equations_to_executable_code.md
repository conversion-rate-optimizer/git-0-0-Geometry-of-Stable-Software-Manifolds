# From Equations to Executable Code

### The Translation Manual: What You Literally Type to Realize the Math

---

## Abstract

This is the companion manual to *Fixed-Point Semantics of Dynamic Computation*. For every mathematical object in that paper — lattices, fixed-point operators, Galois connections, immediate-consequence operators, Z-sets, stable-model reducts, dependent-function types, task abstractions — we give the literal syntax that expresses it in code. The governing principle throughout is: **mathematical notation and programming syntax are the same artifact at different levels of formality**. Haskell's `::` ("has type") is the closest syntactic kin to the mathematician's `:` ("is an element of") — we use it as our Rosetta Stone. Python, JavaScript, Rust, OCaml, Lean 4, and Clingo are shown where each is canonical for the paradigm at hand. The mapping is direct, not metaphorical.

---

## 0. The Universal Translation Principle

The core correspondence:

| Mathematics                     | Haskell                           | Python type hint              | What you type                       |
|---------------------------------|-----------------------------------|-------------------------------|-------------------------------------|
| $x \in A$                       | `x :: A`                          | `x: A`                        | a value declaration                 |
| $f : A \to B$                   | `f :: A -> B`                     | `f: Callable[[A], B]`         | a function signature                |
| $f : A \times B \to C$          | `f :: (A, B) -> C`                | `f: Callable[[A, B], C]`      | a two-arg function                  |
| $\forall x : A.\; P(x)$         | `forall a. P a => ...`            | `TypeVar('A')` + generics     | a polymorphic function              |
| $\sum_{x : A} B(x)$             | `data Sigma a = MkSigma a (B a)`  | `Tuple[A, B]` with deps       | a dependent pair (approximated)     |
| $\prod_{x : A} B(x)$            | `(a :: A) -> B a` (in Idris/Lean) | —                             | dependent function (true DTT only)  |
| composition $g \circ f$         | `g . f`                           | `lambda x: g(f(x))`           | function composition                |
| fixed point $\operatorname{lfp}(F)$ | `fix F` or `lfp F`            | custom `lfp(F)`               | iteration until stable              |

The `::` in Haskell is exactly the mathematician's $\in$ and $:$ unified. When you write `f :: A -> B`, you are asserting the same fact as $f : A \to B$ in the paper. That is the translation. Everything else is mechanics.

---

## 1. Representing a Lattice in Code

The mathematical object

$$
(L, \leq, \vee, \wedge, \bot, \top)
$$

translates to a **typeclass** (Haskell) or **protocol** (Python) or **trait** (Rust).

### Haskell
```haskell
class Lattice a where
  bottom :: a
  top    :: a
  (\/)   :: a -> a -> a   -- join
  (/\)   :: a -> a -> a   -- meet
  leq    :: a -> a -> Bool

-- Example: sets ordered by inclusion
instance Ord k => Lattice (Set k) where
  bottom = Set.empty
  top    = error "no top for unbounded Set"  -- partial lattice
  (\/)   = Set.union
  (/\)   = Set.intersection
  leq    = Set.isSubsetOf
```

### Python
```python
from typing import Protocol, TypeVar
from abc import abstractmethod

A = TypeVar('A')

class Lattice(Protocol[A]):
    @abstractmethod
    def bottom(self) -> A: ...
    @abstractmethod
    def top(self) -> A: ...
    @abstractmethod
    def join(self, x: A, y: A) -> A: ...
    @abstractmethod
    def meet(self, x: A, y: A) -> A: ...
    @abstractmethod
    def leq(self, x: A, y: A) -> bool: ...

class PowerSetLattice(Lattice[frozenset]):
    def bottom(self): return frozenset()
    def top(self):    raise NotImplementedError
    def join(self, x, y): return x | y
    def meet(self, x, y): return x & y
    def leq(self, x, y):  return x <= y
```

### JavaScript (your stack)
```javascript
class Lattice {
  bottom()           { throw new Error("abstract"); }
  top()              { throw new Error("abstract"); }
  join(x, y)         { throw new Error("abstract"); }
  meet(x, y)         { throw new Error("abstract"); }
  leq(x, y)          { throw new Error("abstract"); }
}

class PowerSetLattice extends Lattice {
  bottom()           { return new Set(); }
  join(x, y)         { return new Set([...x, ...y]); }
  meet(x, y)         { return new Set([...x].filter(e => y.has(e))); }
  leq(x, y)          { return [...x].every(e => y.has(e)); }
}
```

**What you actually write** when the math says "let $L$ be a complete lattice": you write an instance/class that provides `bottom`, `join`, `meet`, and `leq`. That's it. The typeclass/protocol is the exact encoding of the algebraic structure.

---

## 2. The Fixed-Point Function

The Kleene formula

$$
\operatorname{lfp}(F) = \bigvee_{n \geq 0} F^n(\bot)
$$

translates directly.

### Haskell
```haskell
-- :: says "the type of this thing is"
-- (a -> a) -> a  means "give me a function from a to a, I'll give you back an a"
lfp :: Eq a => (a -> a) -> a -> a
lfp f x = let x' = f x
          in if x' == x then x else lfp f x'

-- Usage
main = print $ lfp (\n -> min 100 (n + 7)) 0  -- stabilizes at 98 then 100... nope, 105 > 100 so → 100
```

The type signature `lfp :: Eq a => (a -> a) -> a -> a` reads literally: *"`lfp` is a thing which, for any type `a` that has equality, takes a function `a -> a` and an `a`, and produces an `a`."* That is exactly the mathematical statement that $\operatorname{lfp}$ operates on endofunctions of $L$.

### Python
```python
from typing import Callable, TypeVar
A = TypeVar('A')

def lfp(f: Callable[[A], A], x: A) -> A:
    while True:
        x_next = f(x)
        if x_next == x:
            return x
        x = x_next
```

### JavaScript
```javascript
function lfp(f, x) {
  while (true) {
    const xNext = f(x);
    if (deepEqual(xNext, x)) return x;
    x = xNext;
  }
}

// deepEqual for JS objects:
function deepEqual(a, b) { return JSON.stringify(a) === JSON.stringify(b); }
```

### Rust
```rust
fn lfp<A: PartialEq + Clone>(f: impl Fn(A) -> A, mut x: A) -> A {
    loop {
        let x_next = f(x.clone());
        if x_next == x { return x; }
        x = x_next;
    }
}
```

**What you actually write for "compute the least fixed point"**: `lfp(F, bottom)`. That's the literal code. It will loop forever if `F` isn't monotone or the lattice has infinite ascending chains — this is the real content of the convergence theorems.

---

## 3. Monotone Functions — The `::` That Enforces Math

The mathematical statement "$F$ is monotone" cannot be enforced by the type system in most languages, but the *discipline* of writing it is visible in the signature.

### Haskell
```haskell
-- A monotone function on a lattice:
-- We can't enforce monotonicity in vanilla Haskell, but we document the contract.
type Monotone a = a -> a

-- Actually using a refinement type library (Liquid Haskell):
{-@ type Monotone a = {f : a -> a | forall x y. leq x y => leq (f x) (f y)} @-}
```

### Dependent types (Lean 4) — *here* we can enforce it
```lean
-- In Lean 4, we can state and prove monotonicity
structure MonotoneFunc (α : Type) [PartialOrder α] where
  f      : α → α
  mono   : ∀ x y, x ≤ y → f x ≤ f y
```

This is the Curry-Howard content of §10: a monotone function *is* a function together with a proof of its monotonicity. The type signature carries the theorem.

---

## 4. Abstract Interpretation: Galois Connections in Code

The pair

$$
C \underset{\gamma}{\overset{\alpha}{\rightleftarrows}} A
$$

is literally a pair of functions.

### Haskell
```haskell
data Galois c a = Galois
  { alpha   :: c -> a   -- abstraction
  , gamma   :: a -> c   -- concretization
  }

-- Example: abstracting integers to signs {-, 0, +, ⊤}
data Sign = Neg | Zero | Pos | Top deriving (Eq, Show)

intToSign :: Galois Int Sign
intToSign = Galois
  { alpha = \n -> if n < 0 then Neg else if n == 0 then Zero else Pos
  , gamma = \s -> case s of Neg -> -1; Zero -> 0; Pos -> 1; Top -> 0
  }

-- Abstract operator F# that over-approximates the concrete F
absAdd :: Sign -> Sign -> Sign
absAdd Zero y = y
absAdd x Zero = x
absAdd Pos Pos = Pos
absAdd Neg Neg = Neg
absAdd _ _ = Top
```

### Python
```python
from dataclasses import dataclass
from typing import Callable, TypeVar, Generic
C = TypeVar('C'); A = TypeVar('A')

@dataclass
class Galois(Generic[C, A]):
    alpha: Callable[[C], A]
    gamma: Callable[[A], C]

# Signs abstraction
class Sign:
    NEG, ZERO, POS, TOP = 'neg', 'zero', 'pos', 'top'

int_to_sign = Galois(
    alpha=lambda n: Sign.NEG if n < 0 else Sign.ZERO if n == 0 else Sign.POS,
    gamma=lambda s: {-1: Sign.NEG, 0: Sign.ZERO, 1: Sign.POS}.get(s, 0),
)
```

**What you actually write for abstract interpretation**: a pair of functions (abstract ↔ concrete) plus abstract versions of each concrete operator. The soundness proof from §4.2 of the prior paper is then a property you verify (or prove in Lean).

---

## 5. Datalog: The Direct Translation of `h :- b1, b2`

### A Datalog rule
```datalog
path(X, Y) :- edge(X, Y).
path(X, Y) :- edge(X, Z), path(Z, Y).
```

### In Python with a hand-rolled engine
```python
from itertools import product

def immediate_consequence(rules, facts):
    """T_P operator: one step of Datalog evaluation."""
    new_facts = set(facts)
    for head, body in rules:
        # Find all substitutions σ that make body ⊆ facts
        for sigma in all_bindings(body, facts):
            new_facts.add(apply(head, sigma))
    return new_facts

def all_bindings(body, facts, sigma=None):
    """Yield every substitution satisfying all body atoms against facts."""
    sigma = sigma or {}
    if not body:
        yield sigma
        return
    atom, *rest = body
    for fact in facts:
        unified = unify(atom, fact, dict(sigma))
        if unified is not None:
            yield from all_bindings(rest, facts, unified)

def unify(pattern, fact, sigma):
    if pattern[0] != fact[0] or len(pattern) != len(fact):
        return None
    for p, f in zip(pattern[1:], fact[1:]):
        if is_var(p):
            if p in sigma and sigma[p] != f: return None
            sigma[p] = f
        elif p != f:
            return None
    return sigma

def is_var(x): return isinstance(x, str) and x[0].isupper()
def apply(atom, sigma):
    return tuple([atom[0]] + [sigma.get(t, t) for t in atom[1:]])

# The least fixed point is Kleene iteration:
def datalog_lfp(rules, initial_facts):
    return lfp(lambda facts: immediate_consequence(rules, facts), frozenset(initial_facts))
```

### In Rust with Datafrog
```rust
use datafrog::{Iteration, Relation};

fn compute_paths(edges: Vec<(u32, u32)>) -> Relation<(u32, u32)> {
    let mut iter = Iteration::new();
    let path   = iter.variable::<(u32, u32)>("path");
    let edge_r = Relation::from_iter(edges);

    path.extend(edge_r.iter().cloned());
    while iter.changed() {
        // path(X, Y) :- edge(X, Z), path(Z, Y).
        path.from_join(&path, &edge_r, |_z, &y, &x| (x, y));
    }
    path.complete()
}
```

The Rust version makes the Kleene iteration (`while iter.changed()`) and the join (`from_join`) explicit. This is what semi-naive evaluation looks like in production.

**What you actually write for a Datalog rule**: you write the head and body as pattern-matching structures, and call `lfp` on the immediate-consequence operator. That is the entire translation.

---

## 6. SAT and SMT: Constraints as First-Class Objects

### Z3 in Python — the canonical SMT interface
```python
from z3 import Solver, Int, Bool, And, Or, Not, Implies, sat

# Mathematical statement:
#   ∃ x, y ∈ ℤ such that x + 2y = 7 ∧ x > 0 ∧ y > 0
# Code:
x = Int('x')
y = Int('y')
s = Solver()
s.add(x + 2*y == 7)
s.add(x > 0, y > 0)

if s.check() == sat:
    m = s.model()
    print(f"x = {m[x]}, y = {m[y]}")
else:
    print("unsat")
```

The `Int('x')` is the code for "$x \in \mathbb{Z}$." The `s.add(...)` is the code for "add constraint $\varphi$ to the system." The `s.check()` runs DPLL(T) and returns `sat`, `unsat`, or `unknown` (the last one is how the undecidable ceiling of §12 appears in practice).

### Encoding your Intent engine as SMT
```python
from z3 import Solver, Bool, Implies, And, Not

email_present = Bool('email_present')
opted_in      = Bool('opted_in')
eligible      = Bool('eligible')
sent          = Bool('sent')
blocked       = Bool('blocked')

s = Solver()

# Derivation: eligible ⇔ email_present ∧ opted_in
s.add(eligible == And(email_present, opted_in))

# Constraint (priority 10): eligible ∧ ¬sent → sent
s.add(Implies(And(eligible, Not(sent)), sent))   # forces sent = True when eligible

# Higher-priority constraint: blocked → ¬sent
s.add(Implies(blocked, Not(sent)))

# Input:
s.add(email_present == True, opted_in == True, blocked == False)

print(s.check())           # sat
print(s.model())           # eligible=True, sent=True
```

The priority system from your engine becomes soft constraints in weighted SMT:

```python
from z3 import Optimize

opt = Optimize()
opt.add(eligible == And(email_present, opted_in))

# Soft constraint with weight 10:
opt.add_soft(Implies(And(eligible, Not(sent)), sent), weight=10)
# Soft constraint with weight 100 (higher priority):
opt.add_soft(Implies(blocked, Not(sent)), weight=100)

opt.add(email_present == True, opted_in == True, blocked == True)
opt.check()
print(opt.model())  # sent = False, because blocked wins (higher weight)
```

**This is your engine as SMT.** The `add_soft(constraint, weight=N)` is literally the priority parameter from your `addConstraint(fn, priority)`. Z3 solves the lexicographic MaxSAT problem from §13.3 of the prior paper.

---

## 7. Self-Adjusting Computation: Jane Street `Incremental`

### OCaml (the canonical Incremental library)
```ocaml
open Core
open Incremental

module Inc = Incremental.Make ()

let x = Inc.Var.create 10
let y = Inc.Var.create 20

(* Build a graph: z depends on x and y *)
let z = Inc.map2 (Inc.Var.watch x) (Inc.Var.watch y) ~f:(fun a b -> a + b)

(* Observe z to make it active *)
let z_obs = Inc.observe z

let () =
  Inc.stabilize ();
  printf "z = %d\n" (Inc.Observer.value_exn z_obs);   (* 30 *)

  (* Change x; only z recomputes, nothing else *)
  Inc.Var.set x 99;
  Inc.stabilize ();
  printf "z = %d\n" (Inc.Observer.value_exn z_obs)    (* 119 *)
```

The `map2 a b ~f` corresponds to building a node in the self-adjusting DAG. `stabilize` runs the change-propagation algorithm from §7.2 of the prior paper.

### React hooks as SAC (your JavaScript stack)
```javascript
import { useState, useMemo } from 'react';

function MyComponent() {
  const [x, setX] = useState(10);
  const [y, setY] = useState(20);

  // useMemo is literally change propagation:
  // recompute only when x or y changes.
  const z = useMemo(() => {
    console.log("recomputing z");
    return x + y;
  }, [x, y]);   // <-- dependency list = read set

  return <div>{z}</div>;
}
```

React's `useMemo` dependency array is the set of modifiables from §7.1. The React reconciler is the change-propagation algorithm of §7.2. **Your JavaScript frontend is already running a self-adjusting computation** — you are using the math from the prior paper every time you write a React component.

### Python Adapton-style with explicit thunks
```python
class Thunk:
    def __init__(self, fn, deps):
        self.fn = fn
        self.deps = deps
        self.cached = None
        self.dirty = True

    def force(self):
        if self.dirty:
            self.cached = self.fn()
            self.dirty = False
        return self.cached

    def invalidate(self):
        self.dirty = True

# Build the graph
x = {'val': 10, 'subscribers': []}
y = {'val': 20, 'subscribers': []}
z = Thunk(lambda: x['val'] + y['val'], deps=[x, y])
x['subscribers'].append(z)
y['subscribers'].append(z)

def set_var(var, new_val):
    var['val'] = new_val
    for t in var['subscribers']:
        t.invalidate()
```

---

## 8. Differential Dataflow & DBSP

### Timely/Differential Dataflow in Rust
```rust
use timely::dataflow::InputHandle;
use differential_dataflow::input::Input;
use differential_dataflow::operators::{Join, Count, Iterate};

fn main() {
    timely::execute_from_args(std::env::args(), |worker| {
        let mut edges = InputHandle::new();

        worker.dataflow::<u64, _, _>(|scope| {
            let edges = edges.to_collection(scope);

            // path(X, Y) :- edge(X, Y); path(X, Y) :- path(X, Z), edge(Z, Y)
            let paths = edges.iterate(|transitive| {
                edges.enter(&transitive.scope())
                     .join_map(&transitive, |_z, &x, &y| (x, y))
                     .concat(&edges.enter(&transitive.scope()))
                     .distinct()
            });

            paths.inspect(|x| println!("{:?}", x));
        });

        // Feed edges and changes
        edges.insert((1, 2)); edges.insert((2, 3)); edges.insert((3, 4));
        edges.advance_to(1);
    }).unwrap();
}
```

The `.iterate(|x| ...)` is literally the `lfp` from §3.2. The `.join_map(...)` is the join operator extended to Z-sets. When you `.advance_to(1)`, you're telling the frontier (the partial order on timestamps from §8.6) to move, and differential dataflow recomputes only the deltas.

### DBSP / Materialize SQL — the declarative face
```sql
-- Create a streaming source:
CREATE SOURCE edges (src INT, dst INT) FROM KAFKA ...;

-- Create an incremental materialized view.
-- This is literally Q^Δ = D ∘ Q ∘ I from §8.4:
CREATE MATERIALIZED VIEW paths AS
  WITH RECURSIVE p(src, dst) AS (
    SELECT src, dst FROM edges
    UNION
    SELECT e.src, p.dst FROM edges e, p WHERE e.dst = p.src
  )
  SELECT * FROM p;

-- Every INSERT/DELETE on edges automatically updates paths incrementally.
-- You wrote one SQL statement; the system synthesized the incremental version.
```

**What you actually write for "maintain this view as data changes"**: one SQL query. The DBSP algebra from §8 is applied at compile time; you never see it.

---

## 9. Answer Set Programming: Clingo

### Clingo rule syntax
```prolog
% The Gelfond-Lifschitz reduct is computed under the hood.
% You just write the rules.

% Facts:
node(1..5).
edge(1,2). edge(2,3). edge(3,4). edge(4,5). edge(5,1).

% Choice rule: select a subset of nodes as a "cover"
{ in_cover(X) } :- node(X).

% Constraint: every edge must have at least one endpoint in the cover
:- edge(X, Y), not in_cover(X), not in_cover(Y).

% Minimize cover size:
#minimize { 1,X : in_cover(X) }.
```

### Python-Clingo integration
```python
import clingo

ctl = clingo.Control()
ctl.add("base", [], """
    node(1..5).
    edge(1,2). edge(2,3). edge(3,4). edge(4,5). edge(5,1).
    { in_cover(X) } :- node(X).
    :- edge(X, Y), not in_cover(X), not in_cover(Y).
    #minimize { 1,X : in_cover(X) }.
""")
ctl.ground([("base", [])])

with ctl.solve(yield_=True) as handle:
    for model in handle:
        print(model.symbols(atoms=True))
```

The `:- body.` is a *constraint* (forbid models where body is true). The `{ a } :- body.` is a *choice* rule (optionally derive `a`). The `#minimize` is a weighted soft constraint — exactly the MaxSAT formulation from §6.8.

**What you write for "find all consistent worlds satisfying these rules"**: the rules, in logical syntax, and `ctl.solve()`. The Gelfond-Lifschitz reduct (§9.2) runs internally.

---

## 10. Curry–Howard in Actual Proof Assistants

### Lean 4 — proposition as type, proof as program
```lean
-- The proposition "for all natural numbers n, n + 0 = n"
-- is literally a dependent function type:
theorem add_zero : ∀ (n : Nat), n + 0 = n := by
  intro n            -- assume n : Nat
  induction n with
  | zero   => rfl    -- 0 + 0 = 0 by reflexivity
  | succ k ih => rw [Nat.add_succ, ih]

-- The same theorem, written as a program (not tactic mode):
def add_zero' : (n : Nat) → n + 0 = n
  | 0      => rfl
  | n + 1  => congrArg (· + 1) (add_zero' n)
```

**The type `(n : Nat) → n + 0 = n` is the proposition. The term is the proof. Running the type-checker *is* verifying the proof.** This is §10 made concrete.

### Haskell with GADTs — a weaker form
```haskell
{-# LANGUAGE GADTs, DataKinds, KindSignatures, TypeFamilies #-}

-- Peano naturals at the type level
data Nat = Z | S Nat

-- Vectors indexed by length
data Vec (n :: Nat) a where
  VNil  :: Vec 'Z a
  VCons :: a -> Vec n a -> Vec ('S n) a

-- A function whose type guarantees it preserves length
vmap :: (a -> b) -> Vec n a -> Vec n b
vmap _ VNil         = VNil
vmap f (VCons x xs) = VCons (f x) (vmap f xs)
```

The type `Vec n a` is a *dependent type*: its type depends on the length `n`. Writing `vmap` wrong (e.g., dropping an element) would not type-check — the type system enforces the invariant.

### Idris (full dependent types)
```idris
-- Length-indexed append; guaranteed to produce a vector of length n + m.
append : Vect n a -> Vect m a -> Vect (n + m) a
append Nil       ys = ys
append (x :: xs) ys = x :: append xs ys
```

**The compiler checks that the lengths line up.** You cannot even write an incorrect `append` that compiles.

---

## 11. Build Systems: The Task Abstraction in Code

### Shake (Haskell) — the purest task formulation
```haskell
import Development.Shake

main :: IO ()
main = shakeArgs shakeOptions $ do
  -- Target: build all .o files
  want ["hello.o"]

  -- Task: how to produce *.o from *.c
  "*.o" %> \out -> do
    let src = out -<.> "c"
    need [src]                -- declare dependency
    cmd_ "gcc" "-c" src "-o" out
```

The `%>` is the task declaration; `need [src]` is the monadic effect `f v` from §11.1 of the prior paper. Shake's rebuilder is "verifying trace" and its scheduler is "suspending."

### Nix derivations — fixed points at the package level
```nix
let
  hello = derivation {
    name    = "hello";
    system  = "x86_64-linux";
    builder = "/bin/sh";
    args    = [ "-c" "echo hello > $out" ];
  };
in hello
```

Every Nix derivation is keyed by the hash of its inputs. Two builds with identical inputs produce identical outputs (content-addressed). The "build" is the fixed-point computation that resolves all transitive dependencies.

### Bazel (your stack maybe, given Cloudflare workflows)
```python
# BUILD.bazel
cc_library(
    name = "mathlib",
    srcs = ["math.cc"],
    hdrs = ["math.h"],
)

cc_binary(
    name = "main",
    srcs = ["main.cc"],
    deps = [":mathlib"],
)
```

`deps = [":mathlib"]` is the task abstraction in practice.

---

## 12. Your Generic Engine — Fully Typed and Fully Translated

Here is the engine from your document, with every piece of math from the prior paper made explicit.

### The math, restated
- State: $S \in \mathcal{S}$.
- Derivations: $D_i : \mathcal{S} \to \mathcal{S}$, each a partial-update function.
- Constraints with priority: $(C_j, \pi(j))$ where $C_j : \mathcal{S} \to \mathcal{S}$ projects onto a validity surface.
- Global operator: $F = \left(\bigcirc_j C_j\right) \circ \left(\bigcirc_i D_i\right)$, constraints composed in decreasing priority order.
- Execution: $S^\star = \operatorname{lfp}(F)$ via Kleene iteration.

### TypeScript version (typed, so `::` reads clearly)
```typescript
// Types correspond exactly to the math.
type State = Record<string, unknown>;

// A Derivation D_i : S → S (returns a partial update to merge)
type Derivation = (s: State) => Partial<State> | null;

// A Constraint C_j : S → S (returns a corrective update, or null if satisfied)
type Constraint = {
  priority: number;
  check: (s: State) => Partial<State> | null;
};

class IntentEngine {
  private state: State = {};
  private derivations: Derivation[] = [];
  private constraints: Constraint[] = [];

  // Build F = (∏ C_j) ∘ (∏ D_i) via Kleene iteration.
  resolve(maxIterations = 1000): State {
    for (let n = 0; n < maxIterations; n++) {
      const snapshot = JSON.stringify(this.state);

      // Derivations (monotone propagation)
      for (const D of this.derivations) {
        const update = D(this.state);
        if (update) Object.assign(this.state, update);
      }

      // Constraints in decreasing priority order
      const sorted = [...this.constraints].sort((a, b) => b.priority - a.priority);
      for (const C of sorted) {
        const fix = C.check(this.state);
        if (fix) Object.assign(this.state, fix);
      }

      // Fixed point check: S_{n+1} = F(S_n) → S_n
      if (JSON.stringify(this.state) === snapshot) return this.state;
    }
    throw new Error("No convergence — conflicting intents");
  }

  setState(patch: Partial<State>): State {
    Object.assign(this.state, patch);
    return this.resolve();
  }

  addDerivation(d: Derivation): void { this.derivations.push(d); }
  addConstraint(c: Constraint): void { this.constraints.push(c); }
}

// Usage
const engine = new IntentEngine();

engine.addDerivation((s) =>
  ({ eligible: Boolean(s.email && s.optedIn) })
);

engine.addConstraint({
  priority: 10,
  check: (s) => (s.eligible && !s.sent)
    ? { sent: true, action: "sendEmail" }
    : null
});

engine.addConstraint({
  priority: 100,
  check: (s) => (s.sent && s.blocked)
    ? { sent: false }
    : null
});

console.log(engine.setState({ email: "a@b.com", optedIn: true }));
```

### The same engine as SMT (production-grade route)
If you want the engine to be *provably* correct (no manual iteration, real optimization), replace the loop with Z3:

```typescript
// Instead of Kleene iteration, encode every derivation and constraint
// as a Z3 assertion and call the solver. Z3 handles the fixed-point.

import { init, Solver, Bool, Implies, And, Not } from 'z3-solver';

async function runEngineViaSMT(input: {email: string, optedIn: boolean, blocked: boolean}) {
  const { Context } = await init();
  const { Solver, Bool, Implies, And, Not } = new Context('main');

  const s = new Solver();

  const email_present = Bool.const('email_present');
  const opted_in      = Bool.const('opted_in');
  const eligible      = Bool.const('eligible');
  const sent          = Bool.const('sent');
  const blocked       = Bool.const('blocked');

  // Derivations as biconditionals:
  s.add(eligible.eq(And(email_present, opted_in)));

  // Constraints as implications (use Optimize for priorities):
  s.add(Implies(And(eligible, Not(sent)), sent));
  s.add(Implies(blocked, Not(sent)));

  // Input:
  s.add(email_present.eq(input.email ? true : false));
  s.add(opted_in.eq(input.optedIn));
  s.add(blocked.eq(input.blocked));

  if (await s.check() === 'sat') {
    return s.model();
  }
  throw new Error("unsat");
}
```

The Z3 version **does not iterate**. It solves the full constraint system in one call. This is the closest you can get, in production, to "one jump" resolution. The cost is hidden inside Z3's CDCL/DPLL(T) machinery — the math of §6.

### Differential version (incremental — scales to huge state)
```javascript
// Instead of re-running the whole engine on every change,
// use a reactive/SAC approach à la React/Incremental/DBSP:

const { useState, useMemo } = require('react');

function useIntentEngine(inputs) {
  const eligible = useMemo(
    () => Boolean(inputs.email && inputs.optedIn),
    [inputs.email, inputs.optedIn]
  );

  const sent = useMemo(() => {
    if (inputs.blocked) return false;      // priority 100
    if (eligible) return true;             // priority 10
    return false;
  }, [eligible, inputs.blocked]);

  return { eligible, sent };
}
```

When `inputs.email` changes, only `eligible` and downstream nodes recompute. This is your engine as a self-adjusting computation from §7.

---

## 13. Multi-Substrate Engine: Cross-File-Type Constraints in Code

This is §13.5 of the prior paper turned into code. Each file type defines a local substrate, and a coordinator enforces global consistency.

### TypeScript (general, your stack)
```typescript
type Substrate<S> = {
  name: string;
  state: S;
  derivations: Array<(s: S) => Partial<S> | null>;
  constraints: Array<{ priority: number; check: (s: S) => Partial<S> | null }>;
};

type CrossLink<SA, SB> = {
  from: string;
  to: string;
  translate: (sa: SA) => Partial<SB> | null;
};

class MultiSubstrateEngine {
  private substrates: Record<string, Substrate<any>> = {};
  private links: CrossLink<any, any>[] = [];

  addSubstrate(s: Substrate<any>): void { this.substrates[s.name] = s; }
  addLink(l: CrossLink<any, any>): void { this.links.push(l); }

  resolve(maxIter = 1000): Record<string, any> {
    for (let n = 0; n < maxIter; n++) {
      const snapshot = JSON.stringify(this.substrates);

      // 1. Resolve each substrate locally (inner lfp).
      for (const sub of Object.values(this.substrates)) {
        this.resolveLocal(sub);
      }

      // 2. Propagate across links.
      for (const link of this.links) {
        const src = this.substrates[link.from].state;
        const update = link.translate(src);
        if (update) Object.assign(this.substrates[link.to].state, update);
      }

      // 3. Fixed point on the product lattice?
      if (JSON.stringify(this.substrates) === snapshot) {
        return Object.fromEntries(
          Object.entries(this.substrates).map(([k, v]) => [k, v.state])
        );
      }
    }
    throw new Error("No cross-substrate convergence");
  }

  private resolveLocal(sub: Substrate<any>): void {
    for (const D of sub.derivations) {
      const u = D(sub.state);
      if (u) Object.assign(sub.state, u);
    }
    const sorted = [...sub.constraints].sort((a, b) => b.priority - a.priority);
    for (const C of sorted) {
      const f = C.check(sub.state);
      if (f) Object.assign(sub.state, f);
    }
  }
}

// Usage: markdown intent ↔ python execution ↔ html reflection
const engine = new MultiSubstrateEngine();

engine.addSubstrate({
  name: 'markdown',
  state: { text: "User must receive confirmation email" },
  derivations: [(s) => s.text?.includes("confirmation email")
    ? { intent_sendEmail: true } : null],
  constraints: [],
});

engine.addSubstrate({
  name: 'python',
  state: { sent: false },
  derivations: [],
  constraints: [{
    priority: 10,
    check: (s) => (s.intent_sendEmail && !s.sent)
      ? { sent: true } : null
  }],
});

engine.addSubstrate({
  name: 'html',
  state: { render: "" },
  derivations: [(s) => ({ render: s.sent ? "<div>Sent</div>" : "<div>Pending</div>" })],
  constraints: [],
});

// Cross-substrate links: markdown → python, python → html
engine.addLink({
  from: 'markdown', to: 'python',
  translate: (s) => s.intent_sendEmail ? { intent_sendEmail: true } : null
});
engine.addLink({
  from: 'python', to: 'html',
  translate: (s) => ({ sent: s.sent })
});

console.log(engine.resolve());
```

**This is the code realization of the product-lattice fixed-point from §13.5.** The outer loop is the Kleene iteration on the combined operator; the inner loop per substrate is the local Kleene iteration; the cross-links are the inter-substrate translations $\alpha_{ij}$.

---

## 14. The Hard Ceiling in Code: What Undecidability Looks Like in Practice

The theorems of §12 appear in code as three concrete symptoms.

### Undecidability → `unknown` returns
```python
from z3 import Solver, Real, sat, unsat

s = Solver()
x = Real('x')
# Nonlinear real arithmetic: decidable (Tarski) but often hits solver heuristics.
s.add(x*x*x - 2*x*x + x == 0)
s.add(x > 0)

result = s.check()
print(result)   # may print 'sat', 'unsat', or 'unknown'
if str(result) == 'unknown':
    print("Solver gave up — this is what the ceiling looks like in code.")
```

### NP-hardness → timeouts
```python
s = Solver()
s.set("timeout", 5000)   # 5 second wall clock
# ... pile on a huge SAT instance ...
result = s.check()
# For NP-hard problems, you cannot guarantee a result in polynomial time.
# You can only guarantee a bounded wait. This is the ceiling managed pragmatically.
```

### Non-convergence → iteration caps
```typescript
// Your own engine:
resolve(maxIterations = 1000) { ... }
// If you remove the cap, the engine can loop forever on conflicting intents.
// Rice's theorem says: you cannot write a function that decides,
// for arbitrary rules, whether they converge. You MUST have a cap.
```

**What you actually write to handle the ceilings**: `timeout`, `maxIterations`, and `unknown` handling. Every production constraint system has these. They are not bugs — they are the engineering acknowledgment that the math says "you cannot do better."

---

## 15. The Master Cheat Sheet

| You want to express…                                    | You literally write…                                          |
|---------------------------------------------------------|---------------------------------------------------------------|
| "$x$ is an element of $A$"                              | `x :: A` (Haskell) / `x: A` (Python/TS)                       |
| "$f$ is a function from $A$ to $B$"                     | `f :: A -> B` / `f: Callable[[A], B]`                         |
| "$L$ is a complete lattice"                             | `class Lattice a where { bottom :: a; join :: a -> a -> a; ... }` |
| "compute $\operatorname{lfp}(F)$"                       | `lfp(F, bottom)` — loop until `F(x) == x`                     |
| "$F$ is monotone"                                       | a refinement type / Lean proof obligation / a documented contract |
| Galois connection $\alpha \dashv \gamma$                | a record with two fields, `alpha` and `gamma`                 |
| Datalog rule $h \leftarrow b_1, b_2$                    | `path(X, Y) :- edge(X, Z), path(Z, Y).` (in clingo/souffle/datafrog) |
| SAT constraint                                          | `z3.Solver().add(constraint_expression)`                      |
| priority/weighted constraint                            | `z3.Optimize().add_soft(constraint, weight=N)`                |
| self-adjusting node                                     | `useMemo(() => fn, [deps])` / `Inc.map2 x y ~f`               |
| incremental view                                        | `CREATE MATERIALIZED VIEW foo AS SELECT ...` (Materialize)    |
| stable model                                            | clingo rule set + `ctl.solve()`                               |
| dependent type                                          | `(x : A) -> B x` in Lean 4 / Idris                            |
| build task                                              | `"*.o" %> \out -> do { need [src]; cmd ... }` (Shake)         |
| your engine's fixed point                               | `engine.resolve()` with Kleene iteration + maxIter cap        |
| multi-substrate convergence                             | an outer Kleene loop over a product-lattice of substrates     |

---

## 16. Closing: What This Manual Actually Says

Every mathematical object in the prior paper has a direct, unambiguous code realization. The `::` / `:` / `Type` annotation is the physical imprint of a mathematical statement onto syntax. When you write

```haskell
lfp :: (Eq a, Lattice a) => (a -> a) -> a -> a
```

you are writing the type-theoretic version of "*$\operatorname{lfp}$ is a function that, given a monotone endomorphism of a complete lattice, returns its least fixed point*" — the theorem of Knaster–Tarski, compiled.

The equations don't become code through translation. They already **are** code, wearing different notation. What this manual gives you is the dictionary for reading them either way.

To build a real system from the math:

1. Pick your state lattice. Implement it as a class/struct.
2. Write derivations as functions `S -> S`.
3. Write constraints as functions `S -> S` with priorities.
4. Assemble `F` as composition.
5. Call `lfp(F, bottom)` with a maxIter cap.
6. When the system needs to scale: replace your hand-rolled `lfp` with Z3 (for logic), Materialize (for streams), Incremental (for reactive), or Lean (for correctness).

That's the whole pipeline. Every line of code in this manual is a compiled mathematical theorem. Build from them.

---

*End of translation manual.*
