/**
 * +Y_FORWARD: Intent Vector
 * ==========================
 * Ψ_i = embedding(module_i) / ||embedding(module_i)||
 *
 * The unit vector that is a module's identity in semantic space.
 * Two modules are semantically close when Ψ_A · Ψ_B is high.
 * This is what replaces file paths as the basis for coupling.
 */

import { normalize, cosineSimilarity, type IntentVector } from "../0.1_LATTICE/weight_matrix";

export interface IntentRegistration {
  id: string;
  psi: IntentVector;
  label: string;
}

/**
 * Registry of all module intent vectors.
 * Modules register here at initialization.
 */
export class IntentRegistry {
  private store = new Map<string, IntentRegistration>();

  register(id: string, label: string, rawVector: IntentVector): void {
    this.store.set(id, { id, label, psi: normalize(rawVector) });
  }

  get(id: string): IntentRegistration | undefined {
    return this.store.get(id);
  }

  /**
   * Find nearest neighbors by cosine similarity.
   */
  nearestNeighbors(
    queryId: string,
    topK: number = 5
  ): Array<{ id: string; similarity: number }> {
    const query = this.store.get(queryId);
    if (!query) return [];

    return Array.from(this.store.values())
      .filter(r => r.id !== queryId)
      .map(r => ({ id: r.id, similarity: cosineSimilarity(query.psi, r.psi) }))
      .sort((a, b) => b.similarity - a.similarity)
      .slice(0, topK);
  }

  all(): IntentRegistration[] {
    return Array.from(this.store.values());
  }

  get size(): number { return this.store.size; }
}
