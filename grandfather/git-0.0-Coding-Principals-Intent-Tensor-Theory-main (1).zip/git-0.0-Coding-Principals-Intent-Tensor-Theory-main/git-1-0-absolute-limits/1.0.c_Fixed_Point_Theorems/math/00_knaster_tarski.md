# Knaster–Tarski Theorem

The foundational existence theorem for fixed points on lattices.

## Statement

**Theorem (Knaster–Tarski, 1955).** *Let $(L, \leq)$ be a complete lattice and $f : L \to L$ a monotone function. Then the set $\operatorname{Fix}(f) = \{x \in L : f(x) = x\}$ is non-empty and is itself a complete lattice under $\leq$. In particular:*

$$
\operatorname{lfp}(f) \;=\; \bigwedge \{x \in L : f(x) \leq x\},
\qquad
\operatorname{gfp}(f) \;=\; \bigvee \{x \in L : x \leq f(x)\}.
$$

## Proof of lfp existence

Let $P = \{x \in L : f(x) \leq x\}$ be the set of **pre-fixed points**.

**Step 1: $P$ is non-empty.**
Since $L$ is a complete lattice, $\top \in L$. For any $y \in L$, $f(y) \leq \top$ trivially, so $f(\top) \leq \top$, hence $\top \in P$.

**Step 2: Define $\alpha = \bigwedge P$.**
This exists because $L$ is complete.

**Step 3: $\alpha$ is a pre-fixed point.**
For any $x \in P$: $\alpha \leq x$ (since $\alpha$ is a lower bound of $P$). By monotonicity, $f(\alpha) \leq f(x)$. Since $x \in P$, $f(x) \leq x$. By transitivity, $f(\alpha) \leq x$.

Thus $f(\alpha)$ is a lower bound of $P$. Since $\alpha$ is the greatest lower bound, $f(\alpha) \leq \alpha$, i.e., $\alpha \in P$.

**Step 4: $\alpha$ is a post-fixed point.**
Since $\alpha \in P$, by Step 3, $f(\alpha) \leq \alpha$. Applying monotonicity: $f(f(\alpha)) \leq f(\alpha)$, so $f(\alpha) \in P$. By minimality of $\alpha$, $\alpha \leq f(\alpha)$.

**Step 5: $\alpha$ is a fixed point.**
Combining Steps 3 and 4: $f(\alpha) \leq \alpha$ and $\alpha \leq f(\alpha)$. By antisymmetry, $f(\alpha) = \alpha$.

**Step 6: $\alpha$ is the least fixed point.**
Every fixed point is a pre-fixed point ($f(x) = x \Rightarrow f(x) \leq x$), so is $\geq \alpha$ (since $\alpha$ is $\bigwedge$ of pre-fixed points means $\alpha \leq$ every pre-fixed point).

$\blacksquare$

The proof of gfp is dual: swap $\leq \leftrightarrow \geq$, $\bigwedge \leftrightarrow \bigvee$, pre-fixed ↔ post-fixed.

## The full Knaster–Tarski result

The theorem actually asserts more than just the existence of a least and greatest fixed point: $\operatorname{Fix}(f)$ is itself a **complete lattice**. For any subset $S \subseteq \operatorname{Fix}(f)$:

$$
\bigvee_{\operatorname{Fix}(f)} S \;=\; \operatorname{lfp}\left(f |_{[\bigvee_L S,\, \top]}\right),
$$

the least fixed point of $f$ restricted to the interval above $\bigvee_L S$. This is less commonly used in practice but is the full statement.

## Significance

- **Existence is guaranteed** by monotonicity alone. No continuity, no smoothness, no metric is required.
- **The proof is non-constructive.** It tells you $\operatorname{lfp}(f)$ exists but does not give an algorithm to find it. For that, you need Kleene's theorem or transfinite iteration.
- **The characterization** "$\operatorname{lfp}(f) = \bigwedge$ pre-fixed points" is the foundation of **Park induction**: to prove $\operatorname{lfp}(f) \leq x$, prove that $x$ is a pre-fixed point.

## Historical note

Bronisław Knaster proved the theorem for power sets in 1928. Alfred Tarski extended it to arbitrary complete lattices in his 1955 paper *A Lattice-Theoretical Fixpoint Theorem and Its Applications*. The theorem is sometimes attributed to Tarski alone.

A converse of Tarski's theorem (every complete lattice arises as $\operatorname{Fix}(f)$ for some monotone $f$) was proved by Anne C. Davis in 1955.

## Corollaries

**Corollary 1 (Tarski's fixed-point theorem for $\cap$-structures).** If $\mathcal{C}$ is a family of subsets of $X$ closed under arbitrary intersections, and $f : \mathcal{C} \to \mathcal{C}$ is monotone, then $f$ has a least fixed point.

**Corollary 2 (Cantor–Bernstein).** The Cantor–Bernstein theorem (if $|A| \leq |B|$ and $|B| \leq |A|$ then $|A| = |B|$) follows from Knaster–Tarski. (Proof omitted; see Wikipedia's Knaster–Tarski page.)

**Corollary 3 (Park).** $\operatorname{lfp}(f)$ satisfies the induction principle $f(x) \leq x \Rightarrow \operatorname{lfp}(f) \leq x$ for every $x \in L$.
