# Equations That Drive the Frontier

The complete list of theorems underlying every paradigm in this chapter.

## Existence theorems

1. **Knaster–Tarski.** *Monotone $F$ on complete lattice $\Rightarrow$ $\operatorname{Fix}(F)$ is a complete lattice.* (§1.0.c)
2. **Kleene.** *Scott-continuous $F$ on pointed DCPO $\Rightarrow$ $\operatorname{lfp}(F) = \bigvee_n F^n(\bot)$.* (§1.0.c)
3. **Banach.** *Contraction $f$ with factor $q < 1$ on complete metric space $\Rightarrow$ unique fixed point, exponential convergence.* (§1.0.c)

## Semantic theorems

4. **Cousot–Cousot soundness.** *Galois connection + soundness condition $\Rightarrow$ abstract fixed point over-approximates concrete.* (§1.0.d)
5. **Van Emden–Kowalski minimal model.** *For Datalog $P$, $M_P = \operatorname{lfp}(T_P) = \bigcup_n T_P^n(\emptyset)$.* (§1.0.e)
6. **Datalog complexity.** *Data complexity of Datalog is PTIME-complete.* (§1.0.e)
7. **Gelfond–Lifschitz.** *Stable models of $P$ = fixed points of $\Gamma_P(S) := M(P^S)$.* (§1.0.i)

## Search theorems

8. **Cook–Levin.** *SAT is NP-complete.* (§1.0.f, §1.0.l)
9. **Nelson–Oppen.** *Signature-disjoint, stably-infinite, decidable theories have decidable combination.* (§1.0.f)
10. **Rice's theorem.** *Every non-trivial semantic property of programs is undecidable.* (§1.0.l)

## Incremental theorems

11. **Acar–Blelloch–Harper trace stability.** *Trace-stable self-adjusting program runs in time proportional to trace distance.* (§1.0.g)
12. **DBSP fundamental identities.** *$\mathbf{D} \circ \mathbf{I} = \mathbf{I} \circ \mathbf{D} = \operatorname{id}$.* (§1.0.h)
13. **DBSP IVM.** *$Q^\Delta = \mathbf{D} \circ Q \circ \mathbf{I}$ is mechanically derivable for linear/bilinear $Q$ and runs in time proportional to the input delta.* (§1.0.h)

## Proof-theoretic theorems

14. **Curry–Howard correspondence.** *Bijection between proofs, terms, and programs.* (§1.0.j)
15. **Curry–Howard–Lambek.** *Further correspondence to Cartesian closed categories.* (§1.0.j)
16. **Type-inhabitation undecidability.** *In CIC / dependent type theory, deciding inhabitation is undecidable.* (§1.0.j)
17. **Strong normalization of CIC.** *Every well-typed CIC term reduces to a normal form in finitely many steps.* (§1.0.j)

## Build system theorem

18. **Mokhov–Mitchell–Peyton Jones.** *Every build system factors as rebuilder × scheduler in a $4 \times 3$ grid of standard options.* (§1.0.k)

## Cosmic ceilings

19. **Turing halting.** *No total computable $H$ decides program halting.* (§1.0.l)
20. **Gödel 1st.** *Any consistent computably-axiomatized arithmetic is incomplete.* (§1.0.l)
21. **Gödel 2nd.** *No consistent arithmetic proves its own consistency.* (§1.0.l)
22. **Time hierarchy.** *$f \log f = o(g) \Rightarrow \text{DTIME}(f) \subsetneq \text{DTIME}(g)$.* (§1.0.l)

## ITT engine theorems (this chapter)

23. **Generic engine convergence.** *If all derivations are Scott-continuous and all constraints are monotone projections, the engine converges via Kleene.* (§1.0.m)
24. **Engine oscillation.** *If $F(s_1) = s_2, F(s_2) = s_1, s_1 \neq s_2$, the engine does not converge on inputs entering $\{s_1, s_2\}$.* (§1.0.m)
25. **Priority-as-lex-MaxSAT.** *The priority resolution problem of the engine is equivalent to lexicographic multi-level MaxSAT.* (§1.0.m)
26. **Multi-substrate Kleene.** *If each substrate operator and each cross-substrate translator is Scott-continuous, the product engine converges.* (§1.0.n)

## The master equation

All of the above, condensed to one statement:

$$
\boxed{\;\; S^\star \;=\; F(S^\star) \;\;}
$$

with the choice of lattice, operator shape (monotone, Scott-continuous, contractive, projective), effect (pure, reactive, incremental, distributed), and search strategy (Kleene iteration, DPLL, Nelson–Oppen, stable-model search, proof search) determining *which* paradigm you are in.

The ceilings — halting, Rice, Cook–Levin, Gödel, time hierarchy — bound the entire space uniformly, regardless of which choices you make.

This is the full picture of the absolute limits of dynamic computation. Everything in this chapter is either a theorem within this picture, a proof, or an implementation that realizes it.
