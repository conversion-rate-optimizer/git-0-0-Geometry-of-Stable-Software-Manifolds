/**
 * Three-substrate demo: .md ↔ .py ↔ .html
 *
 * Markdown declares intents; Python implements them; HTML reflects the
 * implementation. All three co-resolve from a single user edit.
 */

import { MultiSubstrateEngine } from './multi_substrate_engine';

const engine = new MultiSubstrateEngine();

// ---- Substrate 1: Markdown ----
engine.addSubstrate({
  name: 'markdown',
  state: {
    text: "User must receive a confirmation email after signup."
  },
  derivations: [
    // Parse the markdown for "must receive ... email" patterns
    (s) => {
      const t = String(s.text || "");
      const intent_sendEmail = /must\s+receive\s+.*email/i.test(t);
      const intent_showConfirmation = /confirmation/i.test(t);
      return { intent_sendEmail, intent_showConfirmation };
    }
  ],
  constraints: []
});

// ---- Substrate 2: Python ----
engine.addSubstrate({
  name: 'python',
  state: {
    has_send_email_fn: false,
    has_show_confirmation_fn: false,
    implementations_complete: false
  },
  derivations: [
    // implementations_complete when both flags are true
    (s) => ({
      implementations_complete: Boolean(s.has_send_email_fn && s.has_show_confirmation_fn)
    })
  ],
  constraints: []
});

// ---- Substrate 3: HTML ----
engine.addSubstrate({
  name: 'html',
  state: {
    render: "",
    show_email_button: false,
    show_confirmation_div: false
  },
  derivations: [
    (s) => {
      let render = "";
      if (s.show_email_button)     render += "<button id='send-email'>Send</button>";
      if (s.show_confirmation_div) render += "<div class='confirm'>Sent!</div>";
      return { render };
    }
  ],
  constraints: []
});

// ---- Cross-substrate translators ----

// .md → .py: intents become function obligations
engine.addLink({
  from: 'markdown', to: 'python',
  label: 'md→py: intents to function obligations',
  translate: (md) => ({
    has_send_email_fn: Boolean(md.intent_sendEmail),
    has_show_confirmation_fn: Boolean(md.intent_showConfirmation)
  })
});

// .py → .html: implementations become visible UI
engine.addLink({
  from: 'python', to: 'html',
  label: 'py→html: implementations to buttons/divs',
  translate: (py) => ({
    show_email_button:     Boolean(py.has_send_email_fn),
    show_confirmation_div: Boolean(py.has_show_confirmation_fn)
  })
});

// ---- Resolve ----
const result = engine.resolve();
console.log("Resolved multi-substrate state:");
for (const [name, state] of Object.entries(result)) {
  console.log(`\n[${name}]`);
  console.log(JSON.stringify(state, null, 2));
}
