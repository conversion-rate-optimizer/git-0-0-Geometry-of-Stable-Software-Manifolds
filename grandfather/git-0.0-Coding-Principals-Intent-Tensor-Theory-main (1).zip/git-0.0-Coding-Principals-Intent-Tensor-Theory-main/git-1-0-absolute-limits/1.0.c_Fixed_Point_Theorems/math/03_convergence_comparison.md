# Convergence Regimes Compared

When do you use which theorem? The decision matters for both correctness and performance.

## The comparison table

| Aspect                     | Knaster–Tarski           | Kleene                    | Banach                       |
|----------------------------|--------------------------|---------------------------|------------------------------|
| **Domain type**            | Complete lattice         | Pointed DCPO              | Complete metric space         |
| **Operator requirement**   | Monotone                 | Scott-continuous          | Contractive ($q < 1$)        |
| **Existence?**             | Yes (multiple fixed pts) | Yes (least fixed point)   | Yes and unique               |
| **Uniqueness?**            | No                       | No                        | Yes                          |
| **Constructive?**          | No                       | Yes (countable iteration) | Yes (any starting point)     |
| **Convergence rate?**      | —                        | Countable                 | Exponential $O(q^n)$         |
| **Starting point matters?**| —                        | Must be $\leq$ fixed pt   | Any point converges          |
| **Needs metric?**          | No                       | No                        | Yes                          |

## Which regime is your engine in?

Ask these questions about your operator $F$:

### Q1: Does my state space have a natural $\leq$ that $F$ preserves?

- **Yes → Monotone.** Knaster–Tarski gives existence.
- **No → You are outside this framework entirely.** You cannot use iterative fixed-point methods; you need search (SAT/SMT) or optimization.

### Q2: If monotone, is $F$ Scott-continuous?

- **Yes → Kleene.** Iterate $F$ from $\bot$; it converges.
- **No → Only Knaster–Tarski existence; iteration may not reach lfp.** This happens when $F$ involves "for all infinite sets" universal quantification without continuity. In practice, for finite-height lattices (finite state), this never matters (finite Scott-continuity is automatic).

### Q3: Does my domain have a metric and is $F$ a contraction?

- **Yes → Banach.** Exponential convergence from any point.
- **No → Stick with Kleene.** Iterate discretely; check for stability.

## Practical map

### Datalog / ASP (semi-naive evaluation)
- Lattice: power set of Herbrand base.
- Operator: $T_P$ (immediate consequence).
- $T_P$ is Scott-continuous (in fact has a stronger "finitary" property).
- **Regime: Kleene.** Iterate semi-naively.

### Abstract interpretation on finite-height domain
- Lattice: finite-height abstract domain.
- Operator: abstract transition.
- Monotone by construction, Scott-continuous because finite.
- **Regime: Kleene.** Iterate once per state.

### Abstract interpretation on infinite-height domain
- Lattice: intervals, polyhedra, etc.
- Operator: abstract transition.
- Monotone but may not Scott-continuous in practice.
- **Regime: Kleene + widening.** Iterate with a widening operator to force termination (see `1.0.d/math/02_widening_narrowing.md`).

### Reactive UI (React, Incremental)
- Lattice: a DAG of derived values over a flat-domain state.
- Operator: re-evaluate invalidated nodes.
- Scott-continuous (each node's dependencies are bounded).
- **Regime: Kleene-style, but demand-driven.**

### Numerical fixed-point solvers
- Metric: $L^2$ or sup norm.
- Operator: some explicit map.
- Contractive within a region of attraction.
- **Regime: Banach.** Iterate from any starting point.

### SAT/SMT solvers
- **Not iterative at all.** SAT solvers do DPLL/CDCL search; they do not fit any of the three regimes. Their correctness is proved via model-theoretic arguments, not fixed-point iteration.

### ITT Intent Engine (your generic engine)
- Lattice: product of substrate states.
- Operator: composition of derivations and constraints in priority order.
- Monotonicity: depends on whether constraints can *retract* assignments.
  - If no retraction (monotone): **Kleene** applies.
  - If retraction (e.g., "if blocked then not sent"): **non-monotone**, no guarantee.
- This is the formal content of "conflicting intents" — you've left the Kleene regime.

## How to restore convergence when you're outside Kleene

Several standard techniques:

1. **Stratification.** Partition your constraints into layers, such that each layer is monotone given the results of previous layers. Run each layer to a fixed point, then proceed. This is how Datalog-with-negation works.

2. **Priority levels + fairness.** Ensure that no finite sub-cycle exists in the constraint graph. Guarantees termination but not convergence to a specific fixed point.

3. **Switch to search.** Replace iterative resolution with SAT/SMT. The solver handles the oscillation internally.

4. **Soft constraints + gradient descent.** Turn hard constraints into soft penalties and optimize. Brings you into the Banach regime (locally).

5. **Bounded iteration with best-effort output.** Set `maxIter` and return the most-consistent state found. This is what your engine does; it is *pragmatic but not theoretically clean*.

## Checklist for your operator

Before running your engine in production, answer:

- [ ] What is the lattice?
- [ ] Is every operator monotone on that lattice?
- [ ] Is the lattice finite-height, or do I need widening?
- [ ] Do any of my constraints retract assignments?
- [ ] If yes, am I stratified, or do I accept non-convergence?
- [ ] What is my `maxIter`?
- [ ] What is my fallback when `maxIter` is exceeded?

Honest answers to these determine what guarantees your engine actually gives.
