# GitCMA v2 Formalization — Locked Lattice Edition

## Law 1: Locked lattice
Structural coordinate paths are physical constants:

`addr(x,y) = git-x-y-semantic-slug`

Primary identity is `(x,y)`, not slug.

## Law 2: Selection law
`S_sel = R / (Rdot * t_ref)`

Persistence condition:
`S_sel >= 1`

## Law 3: Bloom law
`Q(t) = A_tot(t) / (Theta * S_free(t))`

Bloom occurs when `Q(t) > 1`.

## Law 4: Wave polarity
`W(phi,theta)=sin(2phi)cos(2theta)`
`V(phi,theta)=-W(phi,theta)`

## Law 5: Coordinate-first execution
- Resolve coordinate.
- Seed field.
- Diffuse state.
- Compute Laplacian.
- Gate persistence.
- Emit bloom report.
