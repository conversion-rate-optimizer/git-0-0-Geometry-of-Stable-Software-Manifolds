# 1.0.d — Abstract Interpretation

The Cousot–Cousot framework: sound approximation of program semantics via Galois connections.

## Files

**Math:**
- `math/00_galois_connections.md` — Abstraction/concretization pairs.
- `math/01_soundness.md` — The soundness theorem.
- `math/02_widening_narrowing.md` — Termination for infinite-height lattices.
- `math/03_canonical_domains.md` — Intervals, polyhedra, octagons, sign.

**Code:**
- `code/galois_python.py` — Galois connection as a Python dataclass.
- `code/signs_abstract_interpreter.py` — Complete signs analysis for a toy IMP language.
- `code/intervals_widening.py` — Interval domain with widening.
