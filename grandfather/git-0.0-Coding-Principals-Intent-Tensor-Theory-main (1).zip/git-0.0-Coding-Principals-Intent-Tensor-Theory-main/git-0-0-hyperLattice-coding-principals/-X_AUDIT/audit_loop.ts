/**
 * -X_AUDIT: Audit Loop
 * =====================
 * Measures execution outcomes and feeds results back into the manifold.
 * Updates S values in the Resonance Registry after each production run.
 * Closes the feedback loop: Manifestation → Observation → Update.
 */

import Resonance from "../0.0_SUBSTRATE/registry";

export interface AuditRecord {
  intentKey: string;
  success: boolean;
  latencyMs: number;
  iteration: number;
  deltaS: number;
}

const AUDIT_LOG: AuditRecord[] = [];
const MAX_LOG = 500;

/**
 * Record a production run outcome and update the module's S value.
 *
 * Success  → S += 0.1  (structure proved itself)
 * Failure  → S -= 0.2  (structure failed under real conditions)
 */
export function recordExecution(
  intentKey: string,
  success: boolean,
  latencyMs: number,
  iteration: number
): void {
  const deltaS = success ? 0.1 : -0.2;

  // Update persistence in the registry
  const entry = (Resonance as any).registry?.get(intentKey);
  if (entry) {
    const newS = Math.max(0, entry.sValue + deltaS);
    Resonance.updatePersistence(intentKey, newS);
  }

  const record: AuditRecord = { intentKey, success, latencyMs, iteration, deltaS };
  if (AUDIT_LOG.length >= MAX_LOG) AUDIT_LOG.shift();
  AUDIT_LOG.push(record);

  const status = success ? "✓" : "✗";
  console.log(`[AUDIT]: ${status} ${intentKey} | Δs=${deltaS > 0 ? "+" : ""}${deltaS} | ${latencyMs}ms`);
}

/**
 * Audit summary for a given module over recent history.
 */
export function auditSummary(intentKey: string, last = 20): {
  successRate: number;
  avgLatency: number;
  netDeltaS: number;
} {
  const records = AUDIT_LOG
    .filter(r => r.intentKey === intentKey)
    .slice(-last);

  if (records.length === 0) return { successRate: 0, avgLatency: 0, netDeltaS: 0 };

  const successes = records.filter(r => r.success).length;
  const avgLatency = records.reduce((s, r) => s + r.latencyMs, 0) / records.length;
  const netDeltaS  = records.reduce((s, r) => s + r.deltaS, 0);

  return {
    successRate: successes / records.length,
    avgLatency,
    netDeltaS,
  };
}

export function getAuditLog(): AuditRecord[] { return [...AUDIT_LOG]; }
