/**
 * +X_LATERAL: Event Emitter
 * ==========================
 * Non-linear broadcast bus. Modules emit field events;
 * subscribers receive them based on resonance, not address.
 *
 * A module does not call another module directly.
 * It broadcasts a tension into the substrate.
 * Modules tuned to that frequency receive it.
 */

export type FieldEventType =
  | "BLOOM"
  | "ANCHOR_FORMED"
  | "CYCLE_DISSOLVED"
  | "BOND_FORMED"
  | "RESIDUE_ARCHIVED"
  | "VACUUM_ERROR";

export interface FieldEvent {
  type: FieldEventType;
  sourceId: string;
  payload: Record<string, unknown>;
  timestamp: number;
}

type EventHandler = (event: FieldEvent) => void;

export class FieldEventEmitter {
  private handlers = new Map<FieldEventType, EventHandler[]>();
  private log: FieldEvent[] = [];
  private maxLog = 200;

  on(type: FieldEventType, handler: EventHandler): void {
    const existing = this.handlers.get(type) ?? [];
    this.handlers.set(type, [...existing, handler]);
  }

  off(type: FieldEventType, handler: EventHandler): void {
    const existing = this.handlers.get(type) ?? [];
    this.handlers.set(type, existing.filter(h => h !== handler));
  }

  emit(type: FieldEventType, sourceId: string, payload: Record<string, unknown> = {}): void {
    const event: FieldEvent = { type, sourceId, payload, timestamp: Date.now() };

    // Archive
    if (this.log.length >= this.maxLog) this.log.shift();
    this.log.push(event);

    // Dispatch
    const handlers = this.handlers.get(type) ?? [];
    for (const h of handlers) {
      try { h(event); } catch { /* handler errors don't kill the bus */ }
    }
  }

  recent(type?: FieldEventType, n = 10): FieldEvent[] {
    const filtered = type ? this.log.filter(e => e.type === type) : this.log;
    return filtered.slice(-n);
  }

  get eventCount(): number { return this.log.length; }
}

/** Global event bus — singleton for the manifold */
export const fieldBus = new FieldEventEmitter();
