/**
 * 0.3_COMPETITION: Decay Enforcer
 * =================================
 * The collapse rule. Non-negotiable.
 *
 * Nodes outside winning cycles have their φ decayed.
 * Without this: losers never die, system never resolves.
 * With this: only persistent structures survive.
 *
 * "Numerical Exorcism" — if you are not part of a
 * self-sustaining structure, you are noise.
 *
 * Three decay modes:
 *   SOFT   — φ *= 0.5   (gentle pruning, good for exploration)
 *   HARD   — φ *= 0.1   (aggressive selection, good for production)
 *   PURGE  — φ  = 0     (total reset of non-winners)
 *
 * Usage: call after every competition round.
 * Apply SOFT during early field settling (steps 1-10).
 * Apply HARD after the field has stabilized (step 10+).
 */

import type { CycleState } from "./cycle_competition";

export type DecayMode = "SOFT" | "HARD" | "PURGE";

const DECAY_FACTORS: Record<DecayMode, number> = {
  SOFT:  0.5,
  HARD:  0.1,
  PURGE: 0.0,
};

export interface DecayReport {
  decayed: string[];    // Nodes that were penalized
  surviving: string[];  // Nodes in winning cycles
  totalLost: number;    // Σφ removed from system
}

/**
 * Apply decay to all nodes outside winning cycles.
 *
 * Returns updated phi and a report of what happened.
 */
export function applyDecay(
  allNodes: string[],
  winners: CycleState[],
  phi: Map<string, number>,
  mode: DecayMode = "HARD"
): { phi: Map<string, number>; report: DecayReport } {
  const winningNodes = new Set(winners.flatMap(c => c.nodes));
  const factor = DECAY_FACTORS[mode];

  const updated = new Map(phi);
  const decayed: string[] = [];
  const surviving: string[] = [];
  let totalLost = 0;

  for (const id of allNodes) {
    if (winningNodes.has(id)) {
      surviving.push(id);
    } else {
      const current = phi.get(id) ?? 0;
      const next = current * factor;
      updated.set(id, next);
      decayed.push(id);
      totalLost += current - next;
    }
  }

  return {
    phi: updated,
    report: { decayed, surviving, totalLost },
  };
}

/**
 * Vacuum check: did the competition round produce any winners?
 *
 * If no winners: the field has fully dissipated.
 * This is not an error — it means the seed was too weak
 * or the graph has no cycles strong enough to self-sustain.
 */
export function checkVacuum(winners: CycleState[]): boolean {
  return winners.length === 0;
}

/**
 * Full competition step: decay + vacuum check in one call.
 * Throws if vacuum — no stable structure emerged.
 */
export function resolveOrThrow(
  allNodes: string[],
  winners: CycleState[],
  phi: Map<string, number>,
  mode: DecayMode = "HARD"
): { phi: Map<string, number>; report: DecayReport } {
  if (checkVacuum(winners)) {
    throw new Error(
      "[VACUUM_ERROR]: No stable cycles emerged under competition. " +
      "Seed was too weak or graph has no self-sustaining loops. " +
      "Intent dissipated."
    );
  }

  return applyDecay(allNodes, winners, phi, mode);
}
