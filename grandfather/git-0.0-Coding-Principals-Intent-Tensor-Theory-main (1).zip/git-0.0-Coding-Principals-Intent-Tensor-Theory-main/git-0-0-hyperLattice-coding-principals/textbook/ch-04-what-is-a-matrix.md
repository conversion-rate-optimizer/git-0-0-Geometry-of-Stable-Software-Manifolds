# Chapter 04 — What Is a Matrix?

*Read time: 9 minutes*

---

## The Person Who Made Spreadsheets Possible

In 1858, a British mathematician named Arthur Cayley 
published a paper called "A Memoir on the Theory of Matrices."

Before that paper, there were no matrices. Not in the 
sense of a formal mathematical object with rules for 
how to combine them. There were tables of numbers — 
accountants had used those for centuries — but there 
was no systematic theory of what you could *do* with 
tables of numbers.

Cayley changed that. He defined what a matrix is, 
defined how to add two matrices, and — crucially — 
defined how to multiply two matrices.

Every spreadsheet program ever built. Every scientific 
computing library. Every machine learning system. 
Every 3D video game rendering engine. Every physics 
simulation. All of them rest, underneath, on the 
rules Cayley wrote down in 1858.

---

## What a Matrix Is

A matrix is a rectangular table of numbers.

```
[ 2  5  1 ]
[ 3  0  4 ]
[ 1  7  2 ]
```

That is a 3×3 matrix. Three rows, three columns.

The weight matrix W from Chapter 02 is a matrix. 
The number at row i, column j is the coupling 
strength between module i and module j.

That is all a matrix is: a table of numbers with 
a specific size.

---

## What You Can Do With Matrices

The useful operation — the one that makes everything else 
possible — is **matrix-vector multiplication**.

A vector is just a column of numbers:

```
v = [ 0.8 ]
    [ 0.3 ]
    [ 0.1 ]
```

Multiplying a matrix by a vector produces a new vector. 
Each entry of the new vector is a weighted sum of the 
original vector's entries.

Concretely — if W is the weight matrix and φ is the 
field vector (one Φ value per module), then:

```
W × φ = "each module's field value weighted by its connections"
```

The entry for module i in the result is:
```
(W × φ)[i] = W[i,0]×φ[0] + W[i,1]×φ[1] + W[i,2]×φ[2] + ...
```

In English: take every neighbor's field value, multiply 
by how strongly connected you are to that neighbor, add 
them up. That is module i's "received influence" from 
the whole network.

This is exactly the diffusion from Chapter 03 — written 
as a matrix multiplication.

---

## Why This Is Powerful

Before Cayley formalized this, computing "every node's 
influence from every neighbor" required writing a loop 
that manually went through each pair. With matrix 
multiplication, you do the entire computation for all 
nodes simultaneously in one operation.

This is not just a convenience. It is a different way 
of thinking. Matrix multiplication lets you treat the 
entire network state as a single object and transform 
it in one step.

In Python:
```python
new_phi = W @ phi  # @ is matrix multiplication
```

In one line, all 1000 modules update based on all their 
connections simultaneously. Without matrices, that would 
be a nested loop with a million iterations.

---

## The Spreadsheet Connection

When you type a formula in a spreadsheet like:
```
=SUMPRODUCT(A1:A5, B1:B5)
```

You are computing a dot product — which is matrix 
multiplication with a single row and column.

When you use MMULT() in Excel to multiply two tables, 
you are doing Cayley's matrix multiplication directly.

The entire spreadsheet paradigm — values in cells, 
formulas that reference other cells, automatic 
recalculation — is a user interface built on top 
of the matrix operations Cayley defined.

---

## The Degree Matrix D

In the field equation, there is a normalization step. 
After computing W × φ (the raw influence), you divide 
by each node's degree — how many connections it has — 
so that highly-connected nodes do not dominate.

This normalization is done with the **degree matrix D**:

```
D = diagonal matrix where D[i,i] = sum of row i of W
```

So D is a matrix with node degrees on the diagonal 
and zeros everywhere else.

`D⁻¹ × W × φ` is "W × φ divided by each node's degree" — 
the normalized influence.

This is a foundational operation in network science, 
graph theory, and machine learning. Every algorithm 
that operates on graphs — Google's PageRank, social 
network analysis, recommendation systems — uses some 
version of `D⁻¹W` under the hood.

---

## The Laplacian Matrix L = D - W

One more matrix that appears throughout this codebase: 
the **graph Laplacian**.

```
L = D - W
```

Subtract the weight matrix from the degree matrix. 
The result: diagonal entries are each node's total 
degree. Off-diagonal entries are negative of the 
coupling strengths.

When you multiply L by the field vector φ:
```
L × φ = (D - W) × φ = D×φ - W×φ
```

The entry for node i is:
```
(L × φ)[i] = degree[i] × φ[i] - sum of (W[i,j] × φ[j]) for all j
           = sum of W[i,j] × (φ[i] - φ[j]) for all j
```

That last line is exactly "the difference between my 
field value and each neighbor's, weighted by connection 
strength" — the curvature from Chapter 03.

So `L × φ` computes the graph curvature for every 
node simultaneously. One matrix multiplication, all 
curvatures at once. Fourier's diffusion equation, 
made computable by Cayley's matrix algebra.

---

## Summary

- A matrix is a table of numbers with defined operations
- Arthur Cayley formalized matrix multiplication in 1858
- Matrix-vector multiply: transforms a whole network state in one step
- W × φ computes all nodes' received influence simultaneously
- D is the degree matrix — normalizes so hubs don't dominate
- L = D - W is the graph Laplacian — computes field curvature
- Spreadsheets are built on these exact operations

---

**Previous:** [Chapter 03 — How Fields Spread](./ch-03-how-fields-spread.md)  
**Next:** [Chapter 05 — The Selection Gate](./ch-05-the-selection-gate.md)
