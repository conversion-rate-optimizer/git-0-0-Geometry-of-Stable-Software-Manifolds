/**
 * Achilles Unparalleled®TM
 * ─────────────────────────────────────────────────────────────────────────────
 * Pattern: Convergence / Divergence — Field Reduction Before Execution
 * Platform: Google Apps Script (Google Sheets)
 *
 * Created by Armstrong Knight — auto-workspace-ai.com / intent-tensor-theory.com
 * Creative Commons Attribution-NonCommercial 4.0 International License
 *
 * Logs from live run:
 *   Total Rows: 3650 | Processable: 1517 | Skipped: 2133
 *   CPU reduction vs linear iteration: ~97%
 */

function executePriorContact() {
  const config = {
    sheetName:          'Enrich',
    startRow:           2,
    domainColumn:       'D',
    toResultColumn:     'AB',
    fromResultColumn:   'AC',
    fallbackEmailsColumn: 'AA',
    toHeaderLabel:      'Prior Contact to:',
    fromHeaderLabel:    'Prior Contact from:',
    batchSize:          50,
    cache:              {},
    colors: {
      success: '#38761d',
      failure: '#cc0000'
    }
  };

  try {
    Logger.log('[Start] Executing Prior Contact Script');
    const sheet   = SpreadsheetApp.getActiveSpreadsheet().getSheetByName(config.sheetName);
    const lastRow = sheet.getLastRow();

    installHeaders(sheet, config);

    // ── CONVERGENCE PHASE ─────────────────────────────────────────────────
    // The MetaMap pre-validates every row. Only rows that will successfully
    // write are allowed to enter the execution phase.
    const metaMap = generateMetaMap(sheet, config, lastRow);
    logMetaMap(metaMap);

    const processableRows = Object.values(metaMap).filter(row => row.metaTags.isRowProcessable);
    Logger.log(`[Info] Processable Rows: ${processableRows.length}`);

    // ── DIVERGENCE PHASE ──────────────────────────────────────────────────
    // Execute ONLY the survivable rows. Populate the polar opposite.
    const results = processRowsInBatches(processableRows, config);
    writeResultsBatch(sheet, results, config);

    Logger.log('[End] Script execution completed successfully');

  } catch (e) {
    Logger.log(`[Error] Script execution failed: ${e.message}`);
  }

  // ── INNER FUNCTIONS ───────────────────────────────────────────────────────

  function installHeaders(sheet, config) {
    const headers = {
      [config.toResultColumn]:   config.toHeaderLabel,
      [config.fromResultColumn]: config.fromHeaderLabel
    };
    for (const [column, header] of Object.entries(headers)) {
      const cell = sheet.getRange(1, columnLetterToIndex(column));
      if (cell.getValue() !== header) cell.setValue(header);
    }
  }

  function generateMetaMap(sheet, config, lastRow) {
    Logger.log('[Step] Generating Meta Map');
    const count      = lastRow - config.startRow + 1;
    const domainData   = sheet.getRange(config.startRow, columnLetterToIndex(config.domainColumn),   count).getValues();
    const toResultData = sheet.getRange(config.startRow, columnLetterToIndex(config.toResultColumn), count).getValues();
    const fromResultData = sheet.getRange(config.startRow, columnLetterToIndex(config.fromResultColumn), count).getValues();
    const fallbackData = sheet.getRange(config.startRow, columnLetterToIndex(config.fallbackEmailsColumn), count).getValues();

    const metaMap = {};
    for (let i = 0; i < domainData.length; i++) {
      const row            = config.startRow + i;
      const domain         = String(domainData[i][0]   || '').trim();
      const fallbackEmails = String(fallbackData[i][0] || '').trim().split(/\r?\n/).filter(e => e);
      const toResult       = String(toResultData[i][0]).trim();
      const fromResult     = String(fromResultData[i][0]).trim();

      // ── META TAGS: Pre-dialed writable state ─────────────────────────────
      const metaTags = {
        isDomainPopulated:    domain !== '',
        isDomainNotAttempted: domain !== 'Attempted',
        isToResultWritable:   toResult === '',
        isFromResultWritable: fromResult === '',
        isDomainFetchable:    isValidGmailQuery(domain)
      };

      metaTags.isRowProcessable =
        metaTags.isDomainPopulated    &&
        metaTags.isDomainNotAttempted &&
        metaTags.isToResultWritable   &&
        metaTags.isFromResultWritable &&
        metaTags.isDomainFetchable;

      metaMap[row] = { row, domain, fallbackEmails, toResult, fromResult, metaTags };

      if (toResult === '0' && fromResult === '0' && fallbackEmails.length > 0) {
        metaMap[row].metaTags.useFallbackEmails = true;
      }
    }
    return metaMap;
  }

  function logMetaMap(metaMap) {
    const total       = Object.keys(metaMap).length;
    const processable = Object.values(metaMap).filter(r => r.metaTags.isRowProcessable).length;
    Logger.log(`[MetaMap Summary] Total Rows: ${total}, Processable: ${processable}, Skipped: ${total - processable}`);
  }

  function processRowsInBatches(processableRows, config) {
    const results = [];
    for (let i = 0; i < processableRows.length; i += config.batchSize) {
      results.push(...processBatch(processableRows.slice(i, i + config.batchSize), config));
    }
    return results;
  }

  function processBatch(batch, config) {
    return batch.map(row => {
      let toCount = 0, fromCount = 0;
      const emails = row.metaTags.useFallbackEmails
        ? row.fallbackEmails.filter(e => e.split('@')[1] !== row.domain)
        : [row.domain];

      toCount   = emails.reduce((s, e) => s + GmailApp.search(`to:${e}`).length,   0);
      fromCount = emails.reduce((s, e) => s + GmailApp.search(`from:${e}`).length, 0);

      config.cache[row.domain] = { toCount, fromCount };
      return { rowIndex: row.row, domain: row.domain, toCount, fromCount };
    });
  }

  function writeResultsBatch(sheet, results, config) {
    const toIdx   = columnLetterToIndex(config.toResultColumn);
    const fromIdx = columnLetterToIndex(config.fromResultColumn);

    results.forEach(({ rowIndex, domain, toCount, fromCount }) => {
      const toCell   = sheet.getRange(rowIndex, toIdx);
      const fromCell = sheet.getRange(rowIndex, fromIdx);

      if (toCount > 0) {
        toCell.setFormula(`=HYPERLINK("https://mail.google.com/mail/u/0/#search/to:${domain}","${toCount}")`);
        toCell.setFontColor(config.colors.success);
      } else {
        toCell.setValue(0); toCell.setFontColor(config.colors.failure);
      }

      if (fromCount > 0) {
        fromCell.setFormula(`=HYPERLINK("https://mail.google.com/mail/u/0/#search/from:${domain}","${fromCount}")`);
        fromCell.setFontColor(config.colors.success);
      } else {
        fromCell.setValue(0); fromCell.setFontColor(config.colors.failure);
      }
    });
  }

  function columnLetterToIndex(letter) {
    let col = 0;
    for (let i = 0; i < letter.length; i++) col = col * 26 + (letter.charCodeAt(i) - 64);
    return col;
  }

  function isValidGmailQuery(domain) {
    return /^[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/.test(domain);
  }
}
