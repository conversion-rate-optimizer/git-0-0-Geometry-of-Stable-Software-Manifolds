/**
 * -Z_BASE: Axiomatic Primitives — Dimensionless CTS Constants
 * ============================================================
 * Source: Pre-Veil Mechanics Vol I (Knight 2026) + Atomic Polarity (Knight 2026)
 * ORCID: 0009-0004-8153-8335
 *
 * These are NOT configurable. They are the pre-geometric ground state.
 * Every threshold in the hyperLattice is derived from these four parameters.
 * Changing them is not "tuning" — it is changing the physics.
 *
 * i₀ anchor: This file never imports from any other file.
 * It is the -Z pole. Everything else is a distortion of this seed.
 */

// ─── Allen-Cahn PDE Parameters ───────────────────────────────────────────────
// ∂Φ/∂t = η∇²Φ + μΦ³ − νΦ

export const CTS = {
  /** Diffusion coefficient — rate tension spreads from high-Φ to low-Φ regions */
  eta: 0.08,

  /** Cubic saturation coefficient — strength of restoring force toward S₂ equilibria */
  mu: 1.2,

  /** Linear damping coefficient — rate of decay back toward S₀ */
  nu: 0.35,

  /** First-crossing threshold — minimum Φ for S₁ activation */
  epsilon: 0.01,

  /** Discrete time step for numerical integration */
  dt: 0.02,

  /** S₂ stable equilibrium: Φ*₊ = √(ν/μ) — the matter ceiling.
   * NOTE: Φ*₊ is an energy barrier in the single-node ODE.
   * Non-zero activation requires seed forcing or spatial coupling.
   * Test-verified: without λs, field decays to S₀ for any Φ < Φ*₊.
   */
  get phi_star(): number {
    return Math.sqrt(this.nu / this.mu); // ≈ 0.540
  },

  /** Maximum recursion depth derived from Allen-Cahn diffusion geometry */
  n_max: 8,
} as const;

// ─── HyperLattice Field Parameters ───────────────────────────────────────────

export const LATTICE = {
  /**
   * Seed retention constant λ
   * How much the intent seed dominates vs. neighbor diffusion.
   * Calibrated: field settles in ~30 iterations at λ=0.63
   */
  lambda: 0.63,

  /**
   * Semantic locality threshold for W_ij
   * Below this cosine similarity → coupling = 0
   * Prevents dense noise operator (fully connected Laplacian)
   */
  resonance_threshold: 0.16,

  /**
   * Non-linear coupling exponent
   * W_ij = cos(Ψ_i, Ψ_j)^1.35 when above threshold
   */
  coupling_exponent: 1.35,

  /** Field convergence iterations */
  settle_iterations: 30,

  /** Numerical stability floor (prevents division by zero) */
  epsilon_field: 1e-12,
} as const;

// ─── Selection Gate Constants ─────────────────────────────────────────────────

export const SELECTION = {
  /** Node persistence threshold: S_i = φ_i / |Δφ_i| ≥ 1 */
  persistence: 1.0,

  /**
   * Bloom threshold: Q(t) > 1.1
   * Module may spawn sub-geometry and influence manifold topology
   */
  bloom: 1.1,

  /**
   * Cycle persistence threshold: S_C = Σφ / Σ|Δφ| ≥ 1
   * Loop is a self-sustaining object (3D closure)
   */
  cycle_persistence: 1.0,

  /**
   * Anchor threshold: S_C > 1.2
   * Cycle becomes permanent even if seed is removed
   */
  anchor: 1.2,
} as const;

// ─── Void Geometry Parameters (from Atomic Polarity) ─────────────────────────

export const VOID = {
  /**
   * Module void density threshold τ
   * Analog of electron density isosurface in G_void(Z,S;τ)
   * Below this: module dependency is "uncommitted" (open bond site)
   */
  tau: 0.8,

  /**
   * Intrapolarity sensitivity
   * ξ_intra ∝ ∇(1 − ELF) within B_void
   * Code analog: gradient of uncommitted dependency tension
   */
  intra_sensitivity: 1.0,
} as const;

// ─── Entropy Weights for Q(t) ─────────────────────────────────────────────────

export const BLOOM = {
  /** Weight on variance term in S_free */
  eta_1: 1.0,
  /** Weight on entropy term in S_free */
  eta_2: 1.0,
  /** Global disorder scaling Θ */
  theta: 1.0,
} as const;

// ─── Derived Constants (computed, not calibrated) ────────────────────────────

export const DERIVED = {
  /** Phase residue condition: (W) = 0 → void closure → module is "bonded" */
  phase_residue_closed: 0,

  /** E-Cascade: minimum sub-key count for a valid excitation */
  min_sub_keys: 3,

  /** Spreading radius at time t: r(t) = √(4ηt) */
  spreading_radius: (t: number): number => Math.sqrt(4 * CTS.eta * t),
} as const;

// ─── Type Exports ─────────────────────────────────────────────────────────────

export type StratumLabel = "S0" | "S1a" | "S1b" | "S2";

export function classifyPhi(phi: number): StratumLabel {
  if (phi < CTS.epsilon) return "S0";
  if (phi < CTS.phi_star * 0.4) return "S1a";
  if (phi < CTS.phi_star) return "S1b";
  return "S2";
}
