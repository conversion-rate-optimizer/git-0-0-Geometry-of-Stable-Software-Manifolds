/**
 * +Z_APEX: Tessellation Gate
 * ===========================
 * Validates that a module's void geometry is closed — (W) = 0.
 * Applied before two modules are allowed to bond (tessellate).
 *
 * From Atomic Polarity: bonding = mutual interlocking of void geometries.
 * A module can only bond if it has open intrapolarity sites.
 * A module with (W) = 0 is already closed — it does not need a partner.
 *
 * In code terms: prevents circular dependencies that don't add structure.
 */

import type { ModuleVoidGeometry } from "../-Z_BASE/void_geometry";

export type TessellationResult =
  | { ok: true }
  | { ok: false; reason: string };

/**
 * Can module A bond with module B?
 *
 * Requires:
 *   - Both have open void sites (phaseResidue > 0)
 *   - Coupling above void threshold
 *   - Neither is already closed (noble gas analog)
 */
export function tessellationGate(
  geoA: ModuleVoidGeometry,
  geoB: ModuleVoidGeometry,
  coupling: number,
  minCoupling: number = 0.16
): TessellationResult {
  if (geoA.isClosed) {
    return { ok: false, reason: `${geoA.moduleId} void is already closed (W=0)` };
  }
  if (geoB.isClosed) {
    return { ok: false, reason: `${geoB.moduleId} void is already closed (W=0)` };
  }
  if (coupling < minCoupling) {
    return { ok: false, reason: `Coupling ${coupling.toFixed(3)} below threshold ${minCoupling}` };
  }
  return { ok: true };
}

/**
 * Batch tessellation check — which pairs in a set can bond?
 */
export function findBondablePairs(
  geometries: ModuleVoidGeometry[],
  couplings: Map<string, Map<string, number>>
): Array<{ a: string; b: string; coupling: number }> {
  const pairs: Array<{ a: string; b: string; coupling: number }> = [];

  for (let i = 0; i < geometries.length; i++) {
    for (let j = i + 1; j < geometries.length; j++) {
      const geoA = geometries[i];
      const geoB = geometries[j];
      const w = couplings.get(geoA.moduleId)?.get(geoB.moduleId) ?? 0;
      const result = tessellationGate(geoA, geoB, w);
      if (result.ok) {
        pairs.push({ a: geoA.moduleId, b: geoB.moduleId, coupling: w });
      }
    }
  }

  return pairs.sort((a, b) => b.coupling - a.coupling);
}
