# Product Lattices

The state space of a multi-substrate engine.

## Construction

Let $\mathcal{S}_1, \mathcal{S}_2, \ldots, \mathcal{S}_k$ be the state lattices of $k$ substrates (e.g., one for each file type: `.md`, `.py`, `.html`, ...).

The **product lattice** is

$$
\mathcal{S} \;=\; \mathcal{S}_1 \times \mathcal{S}_2 \times \cdots \times \mathcal{S}_k
$$

with the **componentwise order**:

$$
(s_1, \ldots, s_k) \leq (s_1', \ldots, s_k') \iff \forall i.\; s_i \leq_i s_i'.
$$

## Properties

**Proposition.** *If each $\mathcal{S}_i$ is a complete lattice (resp. pointed DCPO), so is $\prod_i \mathcal{S}_i$.*

**Proof.** Joins and meets are computed componentwise:
$$
\bigvee_\alpha (s_1^\alpha, \ldots, s_k^\alpha) = \left(\bigvee_\alpha s_1^\alpha, \ldots, \bigvee_\alpha s_k^\alpha\right).
$$
Completeness of each $\mathcal{S}_i$ gives completeness of the product.

$\bot_\mathcal{S} = (\bot_1, \ldots, \bot_k)$, $\top_\mathcal{S} = (\top_1, \ldots, \top_k)$.

## Projections and injections

For each $i$, there are canonical maps:

- **Projection** $\pi_i : \mathcal{S} \to \mathcal{S}_i$, $(s_1, \ldots, s_k) \mapsto s_i$.
- **Injection** $\iota_i : \mathcal{S}_i \to \mathcal{S}$, $s \mapsto (\bot_1, \ldots, s, \ldots, \bot_k)$ (with $s$ in position $i$).

Both are monotone. Projection preserves joins and meets; injection preserves joins but not meets.

## Substrate-local operators

Each substrate $i$ has its own engine operator $F_i : \mathcal{S}_i \to \mathcal{S}_i$ (the generic engine from `1.0.m` applied locally).

These lift to the product via

$$
\hat F_i \;\coloneqq\; \iota_i \circ F_i \circ \pi_i + (\operatorname{id} - \iota_i \circ \pi_i).
$$

Informally: apply $F_i$ to the $i$-th component; leave all others unchanged.

## The naive product engine

The simplest cross-substrate engine is:

$$
F_{\text{prod}} \;\coloneqq\; \hat F_k \circ \hat F_{k-1} \circ \cdots \circ \hat F_1.
$$

One pass of each substrate's engine, in sequence. Iterate $F_\text{prod}$ to a fixed point.

**Theorem.** *If each $F_i$ is monotone on $\mathcal{S}_i$, then $F_\text{prod}$ is monotone on $\mathcal{S}$ and converges (Knaster–Tarski).*

**Theorem.** *If each $F_i$ is Scott-continuous, so is $F_\text{prod}$, and Kleene applies: $\operatorname{lfp}(F_\text{prod}) = \bigvee_n F_\text{prod}^n(\bot)$.*

## The problem with the naive product

Without **cross-substrate translators**, the product engine just runs each substrate independently. There is no interaction.

To get interaction — where `.md` content influences `.py` content influences `.html` content — we need explicit **coupling operators** (next file).

## Example: three-substrate state

$$
\mathcal{S}_{.md}   = \{\text{parsed markdown intent nodes}\}, \;
\mathcal{S}_{.py}   = \{\text{Python AST with annotations}\}, \;
\mathcal{S}_{.html} = \{\text{DOM with attributes}\}.
$$

The global state is $(s_{.md}, s_{.py}, s_{.html})$. Without couplings, these are independent. With couplings, a change in $s_{.md}$ can propagate to $s_{.py}$ and $s_{.html}$, and vice versa.

## Why the product matters

- **One fixed-point computation** resolves global consistency across all file types.
- **Provable convergence** (under the right conditions) gives strong guarantees.
- **Incremental maintenance** (via SAC or DBSP) can be applied to the product.

This is the formal skeleton of the ITT multi-substrate vision.
