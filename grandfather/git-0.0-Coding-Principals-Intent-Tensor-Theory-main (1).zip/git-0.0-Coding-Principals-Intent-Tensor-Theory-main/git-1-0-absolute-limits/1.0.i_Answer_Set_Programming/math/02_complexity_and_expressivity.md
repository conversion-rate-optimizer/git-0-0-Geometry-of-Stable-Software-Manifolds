# ASP Complexity and Expressivity

Where ASP sits in the complexity landscape and what it can express.

## Complexity classes

For **normal logic programs** (single atom heads, negation-as-failure):

| Problem                               | Complexity              |
|---------------------------------------|-------------------------|
| Existence of a stable model           | NP-complete             |
| Is $a$ in some stable model?          | NP-complete (credulous) |
| Is $a$ in every stable model?         | coNP-complete (cautious)|

For **disjunctive logic programs** (disjunction in heads):

| Problem                               | Complexity              |
|---------------------------------------|-------------------------|
| Existence of a stable model           | $\Sigma_2^P$-complete   |
| Credulous reasoning                   | $\Sigma_2^P$-complete   |
| Cautious reasoning                    | $\Pi_2^P$-complete      |

These complexities are for **propositional** ASP (no variables, no grounding). With variables and grounding, the effective complexity is higher because the grounded program can be exponentially larger than the source.

## Grounding complexity

Given a program $P$ with variables and a set of constants $C$, the grounded program $\text{ground}(P, C)$ can have $|P| \cdot |C|^k$ rules where $k$ is the maximum number of distinct variables per rule.

**Grounding blow-up** is a major practical issue. Modern solvers (clingo) use:
- **Intelligent grounding:** only ground rules whose bodies can be satisfied.
- **Lazy grounding:** ground during search.
- **Aggregates:** to avoid exponential expansion of set-based constraints.

## Expressivity

**Propositional ASP** (without variables or function symbols) can express exactly **NP** decision problems (for normal programs) or **$\Sigma_2^P$** (for disjunctive programs).

**Data complexity** (fixing the program, varying facts): NP for normal; $\Sigma_2^P$ for disjunctive.

**Program complexity**: higher, matching the complexity of grounding.

## What you can encode

- All of SAT.
- All of integer linear programming (via `#sum`).
- Planning (propositional or classical).
- Graph problems: coloring, Hamilton cycle, clique, vertex cover.
- Configuration problems.
- Constraint satisfaction.
- Combinatorial optimization (with weights).

## What you cannot encode efficiently

- **Problems requiring exponential-size solutions:** enumerate all subsets, all paths, etc. ASP can enumerate, but the solution set is exponential.
- **Problems requiring real arithmetic:** ASP is discrete; use SMT.
- **PSPACE-hard problems** (game-theoretic planning with adversarial moves): one level too hard for plain ASP.

## Extensions

- **Constraint ASP:** integrate external constraint solvers (e.g., clingcon adds LP / CSP variables).
- **HEX programs:** external predicates that query databases, ontologies, other solvers.
- **ASP modulo theories:** analog of SMT for ASP — integrate theory solvers for arithmetic, strings, etc.

These extend ASP's expressivity toward NP-plus-theory reasoning, at the cost of losing some ASP-specific optimizations.

## Practical takeaway

ASP hits a sweet spot: expressive enough for most NP-hard combinatorial problems, with a clean declarative syntax and mature tooling (clingo, DLV, WASP). For problems that fit, it's the highest-productivity route to a working solver.

For your Intent Engine at scale: if the engine is predominantly an enumeration or configuration problem (find a consistent intent satisfying all constraints), ASP is the natural production-grade backend. If the engine is predominantly numerical (optimize over continuous parameters), SMT with real arithmetic or a convex optimizer is better.
