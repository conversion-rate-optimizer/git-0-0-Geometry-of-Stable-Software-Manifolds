// Rust trait for lattices.
//
// trait = Haskell typeclass = Python Protocol.
// Bounds like `Eq + Clone` declare what operations the lattice element
// type must support; these correspond to the ambient structure we need
// to even talk about equality and copying.

use std::collections::BTreeSet;
use std::hash::Hash;

pub trait Lattice: Eq + Clone {
    fn bottom() -> Self;
    fn top() -> Self;
    fn join(&self, other: &Self) -> Self;
    fn meet(&self, other: &Self) -> Self;
    fn leq(&self, other: &Self) -> bool;
}

// Example 1: bool as a 2-element lattice.
impl Lattice for bool {
    fn bottom() -> Self { false }
    fn top() -> Self    { true }
    fn join(&self, o: &Self) -> Self { *self || *o }
    fn meet(&self, o: &Self) -> Self { *self && *o }
    fn leq(&self, o: &Self) -> bool  { !*self || *o }
}

// Example 2: BTreeSet<T> under inclusion.
// We make a newtype so we don't collide with stdlib semantics.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct SetLat<T: Ord + Clone>(pub BTreeSet<T>);

impl<T: Ord + Clone> Lattice for SetLat<T> {
    fn bottom() -> Self { SetLat(BTreeSet::new()) }
    fn top() -> Self    { panic!("Unbounded set has no top") }
    fn join(&self, o: &Self) -> Self {
        SetLat(self.0.union(&o.0).cloned().collect())
    }
    fn meet(&self, o: &Self) -> Self {
        SetLat(self.0.intersection(&o.0).cloned().collect())
    }
    fn leq(&self, o: &Self) -> bool { self.0.is_subset(&o.0) }
}

// The universal lfp function.
// Returns Err if max_iter is exceeded.
pub fn lfp<L, F>(f: F, start: L, max_iter: usize) -> Result<L, &'static str>
where
    L: Lattice,
    F: Fn(&L) -> L,
{
    let mut x = start;
    for _ in 0..max_iter {
        let x_next = f(&x);
        if x == x_next {
            return Ok(x);
        }
        x = x_next;
    }
    Err("No fixed point reached — operator may not be monotone.")
}

// Example use: transitive closure of a relation.
#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn transitive_closure_via_lfp() {
        let edges: BTreeSet<(i32, i32)> =
            [(1, 2), (2, 3), (3, 4)].iter().cloned().collect();
        let start = SetLat(edges.clone());

        let closed = lfp(|r: &SetLat<(i32, i32)>| {
            let mut new_set = r.0.clone();
            for &(a, b) in &r.0 {
                for &(c, d) in &r.0 {
                    if b == c {
                        new_set.insert((a, d));
                    }
                }
            }
            SetLat(new_set)
        }, start, 100).unwrap();

        assert!(closed.0.contains(&(1, 4)));
    }
}
