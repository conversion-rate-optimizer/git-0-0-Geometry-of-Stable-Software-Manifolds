# Galois Connections

The mathematical core of abstract interpretation.

## Definition

Let $(C, \leq_C)$ and $(A, \leq_A)$ be posets. A **Galois connection** between $C$ (the **concrete** domain) and $A$ (the **abstract** domain) is a pair of monotone functions

$$
\alpha : C \to A, \qquad \gamma : A \to C
$$

such that for all $c \in C$ and $a \in A$:

$$
\alpha(c) \leq_A a \;\iff\; c \leq_C \gamma(a).
$$

This is the **defining adjunction**. We write $C \underset{\gamma}{\overset{\alpha}{\rightleftarrows}} A$ or $\alpha \dashv \gamma$.

**Intuition.** $\alpha$ is the "abstraction" — it forgets detail. $\gamma$ is the "concretization" — it fills in "everything that could have been there." The adjunction says: *the best abstract approximation of a concrete element from below is the dual of the concretization above it.*

## Equivalent characterizations

A pair $(\alpha, \gamma)$ is a Galois connection iff any of the following equivalent conditions hold:

1. **The adjunction:** $\alpha(c) \leq_A a \iff c \leq_C \gamma(a)$.
2. **The inflation/deflation pair:** $c \leq_C \gamma(\alpha(c))$ and $\alpha(\gamma(a)) \leq_A a$, plus monotonicity of both $\alpha$ and $\gamma$.
3. **$\alpha$ preserves all existing joins, $\gamma$ preserves all existing meets.**

## Derived notions

**The induced closure operator on $C$:**
$$
\bar\gamma \circ \bar\alpha : C \to C, \qquad c \mapsto \gamma(\alpha(c)).
$$
This is the "abstraction and then back": the best concrete over-approximation of $c$ that is representable in $A$.

**The induced closure operator on $A$:**
$$
\alpha \circ \gamma : A \to A, \qquad a \mapsto \alpha(\gamma(a)).
$$
If this is the identity, the Galois connection is a **Galois insertion** (i.e., $\alpha$ is surjective). Insertions are what you usually want: every abstract element represents some concrete set.

## The "best abstract transformer"

Given a concrete operator $F : C \to C$, the **best abstract approximation** is

$$
F^\sharp := \alpha \circ F \circ \gamma : A \to A.
$$

**Proposition.** $F^\sharp$ is the best (most precise) abstract operator consistent with $F$: for any other monotone $G : A \to A$ satisfying $\alpha \circ F \leq_A G \circ \alpha$, we have $F^\sharp \leq G$.

## Example: sign abstraction

- Concrete: $C = 2^{\mathbb{Z}}$ (sets of integers), ordered by $\subseteq$.
- Abstract: $A = \{\bot, <0, 0, >0, \leq 0, \geq 0, \neq 0, \top\}$ (sign intervals), ordered by inclusion of represented sets.

$\alpha$ maps a set $S \subseteq \mathbb{Z}$ to the tightest sign representation:
- $\alpha(\emptyset) = \bot$.
- $\alpha(\{0\}) = \{= 0\}$.
- $\alpha(\{1, 2, 3\}) = \{> 0\}$.
- $\alpha(\{-1, 1\}) = \{\neq 0\}$.
- $\alpha(\{0, 1, 2\}) = \{\geq 0\}$.

$\gamma$ maps a sign to the set it represents:
- $\gamma(\bot) = \emptyset$.
- $\gamma(\top) = \mathbb{Z}$.
- $\gamma(\{> 0\}) = \{1, 2, 3, \ldots\}$.

The adjunction holds: $\alpha(S) \leq a$ iff $S \subseteq \gamma(a)$.

## Example: interval abstraction

- Concrete: $C = 2^{\mathbb{Z}}$.
- Abstract: $A = \{\bot\} \cup \{[a, b] : a \leq b, a \in \mathbb{Z} \cup \{-\infty\}, b \in \mathbb{Z} \cup \{+\infty\}\}$.

$\alpha(S) = [\min S, \max S]$ if $S$ is non-empty, else $\bot$.
$\gamma([a, b]) = \{n : a \leq n \leq b\}$.

The interval lattice has infinite ascending chains: $[0, 0] \sqsubset [0, 1] \sqsubset [0, 2] \sqsubset \cdots$. This is why widening (see `02_widening_narrowing.md`) is necessary.

## Example: polyhedral abstraction

- Concrete: $C = 2^{\mathbb{R}^n}$.
- Abstract: $A$ = the lattice of convex polyhedra in $\mathbb{R}^n$.

$\gamma(P)$ = the set of points in $P$.
$\alpha(S)$ = the smallest convex polyhedron containing $S$.

Polyhedra capture linear relationships among variables; used heavily in program analysis (e.g., bounds on array accesses).

## Why Galois connections matter

Because they give us **soundness by construction**. If you have a Galois connection and compute $\operatorname{lfp}(F^\sharp)$ in the abstract domain, you know that the result **over-approximates** $\alpha(\operatorname{lfp}(F))$ — see `01_soundness.md`.

This means: if the abstract result says "no error state is reachable," then no error state is reachable in the concrete semantics either. The abstract interpreter has *proved* a property of the original program.

## Galois connections vs. arbitrary pairs

Not every abstraction/concretization pair is a Galois connection. For the framework to work, you need:
- Monotonicity of both.
- The adjunction (or inflation/deflation + monotonicity).

Without these, soundness can fail: the abstract computation might report "no error" when errors actually exist.

Modern abstract interpreters (Astrée, Clang Static Analyzer, Facebook Infer) all design their domains as proper Galois connections for this reason.
