# 1.0.l — The Hard Ceilings

The theorems that bound every dynamic-computation framework, with proofs.

## Files

**Math:**
- `math/00_halting_problem.md` — Turing 1936, full proof.
- `math/01_rice_theorem.md` — Every non-trivial semantic property is undecidable.
- `math/02_cook_levin.md` — SAT is NP-complete.
- `math/03_godel_incompleteness.md` — Arithmetic is incomplete.
- `math/04_time_hierarchy.md` — More time → strictly more power.

**Code:**
- `code/ceilings_in_code.py` — How these theorems manifest as `unknown`, `timeout`, `maxIter`.
