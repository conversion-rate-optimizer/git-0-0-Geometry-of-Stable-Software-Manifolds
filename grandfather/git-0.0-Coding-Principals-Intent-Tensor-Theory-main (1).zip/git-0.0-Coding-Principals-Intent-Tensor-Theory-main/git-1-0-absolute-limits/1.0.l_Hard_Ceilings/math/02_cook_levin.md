# The Cook–Levin Theorem

The theorem that founded complexity theory: SAT is NP-complete.

## Statement

**Theorem (Cook 1971, Levin 1973).** *The Boolean satisfiability problem (SAT) is NP-complete.*

In more detail:
1. **SAT ∈ NP.** Given a proposed assignment, checking satisfaction is polynomial.
2. **SAT is NP-hard.** Every problem in NP reduces polynomially to SAT.

## Proof sketch of NP-hardness

Let $L$ be an arbitrary language in NP. By definition, there is a polynomial-time non-deterministic Turing machine $M$ and a polynomial $p$ such that:

$$
x \in L \iff \text{some computation path of } M \text{ on } x \text{ accepts in } \leq p(|x|) \text{ steps.}
$$

Cook constructs a polynomial-size CNF formula $\varphi_{M, x}$ over variables encoding:
- **Tape contents** at each time step.
- **Head position** at each time step.
- **Machine state** at each time step.
- **Transition choices** at each step (non-deterministic).

Clauses express:
- **Initial state** of the tape (encoding the input $x$).
- **Transition rules** of $M$ (at each step, some transition fires).
- **Tape stability** (cells not under the head stay the same).
- **Acceptance** (the machine is in an accepting state at some step $\leq p(|x|)$).

$\varphi_{M, x}$ is satisfiable iff some computation path of $M$ on $x$ accepts. Construction is polynomial in $|x|$ and $p(|x|)$, so in $|x|$.

This is the **tableau encoding** of a Turing machine into SAT.

$\blacksquare$

## Completeness implications

Since every NP problem reduces to SAT, **SAT is universal** for NP:
- If SAT is in P, then P = NP.
- Conversely, if P ≠ NP, no polynomial algorithm solves SAT in the worst case.

$P \stackrel{?}{=} NP$ remains the most famous open problem in mathematics/CS.

## Practical significance

Modern SAT solvers handle millions of clauses in seconds on real-world instances, but:
- **Worst-case is still exponential.** Specifically hard instances (random 3-SAT near the phase transition, pigeonhole formulas) exhibit super-polynomial behavior.
- **No instance-size guarantee.** Small changes to a formula can flip solving time from seconds to days.

This is the engineering reality of the NP-complete boundary.

## Other NP-complete problems (via reduction from SAT)

- 3-SAT, 3-coloring of graphs.
- Hamiltonian cycle.
- Traveling salesman (decision).
- Subset sum, Knapsack (decision).
- Vertex cover, clique, independent set.
- SMT (in many theories).
- Integer linear programming feasibility.
- Many planning, scheduling, allocation problems.

Thousands of natural problems are now known to be NP-complete. Cook–Levin gave us the framework; Karp (1972) provided the first extensive list.

## Complexity hierarchy

```
P ⊆ NP ⊆ PSPACE ⊆ EXPTIME ⊆ EXPSPACE ⊆ ...
```

Strictly between P and NP (if P ≠ NP) are problems that are in NP but not NP-complete — the existence of such problems is guaranteed by Ladner's theorem.

Above NP:
- **coNP:** problems whose *no*-instances have polynomial-checkable certificates.
- **Polynomial hierarchy:** $\Sigma_k^P, \Pi_k^P$ levels corresponding to alternation of quantifiers.
- **PSPACE:** polynomial-space decidable.
- **EXPTIME:** exponential-time decidable.

SAT is canonical for level 1 of this hierarchy. Each level up has its own canonical complete problem (QBF for PSPACE, etc.).

## Consequences for dynamic-coding engines

Any engine expressive enough to encode arbitrary SAT instances is:
- **NP-hard** in the worst case.
- Dependent on heuristics (CDCL, restarts, VSIDS) for practical performance.
- Vulnerable to adversarial inputs.

The practical implication: **benchmarking matters**. The complexity landscape of your inputs is at least as important as the worst-case complexity of your algorithms.

## Connection to dynamic-coding paradigms

| Paradigm                 | Typical complexity                |
|--------------------------|-----------------------------------|
| Datalog                  | PTIME                             |
| Stratified Datalog       | PTIME                             |
| ASP (stable models)      | NP-complete                       |
| SAT / SMT                | NP-complete (and beyond)          |
| Disjunctive ASP          | $\Sigma_2^P$-complete             |
| Planning                 | PSPACE-complete (classical)       |
| Synthesis / game playing | 2-EXPTIME or higher               |

As expressivity grows, complexity grows. SAT is the canonical step up from PTIME to NP — crossing this line is often unavoidable if you want negation, disjunction, or arbitrary choice in your system.
