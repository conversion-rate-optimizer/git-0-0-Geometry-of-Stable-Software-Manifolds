-- Haskell Shake: monadic build system.
-- Install: cabal install shake

import Development.Shake
import Development.Shake.FilePath

main :: IO ()
main = shakeArgs shakeOptions $ do
  want ["_build/hello.o", "_build/world.o"]

  "_build/*.o" %> \out -> do
    let src = "src" </> takeBaseName out <.> "c"
    need [src]                                 -- monadic fetch
    cmd_ "gcc" "-c" src "-o" out

  "_build/app" %> \out -> do
    objs <- getDirectoryFiles "_build" ["*.o"]
    need objs
    cmd_ "gcc" objs "-o" out
