# Energy Formulation

Viewing the engine as minimizing an inconsistency functional.

## The energy functional

Given constraints $(C_j)$ with weights $w_j$, define

$$
E : \mathcal{S} \to \mathbb{R}_{\geq 0}, \qquad E(s) = \sum_j w_j \cdot \text{viol}_j(s)
$$

where $\text{viol}_j(s) \in \{0, 1\}$ (hard constraints) or $\text{viol}_j(s) \in \mathbb{R}_{\geq 0}$ (soft metric).

The engine's goal, in this formulation:

$$
s^\star = \arg\min_{s \in \mathcal{S}} E(s).
$$

## Why energy

Three reasons:

1. **Unification.** MaxSAT, WCSP, Markov Random Fields, stochastic optimization — all instances of energy minimization with different structural assumptions.

2. **Continuous relaxation.** Integer state → real relaxation; NP-hard discrete optimization → convex optimization (in favorable cases).

3. **Physics analogy.** The engine reaches equilibrium when energy is minimized. This is the thermodynamic picture underlying many ITT framings.

## Special cases

### Hard-only
If all $w_j = +\infty$ on violation, 0 otherwise, $\arg\min E$ is exactly the set of states satisfying every constraint.

### MaxSAT
If $w_j$ finite and $\text{viol}_j \in \{0, 1\}$, this is standard weighted MaxSAT.

### Markov Random Field
If $\mathcal{S} = \prod_i V_i$ is a product space and each $C_j$ has scope over a small subset of variables, the energy is a **sum of local potentials** — exactly an MRF.

Inference via:
- Belief propagation (message passing).
- Gibbs sampling / MCMC.
- Mean-field approximation.
- Junction tree algorithm (exact, exponential in treewidth).

### Continuous optimization
If $\mathcal{S} \subseteq \mathbb{R}^n$ and $E$ is smooth, use:
- Gradient descent: $s_{t+1} = s_t - \eta \nabla E(s_t)$.
- Newton's method (if Hessian is tractable).
- L-BFGS, Adam, etc. (quasi-Newton).

If $E$ is convex, these converge to the global minimum.

## Boltzmann interpretation

Define

$$
P(s) \;\propto\; \exp(-\beta \cdot E(s))
$$

where $\beta > 0$ is the "inverse temperature."

- As $\beta \to \infty$, $P$ concentrates on $\arg\min E$ — deterministic minimization.
- At finite $\beta$, $P$ is spread — probabilistic / noisy optimization.

This connects constraint satisfaction to **probabilistic graphical models** and makes techniques like simulated annealing (slowly increasing $\beta$) natural.

## Gradient flow (continuous time)

The deterministic continuous-time analog is **gradient flow**:

$$
\frac{d s}{d t} = -\nabla E(s).
$$

Under regularity conditions, trajectories converge to critical points of $E$. For convex $E$, every trajectory reaches the global minimum.

**ITT Allen–Cahn dynamics** sit here: a reaction-diffusion equation that can be interpreted as gradient flow on a specific energy functional. The iteration-to-fixed-point discrete view and the gradient-flow continuous view are the same picture at different time scales.

## When energy works, when it doesn't

Energy works well when:
- Constraints have graded violation (real-valued).
- State space has a natural geometry.
- Smooth relaxations exist.

Energy does not apply naturally when:
- Constraints are combinatorial (no graded violation).
- State space is fundamentally discrete (no natural embedding).
- Problem is PSPACE-hard or worse (optimization insight doesn't help).

Most ITT-relevant problems have some continuous / graded structure. Energy minimization is often the right production-grade route.

## Practical recipe

1. Assign each constraint a weight $w_j > 0$ (lower priority = lower weight).
2. Define $\text{viol}_j(s)$ as a smooth-ish function (e.g., squared distance from the constraint surface).
3. Sum to get $E(s)$.
4. Start from any $s_0$; apply gradient descent or (L-)BFGS.
5. Observe convergence rate and final energy.
6. Tune weights to prioritize different constraints.

This gives a deterministic, continuous engine that often outperforms iterative rule systems when the lattice is relaxable.

## The ITT connection

ITT's physics-inspired formulations (Allen–Cahn semantic diffusion, Selection Number dynamics, CyberAxis tensors) naturally live in the energy formulation. The fixed-point equation $S^\star = F(S^\star)$ becomes $\nabla E(s^\star) = 0$ — the same object in different language.

This is where ITT's perspective might genuinely contribute: a principled way to translate physics-motivated dynamics into verified constraint engines, inheriting convergence theorems from both sides.
