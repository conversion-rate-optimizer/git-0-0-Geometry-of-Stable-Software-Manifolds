# Propositions as Types

The isomorphism between logic and computation.

## The core correspondence

| Logic                    | Type theory                       | Program / evaluation           |
|--------------------------|-----------------------------------|--------------------------------|
| Proposition $A$          | Type $A$                          | —                              |
| Proof of $A$             | Term $t : A$                      | Program inhabiting $A$         |
| $A \Rightarrow B$        | $A \to B$                         | Function                       |
| $A \wedge B$             | $A \times B$                      | Pair / record                  |
| $A \vee B$               | $A + B$                           | Tagged union                   |
| $\top$                   | Unit type `1`                     | `()`                           |
| $\bot$                   | Empty type `0`                    | (no terms)                     |
| $\neg A$                 | $A \to 0$                         | Function with empty codomain   |
| $\forall x : A.\; P(x)$  | $\prod_{x : A} P(x)$              | Dependent function             |
| $\exists x : A.\; P(x)$  | $\sum_{x : A} P(x)$               | Dependent pair                 |
| Cut elimination          | $\beta$-reduction                 | Evaluation                     |
| Normal form              | Value                             | Terminated program             |

## Curry (1958) and Howard (1969)

Curry observed that typed lambda terms and natural-deduction proofs have the same structure. Howard extended to full intuitionistic logic.

**Theorem (Curry–Howard correspondence).** *There is a bijection between:*
- *Proofs of $A$ in intuitionistic natural deduction.*
- *Closed terms of type $A$ in the simply-typed lambda calculus.*
- *Programs that produce a value of type $A$.*

**Theorem (Curry–Howard–Lambek).** *These further correspond to objects of a Cartesian closed category.*

## Why this matters

Proving a theorem *is* writing a program:

- The **type** is the theorem statement.
- The **term** (program) is the proof.
- **Type checking** is proof checking.

Modern **proof assistants** (Lean 4, Rocq, Agda, Idris) are built on this idea. Writing a proof feels like writing a program; the compiler verifies it.

## Example

**Theorem:** $A \wedge B \Rightarrow B \wedge A$.

**Proof (natural deduction):**
1. Assume $A \wedge B$.
2. Extract $A$ via $\wedge$-elim-left.
3. Extract $B$ via $\wedge$-elim-right.
4. Introduce $B \wedge A$ via $\wedge$-intro.

**Term:**
```haskell
swap :: (a, b) -> (b, a)
swap (x, y) = (y, x)
```

**The function `swap` is the proof.** Running the function corresponds to cut-elimination in the proof.

## Intuitionistic vs. classical

Curry–Howard corresponds **intuitionistic** logic (no excluded middle) to simply-typed lambda calculus.

**Classical** logic requires additional machinery:
- Griffin (1990): Felleisen's control operator $C$ corresponds to $\neg\neg A \Rightarrow A$.
- Parigot's $\lambda\mu$-calculus: extends lambda calculus with classical control.

For most programming purposes, intuitionistic logic is enough: every constructive proof gives a computable function.

## Implications for dynamic coding

- **Specification as type:** you can write `sort :: (xs : List Int) -> (ys : List Int) -> IsSorted ys * IsPermutation xs ys` and the compiler verifies your implementation is correct.
- **Invariants encoded in types:** `Vec n a` is a list of exactly `n` elements; indexing is statically safe.
- **Certificates:** every successful computation carries a proof that the result satisfies the specification.

This is the endpoint of the dependent-types-as-computation story: types are executable mathematics.

## The ceiling

**Undecidability of type inhabitation.** Given a type $A$, is there a term $t : A$? In full dependent type theory, this is **undecidable** (see `02_type_inhabitation.md`). Gödel's incompleteness theorem reincarnated — we cannot algorithmically find all proofs.

So: type-checking a *given* term is decidable. Finding a term for a *given* type is not. Proof search is fundamentally incomplete.
