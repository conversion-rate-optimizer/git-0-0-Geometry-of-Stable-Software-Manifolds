/**
 * 0.3_COMPETITION: Temporal Tensor (Field Hardening)
 * ====================================================
 * Implements Hebbian-style weight updates based on cycle wins.
 *
 * The plasticity rule:
 *   W_ij(t+1) = W_ij(t) + α * (S_C - 1)  for all i,j ∈ winning cycle
 *   W         *= 0.99                       global decay (prevents saturation)
 *
 * What this does:
 *   Winning cycles carve their paths deeper into W.
 *   Future field diffusion flows more easily through proven routes.
 *   The manifold learns which structures have historically won.
 *
 * This is the bridge from field-solving to field-memory.
 * The equivalent of version control — but emergent, not manual.
 *
 * Anchor condition:
 *   If a cycle wins for ANCHOR_THRESHOLD consecutive steps,
 *   it becomes an anchor: injects its own seed, survives without input.
 */

import { SELECTION } from "../-Z_BASE/axioms";
import type { CycleState } from "./cycle_competition";

/** How fast winning cycles reinforce their paths */
const PLASTICITY = 0.05;

/** Global weight decay — prevents W from saturating */
const WEIGHT_DECAY = 0.99;

/** Consecutive wins required to become an anchor */
const ANCHOR_THRESHOLD = 5;

export interface AnchorRecord {
  nodes: string[];
  consecutiveWins: number;
  isAnchor: boolean;
  /** Intrinsic excitation injected when anchor is active */
  selfSeed: number;
}

export class TemporalTensor {
  /** Learned weight matrix — hardens where winning cycles live */
  private W: Map<string, Map<string, number>> = new Map();

  /** Win streak tracker per cycle (keyed by sorted node list) */
  private streaks: Map<string, AnchorRecord> = new Map();

  private alpha: number;

  constructor(alpha: number = PLASTICITY) {
    this.alpha = alpha;
  }

  /**
   * Update W based on this round's winners.
   * Winners reinforce their edges. Everything else slowly decays.
   */
  updateManifold(winners: CycleState[]): void {
    // Reinforce winning cycle edges
    for (const cycle of winners) {
      const reinforcement = this.alpha * (cycle.S - 1);

      for (const i of cycle.nodes) {
        for (const j of cycle.nodes) {
          if (i === j) continue;
          const row = this.W.get(i) ?? new Map<string, number>();
          row.set(j, (row.get(j) ?? 0) + reinforcement);
          this.W.set(i, row);
        }
      }
    }

    // Global decay — manifold forgets slowly without reinforcement
    for (const [, row] of this.W) {
      for (const [id, w] of row) {
        row.set(id, w * WEIGHT_DECAY);
      }
    }
  }

  /**
   * Track win streaks and promote cycles to anchor status.
   */
  updateStreaks(winners: CycleState[], allCycles: CycleState[]): AnchorRecord[] {
    const winnerKeys = new Set(
      winners.map(c => [...c.nodes].sort().join(","))
    );

    // Increment winners, reset losers
    for (const cycle of allCycles) {
      const key = [...cycle.nodes].sort().join(",");
      const record = this.streaks.get(key) ?? {
        nodes: cycle.nodes,
        consecutiveWins: 0,
        isAnchor: false,
        selfSeed: 0,
      };

      if (winnerKeys.has(key)) {
        record.consecutiveWins++;
        // Promote to anchor after sustained winning
        if (record.consecutiveWins >= ANCHOR_THRESHOLD) {
          record.isAnchor = true;
          record.selfSeed = 0.5; // Injects its own activation
          console.log(`[ANCHOR_LOCKED]: ${key} — ${record.consecutiveWins} consecutive wins`);
        }
      } else {
        record.consecutiveWins = 0;
        record.isAnchor = false;
        record.selfSeed = 0;
      }

      this.streaks.set(key, record);
    }

    return Array.from(this.streaks.values()).filter(r => r.isAnchor);
  }

  /**
   * Apply anchor self-excitation to the seed map.
   * Anchors inject their own activation — they survive without external input.
   */
  applyAnchors(
    seed: Map<string, number>,
    anchors: AnchorRecord[]
  ): Map<string, number> {
    const updated = new Map(seed);
    for (const anchor of anchors) {
      for (const id of anchor.nodes) {
        updated.set(id, Math.max(updated.get(id) ?? 0, anchor.selfSeed));
      }
    }
    return updated;
  }

  /**
   * Get the learned weight reinforcements.
   * These are ADDITIONS to the base W — not replacements.
   * Base W comes from semantic similarity; this layer adds history.
   */
  getLearnedWeights(): Map<string, Map<string, number>> {
    return this.W;
  }

  /**
   * Merge learned weights into the base weight matrix.
   * Learned paths become stronger coupling channels.
   */
  mergeIntoBase(
    baseW: Map<string, Map<string, number>>
  ): Map<string, Map<string, number>> {
    const merged = new Map(baseW);
    for (const [i, row] of this.W) {
      const baseRow = merged.get(i) ?? new Map<string, number>();
      for (const [j, learned] of row) {
        baseRow.set(j, (baseRow.get(j) ?? 0) + learned);
      }
      merged.set(i, baseRow);
    }
    return merged;
  }
}
