/**
 * 0.2_CYCLES: Cycle Detector
 * ===========================
 * Finds all simple cycles in the weighted graph.
 * Wraps the DFS-based cycle finder from cycle_persistence.ts
 * and adds filtering by minimum weight threshold.
 *
 * Only edges above LATTICE.resonance_threshold (0.16) form cycles —
 * weak couplings don't create self-sustaining loops.
 */

import { LATTICE } from "../-Z_BASE/axioms";

/**
 * Find all simple cycles in the directed weight graph.
 * Limits to cycles of length 2 through maxLength.
 *
 * Only traverses edges above the resonance threshold —
 * sub-threshold edges cannot carry enough field to sustain a loop.
 */
export function detectCycles(
  W: Map<string, Map<string, number>>,
  maxLength: number = 8
): string[][] {
  const nodes = Array.from(W.keys());
  const cycles: string[][] = [];
  const seen = new Set<string>();

  function dfs(start: string, current: string, path: string[]): void {
    if (path.length > maxLength) return;

    const neighbors = W.get(current);
    if (!neighbors) return;

    for (const [next, weight] of neighbors) {
      // Only follow edges above threshold
      if (weight < LATTICE.resonance_threshold) continue;

      if (next === start && path.length >= 2) {
        // Found a cycle — normalize key to detect duplicates
        const key = [...path].sort().join(",");
        if (!seen.has(key)) {
          seen.add(key);
          cycles.push([...path]);
        }
        continue;
      }

      if (!path.includes(next)) {
        dfs(start, next, [...path, next]);
      }
    }
  }

  for (const node of nodes) {
    dfs(node, node, [node]);
  }

  return cycles;
}

/**
 * Filter cycles to only those where ALL edges exceed threshold.
 * A cycle is only viable if every link in it can carry field.
 */
export function viableCycles(
  cycles: string[][],
  W: Map<string, Map<string, number>>
): string[][] {
  return cycles.filter(cycle => {
    for (let i = 0; i < cycle.length; i++) {
      const from = cycle[i];
      const to = cycle[(i + 1) % cycle.length];
      const w = W.get(from)?.get(to) ?? 0;
      if (w < LATTICE.resonance_threshold) return false;
    }
    return true;
  });
}

/**
 * Minimum cycle weight — the weakest edge in the cycle.
 * This is the bottleneck for field circulation.
 */
export function cycleBottleneck(
  cycle: string[],
  W: Map<string, Map<string, number>>
): number {
  let min = Infinity;
  for (let i = 0; i < cycle.length; i++) {
    const from = cycle[i];
    const to = cycle[(i + 1) % cycle.length];
    const w = W.get(from)?.get(to) ?? 0;
    min = Math.min(min, w);
  }
  return min === Infinity ? 0 : min;
}
