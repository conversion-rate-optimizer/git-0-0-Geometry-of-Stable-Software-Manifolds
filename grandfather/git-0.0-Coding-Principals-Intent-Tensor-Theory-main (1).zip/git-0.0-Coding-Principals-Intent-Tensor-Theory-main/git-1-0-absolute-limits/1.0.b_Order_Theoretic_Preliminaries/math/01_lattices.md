# Lattices and Complete Lattices

## Lattices

A **lattice** is a poset $(L, \leq)$ in which every two-element subset $\{a, b\} \subseteq L$ has:
- A **join** (least upper bound) $a \vee b$.
- A **meet** (greatest lower bound) $a \wedge b$.

By induction, every non-empty finite subset of a lattice has a join and a meet.

### Equivalent algebraic definition

A lattice can equivalently be defined as an algebraic structure $(L, \vee, \wedge)$ where $\vee$ and $\wedge$ are binary operations satisfying:

1. **Commutativity:** $a \vee b = b \vee a$; $a \wedge b = b \wedge a$.
2. **Associativity:** $(a \vee b) \vee c = a \vee (b \vee c)$; $(a \wedge b) \wedge c = a \wedge (b \wedge c)$.
3. **Absorption:** $a \vee (a \wedge b) = a$; $a \wedge (a \vee b) = a$.
4. **Idempotence:** $a \vee a = a$; $a \wedge a = a$. (Derivable from absorption.)

The order is recovered by $a \leq b \iff a \vee b = b \iff a \wedge b = a$.

## Complete lattices

A **complete lattice** is a poset $(L, \leq)$ in which *every* subset $S \subseteq L$ (including $\emptyset$ and infinite subsets) has both $\bigvee S$ and $\bigwedge S$.

Consequences:
- $\top := \bigvee L = \bigwedge \emptyset$ (top element).
- $\bot := \bigwedge L = \bigvee \emptyset$ (bottom element).
- Every complete lattice has $\top$ and $\bot$.

### Why completeness matters

Knaster–Tarski and Kleene both require *some* form of completeness (full completeness for Knaster–Tarski; directed-completeness with a bottom for Kleene). The existence of arbitrary joins and meets is precisely what makes fixed-point existence provable.

## Canonical examples

### Example 1: Power set

$(2^X, \subseteq)$ is a complete lattice for any set $X$:
- $\bigvee \mathcal{S} = \bigcup \mathcal{S}$.
- $\bigwedge \mathcal{S} = \bigcap \mathcal{S}$.
- $\top = X$, $\bot = \emptyset$.

This is the most important example: Datalog, SAT, constraint-satisfaction problems, and set-based static analyses all work over power-set lattices.

### Example 2: Flat domain

For any set $X$, the **flat domain** $X_\bot$ adds a new bottom element $\bot$ below all of $X$, with distinct elements of $X$ incomparable to each other:

```
    x₁   x₂   x₃   ...
      \   |   /
        \ | /
          ⊥
```

This is a complete lattice only if we additionally add a top $\top$. Flat domains model "partial information" — either known (element of $X$) or unknown ($\bot$).

### Example 3: Pointed DCPO

A **directed-complete partial order** (DCPO) is a poset in which every directed subset has a supremum. A **pointed DCPO** additionally has a bottom element. DCPOs are weaker than complete lattices (not every subset is required to have a sup), but strong enough for Kleene's theorem.

Every complete lattice is a pointed DCPO, but not conversely.

### Example 4: Interval domain

For $\mathbb{R}$, the set of intervals $[a, b]$ with $a \leq b$, ordered by reverse inclusion ($I_1 \leq I_2 \iff I_2 \subseteq I_1$), gives a complete lattice. This is used in interval arithmetic for program analysis.

### Example 5: Function space

If $L$ is a complete lattice and $X$ is any set, then $X \to L$ with pointwise order is a complete lattice. Joins and meets are pointwise.

This makes state spaces — functions from variables to values — into lattices.

## Sub-lattices and morphisms

A subset $L' \subseteq L$ is a **sub-lattice** iff it is closed under $\vee$ and $\wedge$.

A function $f : L_1 \to L_2$ between lattices is a **lattice homomorphism** iff $f(a \vee b) = f(a) \vee f(b)$ and $f(a \wedge b) = f(a) \wedge f(b)$.

**Complete** lattice homomorphisms preserve arbitrary joins and meets.

## What we actually use

For the rest of this chapter:
- **Most fixed-point results** require only **complete lattice** or **pointed DCPO**.
- **Abstract interpretation** uses **Galois connections** between complete lattices (monotone but not necessarily homomorphic).
- **Datalog semantics** uses the **power set lattice** over the Herbrand base.
- **Differential dataflow** uses **Z-modules** (which are *not* lattices — they are abelian groups). This is one of the places the lattice framework is replaced by a different algebraic object.
