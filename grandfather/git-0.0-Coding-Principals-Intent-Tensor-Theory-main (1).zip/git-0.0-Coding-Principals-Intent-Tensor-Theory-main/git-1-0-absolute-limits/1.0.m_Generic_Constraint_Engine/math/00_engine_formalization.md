# Formalization of the Generic Engine

The ITT Intent Engine, written mathematically.

## Types

Let $\mathcal{S}$ be a **state space** — a structured set (typically $\mathcal{S} = V_1 \times V_2 \times \cdots \times V_n$ for variable domains $V_i$).

Assume $(\mathcal{S}, \leq)$ is a complete lattice, or at least a pointed DCPO.

## Derivations

A **derivation** is a partial map

$$
D_i : \mathcal{S} \rightharpoonup \mathcal{S}
$$

that proposes an update to the state. Typically $D_i(s) = s \sqcup \delta_i(s)$ — join the current state with some newly-derived information.

## Constraints

A **constraint** is a projection

$$
C_j : \mathcal{S} \to \mathcal{S}
$$

that enforces a condition. If $s$ satisfies $C_j$, then $C_j(s) = s$. Otherwise, $C_j(s)$ is a "corrected" state satisfying the condition.

Each constraint has a **priority** $\pi(j) \in \mathbb{N}$.

## The engine operator

The engine is parameterized by:
- A finite set of derivations $\{D_i\}_{i \in I}$.
- A finite set of constraints $\{(C_j, \pi(j))\}_{j \in J}$.

Define

$$
F \;\coloneqq\; \left( \bigcirc_{j \in J,\, \text{ordered by decreasing } \pi} C_j \right) \circ \left( \bigcirc_{i \in I} D_i \right).
$$

The engine runs

$$
s_{t+1} = F(s_t), \qquad s_0 = \text{initial state}
$$

until $s_{t+1} = s_t$, returning $s^\star = s_t$.

## Formal statements

**Definition (Engine convergence).** The engine **converges** on input $s_0$ iff the sequence $s_0, s_1, s_2, \ldots$ is eventually stationary.

**Definition (Engine correctness).** A converged $s^\star$ is **correct** iff:
1. $D_i(s^\star) \leq s^\star$ for all $i$ (no further derivations).
2. $C_j(s^\star) = s^\star$ for all $j$ (all constraints satisfied).

## Existence theorems (inherited from Chapter 1)

**Theorem (Kleene applied to the engine).** *If $F$ is Scott-continuous on a pointed DCPO, then $\operatorname{lfp}(F) = \bigvee_n F^n(\bot)$ exists and is reached in countably many steps.*

**Theorem (Knaster–Tarski applied to the engine).** *If $F$ is monotone on a complete lattice, then $\operatorname{Fix}(F)$ is non-empty and forms its own complete lattice.*

## Non-convergence cases

**Theorem (Oscillation).** *If there exist distinct states $s_1, s_2$ such that $F(s_1) = s_2$ and $F(s_2) = s_1$ with $s_1 \neq s_2$, the engine does not converge on any input that enters the orbit $\{s_1, s_2\}$.*

This is the formalization of "conflicting intents" in the original engine documentation.

## Soundness vs. completeness

- **Sound engine:** if it returns $s^\star$, then $s^\star$ is a fixed point.
- **Complete engine:** if a fixed point exists reachable from $s_0$, the engine finds it.

Hand-rolled Kleene iteration is sound by construction. It is complete *only* for Scott-continuous operators on finite-height lattices.

For non-monotone or retractive constraints, the engine is sound (when it returns) but incomplete. Options to recover completeness:
- Use SAT/SMT backend.
- Stratify the constraint system.
- Use ASP with stable-model semantics.

## Comparing to classical systems

| Classical system    | Engine analog                                      |
|---------------------|----------------------------------------------------|
| Datalog             | Pure derivations, no constraints with retraction.  |
| Attribute grammars  | Tree-structured state, monotone derivations.       |
| Reactive UI         | SAC-style engine (change propagation).             |
| Rule engines        | Production rules with priority.                    |
| Constraint solvers  | Engine + full backtracking.                        |

The ITT engine's distinctive feature is its **explicit priority system** for resolving non-monotone constraint conflicts. This corresponds to lex-MaxSAT (see `02_priority_as_lex_maxsat.md`).
