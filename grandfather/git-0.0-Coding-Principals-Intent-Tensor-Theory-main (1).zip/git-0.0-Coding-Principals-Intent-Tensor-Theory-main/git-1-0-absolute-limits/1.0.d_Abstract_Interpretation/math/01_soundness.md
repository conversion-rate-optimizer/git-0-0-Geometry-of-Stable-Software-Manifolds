# The Soundness Theorem

Why abstract interpretation is sound: because of the adjunction.

## Statement

**Theorem (Cousot & Cousot, 1977).** *Let $(C, \leq_C)$ and $(A, \leq_A)$ be complete lattices, let $\alpha \dashv \gamma$ be a Galois connection between them, and let $F : C \to C$ and $F^\sharp : A \to A$ be monotone functions satisfying*

$$
\alpha \circ F \;\leq_A\; F^\sharp \circ \alpha \qquad \text{(soundness condition)}.
$$

*Then:*

$$
\alpha(\operatorname{lfp}(F)) \;\leq_A\; \operatorname{lfp}(F^\sharp).
$$

## Proof

Let $c^\star = \operatorname{lfp}(F)$ and $a^\star = \operatorname{lfp}(F^\sharp)$.

**Step 1: Define $b = \gamma(a^\star)$. We claim $F(b) \leq_C b$.**

By the adjunction, $F(b) \leq_C b$ iff $\alpha(F(b)) \leq_A a^\star$. We show this:

$$
\alpha(F(b)) = \alpha(F(\gamma(a^\star))) \leq_A F^\sharp(\alpha(\gamma(a^\star))) \leq_A F^\sharp(a^\star) = a^\star,
$$

using the soundness condition and $\alpha \circ \gamma \leq_A \operatorname{id}_A$ (from the adjunction) and monotonicity of $F^\sharp$ and the fixed-point property of $a^\star$.

**Step 2: $b$ is a pre-fixed point of $F$.**

So by Park induction (see `1.0.c/math/03_fixed_point_vocabulary.md`), $\operatorname{lfp}(F) \leq_C b$, i.e., $c^\star \leq_C \gamma(a^\star)$.

**Step 3: Apply $\alpha$.**

By monotonicity, $\alpha(c^\star) \leq_A \alpha(\gamma(a^\star)) \leq_A a^\star$ (using $\alpha \circ \gamma \leq \operatorname{id}$).

$\blacksquare$

## What soundness actually says

"The abstract least fixed point over-approximates the abstraction of the concrete least fixed point."

Put another way: if the abstract analysis says $P$ is true, then $P$ is true (after concretizing). The abstract analysis cannot prove false statements — it can only **fail to prove true statements** (incompleteness).

## Completeness — when abstraction loses nothing

**Definition.** The pair $(F, F^\sharp)$ is **complete** iff

$$
\alpha \circ F = F^\sharp \circ \alpha.
$$

In this case, $\alpha(\operatorname{lfp}(F)) = \operatorname{lfp}(F^\sharp)$ (equality, not just $\leq$).

Completeness is rare and delicate. Most practical abstract interpretations sacrifice completeness for tractability.

## Best abstract transformer

We defined $F^\sharp = \alpha \circ F \circ \gamma$ as the "best" abstract transformer. It is the most precise abstract operator consistent with $F$ (see `00_galois_connections.md`).

However, $F^\sharp$ is often **not computable**, because it involves concretizing to infinite sets. In practice, we pick a *computable* $F^\sharp$ that over-approximates the best one.

## Example: signs analysis of $x := x + 1$

- $C = 2^{\mathbb{Z}}$.
- $A = $ signs lattice.
- $F(S) = \{n + 1 : n \in S\}$ (concrete semantics of "add 1").
- $F^\sharp$ on signs:
  - $F^\sharp(\bot) = \bot$.
  - $F^\sharp(\top) = \top$.
  - $F^\sharp(\{= 0\}) = \{> 0\}$.
  - $F^\sharp(\{> 0\}) = \{> 0\}$.
  - $F^\sharp(\{< 0\}) = \{\leq 0\}$ (since $-1 + 1 = 0$).
  - $F^\sharp(\{\leq 0\}) = \top$? No, $\{\leq 0\} + 1 = \{\leq 1\}$; in our signs lattice, that's $\top$ unless we add a specific element for $\{\leq 1\}$, which signs don't have.
- This last row shows where precision is lost. A richer lattice (intervals) would not lose it.

## The generalization

The same theorem holds for Galois **insertions** (where $\alpha$ is surjective), sub-Galois connections, and various weaker adjunctions — with corresponding weakenings of the conclusion.

For our purposes, the key takeaway is simply: **if you can write down a Galois connection, you get soundness for free**. The math does the heavy lifting.

## Application to your engine

If the ITT Intent Engine operates on a state lattice $\mathcal{S}$ and you design an abstraction $\alpha : \mathcal{S} \to \mathcal{A}$ for some simpler analysis (e.g., "does this state have $\text{sent} = \text{True}$?"), then running the abstract engine $F^\sharp$ on $\mathcal{A}$ gives a sound over-approximation of any property provable from the concrete fixed point.

This is how you get **verified** results from a constraint engine without running the full concrete computation.
