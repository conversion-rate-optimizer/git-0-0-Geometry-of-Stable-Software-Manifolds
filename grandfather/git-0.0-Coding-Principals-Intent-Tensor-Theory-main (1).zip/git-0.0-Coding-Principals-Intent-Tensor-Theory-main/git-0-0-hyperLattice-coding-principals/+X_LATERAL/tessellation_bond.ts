/**
 * +X_LATERAL: Tessellation Bond
 * ==============================
 * Records and manages module bonding events.
 * A bond forms when two modules' void geometries tessellate.
 * Each bond is a discrete topological event (BET catastrophe analog).
 */

import { fieldBus } from "./event_emitter";

export interface Bond {
  moduleA: string;
  moduleB: string;
  coupling: number;
  formedAt: number;   // Iteration
  active: boolean;
}

export class TessellationBondRegistry {
  private bonds: Bond[] = [];
  private iteration = 0;

  tick(): void { this.iteration++; }

  /**
   * Record a new bond between two modules.
   * Emits BOND_FORMED event to the field bus.
   */
  form(moduleA: string, moduleB: string, coupling: number): Bond {
    // Check if already bonded
    const existing = this.bonds.find(
      b => b.active &&
      ((b.moduleA === moduleA && b.moduleB === moduleB) ||
       (b.moduleA === moduleB && b.moduleB === moduleA))
    );
    if (existing) return existing;

    const bond: Bond = {
      moduleA, moduleB, coupling,
      formedAt: this.iteration,
      active: true,
    };

    this.bonds.push(bond);
    fieldBus.emit("BOND_FORMED", moduleA, { moduleB, coupling });
    return bond;
  }

  /**
   * Dissolve a bond (BET catastrophe — topology changes).
   */
  dissolve(moduleA: string, moduleB: string): void {
    for (const bond of this.bonds) {
      if (bond.active &&
          ((bond.moduleA === moduleA && bond.moduleB === moduleB) ||
           (bond.moduleA === moduleB && bond.moduleB === moduleA))) {
        bond.active = false;
      }
    }
  }

  activeBonds(): Bond[] { return this.bonds.filter(b => b.active); }

  bondsFor(moduleId: string): Bond[] {
    return this.activeBonds().filter(
      b => b.moduleA === moduleId || b.moduleB === moduleId
    );
  }

  get count(): number { return this.activeBonds().length; }
}
