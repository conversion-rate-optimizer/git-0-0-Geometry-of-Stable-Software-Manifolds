# Kleene's Fixed Point Theorem

The **constructive** fixed-point theorem: when Scott-continuity holds, the Kleene chain reaches the least fixed point.

## Statement

**Theorem (Kleene).** *Let $(L, \leq, \bot)$ be a pointed DCPO and $f : L \to L$ a Scott-continuous function. Then:*

$$
\operatorname{lfp}(f) \;=\; \bigvee_{n \in \mathbb{N}} f^n(\bot),
$$

*where the **Kleene chain** $(\bot, f(\bot), f^2(\bot), \ldots)$ is defined by $f^0(\bot) = \bot$ and $f^{n+1}(\bot) = f(f^n(\bot))$.*

## Proof

**Step 1: The Kleene chain is directed (in fact, a chain).**
We show $f^n(\bot) \leq f^{n+1}(\bot)$ for all $n$ by induction.
- Base: $\bot \leq f(\bot)$ because $\bot$ is the minimum.
- Step: Assume $f^n(\bot) \leq f^{n+1}(\bot)$. By monotonicity (which Scott-continuity implies), $f(f^n(\bot)) \leq f(f^{n+1}(\bot))$, i.e., $f^{n+1}(\bot) \leq f^{n+2}(\bot)$.

So the Kleene chain is non-decreasing; any non-decreasing sequence is directed.

**Step 2: The supremum exists.**
Because $L$ is directed-complete, $\alpha := \bigvee_n f^n(\bot)$ exists.

**Step 3: $\alpha$ is a fixed point.**
By Scott-continuity:

$$
f(\alpha) \;=\; f\left(\bigvee_n f^n(\bot)\right) \;=\; \bigvee_n f(f^n(\bot)) \;=\; \bigvee_n f^{n+1}(\bot).
$$

The last supremum equals $\alpha$: the sequences $\{f^n(\bot)\}_{n \geq 0}$ and $\{f^{n+1}(\bot)\}_{n \geq 0}$ are eventually the same and monotone, so they have the same supremum.

Hence $f(\alpha) = \alpha$.

**Step 4: $\alpha$ is the least fixed point.**
Let $\beta$ be any fixed point: $f(\beta) = \beta$. Then $\bot \leq \beta$, and by induction $f^n(\bot) \leq \beta$ for all $n$ (applying monotonicity and $f(\beta) = \beta$). Hence $\alpha = \bigvee_n f^n(\bot) \leq \beta$.

$\blacksquare$

## Why Scott-continuity is needed

Monotonicity alone is not enough to guarantee the Kleene chain reaches the lfp. Here is a counter-example.

**Counter-example.** Let $L = \mathbb{N} \cup \{\infty\}$ with the usual order, and $f(n) = n + 1$ for $n < \infty$, $f(\infty) = \infty$. $L$ is a complete lattice (in fact a chain). $f$ is monotone. The Kleene chain from $\bot = 0$ is $0, 1, 2, 3, \ldots$, which is strictly increasing. Its supremum is $\infty$. But $f(\infty) = \infty \neq \bigvee_n f^n(0) = \infty$... actually that works.

A better counter-example: let $L = \{0\} \cup \{1, 2, \ldots\} \cup \{\omega, \omega + 1\}$ with $0 < 1 < 2 < \cdots < \omega < \omega + 1$, and define $f(n) = n+1$ for $n \in \mathbb{N}$, $f(\omega) = \omega + 1$, $f(\omega + 1) = \omega + 1$. $f$ is monotone. The Kleene chain from $0$ has supremum $\omega$. But $f(\omega) = \omega + 1 \neq \omega$, so the supremum of the Kleene chain is *not* a fixed point. The true $\operatorname{lfp}(f) = \omega + 1$.

The failure: $f$ is not Scott-continuous, because $f(\bigvee_n n) = f(\omega) = \omega + 1$ but $\bigvee_n f(n) = \bigvee_n (n+1) = \omega$.

## Transfinite extension

For monotone-but-not-Scott-continuous $f$, define transfinite iteration:

- $f^0(\bot) = \bot$.
- $f^{\alpha + 1}(\bot) = f(f^\alpha(\bot))$.
- $f^\lambda(\bot) = \bigvee_{\alpha < \lambda} f^\alpha(\bot)$ for limit ordinals $\lambda$.

**Theorem.** For monotone $f$ on a complete lattice, there exists an ordinal $\alpha^\star$ (with $|\alpha^\star| \leq |L|^+$) such that $f^{\alpha^\star + 1}(\bot) = f^{\alpha^\star}(\bot) = \operatorname{lfp}(f)$.

In the counter-example above, $\alpha^\star = \omega + 1$, and $f^{\omega + 1}(\bot) = \omega + 1$ is the fixed point.

## Computational significance

- **Scott-continuity = countable iteration.** Your `while changed: x = f(x)` loop works.
- **Monotone but not Scott-continuous = transfinite iteration.** Your loop may run forever even when a fixed point exists.
- **Not monotone = no guarantee at all.** Your loop may oscillate.

Datalog, reactive systems, abstract interpretation on finite-height lattices: Scott-continuous. Their engines are correct.

Non-monotone rule systems, constraint engines with negation or retraction: not monotone. Their engines need `maxIter` caps.

## Relation to computability

Kleene's theorem is why the **Kleene fixed-point combinator** (and the Y combinator) work. When you write:

```haskell
fix f = let x = f x in x
```

you are computing the lfp of $f$ in the domain of partial values ordered by information content — a Scott-continuous operation on a pointed DCPO. This is the semantic foundation of recursion in Haskell, OCaml, and every other functional language.
