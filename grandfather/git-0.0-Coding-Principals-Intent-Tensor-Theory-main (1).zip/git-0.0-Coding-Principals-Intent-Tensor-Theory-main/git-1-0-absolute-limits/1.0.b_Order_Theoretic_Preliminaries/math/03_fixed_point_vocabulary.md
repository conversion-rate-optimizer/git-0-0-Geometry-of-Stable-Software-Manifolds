# Fixed Point Vocabulary

Distinguishing the several notions of "fixed" that get conflated in informal discussion.

## Fixed points proper

An element $x \in L$ is a **fixed point** of $f : L \to L$ iff

$$
f(x) \;=\; x.
$$

The set of all fixed points is $\operatorname{Fix}(f) = \{x \in L : f(x) = x\}$.

## Pre- and post-fixed points

- $x$ is a **pre-fixed point** of $f$ iff $f(x) \leq x$.
- $x$ is a **post-fixed point** of $f$ iff $x \leq f(x)$.

Note that $f(x) = x$ iff $x$ is both pre- and post-fixed. The terminology comes from thinking of $f$ as moving things: at a pre-fixed point, $f$ moves $x$ downward (or keeps it); at a post-fixed point, $f$ moves $x$ upward (or keeps it).

## The Knaster–Tarski characterizations

For monotone $f$ on a complete lattice $L$:

$$
\operatorname{lfp}(f) \;=\; \bigwedge \{x \in L : f(x) \leq x\} \;=\; \bigwedge \{\text{pre-fixed points}\}.
$$

$$
\operatorname{gfp}(f) \;=\; \bigvee \{x \in L : x \leq f(x)\} \;=\; \bigvee \{\text{post-fixed points}\}.
$$

These are the **universal characterizations**: the least fixed point is the "tightest" pre-fixed point; the greatest is the "loosest" post-fixed point.

## Induction principles

From the Knaster–Tarski characterization come two induction principles:

**lfp-induction (Park).** For monotone $f$ and any $x \in L$:
$$
f(x) \leq x \;\Rightarrow\; \operatorname{lfp}(f) \leq x.
$$

*Use:* to prove $\operatorname{lfp}(f) \leq x$, show that $x$ is a pre-fixed point.

**gfp-coinduction.** For monotone $f$ and any $x \in L$:
$$
x \leq f(x) \;\Rightarrow\; x \leq \operatorname{gfp}(f).
$$

*Use:* to prove $x \leq \operatorname{gfp}(f)$, show that $x$ is a post-fixed point.

These are the fundamental proof techniques for reasoning about recursive definitions.

## Approximants

For Scott-continuous $f$ on a pointed DCPO:

- $f^n(\bot)$ is the **$n$-th approximant** of $\operatorname{lfp}(f)$.
- $f^0(\bot) = \bot$ is the "zeroth approximant" — knowing nothing.
- The sequence $\bot \leq f(\bot) \leq f^2(\bot) \leq \cdots$ is called the **Kleene chain**.
- $\operatorname{lfp}(f) = \bigvee_n f^n(\bot)$.

The Kleene chain is what an iterative Datalog evaluator, a constraint propagator, or a reactive graph actually computes.

## Transfinite iteration

For monotone but non-continuous $f$, the Kleene chain may not reach $\operatorname{lfp}(f)$ in countably many steps. The proper construction is **transfinite iteration**:

- $f^0(\bot) = \bot$.
- $f^{\alpha+1}(\bot) = f(f^\alpha(\bot))$.
- $f^\lambda(\bot) = \bigvee_{\alpha < \lambda} f^\alpha(\bot)$ for limit ordinals $\lambda$.

The iteration stabilizes at some ordinal $\alpha^\star \leq |L|^+$, and $f^{\alpha^\star}(\bot) = \operatorname{lfp}(f)$.

In practice: transfinite iteration is a proof device, not an algorithm. If your operator needs it, it is not computable.

## Fixed-point operators as type-level structure

In programming-language theory, the fixed-point operator is often written as:

$$
\text{fix} : (L \to L) \to L, \qquad \text{fix}(f) = \operatorname{lfp}(f)
$$

with type in Haskell:

```haskell
fix :: (a -> a) -> a
fix f = let x = f x in x
```

This works for recursive *values*, using lazy evaluation. For recursive *functions*, there is

```haskell
fix :: (a -> a) -> a
fix f = f (fix f)

-- Used as:
factorial = fix (\rec n -> if n == 0 then 1 else n * rec (n - 1))
```

This is the **Y combinator** of the lambda calculus, implementing recursion without explicit names. It is the untyped programming-language dual of the Knaster–Tarski theorem.
