# Dependent Type Theory

The type system where types can depend on values.

## Dependent function types (Π-types)

The type $\prod_{x : A} B(x)$ is the type of functions that, given an $a : A$, return a value of type $B(a)$.

Notation: `(x : A) -> B x` in Idris/Lean, or `forall x : A, B x` in Rocq.

**Examples:**
- `(n : Nat) -> Vec n Int` — given a natural number, produce a vector of exactly that length.
- `(A : Type) -> A -> A` — the polymorphic identity function, taking the type as an argument.
- `(A : Type) -> (B : Type) -> A -> B -> A` — the constant function.

**As propositions:** $\prod_{x : A} P(x)$ is $\forall x : A.\; P(x)$.

## Dependent pair types (Σ-types)

The type $\sum_{x : A} B(x)$ is the type of pairs $(a, b)$ where $a : A$ and $b : B(a)$.

Notation: `(x : A) ** B x` in Idris, or `{x : A & B x}` in Rocq.

**Examples:**
- `(n : Nat) ** Vec n Int` — a vector of *some* length, bundled with its length.
- `(f : A -> B) ** injective f` — a function bundled with a proof of its injectivity.

**As propositions:** $\sum_{x : A} P(x)$ is $\exists x : A.\; P(x)$.

## Inductive types

An inductive type is defined by a list of **constructors**, each specifying how values of that type can be built.

```lean
inductive List (A : Type) where
  | nil  : List A
  | cons : A -> List A -> List A
```

Pattern-matching gives you the **eliminator**: a way to define functions by case analysis on the constructors.

More elaborate inductive types:

```lean
-- Length-indexed vectors
inductive Vec (A : Type) : Nat -> Type where
  | nil  : Vec A 0
  | cons : A -> Vec A n -> Vec A (n + 1)
```

The type `Vec A n` literally depends on `n`. The compiler tracks length through every operation.

## Identity types (propositional equality)

Two values are propositionally equal iff the identity type $a = b$ is inhabited.

```lean
inductive Eq {A : Type} (a : A) : A -> Prop where
  | refl : Eq a a
```

The only way to construct an `Eq a b` is via `refl`, which requires `a` and `b` to be definitionally equal. However, **propositional equality can be proved by induction**, even when definitional equality is not immediate.

## Universes

Types live in a universe: `Type 0`, `Type 1`, `Type 2`, ...

`Type 0 : Type 1`, `Type 1 : Type 2`, etc. Without this hierarchy, Girard's paradox (the Russell paradox for types) would allow contradiction.

Some systems have **universe polymorphism**: functions that are polymorphic over universe levels.

## The Calculus of Inductive Constructions (CIC)

The type theory at the heart of Rocq and Lean. Features:
- Π and Σ types.
- Inductive types with full dependent pattern matching.
- Universe hierarchy with cumulativity (Rocq) or non-cumulativity (Lean 4).
- Impredicative sort `Prop` for propositions (distinguishes logical content from data).

CIC is **strongly normalizing**: every term reduces to a normal form in finitely many steps. This corresponds to consistency of the underlying logic.

## Homotopy Type Theory (HoTT)

The refinement where identity types are treated as **paths** in a higher groupoid structure.

**Univalence axiom (Voevodsky):** the identity type between types is equivalent to the type of equivalences between them:
$$
(A =_{\text{Type}} B) \simeq (A \simeq B).
$$

Consequences:
- Isomorphic structures are *equal* (eliminating "up to iso" everywhere).
- New mathematical content: identity types encode higher homotopy.

**Cubical type theory** (Cohen, Coquand, Huber, Mörtberg 2018) gives univalence a computational meaning: cubes and paths are part of the syntax.

## Why we care

Dependent types let you encode invariants directly in types:
- `sorted : (xs : List Int) -> Prop` — whether a list is sorted.
- `sort : (xs : List Int) -> (ys : List Int ** (sorted ys, permutation xs ys))` — a sort function that *returns a proof* that the output is sorted and a permutation.

The type is the specification. The term is the implementation *and* its correctness proof. Type-checking is verification.

For a dynamic-coding engine, this is the ultimate type safety — no runtime checks needed, because the compiler has verified everything statically.
