# Chapter 3 — Resonance Registry (Index-to-Index Translation)

Traditional import:
`../../utils/math`

Resonance lookup:
`Resonance.tune("MATH_VECTOR_ALPHA")`

## Protocol
1. Module registers a sub-key and callable.
2. Consumer requests by sub-key.
3. Registry resolves callable in O(1) key lookup.
4. Optional gate checks viability (`S_sel >= 1`) before invocation.

## Design note
Location path remains an OS chassis concern; identity lives in the resonance index.
