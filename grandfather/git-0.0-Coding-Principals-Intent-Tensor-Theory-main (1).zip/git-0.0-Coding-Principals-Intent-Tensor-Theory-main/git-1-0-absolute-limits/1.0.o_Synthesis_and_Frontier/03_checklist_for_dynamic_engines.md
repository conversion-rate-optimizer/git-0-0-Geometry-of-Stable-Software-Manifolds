# Checklist for Building Production Dynamic Engines

Before shipping any constraint engine, answer all of the following.

## State space

- [ ] What is my state lattice $\mathcal{S}$?
- [ ] Is it finite-height or infinite? (If infinite, plan for widening.)
- [ ] Is it a product of simpler lattices? (If so, document each component.)
- [ ] Is the lattice distributive / modular / etc.?

## Operators

- [ ] What are my derivations $D_i$? Are they monotone?
- [ ] What are my constraints $C_j$? Are they projections?
- [ ] Are any constraints retractive (can set a variable to a value contradicting a derivation)?
- [ ] If retractive: can they be stratified?

## Convergence

- [ ] Which regime am I in? (Kleene, Knaster–Tarski, Banach, none.)
- [ ] Do I have a finite convergence bound, or only a theoretical limit?
- [ ] What is my `maxIter` / timeout?
- [ ] What is my fallback when `maxIter` is exceeded?

## Priority / optimization

- [ ] Are priorities scalar or multi-level (lexicographic)?
- [ ] Is the priority system encodable as MaxSAT or WCSP?
- [ ] What is the expected cost of the optimal solution vs. a greedy solution?

## Backend choice

- [ ] Hand-rolled Kleene iteration (simple, predictable, but limited).
- [ ] Z3 / cvc5 (robust, complete, potentially slow on hard instances).
- [ ] clingo / WASP (good for combinatorial problems with multiple solutions).
- [ ] toulbar2 / UAI (good for WCSP).
- [ ] Gradient-based (good for smooth / continuous relaxations).

## Incrementality

- [ ] Do I need incremental updates (responsiveness) or full rebuilds (throughput)?
- [ ] Which technique? (SAC, DBSP, differential dataflow.)
- [ ] What is the typical delta size relative to full state?

## Testing

- [ ] Property tests for idempotence of constraints.
- [ ] Property tests for monotonicity of derivations.
- [ ] Regression tests for oscillation detection.
- [ ] Benchmarks at $10^2, 10^4, 10^6$ input sizes.
- [ ] Adversarial tests (hand-crafted hard instances).

## Observability

- [ ] Log the Kleene chain on convergence failure.
- [ ] Emit constraint violation reports with priority levels.
- [ ] Track wall-clock time per iteration.
- [ ] Track memory usage per iteration.
- [ ] Expose a `--explain` mode that traces a specific variable's resolution.

## Documentation

- [ ] Document the state lattice in user-facing prose.
- [ ] Document each constraint's priority and meaning.
- [ ] Document convergence guarantees and failure modes.
- [ ] Provide examples of known-convergent and known-divergent inputs.

## Operational

- [ ] `--version` reports the engine version and backend.
- [ ] `--validate` runs a quick self-test.
- [ ] `--benchmark` produces a performance report.
- [ ] `--export-smt2` / `--export-clingo` for debugging with standard solvers.

## Cosmic-ceiling awareness

- [ ] I accept that halting-undecidability means `maxIter` is necessary.
- [ ] I accept that Rice's theorem means static analyses are incomplete.
- [ ] I accept that NP-hardness means worst-case performance can be exponential.
- [ ] I accept that Gödel's theorem means my proofs rest on external axioms.
- [ ] I document these acceptances in the user guide.

---

## If you cannot answer "yes" to all of these

Your engine is not ready for production. Either make the answer yes, or explicitly document the gap as a known limitation.

Honest engineering in the face of the ceilings means treating the math not as a decoration but as the governing specification.
