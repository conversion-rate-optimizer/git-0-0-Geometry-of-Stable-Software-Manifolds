# The Halting Problem

Turing's undecidability theorem (1936), the foundational limit.

## Statement

**Theorem (Turing 1936).** *There is no total computable function*

$$
H : \text{Program} \times \text{Input} \to \{0, 1\}
$$

*such that $H(P, x) = 1$ iff $P$ halts on input $x$.*

## Proof

Suppose, for contradiction, such an $H$ exists. Construct a program $D$ (for *diagonal*):

```
def D(P):
    if H(P, P) == 1:
        loop forever
    else:
        halt
```

$D$ takes a program $P$ as input. It consults $H$ to determine whether $P$ halts when run on its own code $P$.

**Key question:** does $D(D)$ halt?

- **Suppose $D(D)$ halts.** Then by the definition of $D$, we took the `else` branch, so $H(D, D) = 0$. By the assumed correctness of $H$, that means $D$ does *not* halt on input $D$. Contradiction.

- **Suppose $D(D)$ does not halt.** Then by the definition of $D$, we took the `if` branch (entering the infinite loop), so $H(D, D) = 1$. By the assumed correctness of $H$, that means $D$ *does* halt on input $D$. Contradiction.

Either case leads to contradiction. Hence no such $H$ exists. $\blacksquare$

## The diagonal argument

This proof is a **diagonal argument**, structurally the same as Cantor's proof that $\mathbb{R}$ is uncountable and Gödel's proof of incompleteness.

The trick is:
1. Enumerate a space (programs).
2. Define a new object by "inverting" a proposed oracle across that enumeration.
3. Show the new object cannot exist in the space, contradicting the enumeration.

## Reductions

Many other problems are undecidable via **reduction from halting**:

- **Equivalence of programs:** "do $P_1$ and $P_2$ compute the same function?" — Reduction: if we could decide this, we could decide halting by asking "is $P$ equivalent to a program that just halts?"
- **Emptiness of the image:** "is there an input on which $P$ halts?"
- **Self-referential problems:** various fixed-point versions.

The structure is always the same: given a hypothetical decider for problem $Q$, build a program that uses it to decide halting.

## Consequences for dynamic-coding engines

You **cannot** write a function that, given an arbitrary constraint system, decides whether it will converge to a fixed point.

This is why every production constraint engine has:
- **`maxIter` caps** on iterative loops.
- **Timeouts** on solver calls.
- **`unknown` return values** from SMT solvers.

These are not bugs or limitations of current technology — they are the code-level manifestation of Turing's theorem. No amount of engineering makes them unnecessary.

## What is decidable

- **Type checking** (in decidable type systems): given a term and a type, is the term well-typed?
- **Regular expression matching:** polynomial time.
- **Termination for restricted languages:** e.g., primitive recursive functions, total functional languages like Agda.
- **Constraint satisfaction in finite domains:** NP-complete, but decidable.

The line is: **Turing completeness → undecidable halting**. Any language you can restrict below Turing-completeness (total functional languages, finite-state systems) has a decidable halting problem.

## Connection to Knaster–Tarski

Knaster–Tarski gives us: *a fixed point exists* for any monotone operator on a complete lattice. But it doesn't say we can *find it* in bounded time. Halting-undecidability is the reason: even if we know a fixed point exists, computing it may take arbitrary time.

Kleene's theorem gives us a constructive procedure under Scott-continuity, but the number of iterations isn't bounded a priori — and for non-continuous operators, the chain may be transfinite.

## Practical design principle

Given halting-undecidability:

- **Design systems so convergence is predictable.** Stratify, bound the lattice, impose time limits.
- **Accept `unknown` as a valid answer.** Don't pretend to decide everything.
- **Separate soundness from completeness.** A system that says "yes" when true and "don't know" otherwise is strictly more honest than one that guesses.

This principle governs SMT solvers, type checkers, constraint engines, and every other system that tries to tame the undecidable.
