"""
Galois connection encoded as a Python dataclass.
"""

from __future__ import annotations
from dataclasses import dataclass
from typing import Callable, TypeVar, Generic

C = TypeVar("C")
A = TypeVar("A")


@dataclass
class Galois(Generic[C, A]):
    """A Galois connection α ⊣ γ between concrete C and abstract A."""
    alpha: Callable[[C], A]
    gamma: Callable[[A], C]

    def check_adjunction(
        self,
        c: C,
        a: A,
        leq_A: Callable[[A, A], bool],
        leq_C: Callable[[C, C], bool],
    ) -> bool:
        """Check α(c) ≤_A a  ⇔  c ≤_C γ(a)."""
        return leq_A(self.alpha(c), a) == leq_C(c, self.gamma(a))


# ---------- Signs abstraction ----------
# Concrete: sets of integers (frozenset[int])
# Abstract: signs lattice

class Sign:
    BOT, NEG, ZERO, POS, NONPOS, NONNEG, NONZERO, TOP = range(8)
    NAMES = ["⊥", "<0", "=0", ">0", "≤0", "≥0", "≠0", "⊤"]


def sign_alpha(S: frozenset) -> int:
    if not S:                        return Sign.BOT
    has_neg  = any(n < 0 for n in S)
    has_zero = 0 in S
    has_pos  = any(n > 0 for n in S)
    if has_neg and has_zero and has_pos: return Sign.TOP
    if has_neg and has_zero:             return Sign.NONPOS
    if has_zero and has_pos:             return Sign.NONNEG
    if has_neg and has_pos:              return Sign.NONZERO
    if has_neg:                          return Sign.NEG
    if has_zero:                         return Sign.ZERO
    return Sign.POS


def sign_gamma(s: int) -> frozenset:
    """Toy concretization: bounded range [-100, 100]."""
    R = range(-100, 101)
    if s == Sign.BOT:     return frozenset()
    if s == Sign.TOP:     return frozenset(R)
    if s == Sign.NEG:     return frozenset(n for n in R if n < 0)
    if s == Sign.ZERO:    return frozenset({0})
    if s == Sign.POS:     return frozenset(n for n in R if n > 0)
    if s == Sign.NONPOS:  return frozenset(n for n in R if n <= 0)
    if s == Sign.NONNEG:  return frozenset(n for n in R if n >= 0)
    if s == Sign.NONZERO: return frozenset(n for n in R if n != 0)
    raise ValueError(f"Unknown sign: {s}")


signs = Galois(alpha=sign_alpha, gamma=sign_gamma)


if __name__ == "__main__":
    # Quick sanity check
    tests = [frozenset(), frozenset({0}), frozenset({1, 2, 3}),
             frozenset({-1, 1}), frozenset({0, 1, 2}), frozenset({-5, 0, 5})]
    for S in tests:
        a = signs.alpha(S)
        print(f"α({sorted(S) if S else '∅'}) = {Sign.NAMES[a]}")
