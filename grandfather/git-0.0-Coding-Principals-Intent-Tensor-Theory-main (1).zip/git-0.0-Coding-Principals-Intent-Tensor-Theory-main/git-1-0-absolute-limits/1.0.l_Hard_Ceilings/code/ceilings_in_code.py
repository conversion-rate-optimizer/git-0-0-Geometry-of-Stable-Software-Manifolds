"""
How the mathematical ceilings of dynamic computation manifest in real code.

The mapping:
  - Halting problem (Turing)   →  maxIterations caps.
  - Rice's theorem             →  static analyzers are either unsound or incomplete.
  - Cook-Levin (NP-hardness)    →  solver timeouts.
  - Gödel incompleteness        →  "unknown" / axiom dependencies.
  - Time hierarchy             →  empirical scaling hits a wall.
"""

from z3 import Solver, Int, Real, And, Or, sat, unsat, unknown
import time


def halting_ceiling_demo():
    """
    Turing: we cannot decide convergence in general.
    In code, this appears as a maxIter cap on Kleene iteration.
    """
    def possibly_non_terminating(state):
        # This rule might not have a fixed point
        if state.get("a"):
            return {"b": True}
        return {"a": not state.get("a", False)}

    def run_engine(initial, max_iter=1000):
        state = dict(initial)
        for i in range(max_iter):
            new_state = dict(state)
            new_state.update(possibly_non_terminating(state) or {})
            if new_state == state:
                return ("converged", i, state)
            state = new_state
        return ("timeout", max_iter, state)

    result = run_engine({"a": False})
    print(f"Halting demo: {result[0]} after {result[1]} iterations")
    # Might converge or might hit max_iter — we cannot decide in advance.


def nphardness_timeout_demo():
    """
    Cook-Levin: SAT is NP-complete. In practice, hard instances
    produce timeouts.
    """
    s = Solver()
    s.set("timeout", 2000)           # 2-second wall clock

    # A hard-ish SAT encoding: pigeonhole principle (n+1 pigeons in n holes).
    n = 10
    from z3 import Bool, Or, Not, AtMost
    pig = [[Bool(f"p_{i}_{j}") for j in range(n)] for i in range(n + 1)]

    # Each pigeon goes in some hole
    for i in range(n + 1):
        s.add(Or(*pig[i]))

    # No hole has two pigeons
    for j in range(n):
        for i1 in range(n + 1):
            for i2 in range(i1 + 1, n + 1):
                s.add(Or(Not(pig[i1][j]), Not(pig[i2][j])))

    start = time.time()
    result = s.check()
    elapsed = time.time() - start
    print(f"Pigeonhole (unsat): {result} after {elapsed:.2f}s")
    if result == unknown:
        print("  Timeout hit the ceiling: NP-hard in practice.")


def undecidability_unknown_demo():
    """
    Gödel / Matiyasevich: non-linear integer arithmetic is undecidable.
    The solver returns `unknown`.
    """
    s = Solver()
    s.set("timeout", 3000)

    x, y, z = Int('x'), Int('y'), Int('z')
    # Fermat's last theorem territory: x^3 + y^3 = z^3, x,y,z > 0.
    # Known to have no solutions; but proving unsat in Z3 for exponent 3
    # requires non-trivial math beyond Presburger.
    s.add(x > 0, y > 0, z > 0)
    s.add(x*x*x + y*y*y == z*z*z)

    result = s.check()
    print(f"Fermat (n=3): {result}")
    if result == unknown:
        print("  'unknown' is the mathematical ceiling manifesting in code.")


def rice_theorem_demo():
    """
    Rice: we cannot decide arbitrary semantic properties.
    Practical consequence: static analyzers are either unsound or incomplete.
    Demonstrated here by showing that a naive "will this program halt?"
    checker must fail.
    """
    def naive_halt_checker(program_text: str) -> bool:
        # Only catches 'while True: pass' explicitly; misses everything else.
        return "while True: pass" not in program_text

    # A program that halts but has a superficial 'while True' pattern:
    sneaky = "x = 0\nwhile True:\n    x += 1\n    if x > 10: break\n"
    print(f"Sneaky halting program: checker says halt={naive_halt_checker(sneaky)}")
    print("  This checker is unsound: it can't see past the syntax.")
    print("  Rice's theorem says: no checker can decide halting for all programs.")


if __name__ == "__main__":
    halting_ceiling_demo()
    print()
    nphardness_timeout_demo()
    print()
    undecidability_unknown_demo()
    print()
    rice_theorem_demo()
