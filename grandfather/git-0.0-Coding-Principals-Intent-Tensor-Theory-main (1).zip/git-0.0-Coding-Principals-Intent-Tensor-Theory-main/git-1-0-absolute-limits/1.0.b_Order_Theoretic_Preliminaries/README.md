# 1.0.b — Order-Theoretic Preliminaries

## What this covers

The algebraic objects on which every fixed-point theorem in this chapter operates:
- Partial orders (posets).
- Lattices; complete lattices.
- Monotone, Scott-continuous, and contractive functions.
- Pre-fixed points, post-fixed points, fixed points.

## Files

**Math:**
- `math/00_posets.md` — Partial orders and basic properties.
- `math/01_lattices.md` — Lattices and complete lattices.
- `math/02_monotone_continuous.md` — Monotone and Scott-continuous functions.
- `math/03_fixed_point_vocabulary.md` — Pre-, post-, and true fixed points.

**Code:**
- `code/lattice_typeclass.hs` — Haskell typeclass.
- `code/lattice_protocol.py` — Python Protocol.
- `code/lattice_trait.rs` — Rust trait.
- `code/lattice_class.ts` — TypeScript class.
- `code/examples.md` — Worked examples across languages.

## Why this matters

Every "it converges" claim in later chapters is a Knaster–Tarski or Kleene theorem applied to some lattice and some operator. If the lattice is wrong or the operator isn't monotone, nothing converges. This folder makes those prerequisites explicit.
