/**
 * 0.1_LATTICE: Weight Matrix
 * ==========================
 * W_ij — the coupling operator between modules.
 *
 * NOT a standard graph edge. It is the energy coupling strength:
 *   W_ij = cos(Ψ_i, Ψ_j)^1.35  if cos(Ψ_i, Ψ_j) > 0.16
 *   W_ij = 0                    otherwise
 *
 * The 0.16 threshold enforces interaction locality in semantic space.
 * Without it: graph = fully connected = dense noise operator = meaningless diffusion.
 * With it: finite propagation paths, real semantic neighborhoods.
 *
 * D_eff(A, B) = D₀ / (1 + Ψ_A · Ψ_B) → 0 at resonance
 */

import { LATTICE } from "../-Z_BASE/axioms";

export type IntentVector = number[];

/**
 * Dot product of two unit vectors = cosine similarity
 */
export function cosineSimilarity(a: IntentVector, b: IntentVector): number {
  if (a.length !== b.length) throw new Error("Vector dimension mismatch");
  let dot = 0;
  for (let i = 0; i < a.length; i++) dot += a[i] * b[i];
  return dot;
}

/**
 * Normalize a vector to unit length (Ψ_i = embedding / ||embedding||)
 */
export function normalize(v: IntentVector): IntentVector {
  const norm = Math.sqrt(v.reduce((s, x) => s + x * x, 0));
  if (norm < 1e-12) return v.map(() => 0);
  return v.map(x => x / norm);
}

/**
 * Non-linear coupling weight between modules A and B:
 *   W_ij = cos^1.35 if cos > threshold, else 0
 */
export function computeCoupling(
  a: IntentVector,
  b: IntentVector,
  threshold: number = LATTICE.resonance_threshold,
  exponent: number = LATTICE.coupling_exponent
): number {
  const cos = cosineSimilarity(a, b);
  if (cos <= threshold) return 0;
  return Math.pow(cos, exponent);
}

/**
 * Build the full W matrix for a set of modules.
 * Returns adjacency as Map<id, Map<id, weight>>.
 */
export function buildWeightMatrix(
  modules: Map<string, IntentVector>
): Map<string, Map<string, number>> {
  const W = new Map<string, Map<string, number>>();
  const ids = Array.from(modules.keys());

  for (const id_i of ids) {
    const row = new Map<string, number>();
    const psi_i = modules.get(id_i)!;

    for (const id_j of ids) {
      if (id_i === id_j) continue;
      const psi_j = modules.get(id_j)!;
      const w = computeCoupling(psi_i, psi_j);
      if (w > 0) row.set(id_j, w);
    }
    W.set(id_i, row);
  }
  return W;
}

/**
 * Effective distance (Topological Proximity Collapse — Axiom II):
 *   D_eff(A, B) = D₀ / (1 + Ψ_A · Ψ_B)
 *
 * Collapses to 0 at perfect resonance. This is the "non-Euclidean import."
 */
export function effectiveDistance(
  a: IntentVector,
  b: IntentVector,
  D0: number = 1.0
): number {
  const cos = cosineSimilarity(a, b);
  return D0 / (1 + cos);
}

/**
 * Degree of a node: d_i = Σ_j W_ij
 */
export function nodeDegree(nodeId: string, W: Map<string, Map<string, number>>): number {
  const neighbors = W.get(nodeId);
  if (!neighbors) return 0;
  let d = 0;
  for (const w of neighbors.values()) d += w;
  return d;
}

/**
 * Normalized weight for diffusion:
 *   W_ij / d_i
 */
export function normalizedWeight(
  nodeId: string,
  neighborId: string,
  W: Map<string, Map<string, number>>
): number {
  const d = nodeDegree(nodeId, W);
  if (d < 1e-12) return 0;
  return (W.get(nodeId)?.get(neighborId) ?? 0) / d;
}
