# Herbrand Semantics

The syntactic model theory that makes logic programming computable.

## Signatures and terms

A **first-order signature** $\Sigma = (\mathcal{F}, \mathcal{P})$ consists of:
- $\mathcal{F}$: a set of **function symbols**, each with an arity $\geq 0$.
- $\mathcal{P}$: a set of **predicate symbols**, each with an arity $\geq 0$.

Function symbols of arity $0$ are **constants**.

A **term** over $\Sigma$ and variables $V$ is:
- A variable $v \in V$.
- A constant $c \in \mathcal{F}$ (arity $0$).
- $f(t_1, \ldots, t_n)$ where $f \in \mathcal{F}$ has arity $n$ and $t_i$ are terms.

A **ground term** is a term with no variables.

## Herbrand universe and base

The **Herbrand universe** $U_\Sigma$ is the set of all ground terms over $\Sigma$.

For Datalog (no function symbols of arity $\geq 1$), $U_\Sigma$ is just the set of constants — a finite set.

The **Herbrand base** $B_\Sigma$ is the set of ground atoms: $\{p(t_1, \ldots, t_n) : p \in \mathcal{P},\; t_i \in U_\Sigma\}$.

For Datalog with $|\mathcal{F}| = c$ constants and predicates of max arity $k$, $|B_\Sigma| \leq |\mathcal{P}| \cdot c^k$ — polynomial in the number of constants.

## Interpretations

An **interpretation** $I \subseteq B_\Sigma$ is a set of ground atoms declared true. The power set $2^{B_\Sigma}$ is ordered by inclusion:

$$
(2^{B_\Sigma}, \subseteq)
$$

is a complete lattice with $\top = B_\Sigma$, $\bot = \emptyset$.

## Ground instances of rules

For a rule $r$: $h \leftarrow b_1, \ldots, b_k$ and a ground substitution $\sigma : V \to U_\Sigma$, the **ground instance** $r\sigma$ replaces every variable $v$ with $\sigma(v)$. A rule has finitely many ground instances in Datalog (because $U_\Sigma$ is finite).

**Definition.** An interpretation $I$ is a **model** of a Datalog program $P$ iff for every ground instance $h\sigma \leftarrow b_1\sigma, \ldots, b_k\sigma$ of every rule in $P$: if $\{b_1\sigma, \ldots, b_k\sigma\} \subseteq I$, then $h\sigma \in I$.

## The minimal-model property

**Theorem.** The intersection of two models of $P$ is a model of $P$.

**Corollary.** Every Datalog program has a **unique minimal model** (intersection of all models) — a least fixed point in the power-set lattice.

This corollary is the reason Datalog has a well-defined declarative semantics: there is no ambiguity about which interpretation is "the meaning" of the program.

## Closed-world assumption

Herbrand semantics embodies the **closed-world assumption (CWA)**:

> *If a ground atom is not in the minimal model, it is assumed false.*

This is what makes Datalog useful for database querying. Under open-world semantics (common in description logic), "not known to be true" is distinct from "false" — and minimal-model semantics fails.

For the rest of this section, we use CWA implicitly.

## Example

Program $P$:
```
parent(alice, bob).
parent(bob, carol).
ancestor(X, Y) :- parent(X, Y).
ancestor(X, Y) :- parent(X, Z), ancestor(Z, Y).
```

- Constants: $\{\text{alice}, \text{bob}, \text{carol}\}$.
- Herbrand universe: $U = \{\text{alice}, \text{bob}, \text{carol}\}$.
- Herbrand base: all ground atoms over predicates $\text{parent}/2$ and $\text{ancestor}/2$. That's $2 \cdot 3^2 = 18$ atoms.
- Minimal model: $\{\text{parent(alice, bob)}, \text{parent(bob, carol)}, \text{ancestor(alice, bob)}, \text{ancestor(bob, carol)}, \text{ancestor(alice, carol)}\}$.

The minimal model has 5 atoms out of 18 possible. Every ground atom not in it is, by CWA, false (e.g., $\text{ancestor(carol, alice)}$ is false).

## Beyond Datalog

If we allow function symbols of arity $\geq 1$ (full Prolog), then $U_\Sigma$ is infinite, $B_\Sigma$ is infinite, and the minimal model may be infinite. The Kleene iteration $T_P^n(\emptyset)$ still converges (as a limit) to the minimal model, but termination of individual queries becomes undecidable.

This is the main reason Datalog restricts to function-free terms: decidability and PTIME complexity.
