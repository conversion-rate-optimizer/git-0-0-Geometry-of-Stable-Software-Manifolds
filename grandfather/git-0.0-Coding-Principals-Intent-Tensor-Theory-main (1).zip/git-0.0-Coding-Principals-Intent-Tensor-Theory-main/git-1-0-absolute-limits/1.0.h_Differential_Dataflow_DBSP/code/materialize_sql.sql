-- Materialize / Feldera SQL examples.
-- Every view below is maintained incrementally via DBSP primitives.

-- 1. Simple selection
CREATE SOURCE orders (id INT, amount DECIMAL, customer TEXT)
    FROM KAFKA BROKER 'localhost:9092' TOPIC 'orders';

CREATE MATERIALIZED VIEW high_value_orders AS
SELECT * FROM orders WHERE amount > 1000;

-- 2. Join
CREATE SOURCE customers (id INT, name TEXT, tier TEXT)
    FROM KAFKA BROKER 'localhost:9092' TOPIC 'customers';

CREATE MATERIALIZED VIEW premium_orders AS
SELECT o.*, c.name, c.tier
FROM   orders o
JOIN   customers c ON o.customer = c.id
WHERE  c.tier = 'premium';

-- 3. Aggregation
CREATE MATERIALIZED VIEW total_per_customer AS
SELECT customer, SUM(amount) AS total, COUNT(*) AS n_orders
FROM   orders
GROUP BY customer;

-- 4. Recursive view (transitive closure)
CREATE SOURCE edges (src INT, dst INT)
    FROM KAFKA BROKER 'localhost:9092' TOPIC 'edges';

CREATE MATERIALIZED VIEW reachable AS
WITH RECURSIVE path(src, dst) AS (
    SELECT src, dst FROM edges
  UNION
    SELECT e.src, p.dst FROM edges e JOIN path p ON e.dst = p.src
)
SELECT * FROM path;

-- 5. Window-based aggregation
CREATE MATERIALIZED VIEW hourly_revenue AS
SELECT
    date_trunc('hour', ts) AS hour,
    SUM(amount) AS revenue
FROM   orders
GROUP BY date_trunc('hour', ts);

-- All views above maintain themselves as new deltas arrive from Kafka.
-- Latency is typically sub-second; throughput is millions of rows/sec.
