//! Datalog via the `crepe` crate in Rust.
//! Rules are compiled at build time into efficient semi-naive iteration.
//!
//! Add to Cargo.toml:
//!   crepe = "0.1"

use crepe::crepe;

crepe! {
    @input
    struct Edge(i32, i32);

    @output
    struct Path(i32, i32);

    Path(x, y) <- Edge(x, y);
    Path(x, y) <- Edge(x, z), Path(z, y);
}

fn main() {
    let mut runtime = Crepe::new();
    runtime.extend(vec![
        Edge(1, 2),
        Edge(2, 3),
        Edge(3, 4),
        Edge(4, 5),
    ]);

    let (paths,) = runtime.run();
    let mut sorted: Vec<_> = paths.into_iter().collect();
    sorted.sort_by_key(|p| (p.0, p.1));
    for Path(a, b) in sorted {
        println!("path({}, {})", a, b);
    }
}
