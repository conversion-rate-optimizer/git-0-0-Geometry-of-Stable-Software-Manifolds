"""
Python Protocol for lattices.

Type hints use : (colon), which plays the role of :: in Haskell and
∈ in mathematics. The structural typing of Protocol captures the
algebraic signature of a lattice without forcing inheritance.
"""

from __future__ import annotations
from typing import Protocol, TypeVar, Callable, FrozenSet, Generic, Iterable, runtime_checkable
from abc import abstractmethod

A = TypeVar("A")


@runtime_checkable
class Lattice(Protocol[A]):
    """
    The algebraic structure (L, ≤, ∨, ∧, ⊥, ⊤).
    Any class providing these methods is-a Lattice by structural subtyping.
    """

    @abstractmethod
    def bottom(self) -> A: ...
    @abstractmethod
    def top(self) -> A: ...
    @abstractmethod
    def join(self, x: A, y: A) -> A: ...
    @abstractmethod
    def meet(self, x: A, y: A) -> A: ...
    @abstractmethod
    def leq(self, x: A, y: A) -> bool: ...


# ---------- Example 1: Boolean lattice ----------
class BoolLattice:
    def bottom(self) -> bool: return False
    def top(self) -> bool: return True
    def join(self, x: bool, y: bool) -> bool: return x or y
    def meet(self, x: bool, y: bool) -> bool: return x and y
    def leq(self, x: bool, y: bool) -> bool: return (not x) or y


# ---------- Example 2: Power-set lattice (unbounded) ----------
class PowerSetLattice(Generic[A]):
    def bottom(self) -> FrozenSet[A]: return frozenset()
    def top(self) -> FrozenSet[A]:
        raise NotImplementedError("Unbounded Set has no top element.")
    def join(self, x: FrozenSet[A], y: FrozenSet[A]) -> FrozenSet[A]: return x | y
    def meet(self, x: FrozenSet[A], y: FrozenSet[A]) -> FrozenSet[A]: return x & y
    def leq(self, x: FrozenSet[A], y: FrozenSet[A]) -> bool: return x <= y


# ---------- The fundamental fixed-point function ----------
def lfp(f: Callable[[A], A], start: A, max_iter: int = 10_000) -> A:
    """
    Kleene iteration: S_{n+1} = f(S_n) from start until stable.

    For finite-height lattices, this converges. For infinite-height lattices
    with Scott-continuous f, this converges to lfp(f) in countably many steps.
    For non-monotone f, this may oscillate — hence max_iter.

    Raises RuntimeError if max_iter is exceeded (the "conflicting intents"
    case from Paper 1 §13.2).
    """
    x = start
    for _ in range(max_iter):
        x_next = f(x)
        if x_next == x:
            return x
        x = x_next
    raise RuntimeError(f"No fixed point reached after {max_iter} iterations — "
                       "operator may not be monotone or lattice has infinite ascending chains.")


# ---------- Example usage ----------
if __name__ == "__main__":
    # Compute the transitive closure of a relation as lfp over sets of edges
    L = PowerSetLattice[tuple]()
    edges = frozenset({(1, 2), (2, 3), (3, 4)})

    def close(R: FrozenSet[tuple]) -> FrozenSet[tuple]:
        return R | frozenset((a, d) for (a, b) in R for (c, d) in R if b == c)

    # Start from edges; compute transitive closure as lfp.
    transitive = lfp(close, edges)
    print(f"Transitive closure: {sorted(transitive)}")
    # [(1, 2), (1, 3), (1, 4), (2, 3), (2, 4), (3, 4)]
