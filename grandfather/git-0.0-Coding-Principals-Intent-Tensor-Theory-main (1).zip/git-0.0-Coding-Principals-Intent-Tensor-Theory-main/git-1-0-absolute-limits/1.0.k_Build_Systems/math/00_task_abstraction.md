# The Task Abstraction

Build systems unified as fixed-point computations over a store.

## The core type

A **task** describing how to compute a value given a way to fetch dependencies:

$$
\text{Task}\, c\, k\, v \;\coloneqq\; \forall f.\; c\, f \Rightarrow (k \to f\, v) \to f\, v.
$$

- $k$ — type of keys (filenames, cell references, target names).
- $v$ — type of values (file contents, cell values, compiled outputs).
- $f$ — the **effect** in which dependencies are fetched. Captures the computation's capabilities.
- $c$ — a *constraint* on $f$: what operations the task is allowed to use on $f$.

In Haskell:

```haskell
type Task c k v = forall f. c f => (k -> f v) -> f v
```

The task receives a "fetch" function $k \to f\,v$ and produces an $f\,v$ (a value in the effect). How the task uses fetch determines what dependencies it has.

## Applicative tasks

$c = \text{Applicative}$: tasks can combine results but **cannot use fetched values to decide which other keys to fetch**.

Dependencies are **statically determined** — known before the computation runs.

**Example systems:** Make, Excel (without INDIRECT), Ninja.

## Monadic tasks

$c = \text{Monad}$: fetched values can influence further fetches.

Dependencies are **dynamically computed** — they may depend on the contents of already-fetched values.

**Example systems:** Shake, Nix (with `import-from-derivation`), Bazel with late-binding rules.

## Selective tasks

$c = \text{Selective}$ (between Applicative and Monad): conditional dependencies without full monadic power. Enables static analysis while allowing some dynamism.

**Example systems:** Dune (OCaml build tool).

## Why the distinction matters

- **Applicative** — fully static dependency graphs. Can pre-compute order, optimize aggressively, parallelize.
- **Monadic** — maximum flexibility but dependencies emerge dynamically. Harder to analyze, but captures real-world needs (e.g., "read this config to decide what to build").
- **Selective** — middle ground.

Modern build systems are increasingly monadic because real-world codebases have dynamic structure (generated code, config-dependent targets).

## The build function

A build system is a function

$$
\text{build} : \text{Tasks}\, c\, k\, v \to k \to \text{Store}\, i\, k\, v \to \text{Store}\, i\, k\, v
$$

Given a collection of tasks (one per key), a target key, and an initial store, produce an updated store in which the target and all transitive dependencies are up-to-date.

Here $i$ is a **persistent information** type the build system maintains across runs (e.g., cache keys, modification times, content hashes).

## Correctness

**Definition (Correctness).** `build T k s = s'` iff:
1. $s'$ contains up-to-date values for $k$ and all its transitive dependencies under $T$.
2. The values in $s'$ satisfy: $\text{getValue}(s', k') = T(k') \circ \text{getValue}(s')$ for each relevant $k'$.

**Definition (Minimality).** The build only re-executes tasks whose dependencies have actually changed.

**Theorem (Mokhov, Mitchell, Peyton Jones).** *Every well-known build system (Make, Ninja, Shake, Excel, Bazel, Buck, Nix, Pluto) instantiates this abstraction; each makes a principled choice of rebuilder and scheduler.*

## Fixed-point interpretation

The build is the least fixed point of the following process:
- Start with the store $s$.
- Whenever a task's declared output differs from the store's current value, update it.
- Repeat until no changes.

For applicative tasks, the fixed point is reached in one topological pass. For monadic tasks, dynamic discovery of new dependencies may require multiple passes (which is why monadic schedulers need "suspending" or "restarting" variants).

## Haskell concrete example (Shake)

```haskell
import Development.Shake

main :: IO ()
main = shakeArgs shakeOptions $ do
  want ["hello.o"]

  "*.o" %> \out -> do
    let src = out -<.> "c"
    need [src]                         -- fetch dependency (monadic)
    cmd_ "gcc" "-c" src "-o" out
```

`need` in Shake is the `fetch` operation. Shake is a *monadic* system — `need` can be called dynamically after previous `need` calls.

## Why this is in the chapter

The build function is *the* productized realization of "declare dependencies, system resolves." Every modern developer uses a build system daily. The paper by Mokhov et al. unified this apparent chaos into one abstract equation — making build systems a first-class instance of the dynamic-computation framework.

For the ITT multi-substrate engine, the natural formulation is: each file type is a task with dependencies on other file types' contents. The build is the cross-substrate fixed point. This is directly the generalization discussed in `02_multi_substrate_extension.md`.
